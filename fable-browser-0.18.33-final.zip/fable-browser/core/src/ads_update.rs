//! Automatic updates of the runtime ad list (`rules/ads.txt`).
//!
//! There is no manual update and no UI for this: the sources are built in
//! (EasyList and EasyPrivacy, the community lists at easylist.to), and the
//! shells fetch them on startup when the list is a week old. The core has
//! no HTTP client on purpose (it builds offline), so the shells fetch: each
//! hands its downloads to [`apply_update`], which extracts the domains,
//! swaps the list in atomically, and stamps the time. A bad download changes
//! nothing: the old list stays active and the next startup tries again.
//!
//! The lists are filter lists, not domain lists, so [`parse_filter`]
//! extracts only whole-domain blocks: `||domain^` rules (a leading `*.`
//! is the same domain under the blocker's suffix matching), plain domain
//! lines as in `ads.txt`, minus `@@` exceptions. It skips what a domain
//! list cannot express: path rules (`||domain/path`), site-conditional
//! rules (`$domain=...`), first-party-only rules (`$~third-party`),
//! `badfilter`, and everything cosmetic (`##`, URL patterns, `&param=`).
//! The blocker only blocks third-party requests anyway, so a bare
//! `||domain^` and a `$third-party` one mean the same thing here.
//!
//! The last successful update is `ads_updated_at` (Unix seconds) and the
//! active list's size is `ads_domains`; both are written by the core only
//! and live in the profile for inspection (there is no panel for them).

use std::io::Write;
use std::path::Path;
use std::time::{SystemTime, UNIX_EPOCH};

/// How often the list may be re-fetched: once a week at most. (EasyList
/// itself suggests four days; a week keeps the traffic down for a browser
/// that fetches two lists.)
pub const UPDATE_INTERVAL_SECS: u64 = 7 * 24 * 60 * 60;
/// The community lists to fetch, in order. Both were live at easylist.to
/// when 0.18.14 was built (EasyList ~2 MB, EasyPrivacy under 1 MB).
pub const SOURCES: &[&str] = &[
    "https://easylist.to/easylist/easylist.txt",
    "https://easylist.to/easylist/easyprivacy.txt",
];
/// At most this many bytes of filter text per update: the shells cap each
/// source at 8 MiB, so two sources can never exceed this.
pub const MAX_FILTER_BYTES: usize = 16 * 1024 * 1024;
/// The setting holding the last successful update, as Unix seconds.
pub const UPDATED_AT_KEY: &str = "ads_updated_at";
/// The setting holding the active list's domain count.
pub const DOMAINS_KEY: &str = "ads_domains";

pub fn now_secs() -> u64 {
    SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0)
}

fn parse_updated_at(value: &str) -> u64 {
    value.parse::<u64>().unwrap_or(0)
}

/// 1 when ad blocking is on and the list is older than the interval (or was
/// never updated). The pure half, so tests need no clock or store. Blocking
/// off means no fetch at all: the update only serves the blocker.
pub fn due_with(ads_on: bool, last: u64, now: u64) -> bool {
    ads_on && (last == 0 || now.saturating_sub(last) >= UPDATE_INTERVAL_SECS)
}

/// 1 when the shell should fetch now.
pub fn update_due() -> bool {
    due_with(
        crate::blocker::ads_enabled(),
        parse_updated_at(&crate::store::setting_get(UPDATED_AT_KEY)),
        now_secs(),
    )
}

/// The sources to fetch, one URL per line.
pub fn update_sources() -> String {
    SOURCES.join("\n")
}

/// The active list's domain count.
pub fn domain_count() -> u64 {
    crate::ad_list::active().domain_count() as u64
}

/// One filter line's domain, if it is a whole-domain block (or exception).
/// `allow` is an `@@` exception: it takes a domain out of the list.
fn filter_domain(line: &str) -> Option<(bool, String)> {
    let mut text = line.trim();
    if text.is_empty() || text.starts_with('!') || text.starts_with('[') {
        return None;
    }
    let mut allow = false;
    if let Some(rest) = text.strip_prefix("@@") {
        allow = true;
        text = rest;
    }
    if let Some(rest) = text.strip_prefix("||") {
        let caret = rest.find('^')?;
        let domain = &rest[..caret];
        let opts = &rest[caret + 1..];
        if !opts.is_empty() {
            // Only plain options (e.g. $third-party, $script, $document):
            // anything conditional ($domain=, $~third-party) or a modifier
            // ($redirect=, $csp=, $removeparam=) is not a domain block, and
            // $badfilter cancels another rule rather than blocking.
            let opts = opts.strip_prefix('$')?;
            if opts.contains('=') || opts.contains('~') || opts.split(',').any(|o| o == "badfilter") {
                return None;
            }
        }
        let domain = domain.strip_prefix("*.").unwrap_or(domain);
        if domain.contains('*') {
            return None;
        }
        let domain = domain.to_ascii_lowercase();
        if !crate::ad_list::valid_domain(&domain) {
            return None;
        }
        return Some((allow, domain));
    }
    // A plain domain line, as in ads.txt; anything else (cosmetic rules,
    // URL patterns) is not a domain and is skipped.
    if !allow && crate::ad_list::valid_domain(text) {
        return Some((false, text.to_ascii_lowercase()));
    }
    None
}

/// Extract the blocked domains from filter-list text (EasyList format, or
/// plain domain lines, or both mixed), minus the `@@` exceptions. Sorted,
/// de-duplicated, or None when the text holds no usable domain at all.
pub fn parse_filter(bytes: &[u8]) -> Option<Vec<String>> {
    if bytes.len() > MAX_FILTER_BYTES {
        return None;
    }
    let text = std::str::from_utf8(bytes).ok()?.trim_start_matches('\u{feff}');
    let mut blocked: Vec<String> = Vec::new();
    let mut allowed: Vec<String> = Vec::new();
    for line in text.lines() {
        if let Some((allow, domain)) = filter_domain(line) {
            if allow {
                allowed.push(domain);
            } else {
                blocked.push(domain);
            }
        }
    }
    blocked.sort_unstable();
    blocked.dedup();
    allowed.sort_unstable();
    allowed.dedup();
    if blocked.is_empty() || blocked.len() > crate::ad_list::MAX_DOMAINS {
        return None;
    }
    let domains: Vec<String> = blocked.into_iter().filter(|d| allowed.binary_search(d).is_err()).collect();
    if domains.is_empty() {
        return None;
    }
    Some(domains)
}

/// Validate `bytes` as a filter list, install the extracted domains as the
/// profile override in `dir`, and stamp the time. Returns the new domain
/// count, or -1 when the download is not a usable list: the active list is
/// untouched then.
pub fn apply_update_to(dir: &str, bytes: &[u8]) -> i64 {
    let domains = match parse_filter(bytes) {
        Some(domains) => domains,
        None => return -1,
    };
    let mut serialised = String::new();
    for domain in &domains {
        serialised.push_str(domain);
        serialised.push('\n');
    }
    // The serialised list must pass the same validation the loader applies.
    let list = match crate::ad_list::AdList::parse(serialised.as_bytes()) {
        Some(list) => list,
        None => return -1,
    };
    let path = Path::new(dir).join("ads.txt");
    // Atomic: the override is only ever a complete file (a crash mid-write
    // leaves the old one, and the loader falls back to the packaged list).
    let tmp = Path::new(dir).join("ads.txt.tmp");
    let count = list.domain_count();
    if std::fs::File::create(&tmp).and_then(|mut f| f.write_all(serialised.as_bytes())).is_err() {
        let _ = std::fs::remove_file(&tmp);
        return -1;
    }
    if std::fs::rename(&tmp, &path).is_err() {
        let _ = std::fs::remove_file(&tmp);
        return -1;
    }
    // Reload from the file just written (the override wins over the packaged
    // list), then stamp the time and the count.
    if !crate::ad_list::load(dir, || None) {
        return -1;
    }
    crate::store::setting_set(UPDATED_AT_KEY, &now_secs().to_string());
    crate::store::setting_set(DOMAINS_KEY, &count.to_string());
    count as i64
}

/// The same, in the store's profile dir (-1 when there is none).
pub fn apply_update(bytes: &[u8]) -> i64 {
    let dir = crate::store::profile_dir();
    if dir.is_empty() {
        return -1;
    }
    apply_update_to(&dir, bytes)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn due_needs_blocking_on_and_a_stale_list() {
        assert!(!due_with(false, 0, 1_000_000));
        assert!(due_with(true, 0, 1_000_000));
        assert!(!due_with(true, 1_000_000, 1_000_000));
        assert!(!due_with(true, 1_000_000, 1_000_000 + UPDATE_INTERVAL_SECS - 1));
        assert!(due_with(true, 1_000_000, 1_000_000 + UPDATE_INTERVAL_SECS));
        assert!(due_with(true, 1_000_000, 1_000_000 + 8 * 24 * 60 * 60));
    }

    #[test]
    fn filter_parser_extracts_domains_and_applies_exceptions() {
        let sample = "[Adblock Plus 2.0]\n\
            ! a comment\n\
            ||ads.example^\n\
            ||track.example^$third-party\n\
            ||img.example^$script\n\
            ||doc.example^$document\n\
            ||wild.example^$third-party\n\
            ||*.star.example^\n\
            ||path.example/ads/\n\
            ||cond.example^$domain=site.example\n\
            ||badfilter.example^$badfilter\n\
            ||first.example^$~third-party\n\
            ||redir.example^$redirect=noopjs\n\
            ##.ad-banner\n\
            /ads/banner.js\n\
            plain.example\n\
            not a domain\n\
            ||gone.example^\n\
            @@||gone.example^\n";
        assert_eq!(
            parse_filter(sample.as_bytes()).unwrap(),
            ["ads.example", "doc.example", "img.example", "plain.example", "star.example", "track.example", "wild.example"]
                .iter()
                .map(|s| s.to_string())
                .collect::<Vec<_>>()
        );
    }

    #[test]
    fn filter_parser_rejects_garbage() {
        assert!(parse_filter(b"").is_none());
        assert!(parse_filter(b"! only comments\n##.ad\n").is_none());
        assert!(parse_filter(b"not a list at all\n").is_none());
        assert!(parse_filter(&[0xff]).is_none());
    }

    #[test]
    fn apply_installs_a_list_and_rejects_a_bad_one() {
        // The test list is the packaged one plus a marker, so any test that
        // reads the active list while this runs still finds its domains.
        let packaged = std::fs::read(Path::new(env!("CARGO_MANIFEST_DIR")).join("../rules/ads.txt")).unwrap();
        let mut bytes = packaged.clone();
        bytes.extend_from_slice(b"ads-update-test.example\n");
        let packaged_count = crate::ad_list::AdList::parse(&packaged).unwrap().domains.len();

        let dir = std::env::temp_dir().join(format!("fable-ads-update-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).unwrap();
        let dir = dir.to_str().unwrap();
        let count = apply_update_to(dir, &bytes);
        assert_eq!(count, (packaged_count + 1) as i64);
        assert!(crate::ad_list::active().contains(crate::hash::fnv1a_lower(b"ads-update-test.example")));
        assert_eq!(domain_count(), (packaged_count + 1) as u64);
        assert!(parse_updated_at(&crate::store::setting_get(UPDATED_AT_KEY)) > 0);
        assert_eq!(crate::store::setting_get(DOMAINS_KEY), (packaged_count + 1).to_string());
        assert!(!Path::new(dir).join("ads.txt.tmp").exists());

        // A filter-format download installs its extracted domains, on top of
        // the packaged list (a superset, so tests reading the active list
        // while this runs still find their domains).
        let mut filter = packaged.clone();
        filter.extend_from_slice(b"||filter-a.example^\n||filter-b.example^$third-party\nplain-filter.example\n");
        let count = apply_update_to(dir, &filter);
        assert_eq!(count, (packaged_count + 3) as i64);
        let mut expected = crate::ad_list::AdList::parse(&packaged).unwrap().domains;
        expected.extend(["filter-a.example", "filter-b.example", "plain-filter.example"].iter().map(|s| s.to_string()));
        expected.sort_unstable();
        let expected_text: String = expected.iter().map(|d| format!("{d}\n")).collect();
        assert_eq!(std::fs::read_to_string(Path::new(dir).join("ads.txt")).unwrap(), expected_text);
        assert!(crate::ad_list::active().contains(crate::hash::fnv1a_lower(b"filter-b.example")));

        // A bad download changes nothing: the installed list stays.
        assert_eq!(apply_update_to(dir, b"not a list at all\n"), -1);
        assert_eq!(domain_count(), (packaged_count + 3) as u64);
        assert_eq!(std::fs::read_to_string(Path::new(dir).join("ads.txt")).unwrap(), expected_text);

        // Restore the packaged list, so later tests see the list they expect.
        crate::ad_list::load("", || {
            crate::ad_list::AdList::from_file(&Path::new(env!("CARGO_MANIFEST_DIR")).join("../rules/ads.txt"))
        });
        let _ = std::fs::remove_dir_all(dir);
    }
}
