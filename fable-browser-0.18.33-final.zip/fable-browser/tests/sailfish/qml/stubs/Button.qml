import QtQuick 2.0
MouseArea {
    width: 200; height: 64
    property string text
}
