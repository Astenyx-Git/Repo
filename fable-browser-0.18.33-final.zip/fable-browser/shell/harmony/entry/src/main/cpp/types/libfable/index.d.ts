// The Rust core through fable_napi.c. Strings are UTF-8; JSON results are strings.
export const version: () => string;
export const setSystemLocale: (tag: string) => void;
export const language: () => string;
export const tr: (key: string) => string;
export const readerScript: () => string;
export const panelPage: () => string;
export const logoUri: () => string;
/** theme://name typed by the user: 1 the skin is now on (restyle, say nothing), 0 a name that is
 *  no skin (nothing changes); load nothing for either. -1 any other address. */
export const themeApply: (url: string) => number;
/** "claude" (the default), "chatgpt", "deepseek", "gemini", "grok" or "kimi". */
export const themeCurrent: () => string;
/** The skin's colours, JSON: {"name":"kimi","dark_ui":true,"ground":"#000000",...} (core/src/theme.rs). */
export const themePalette: () => string;
export const themePrivatePalette: () => string;
/** kind: 0 normal, 1 private (its own storage). iconsJson: {"host": [dataUri, width]} or "". */
export const newtabPage: (kind: number, iconsJson: string) => string;
export const sniffJs: () => string;
export const resolve: (input: string) => string;
export const shouldBlock: (url: string, page: string) => boolean;
/** The script that hides the ad boxes on a page. */
export const adblockScript: () => string;
/** True when following this URL would leave the browser for another app and the setting is on. */
export const blockExternalApp: (url: string) => boolean;
export const blockedCount: () => number;
/** True when the ad list is due a fetch: blocking is on and a week has passed. */
export const adsUpdateDue: () => boolean;
/** The update sources, one URL per line (EasyList and EasyPrivacy). */
export const adsUpdateSources: () => string;
/** Validate the download as a list and install it; the new domain count, or -1. */
export const adsUpdateApply: (data: string) => number;
export const storeOpen: (dir: string, adDomains: Uint8Array) => void;
export const settingGet: (key: string) => string;
export const settingSet: (key: string, value: string) => void;
export const settingsJson: () => string;
export const historyAdd: (url: string, title: string, wallClockMs: number) => void;
export const historyJson: (query: string, limit: number) => string;
export const historyClear: () => boolean;
/** null: the request is the shell's to answer. */
export const panelQuery: (name: string, arg: string, tab: number) => string | null;
export const parseIpReply: (body: string, source: string) => string;
export const deviceInfo: (extras: string) => string;
export const systemInfo: (extras: string) => string;
export const jsonString: (text: string) => string;
export const sniffNote: (tab: number, url: string, hint: string) => boolean;
export const sniffNoteScan: (tab: number, json: string) => number;
export const sniffCount: (tab: number) => number;
export const sniffJson: (tab: number) => string;
export const sniffClear: (tab: number) => void;
// The session snapshot ("restore tabs on start"); sessionSave and the bookmarks go through panelQuery.
export const sessionCount: () => number;
export const sessionActive: () => number;
export const sessionUrl: (index: number) => string;
export const sessionTitle: (index: number) => string;
export const tabsOpen: (nowMs: number) => number;
export const tabsActivate: (id: number, nowMs: number) => boolean;
export const tabsClose: (id: number) => boolean;
export const tabsSetSleepAfterMs: (ms: number) => void;
export const tabsCollectSleepers: (nowMs: number) => number[];
export const downloadBegin: (name: string) => number;
export const downloadFinish: (id: number, success: number) => void;
export const qrDecode: (luma: ArrayBuffer, width: number, height: number, rowStride: number, pixelStride: number) => ArrayBuffer | null;
