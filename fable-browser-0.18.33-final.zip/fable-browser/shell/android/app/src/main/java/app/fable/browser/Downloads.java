package app.fable.browser;

import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;

import java.util.HashSet;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** Keep only normal-tab IDs. The system owns transfers, files and their current status. */
final class Downloads {
    private final DownloadManager manager;
    private final SharedPreferences records;

    Downloads(Context context) {
        manager = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
        records = context.getSharedPreferences("download-records", Context.MODE_PRIVATE);
    }

    void remember(long id) {
        records.edit().putBoolean(Long.toString(id), true).apply();
    }

    String list() {
        JSONArray rows = new JSONArray();
        Set<String> missing = new HashSet<>(records.getAll().keySet());
        if (missing.isEmpty()) return "[]";
        try (Cursor c = manager.query(new DownloadManager.Query())) {
            if (c == null) return "";
            while (c.moveToNext()) {
                String id = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID));
                if (!missing.remove(id)) continue;
                int status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                String state;
                switch (status) {
                    case DownloadManager.STATUS_SUCCESSFUL: state = "done"; break;
                    case DownloadManager.STATUS_FAILED: state = "failed"; break;
                    case DownloadManager.STATUS_PAUSED: state = "paused"; break;
                    case DownloadManager.STATUS_PENDING: state = "pending"; break;
                    default: state = "active";
                }
                rows.put(new JSONObject().put("id", id).put("state", state)
                        .put("name", c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)))
                        .put("bytes", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)))
                        .put("total", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))));
            }
            if (!missing.isEmpty()) {
                SharedPreferences.Editor edit = records.edit();
                for (String id : missing) edit.remove(id);
                edit.apply();
            }
            return rows.toString();
        } catch (RuntimeException | JSONException e) {
            return "";
        }
    }

    boolean forget(String id) {
        return records.edit().remove(id).commit();
    }

    boolean open(Context context, String id) {
        if (!records.contains(id)) return false;
        try {
            long task = Long.parseLong(id);
            Uri uri = manager.getUriForDownloadedFile(task);
            if (uri == null) return false;
            String mime = manager.getMimeTypeForDownloadedFile(task);
            context.startActivity(new Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime == null ? "*/*" : mime)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION));
            return true;
        } catch (RuntimeException e) {
            return false;
        }
    }
}
