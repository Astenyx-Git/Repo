(function () { throw new Error('the script threw'); })();
