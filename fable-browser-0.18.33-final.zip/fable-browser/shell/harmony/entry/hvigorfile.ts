import { HvigorNode, HvigorPlugin } from '@ohos/hvigor';
import { hapTasks } from '@ohos/hvigor-ohos-plugin';
import { copyFileSync, existsSync, mkdirSync, readFileSync } from 'fs';
import { resolve } from 'path';

// Stage the shared asset for both DevEco Studio and command-line HAP builds.
const adDomains: HvigorPlugin = {
  pluginId: 'fable-ad-domains',
  apply(node: HvigorNode) {
    const moduleDir = node.getNodePath();
    const source = resolve(moduleDir, '../../../rules/ads.txt');
    const raw = resolve(moduleDir, 'src/main/resources/rawfile');
    const asset = resolve(raw, 'ads.txt');
    mkdirSync(raw, { recursive: true });
    if (!existsSync(asset) || !readFileSync(asset).equals(readFileSync(source))) {
      copyFileSync(source, asset);
    }
  }
};

export default {
  system: hapTasks,
  plugins: [adDomains]
}
