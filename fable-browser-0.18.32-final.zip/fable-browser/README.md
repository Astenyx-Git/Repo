# Fable Browser

轻量浏览器：不自带渲染引擎，直接用各平台的系统 WebView，自己只做界面和少量核心逻辑。
当前版本 0.18.32。Android 安装包约 2.2 MB，鸿蒙 HAP 约 2.3 MB（arm64 + x86_64），Windows 可执行文件约 1.1 MB（含核心）。

| 平台 | 外壳 | 渲染 | 无痕 |
|---|---|---|---|
| Android | Java + C 写的 JNI 桥 | 系统 WebView | 无痕模式（同一窗口内切换，照 Chrome 手机版） |
| Sailfish OS（0.18.22 起） | C++/QML，Silica + C 桥接核心 C ABI | Sailfish WebView（Gecko / embedlite） | 无痕模式（Gecko 的 privateMode） |
| Linux | C，GTK 3 | WebKitGTK (webkit2gtk-4.1) | 无痕窗口（独立的临时 WebKitWebContext） |
| Windows | C++17，Win32 | WebView2 (Edge) | 无痕窗口（WebView2 InPrivate） |
| macOS（0.9 起） | Objective-C，AppKit | WKWebView（系统 WebKit） | 无痕窗口（不落盘的数据存储） |
| 鸿蒙 HarmonyOS（0.11 起） | ArkTS，ArkUI + C 写的 Node-API 桥 | ArkWeb（系统 Web 组件） | 无痕模式（同 Android；ArkWeb 的无痕存储） |
| iOS / iPadOS（0.16 起；0.16.1 起在 Codemagic 上用 Xcode 构建、在模拟器上运行过，还没有上过真机） | Swift，UIKit | WKWebView（系统 WebKit） | 无痕模式（同 Android；不落盘的数据存储） |

0.10 起各平台功能对齐（0.11 加入鸿蒙）：菜单、设置、历史记录、资源嗅探、元数据、语言切换用的是同一个面板（`ui/panel.html`），设置、历史、嗅探清单、系统信息采集都在共享的 Rust 核心里，外壳只负责把面板放进弹出层并转发消息。桌面版的面板是 400 像素宽的弹出菜单，高度跟随内容；做不到的设置项会被隐藏，不会出现"开了没用"的开关。

### 各平台功能对照（0.12；0.16 加入 iOS）

| 功能 | Android | 鸿蒙 | Linux | Windows | macOS | iOS（0.16） |
|---|---|---|---|---|---|---|
| 新标签页、主页快捷方式、阅读模式 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| 菜单面板 | 底栏 ⋯ | 底栏 ⋯ | 工具栏 ≡ / F10 | 工具栏 ≡ / Alt+F | 工具栏 ≡ | 底栏 ≡ |
| 设置、历史记录（查看、搜索、删除） | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| 界面语言（十种，可单独切换） | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| 无痕不记历史、界面跟随皮肤 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| 追踪拦截与开关 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| 广告拦截与开关（0.18.6，默认关） | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| 拦截外部应用跳转（0.18.6，默认关） | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| 拦截计数 | ✓ | ✓ | ✓ | ✓ | —（WebKit 规则拦截不回报） | —（同 macOS） |
| 下载管理（普通模式菜单） | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| 资源嗅探（网络请求 + 页面扫描）与下载 | ✓ | ✓ | ✓ | ✓ | 仅页面扫描 | 仅页面扫描 |
| 扫描二维码（摄像头） | ✓（离线识别） | — | — | — | ✓（macOS 13 起） | ✓ |
| 扫描二维码（图片） | — | — | ✓（离线识别） | ✓（离线识别） | — | — |
| 页内查找 | ✓ | ✓ | ✓ / Ctrl+F | ✓（WebView2 运行时 1.0.3405 起）/ Ctrl+F | ✓（只说找没找到，不计数）/ ⌘F | ✓（同 macOS） |
| 元数据：公网 IP、简略/详细、系统信息 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| UA 伪装（默认 / iPhone / 自定义） | ✓（另有"桌面版"） | ✓（另有"桌面版"） | ✓ | ✓ | ✓ | ✓（另有"桌面版"） |
| 关闭 JavaScript | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| 不加载图片（省流量） | ✓ | ✓ | ✓ | ✓ | — | ✓ |
| 拦截第三方 Cookie | ✓ | ✓ | ✓ | — | — | — |
| 无痕窗口禁止截图 | ✓ | ✓ | — | ✓ | ✓ | —（只遮住多任务预览） |
| 清除历史、Cookie、缓存 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| 后台标签休眠 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| 文字大小 / 页面缩放（80%–200%，0.12） | ✓ 文字大小 | ✓ 文字大小 | ✓ 页面缩放 | ✓ 页面缩放 | ✓ 页面缩放 | ✓ 文字大小（按页面缩放实现） |
| 屏幕方向（跟随系统 / 竖屏 / 横屏）、屏幕常亮、隐藏状态栏（0.12） | ✓ | ✓ | — | — | — | ✓（iPad 不能锁方向） |
| 可选的主页按钮（0.14，默认不显示） | 底栏，前进与 + 之间 | 底栏，前进与 + 之间 | 前进之后，Alt+Home | 前进之后，Alt+Home | 工具栏前进之后，⇧⌘H | 底栏，前进与 + 之间 |
| 地址栏置于顶部（0.15，默认在底部） | ✓ 地址栏在页面上方，按钮仍在底栏 | —（仍在底部） | — | — | — | ✓ |
| 作为主屏幕应用、隐藏应用（0.13） | ✓ | — | — | — | — | —（iOS 不允许第三方桌面） |
| 主屏幕的"所有应用"抽屉：上滑打开、搜索、按字母排序（0.17） | ✓ | — | — | — | — | — |
| 主屏幕显示系统壁纸（0.18，可关） | ✓ | — | — | — | — | — |
| 系统壁纸：Fable 或自定义（0.18.1） | ✓ | — | — | — | — | — |
| 皮肤 `theme://名字`（0.18.26 图标，0.18.27 配色）：新标签页、面板、阅读模式的配色与标志 | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| 皮肤：浏览器自己的栏和按钮跟着换色 | ✓ 底栏、地址栏、状态栏与导航栏 | ✓ 底栏、地址栏、状态栏与导航栏 | ✓ 工具栏、标签条、地址栏 | ✓ 工具栏、地址栏、深色皮肤时标题栏变深 | 深色皮肤时窗口用系统深色外观 | ✓ 底栏、地址栏、状态栏 |
| 皮肤：同时换掉系统里的应用图标 | ✓ 启动器图标 | —（系统不提供接口） | — | — | — | ✓ 备用应用图标（系统会弹窗确认） |

"—"表示该平台的 WebView 没有对应接口（或这一项只对手机有意义），面板里相应的项不显示。设置里的"显示"一组（0.12）：手机上是"文字大小"，只放大网页文字、不改排版（WebView 的文字缩放）；桌面三个平台的 WebView 没有只缩放文字的接口，同一项叫"页面缩放"，作为每个网页的默认缩放比例，Ctrl/⌘+0 回到这个比例而不是 100%。子页面里有一行示例文字，随所选大小即时变化。资源嗅探在 macOS 上拿不到网络请求（WKWebView 不开放），只靠页面扫描（媒体元素、大图、页面已加载的资源清单）。

## 每种语言负责什么

| 语言 | 位置 | 职责 |
|---|---|---|
| Rust | `core/` | 地址栏解析、追踪器与广告的拦截判定、广告位隐藏规则、外部应用跳转的判定、标签休眠策略、设置与历史记录的存储、资源嗅探的判定与清单、生成新标签页；导出 C ABI（`core/include/fable_core.h`） |
| 汇编 | `native/fnv1a_x86_64.S`、`fnv1a_aarch64.S` | 拦截热路径：不区分大小写的 FNV-1a 64 位主机名哈希。x86-64 一份源码同时支持 System V 和 Win64 调用约定；两份都能生成 ELF（Linux、Android）和 Mach-O（macOS，Apple 芯片与 Intel） |
| Zig | `native/hostset.zig`、`build.zig` | 编译期把 `trackers.txt`（追踪器）解析、哈希、排序成只读表；`build.zig` 负责把汇编和 Zig 交叉编译到任意目标 |
| C | `shell/linux/`、`shell/android/.../fable_jni.c`、`shell/harmony/.../fable_napi.c` | Linux 外壳、WebKit 网页进程扩展（拦截请求）、Android JNI 桥、鸿蒙 Node-API 桥 |
| C++ | `shell/windows/main.cpp` | Windows 外壳 |
| C++/QML | `shell/sailfish/src/`、`shell/sailfish/qml/` | Sailfish OS 外壳：Silica 界面 + Sailfish WebView，C++ 单例把核心 C ABI 暴露给 QML，面板与新标签页的消息经 `<html>` 属性和 `fable-run` 事件往返（见 `shell/sailfish/README.md`） |
| Objective-C | `shell/macos/main.m` | macOS 外壳（AppKit + WKWebView，ARC） |
| Swift | `shell/ios/Fable/` | iOS 外壳（UIKit + WKWebView），通过桥接头文件直接调用核心的 C 接口 |
| Java | `shell/android/` | Android 外壳（系统 WebView 只能从 Java 侧驱动） |
| ArkTS | `shell/harmony/entry/src/main/ets/` | 鸿蒙外壳（ArkUI 底栏 + ArkWeb 网页，界面和行为照 Android 版） |
| 文本表 | `ui/strings.tsv` | 全部界面文字的简体中文、繁體中文、日本語、English、한국어、Русский、Français、Español、العربية、Nederlands、Deutsch、Português、Italiano 十三列对照，编译进核心，各平台共用 |
| HTML/JS | `ui/` | 新标签页、阅读模式脚本、页面资源扫描脚本、应用内面板（菜单、标签页、设置、历史、资源嗅探）。编译进核心，各平台共用 |

汇编和 Zig 都是可选加速：不启用时 Rust 自带等价实现，三者哈希结果必须一致（有测试校验：汇编由 `cargo test --features asm` 查，Zig 的表由 `tests/zig_table_test.sh` 与 Rust 建的表逐项比对，CI 两样都跑）。

## 功能

通用：

- 地址栏：`example.com` 补 `https://`，`localhost:3000` 和 IP 补 `http://`，其余当搜索。http(s)（`//` 漏写会补上）、任意 `about:` 页、`view-source:` 套可加载地址，以及别的 `协议://…`（`ftp://`、`chrome://`、Fable 自己的 `fable://`、各家应用的协议……）照原样交给网页视图，能不能打开由它决定；桌面版（Linux、Windows、macOS）还能开本机的 `file:///…`（别的机器上的 `file://主机/…` 不开）。会执行脚本或读本地/内部内容的协议（`javascript:`、`data:`、`intent:`、`content:`……）一律当搜索词，不打开（0.18.7）
- 皮肤（0.18.26 图标，0.18.27 配色）：地址栏输入 `theme://DeepSeek`、`theme://Gemini`、`theme://Grok`、`theme://Kimi`、`theme://ChatGPT`（大小写不限）换成对应的皮肤，`theme://Claude` 换回默认。ChatGPT 皮肤使用显示名 Astra，新标签页上的格言也换成 Astra 的 “Here beginneth thy way ad astra.”（macOS 的“关于”面板同样）；其他皮肤使用 Fable 和 “Here beginneth thy fable.”。Android 的桌面启动器名称也随皮肤切换。不弹任何提示，当前页面不动；名字不对时什么也不发生。皮肤包括图标和整套配色：新标签页、面板、阅读模式的背景与配色，浏览器自己的栏、地址栏、按钮、进度条（各平台见上表），新标签页中间的标志和标签列表里新标签页的图标；Android 同时换桌面启动器图标，iOS 换备用应用图标（这一步系统会弹窗，应用拦不住）。Grok、Kimi 是深色皮肤，状态栏图标随之变浅。无痕模式使用当前皮肤的配色，通过面具图标和无痕说明区分。只有地址栏（和新标签页的搜索框）能换：网页里的 `theme://` 链接一律不跟随。图稿在 `assets/icon-variants/`，`scripts/gen_themes.py` 从它们生成各平台用的图标；配色在 `core/src/theme.rs`
- 追踪器拦截：只拦第三方请求；直接访问名单内的网站不受影响
- 广告拦截（0.18.6，默认关）：两路一起开。网络上一份广告域名清单（`rules/ads.txt`），只拦第三方请求，站点自己域名上的广告不动；页面上再按样式把广告位本身藏起来（`.adsbygoogle`、`[id^="google_ads_"]`、`.ad-container` 这类容器，以及广告网络的 iframe）。规则是纯 CSS，所以页面后来才插进来的广告也一并藏掉，不必用脚本盯着页面
- 拦截外部应用跳转（0.18.6，默认关）：网页想把用户带去别的应用时（`intent://`、`itms-apps://`、各家的自定义协议、应用商店链接）停在原地，并提示一句。`tel:`、`mailto:`、`sms:` 这类约定俗成的链接照旧交给系统——用户点了电话号码本来就该拨号。Fable 自己的 `fable://`、`theme://` 属于"浏览器自己处理"，不算跳去别的应用（0.18.25）
- 闲置标签休眠：后台标签一段时间没看就释放内存，切回来自动恢复
- 阅读模式：提取正文重新排版，显示预计阅读时间；页面顶部有"退出"，退出后原页面原样恢复（不重新加载）。没有可提取的正文时会提示
- 书签：地址栏星标或菜单收藏，文件夹，面板里查看/搜索/删除/新建文件夹，支持 Chrome/Firefox 的 HTML 书签导入/导出（`bookmarks.tsv` 存在数据目录）；退出时自动快照普通标签页（URL、标题、顺序），下次启动默认恢复，设置 › 标签页里可关；新标签页也在快照里（记作一个空地址），所以开着新标签页退出，再进来它还在；无痕标签绝不进入快照
- 新标签页：内嵌在核心里，图标也内嵌，不联网
- 元数据有"简略 / 详细"两种显示模式（0.7，0.7.1 调整），开关在元数据页标题栏右侧，默认简略，选择会记住。简略模式沿用 0.5.0 的单页设计：公网 IP 卡片之后依次是显示、硬件、浏览器、时间与地区、指纹，每组是数值卡加条目，一页滚到底，数据来自快速设备查询和页面本身。详细模式是概览加十二个分类入口，每类一个子页面，长列表折叠。在详细模式的子页面里切到简略会回到简略单页。复制按钮复制当前页面显示的内容
- 新标签页以 Fable 标志作为自己的网页图标（0.7），标签页列表里新标签页显示标志而不是地球图标；无痕新标签页仍显示无痕图标
- 元数据（设置 › 元数据，0.5 起，0.6 重做）：本应用和网页能读到的全部设备信息，凡是不需要你点同意的都在这里。主页面是公网 IP 卡片、六个概览数值（分辨率、刷新率、CPU、内存、存储、电池）和十二个分类入口，每个入口带一行摘要；点进去是子页面，较长的列表（编解码、传感器、DNS、本机地址、指令集、全部功能标识、内核详情）默认折叠并显示条数，展开状态在返回后保留。每一行点按复制，子页面可复制本页，主页面可复制全部。
  - 网络：连接方式、是否按流量计费、链路带宽、网络接口、Wi-Fi 标准/频段/速率/信号/支持频段、运营商与国家/地区、漫游、SIM 卡槽、信号格数、私人 DNS、MTU、代理、DNS 服务器、本机地址，以及网页可见的连接估计
  - 显示：物理分辨率、尺寸、像素密度、支持的刷新率、HDR 格式、峰值亮度、广色域、挖孔/刘海，以及网页可见的色深、色域、外观
  - 处理器与图形：SoC 型号、各核心簇的型号与最高频率、ABI、GPU、OpenGL ES 与 Vulkan 版本、指令集特性
  - 内存与存储：总内存、可用内存、低内存阈值、单应用上限、存储空间与存储卷
  - 电池：电量、温度、电压、状态、健康、电源、类型、循环次数（Android 14 起）、剩余容量、电流、充满还需
  - 媒体与 DRM：Widevine 安全级别与 HDCP、PlayReady/ClearKey 支持、每种视频/音频格式的硬件或软件解码与最高分辨率、音频采样率与输出设备、空间音频
  - 传感器与相机：每个传感器的名称/类型/厂商/功耗；每个摄像头的朝向、像素、焦距、光圈、传感器尺寸、闪光灯、光学防抖、Camera2 级别（读取规格不需要相机权限）
  - 系统：设备名称、品牌、型号、代号、ANDROID_ID、系统与安全补丁、版本号、构建指纹、编译时间、基带、Bootloader、内核、运行时、锁屏与加密、开发者选项与 USB 调试、开机时长、温控状态、无障碍、系统语言等偏好
  - 浏览器、时间与地区、设备功能（常见功能逐项列出支持与否 + 全部功能标识）、指纹
  - 为此新增了两个安装时自动授予、不会弹窗的权限：网络状态、Wi-Fi 状态。需要定位权限的 Wi-Fi 名称不读取；IMEI、序列号、MAC 地址、Widevine 设备 ID 不读取
- 界面语言（0.4；0.8.1 加入韩语、俄语；0.8.2 加入法语；0.11.1 加入西班牙语；0.12.1 加入阿拉伯语；0.18.19 加入荷兰语；其后又加入德语、葡萄牙语、意大利语）：简体中文、繁體中文、日本語、English、한국어、Русский、Français、Español、العربية、Nederlands、Deutsch、Português、Italiano。默认跟随系统语言（`zh-TW`、`zh-HK` 等归为繁体，`fr-FR`、`fr-CA` 等归为法语，`es-ES`、`es-MX` 等归为西班牙语，`ar-EG`、`ar-SA` 等归为阿拉伯语，`nl-NL` 等归为荷兰语，`de-DE`、`de-AT` 等归为德语，`pt-PT`、`pt-BR` 等归为葡萄牙语，`it-IT`、`it-CH` 等归为意大利语，其他未支持的语言用英语）。俄语界面里无痕模式按 Chrome 俄文版的叫法称作"инкогнито"，西班牙语界面称作"modo incógnito"，阿拉伯语界面称作"وضع التخفي"，意大利语界面按 Chrome 意大利文版称作"in incognito"；韩语、俄语、法语、西班牙语、阿拉伯语、德语、葡萄牙语、意大利语下主页的维基百科快捷方式指向对应语言版本，历史记录的日期按当地写法显示（法语如 17 novembre 2026，西班牙语如 17 de noviembre de 2026，阿拉伯语如 17 نوفمبر 2026，德语如 17. November 2026，葡萄牙语如 17 de novembro de 2026，意大利语如 17 novembre 2026）。阿拉伯语是第一个从右向左的语言：选它后面板、新标签页、阅读模式整页镜像（标题栏、开关、返回与折叠箭头都换向，网址、自定义搜索引擎和自定义 UA 输入框仍保持从左向右），Android 声明了 `supportsRtl`，原生底栏也随之镜像。搜索引擎列表同时加入了 Yandex、Naver 和 Seznam（捷克，`https://search.seznam.cz/?q=%s`），可在设置 › 语言里手动切换，切换后底栏、面板、提示、新标签页、阅读模式立即生效，无需重启。三个平台都会按系统语言显示新标签页和阅读模式；手动切换目前只有 Android 有入口

Android（0.2）：

- 界面全部自绘：底栏用自己的形状和矢量图标，菜单、标签页、设置、历史记录是同一套样式的底部面板，提示用自己的气泡而不是系统 Toast，不再出现系统对话框
- 设置：搜索引擎（DuckDuckGo / 必应 / Google / 百度 / 搜狗 / 自定义）、主页快捷方式（增删改、排序）、拦截追踪器、拦截第三方 Cookie、清除浏览数据、UA、JavaScript、省流量（不加载图片）、休眠时间
- UA 伪装：默认（去掉 WebView 标记，等同 Android 版 Chrome）、桌面版、iPhone、自定义；菜单里可一键切换桌面版网站。同时去掉了 WebView 默认附带的 `X-Requested-With: 应用包名` 请求头
- 无痕模式（0.8 起按 Chrome 的方式重做）：无痕是一个模式，有自己的一组标签页，不再是混在普通标签里的"无痕标签"。
  - 菜单里"无痕模式"进入：回到上次看的无痕标签，没有就新开一个；角标是已打开的无痕标签数。进入后底栏和面板继续使用当前皮肤，"+"和菜单里的"新标签页"打开的都是无痕标签，底栏上的数字只数无痕标签
  - 菜单里"退出无痕"关闭全部无痕标签（随之清除它们的 Cookie 和存储），回到上次看的普通标签
  - 标签页列表分普通和无痕两侧，标题栏右侧的切换按钮带各自数量；点哪一侧的标签就进入哪个模式，两侧的标签互不打扰。无痕一侧没有标签时显示说明和"新建无痕标签页"，有标签时可"全部关闭"
  - 关闭无痕标签时接替的是相邻的无痕标签；最后一个无痕标签关掉（包括按返回键）后回到普通模式的原位置。普通标签同理只由普通标签接替
  - 无痕新标签页仿 Chrome：列出不会保存的（浏览记录、网站图标、Cookie/缓存/网站数据）和仍可能看到你活动的（访问的网站、雇主或学校、网络服务商），说明下载文件会保留。旧版 WebView 无法隔离 Cookie 时，这一条会改成如实说明 Cookie 与普通标签共用
  - 无痕模式下禁止截图、录屏，最近任务里也不显示页面内容（与 Chrome 默认一致）；设置 › 隐私里可以打开"允许无痕模式截图"
  - 隔离：不记历史；在支持多 Profile 的 WebView（约 110 版起）上使用独立的 Cookie 和存储，关闭全部无痕标签后整体删除
- 历史记录：按天分组、搜索、单条删除、清空
- 站点图标：主页快捷方式、标签页列表、历史记录都显示网站自己的图标。已经存过的图标随新标签页一起下发、直接画在页面里，刷新或新开标签时不再先出现空白或地球图标再换成图标（0.4）；拿不到时显示地球图标（不再用标题首字母）。访问过的网站用 WebView 给出的图标，并在网页声明了主屏幕图标时换成更清晰的那张；没访问过的快捷方式由应用向该网站取一次（依次尝试 `/apple-touch-icon.png`、`/favicon.ico`、首页里声明的图标）。无痕标签不留图标，清除历史记录时图标一并清除
- 菜单里"添加到主页"把当前网页加为快捷方式
- 作为主屏幕应用（0.13）：在系统设置里把 Fable 设为默认主屏幕应用后，主页就是手机的桌面——网站快捷方式和已安装的应用排在同一套页面里，左右滑动翻页，底部有页码点；两种图标外观一样（应用图标按自适应图标的图层画成方形，和网站图标用同一种圆角），点网站打开网页，点应用启动应用。长按进入编辑（右上角出现"完成"，从右到左的语言里在左上角；编辑时各页图标略微缩小，顶部空出一条给"完成"，不会挡住第一行图标和它们的"×"）：拖动调整位置（拖到屏幕边缘停一下翻到相邻一页；在最后一页拖到右边缘停一下会新建一页，图标单独放在新页上；拖到某页的空白处会排到那一页末尾；页上的图标都移走后这一页自动消失），"×"移除——网站从快捷方式里删掉，应用只是从主屏幕拿掉（0.17 起仍在"所有应用"里，可以从那里加回来），也可在"设置 › 主页快捷方式 › 恢复移除的应用"一次全部放回。按 Home 键回到主页第一页（复用已在主页的标签，不会越开越多），在主页按返回键不会退出。装上、卸载或更新应用后主页自动刷新。不是默认主屏幕应用时，新标签页和以前一样
  - "所有应用"（0.17，应用抽屉）：在主屏幕上往上滑（抽屉跟着手指上来，松手时过了一小段或甩得够快就打开，否则落回去），或点页码点那一行右端（阿拉伯语在左端）的九宫格按钮。里面是全部带桌面图标的应用，包括从主屏幕拿掉的；按界面语言的字母顺序排：数字按数值（9 在 10 前面），重音不影响（Éclair 排在 E），阿拉伯语按阿拉伯字母顺序；简体中文像国产桌面那样按首字母分组，中文名按拼音首字母和英文名排在一起（"淘宝"在 T、"微信"在 W），用的是 CLDR 拼音排序里每个字母的分界标记（ICU 字母索引的做法），WebView 不认识拼音排序时退回普通排序。顶部的搜索框按名称筛选（不分大小写、忽略重音和阿拉伯语的元音符号；名称开头匹配的排前面），也匹配包名（输入 tencent 能找到微信）；按回车启动第一个结果；找不到时提示没有，并提供"在网上搜索"（在当前标签里搜索）。点按启动应用，抽屉随后收起；长按弹出菜单："添加到主屏幕"（已在主屏幕上的应用是"在主屏幕上找到它"，翻到它所在的页并闪一下）和"应用信息"（系统的应用详情页）；长按后接着拖动，抽屉收起，进入编辑，应用跟着手指放到主屏幕上的任意位置。关闭：在列表顶部往下拉（同样跟手）、返回键、Home 键（同时回到第一页）。返回键在主屏幕上依次关闭：长按菜单 → 抽屉 → 编辑状态，都没有时才照旧处理
  - 手势不冲突：左右滑动仍是页面自己的横向滚动（浏览器处理），只有明显向上的滑动才拉出抽屉；编辑状态下不响应上滑，九宫格按钮也隐藏；按住图标不动仍是进入编辑。抽屉里的列表可以正常上下滚动，只有在顶部往下拉才是关闭；长按之后的移动不会被当成滚动
  - "设置 › 搜索与主页 › 新应用添加到主屏幕"（0.17，只在 Fable 是默认主屏幕应用时出现，默认开）：开着时和以前一样，新装的应用排到主屏幕末尾；关掉后新装的应用只出现在"所有应用"里（像 Pixel 桌面），要时再从抽屉加到主屏幕。为了让这个开关不挪动已有的图标，主页每次打开都会把当前看到的完整顺序存下来（以前只在编辑过之后才存），所以关掉开关时主屏幕保持原样；"恢复移除的应用"会把它们放回主屏幕末尾，不受这个开关影响
  - 只有主页自己能列出应用、取应用图标、启动应用、保存布局：这些请求由壳在拦截层回答，并且只在当前标签的页面就是主页、不是无痕标签、Fable 确实是默认主屏幕应用时才回答；其他网页（包括嵌在网页里的框架）请求一律 404。能启动的只有带桌面图标的应用。列应用用的是 Android 11 起的 `<queries>` 声明，不需要"查询所有应用"权限
- 普通模式的菜单 › 下载管理列出启用此功能后的下载，显示文件名和任务状态。移除记录会保留文件。Android 还可查看下载进度、打开文件或进入系统下载管理；桌面版提供打开下载文件夹的入口。
- 资源嗅探（0.3）：列出当前页面加载的视频、音频、流媒体列表（m3u8 / mpd）和页面上的大图，可按类型筛选，逐个下载、复制链接或在新标签打开；菜单上的角标显示已发现的数量。来源有两路：播放器发出的网络请求，以及打开面板时对页面的一次扫描。清单只在内存里，换页面或关标签即清空
- 扫描二维码（0.18.31：空白地址栏里的按钮，地址栏空白时才出现）：有摄像头的平台（Android、iOS、macOS 13 起、鸿蒙、Sailfish）显示扫码按钮（Google Material 的 "qr_code_scanner" 图标，见文末"第三方素材"），打开摄像头扫码——iOS 与 macOS 通过 AVFoundation，Android 用 Camera2 取后置摄像头的 Y 平面，Sailfish 用 QtMultimedia 取视频帧的 Y 平面，都交给核心的离线解码器（见下），不依赖任何在线服务；没有摄像头扫码的平台（Linux、Windows）以及 Sailfish 显示图片按钮，选一张本地图片文件，同样由核心的离线解码器识别。扫到 http/https 网址就在当前标签页打开，其他内容（Wi‑Fi、名片、纯文字）先由壳显示出来，由用户选复制或搜索。Android 的相机权限只在第一次点扫码时询问。
- Android 当前提供离线 QR Code Model 2 解析接口。后台线程可调用 `Core.decodeQr(luma, width, height, rowStride, pixelStride)`，传入 8 位灰度图或 `YUV_420_888` 的 Y 平面，数组从图像或裁剪区域的左上像素开始。紧密排列的灰度图用 `width` 和 `1` 作为两个步长。返回第一个成功解码的原始字节数组，可包含零字节。无可读码或参数无效时返回 `null`。每边上限为 4096 像素，总像素上限为 4,194,304，JNI 读取的平面跨度上限为 32 MiB。
- 页内查找（菜单的"查找"）：用各平台 WebView 自己的查找接口，不用页面里的 `window.find`（页面能改写它，拿到搜的词）。查找框是一张不遮暗网页的矮面板，输入即找，回车下一个、Shift+回车上一个，显示"第几处，共几处"（苹果的 WKWebView 只说找没找到）；离开查找就清掉高亮
- 加载进度条、刷新/停止、`target=_blank` 开新标签、下载交给系统下载管理器
- 自适应启动图标

**还没做**：书签、页内查找、文件上传、全屏视频、退出后恢复标签、深色模式；桌面两个外壳的设置/历史入口。

## 构建

先装 Rust（`rustup`）。

### Android

```sh
export ANDROID_HOME=...  ANDROID_NDK_HOME=...   # 设了 NDK 就用它的 clang 编汇编哈希，不设则用 Rust 版
scripts/build-android.sh                        # 编 arm64 + x86_64 的核心，再用 Gradle 出 app-debug.apk
```

唯一的库依赖是 `androidx.webkit`（无痕标签的独立 Profile 需要它）。调试包也开了 R8 压缩。

### Linux

```sh
sudo apt install build-essential pkg-config libgtk-3-dev libwebkit2gtk-4.1-dev libsoup-3.0-dev   # Debian / Ubuntu
make linux          # 生成 build/fable、build/webext/libfable_webext.so 和 build/webext/ads.txt
./build/fable
sudo make install   # 可选，装到 /usr/local
```

环境变量 `FABLE_SLEEP_AFTER_SECONDS` 可以改休眠阈值（默认 600，0 表示不休眠；设了它，设置里的"休眠"就不起作用）。`FABLE_PRIVATE=1` 以无痕窗口启动。设置和历史存在 `~/.local/share/fable`。

快捷键：Ctrl+T 新标签，Ctrl+N 新窗口，Ctrl+Shift+N 无痕窗口，Ctrl+W 关闭标签，Ctrl+Shift+W 关闭窗口，Ctrl+L 地址栏，Ctrl+R / F5 刷新，Ctrl+Shift+R 阅读模式，Ctrl+H 历史记录，Ctrl+加号 / 减号 / 0 缩放，F10 菜单，Alt+←/→ 后退前进；Ctrl 或中键点链接在后台新开标签。

### Windows（MSVC，x64）

```bat
cd core && cargo build --release && cd ..
nuget install Microsoft.Web.WebView2 -OutputDirectory packages
cmake -S shell/windows -B build/windows -DWEBVIEW2_SDK=%CD%\packages\Microsoft.Web.WebView2.<版本号>
cmake --build build/windows --config Release
```

运行需要 WebView2 Runtime（Windows 11 自带，Windows 10 多数已随 Edge 装好）。C 运行库是静态链接的，生成的 `fable.exe` 不依赖 VC++ 运行库。MSVC 不能汇编 GNU 语法的 `.S`，所以这条路径用 Rust 版哈希；想用汇编版请走下面的 Zig 路径。也可以在 Linux 上用 clang-cl + lld-link 配合 xwin 下载的 SDK 交叉编译（本仓库的 exe 就是这样编的）。

Windows 版的样子和用法：

- 每个窗口一排原生控件（后退、前进、刷新、地址栏、标签条、新建、关闭、菜单），图标用系统的 Segoe MDL2 Assets 字体；每个标签一个 WebView2
- Ctrl+Shift+N 打开无痕窗口：WebView2 的 InPrivate 模式，所有无痕窗口共用一份只在内存里的数据，最后一个无痕窗口关闭时丢弃；标题栏和地址栏跟随皮肤，不记历史；默认不出现在截图、录屏和屏幕共享里（Windows 10 2004 起，设置里可以允许）
- 菜单面板是一个跟在 ≡ 按钮下方的弹出窗口，点别处自动收起；面板与外壳通过 `chrome.webview.postMessage` 通信
- 追踪、图片拦截都在 `WebResourceRequested` 里做，同一处把媒体请求记进资源嗅探；下载存到"下载"文件夹
- 公网 IP 用 WinHTTP 在后台线程查询（走系统代理）；元数据里的系统信息来自注册表和 Win32 接口，屏幕信息来自当前显示器
- 快捷键：Ctrl+T / Ctrl+N / Ctrl+Shift+N / Ctrl+W / Ctrl+Shift+W / Ctrl+L / Ctrl+R 或 F5 / Ctrl+Shift+R 阅读模式 / Ctrl+H 历史记录 / Ctrl+Tab 切换标签 / Alt+F 菜单 / Alt+←/→
- 设置和历史存在 `%LOCALAPPDATA%\Fable`，和 WebView2 自己的数据放在一起；`FABLE_PRIVATE=1` 以无痕窗口启动

### macOS（11 Big Sur 或更新，Apple 芯片与 Intel 通用）

在 Mac 上，装好 Xcode 命令行工具（`xcode-select --install`）和 Rust（rustup）之后：

```sh
make macos                    # 等同于 sh scripts/build-macos.sh
open build/macos/Fable.app    # 满意的话拖进"应用程序"文件夹
```

脚本会为 arm64 和 x86_64 各编一份带汇编哈希的核心，用 `lipo` 合成通用库，再编译 `shell/macos/main.m` 并打包成 `Fable.app`，最后做一次临时（ad hoc）签名，所以在编译它的这台 Mac 上可以直接打开。加 `ZIG_NATIVE=1` 改用 Zig 原生层（需要 Zig 0.14+）。要发给别的 Mac，需要用 Apple 开发者账号的 Developer ID 证书签名并公证，否则对方会被 Gatekeeper 拦下。

没有 Mac 时可以用 Codemagic（codemagic.io）的云端 Mac：把仓库接到 Codemagic，选 `codemagic.yaml` 里的 `macos`（构建、启动、截图）或 `ios-simulator`（iOS 模拟器版）流程即可，产物里有 App、截图和日志。也可以用它的 API 触发：`POST https://api.codemagic.io/builds`，带 `x-auth-token` 头和 `{"appId": …, "workflowId": "macos", "branch": "main"}`。

macOS 版的样子和用法：

- 标签页就是 macOS 原生的窗口标签：⌘T 新建，⌘W 关闭，标签栏、"显示所有标签页"、"合并所有窗口"都和 Safari 一样；⌘点按或中键点链接在后台新开标签
- ⇧⌘N 新建无痕窗口（照 Chrome 桌面版：无痕是单独的窗口，不是混在普通窗口里的标签）。无痕窗口跟随皮肤，工具栏左侧有"无痕模式"标记；它的标签只会和其他无痕窗口合并。所有无痕标签共用一个只在内存里的数据存储，关闭最后一个无痕标签时随之丢弃，也不记历史。和 Android 不同，macOS 的 WebKit 一直能把无痕数据和普通标签完全隔开
- 追踪拦截用核心生成的规则交给 WebKit 自己的内容拦截器（`WKContentRuleList`），和其他平台拦的是同一份名单
- 空闲的后台标签按休眠策略释放网页（正在出声的除外），点回来时重新加载
- 下载（macOS 11.3 起）存到"下载"文件夹，完成后程序坞里的"下载"堆栈会跳一下
- 工具栏右侧的 ≡ 打开和其他平台相同的菜单面板（NSPopover）；⌘, 设置，⌘Y 历史记录，⌥⌘M 资源嗅探
- 菜单栏、工具栏、提示默认随系统语言，也可以在设置里单独切换；"Fable › 设为默认浏览器"后，其他应用里的链接会在 Fable 中打开

### 鸿蒙 HarmonyOS（HarmonyOS 5.0.2 / API 14 或更新，手机、平板、2in1）

需要 Rust（`rustup target add aarch64-unknown-linux-ohos x86_64-unknown-linux-ohos`）和 DevEco Studio（或命令行工具）：

```sh
scripts/build-harmony.sh --core-only   # 用 SDK 自带的 clang 为 arm64-v8a、x86_64 编核心（带汇编哈希）
# 然后用 DevEco Studio 打开 shell/harmony，File › Project Structure › Signing Configs 勾选"自动生成签名"，运行到手机或模拟器
scripts/build-harmony.sh               # 或者：核心 + hvigor 出 HAP（未签名）
```

脚本默认在 `$DEVECO_SDK_HOME/default/openharmony/native` 找 SDK 的 native 工具链，可用 `OHOS_NDK` 指定；hvigor 用 `HVIGOR` 指定。`--openharmony` 改用公开的 OpenHarmony SDK 编一份（`runtimeOS` 换成 OpenHarmony，代码不变），不需要华为账号，用来检查能否编译。装到真机必须签名，HarmonyOS 的签名证书只能用华为开发者账号申请，所以交付的 HAP 是未签名的。

鸿蒙版的样子和用法：

- 底栏、面板、无痕模式的交互都和 Android 版一致：底部是地址栏和"后退、前进、+、标签数、菜单"一排按钮；菜单、标签页、设置、历史、资源嗅探、元数据是同一个面板页面，在独立的 ArkWeb 视图里显示，只有它拿得到 `FableUI` 桥
- 无痕标签用 ArkWeb 的 `incognitoMode`，所有无痕标签共用一份只在内存里的数据，关闭最后一个无痕标签时清空；无痕时系统栏跟随皮肤，并默认禁止截图和录屏（`setWindowPrivacyMode`，设置里可允许）
- 拦截、资源嗅探、新标签页都在 `onInterceptRequest` 里做；"不加载图片"、"拦截第三方 Cookie"用 ArkWeb 自带的开关
- 下载先存进应用缓存，完成后移到"文件"应用里的 下载/Fable 文件夹（第一次下载时系统会建好这个文件夹）
- 元数据的系统信息：设备名、型号、系统版本来自鸿蒙的设备信息接口，电量来自电池接口，CPU、内存、存储、内核来自 `/proc`（都在 Rust 核心里读），屏幕和网络由 ArkTS 补上
- 可以在系统设置里设为默认浏览器，其他应用里的 http/https 链接会在 Fable 中打开

### iOS / iPadOS（iOS 15 或更新，iPhone 与 iPad）

> 0.16 的 iOS 外壳是在一台没有 Mac 的 Linux 机器上写的；0.16.1 起它在 Codemagic 的 Mac 上用 Xcode 编译通过、在 iPhone 模拟器上运行过（见"验证到了哪一步"里的 0.16.1 一节），**还没有在真机上用过**。

需要一台装有 Xcode 15 或更新版本的 Mac，和 Rust（rustup）：

```sh
scripts/build-ios.sh                                     # 核心 + 模拟器用的 Fable.app（Debug，不签名），最后打印装进模拟器的命令
DEVELOPMENT_TEAM=<团队 ID> scripts/build-ios.sh device   # 真机版（Release，自动签名）
scripts/build-ios.sh core                                # 只编核心：build/ios/iphoneos/、build/ios/iphonesimulator/ 各一份 libfable_core.a（Linux 上也能跑）
```

也可以直接用 Xcode 打开 `shell/ios/Fable.xcodeproj`，在 Signing & Capabilities 里选自己的团队，然后运行。工程的第一个构建阶段会调用 `scripts/build-ios.sh core`，按当前的 SDK 和架构编出带汇编哈希的核心（真机 arm64；模拟器 arm64 + x86_64，用 `lipo` 合成一份），Swift 通过桥接头文件 `Fable-Bridging-Header.h` 引入 `core/include/fable_core.h`。工程文件由 `shell/ios/project.yml` 用 XcodeGen 2.42 生成并一起提交，改了 `project.yml` 之后重新生成即可（更新的 XcodeGen 写出的是 Xcode 16 格式，Xcode 15 打不开）。版本号写在 `project.yml` 里：`MARKETING_VERSION` 与核心一致，`CURRENT_PROJECT_VERSION` 与 Android 的 versionCode 一致，`tests/ios_test.sh` 会检查。图标是一张 1024×1024 不透明的 PNG（`gen_assets.py` 生成，系统自己切圆角）。

iOS 版的样子和用法：

- 照 Android 手机版：底部是地址栏和"后退、前进、（主页）、+、标签数、菜单"一排按钮；键盘弹出时地址栏贴着键盘上移，按钮行收起。打开"地址栏置于顶部"后地址栏移到页面上方，按钮仍在底栏。底栏的颜色一直铺到 Home 指示条下面，横屏时内容避开刘海和圆角（安全区域）
- 菜单、标签页、设置、历史、资源嗅探、元数据是同一个面板页面，放在盖住整个窗口的透明 WKWebView 里，以底部弹出层显示，和 Android 一样（外壳在页面开始前设 `window.FableSheet = true`，面板走 macOS 那种消息桥，但不换成桌面窗口布局）。面板视图有自己的内容控制器，网页拿不到它的消息通道；另有一条内容拦截规则不让它联网
- 无痕模式和 Android 一样是同一窗口里的一组标签：所有无痕标签共用一份只在内存里的数据存储（`WKWebsiteDataStore.nonPersistent()`），关闭最后一个无痕标签或"退出无痕"时丢弃，不记历史。iOS 没有禁止截图的接口，所以设置里没有"允许无痕模式截图"；切到后台时，多任务界面里的预览会被当前皮肤配色的遮罩盖住
- 追踪拦截和 macOS 一样交给 WebKit 的内容拦截器（`WKContentRuleList`）；"不加载图片"也是一条内容拦截规则，只拦网络图片。"桌面版网站"用 WKWebView 自带的桌面网页模式（`preferredContentMode`），UA 随之换成 Mac 版 Safari 的
- "文字大小"用 `pageZoom` 实现：页面按比例重排，和 Safari 的"Aa"一样，不是 Android 那种只放大文字
- 屏幕方向、屏幕常亮、隐藏状态栏和 Android 一样在设置 › 显示 里。iPad 上，iOS 不让支持分屏的应用锁定方向，面板里就不显示"屏幕方向"
- 长按链接：在新标签页中打开（后台打开）、在无痕标签页中打开、复制链接；`target=_blank` 和 `window.open` 开新标签；`tel:`、`mailto:`、App Store 之类的链接点按后交给系统；网页的 alert / confirm / prompt 是系统对话框；下拉刷新
- 下载（WKDownload）存到应用的"文稿"目录，在"文件"App 的"我的 iPhone › Fable"里能看到；设置和历史在 Application Support 里，不会出现在"文件"中
- 网页的深色模式跟随系统（`prefers-color-scheme`），浏览器自己的界面保持 Fable 的配色：普通和无痕模式都使用当前皮肤
- 阿拉伯语时底栏左右镜像，地址栏里的网址仍从左向右
- iOS 上做不到、因此没有的：作为主屏幕应用和隐藏其他应用（iOS 不允许第三方桌面）、第三方 Cookie 开关（WebKit 自己处理，没有接口）、拦截计数和网络请求嗅探（同 macOS）。设为默认浏览器需要 Apple 批准的 `com.apple.developer.web-browser` 权限，工程里没有申请，所以其他应用的链接不会交给 Fable

### 可选：Zig 原生层（Zig 0.14 / 0.15）

```sh
zig build -Dtarget=x86_64-windows-msvc          # 或 aarch64-linux-android、x86_64-linux-gnu、aarch64-macos ...
cd core && FABLE_NATIVE_LIB_DIR=$PWD/../zig-out/lib cargo build --release --features zig-native --target <对应的 Rust 目标>
zig build test
```

## 测试

```sh
make test                                   # Rust 单元测试（纯 Rust、汇编各一遍）、C 链接测试、JNI 桥测试、iOS 外壳检查（tests/ios_test.sh）、版本号检查、全部页面交互测试、CI 冒烟脚本自检、Sailfish 外壳检查（tests/sailfish_test.sh，没有 Qt 5 时跳过）；装了 GTK/WebKitGTK 开发包时再编 Linux 外壳并跑新标签页桥的端到端测试
python3 tests/ui_test.py                    # 全部页面交互测试（下面十项），任何一项失败、报错或通过的检查数不够都以非零退出；FABLE_REQUIRE_UI=1 时没有浏览器也算失败（CI 这样跑）
sh tests/zig_table_test.sh                  # Zig 的表与哈希对 Rust 核心（zig build test，再用 --features zig-native 跑核心测试）；make test 在装了 zig 时也跑（ZIG=…）
python3 tests/version_test.py               # 各处版本号一致，Rust（rust-toolchain.toml）与 Xcode 固定到具体版本；--commit REV 另查"X.Y.Z: …"提交标题与文件里的版本一致；git config core.hooksPath scripts/hooks 后提交时自动查
cd shell/android && gradle :app:testDebugUnitTest   # Android 外壳的 JVM 测试（先跑过 make test）
python3 tests/web_harness.py ui/panel.html#settings out.png --lang zh-Hans --js tests/panel_test.js   # 面板交互测试（Android 桥）
python3 tests/web_harness.py ui/panel.html out.png --lang zh-Hans --prelude tests/desktop_prelude.js --js tests/panel_desktop_test.js   # 面板的桌面模式（消息桥、异步回复、按平台隐藏设置项）
python3 tests/web_harness.py ui/panel.html out.png --lang zh-Hans --prelude tests/ios_prelude.js --js tests/panel_ios_test.js   # 面板的 iOS 模式（消息桥 + 底部弹出层、手机设置项、iOS 的 caps）
python3 tests/web_harness.py ui/newtab.html out.png --lang zh-Hans --launcher tests/launcher_apps.json --prelude tests/launcher_prelude.js --js tests/newtab_launcher_test.js --wait 4   # 主屏幕：分页、点按、编辑、拖动、新建页、Home 键
python3 tests/web_harness.py ui/newtab.html out.png --lang zh-Hans --launcher tests/launcher_breaks.json --prelude tests/launcher_prelude.js --js tests/newtab_breaks_test.js   # 主屏幕：保存下来的分页
python3 tests/web_harness.py ui/newtab.html out.png --lang ar --launcher tests/launcher_apps.json --prelude tests/launcher_prelude.js --js tests/newtab_editing_test.js --wait 2   # 主屏幕编辑："完成"的位置（zh-Hans 右上角，ar 左上角），不挡图标
python3 tests/chrome_harness.py ui/newtab.html out.png --lang zh-Hans --launcher tests/launcher_drawer.json --prelude tests/launcher_prelude.js --js tests/newtab_drawer_test.js --wait 9   # 所有应用（抽屉）：上滑、排序、搜索、长按菜单、拖到主屏幕、关闭；另用 --lang ar 跑一遍；要用无头 Chrome（触摸事件）
python3 tests/web_harness.py ui/newtab.html out.png --lang zh-Hans --launcher tests/launcher_wallpaper.json --prelude tests/launcher_prelude.js --js tests/newtab_wallpaper_test.js --wait 2   # 主屏幕显示壁纸：透明、文字颜色、"所有应用"不透明
```

- Android 的 JVM 测试用 Robolectric 启动真正的 `MainActivity`，连着真正的 Rust 核心，手动触发 WebView 会发出的回调来检查状态；另有一个测试用 Android 自己的绘制代码把底栏渲染成 PNG（`app/build/screenshots/`）。
- `tests/web_harness.py` 用 WebKitGTK 以手机尺寸渲染页面并可执行脚本，需要 `python3-gi`、`gir1.2-webkit2-4.1`、`python3-gi-cairo`（无显示器时用 `xvfb-run`）。`tests/chrome_harness.py` 用无头 Chrome，只要 Python 3 和 `google-chrome`/`chromium`（走 `--remote-debugging-pipe`，不再需要 Playwright）。两个都在出现 FAIL、页面或脚本抛错、页面没加载时以 1 退出；`tests/ui_test.py` 再按每项已知的检查数把关，`tests/ui_harness_selftest.py` 检查这些退出码本身。
- 主屏幕（启动器）只在 Android 的 Chromium WebView 里出现，`ui_test.py` 把主屏幕那几项放在 Chrome 里跑；面板在有 WebKitGTK 时两个引擎都跑（iOS 模式只用 WebKit）。主屏幕测试在 WebKitGTK 2.54 里有一项"Home 键回到第一页"不过：前面一连串模拟拖动之后，WebKitGTK 的 `scrollTo({behavior: 'smooth'})` 不再动（`behavior: 'auto'` 照常），单独测平滑滚动没有问题，Chrome 里也没有问题；这是测试引擎的毛病，不是主屏幕的，0.18.6 时就如此，只是旧测试脚本总以 0 退出，没人看见。
- `tests/ios_test.sh` 不需要 Mac：检查 iOS 工程（`project.pbxproj` 的引用完整、构建阶段、每个 Swift 文件都参与编译、版本号、Info.plist、资源目录与图标）；有 `llvm-nm` 且 `scripts/build-ios.sh core` 编过时，检查 iOS 核心库导出了头文件里的全部函数；有 `swiftc`（Linux 用 swift.org 的工具链即可）时，检查所有 Swift 文件的语法，并把不依赖 UIKit 的 `Core.swift`、`Panel.swift` 连同 `tests/swift/main.swift` 链接本机的核心编译运行。没有 `swiftc` 时跳过后半部分。
- `tests/sailfish_test.sh` 不需要 Sailfish SDK：把 `shell/sailfish/src` 按 C++11 用桌面版 Qt 5 编译、连真的核心运行桥的检查；桥生成的面板页和新标签页在 headless Chrome 里按页面自己的 CSP 跑；`shell/sailfish/qml` 用 Qt Quick Test 运行，Silica、Sailfish WebView、WebEngineSettings 和文件选择器换成替身（`tests/sailfish/qml/stubs`）；最后查 ES5 和 `qmllint`。需要 `qtdeclarative5-dev`、`qml-module-qtquick2`、`qml-module-qttest`，没有 Qt 5 时跳过。

## 验证到了哪一步

全部在一台 x86-64 Linux 机器上完成（Ubuntu 24.04，无实体显示器，无 KVM，所以起不了 Android 模拟器）。

**0.18.32 Astra 的格言；二维码移植在 Sailfish 上编译不过、元数据页折叠箭头不转等审阅修正**

0.18.31 之后的提交（版本号都还留在 0.18.31 / 57，所以这一版是 0.18.32）：MCode 的"退出再进来新标签页不见了"（在 0.18.28 上另开一支，也叫 0.18.29，由 Codex 合并进来，README 里因此有两个 0.18.29）、Hy 的意大利语、Mistral 把扫码入口从菜单移到空白地址栏、k-exaone 的两处韩语用词、Gemini 的书签文件夹、Muse 把"从图片识码"和 Sailfish 相机扫码移植过来、Codex 让 ChatGPT 皮肤显示为 Astra。

- Astra 的格言：Fable 的格言 "Here beginneth thy fable." 是中世纪抄本开篇的套语 "Here beginneth"，对读者说（thy），句尾落在名字上，fable 同时是"寓言"。Astra 保留这句的形式，句尾同样落在名字上：astra 是拉丁语"群星"，ad astra 即"向着群星"（per aspera ad astra）。所以是 **"Here beginneth thy way ad astra."**，替换 Codex 临时放的 "Ad Astra."。名字和格言都由核心按皮肤给出（`theme::brand_name()`、`theme::motto()`），页面和字符串里写 `{brand}`、`{motto}`；新标签页的格言段落是 `{motto}`，字符串表多一行 `motto`（不翻译），macOS 的"关于"面板也用它（`Info.plist` 里的版权行仍是 Fable 的，切到 Astra 时由面板选项盖过）。核心测试和 C 接口测试检查：Astra 的新标签页标题、名字、格言，切回别的皮肤后都是 Fable 的。
- Sailfish 编译不过（Muse，6168ba8）：`fablecore.cpp` 用了 `qSqrt` 却没包含 `<QtMath>`；相机扫描里用 `QVideoFrame::image()`，这是 Qt 5.15 的接口，Sailfish 是 Qt 5.6；两处 `QImage::byteCount()` 在新 Qt 上已弃用、而它的替代 `sizeInBytes()` 在 5.6 里还没有，改成 `bytesPerLine() * height()`。相机帧除了 YUV420P、NV21 也认 YV12、NV12（Y 平面同样在前），其他格式用映射出来的像素按 `QVideoFrame::imageFormatFromPixelFormat` 建图。RPM spec 补上 `BuildRequires: pkgconfig(Qt5Multimedia)`，否则干净的构建环境里 `QT += multimedia` 找不到模块。`tests/sailfish_test.sh` 原来只用 Qt5Core 的参数编译，`QImage` 都找不到；现在和应用一样带 QtGui，有 Qt5Multimedia 时把相机扫描也编译一遍（`-Wall -Wextra -Werror`）。新增检查：从 PNG、JPEG 图片识码，超出解码器上限（4096 px、4 MP）的大图先缩小再识；没有码的图、不存在的文件都读成空。QML 测试补上 Silica 的 `PageHeader`、`Button` 替身和 `QrScanner` 替身，新增 `test_14_scan`：空白地址栏才显示相机和图片两个按钮，网址直接打开，别的内容推出结果页且不搜索，读不出就提示。Linux 版那两行 `if` 拆开写，消掉 `-Wmisleading-indentation` 警告（逻辑本来没错）。真机上的相机没有跑过。
- 元数据页的折叠箭头（Gemini，95d1043）：为了让书签文件夹展开时只转箭头、不转文件夹图标，展开旋转的样式改成只对 `svg.chev`。但元数据页的折叠列表（`drawFold`）用的箭头没有 `chev` 类，展开后不再转，18 px 的尺寸也丢了。已补上类名；面板测试新增两项检查（折叠时箭头横着且 18 px，展开后转下），书签文件夹展开时检查箭头转、文件夹图标和删除按钮不转。去掉修正，前两项在 WebKit 和 Chrome 里都失败。
- 扫码入口移到空白地址栏（Mistral，96a7920）：Android 新增测试 `theCameraButtonShowsOnlyInABlankAddressBar`：有相机且地址栏为空（含只有空格）时显示，输入或显示网页地址时隐藏，没有相机时从不显示。
- 新标签页在恢复时回来（MCode，fcf131b）：Android 为了让快照记下新标签页，新建的标签一开始就把 `pageUrl` 设为新标签页；可为打开某个网址而新建的标签，在网页报出地址之前也被当成新标签页，标签列表里给了它 Fable 的标志（现有测试 `theNewTabPageCarriesTheLogoAsItsIcon` 因此失败）。现在去网页时先清掉这个记号，等网页开始加载再由它报出地址；停在新标签页上的标签照旧从一开始就带着记号，恢复不受影响。
- 意大利语（Hy，2c5a812）：抽查没发现问题，只有 `m_validated`（Internet validated）译成了动作 "Convalida Internet"，改为 "Internet verificata"。
- 测试：核心 89 个（纯 Rust 与汇编各一遍）；C 链接、JNI、鸿蒙 NAPI、版本、界面测试、皮肤标志测试、Sailfish（桥接 26 项、QML 16 项）、zig、Linux 各项都通过；Android 67 个。iOS、鸿蒙、Windows、macOS 的原生界面没有编译运行过（Windows 的识图代码逐行读过：WIC 用 `#pragma comment` 链接，MSVC 与 clang-cl 都认）。
- 版本：versionCode 加到 58（Android / 鸿蒙 / iOS 一致），各处版本号 0.18.32。

**0.18.31 皮肤标志：Grok、Kimi 的光环改正，标志叠回底色就是原图**

- 问题：0.18.30 的 Grok 标志光环形状不对，左端被削掉一截，右上方穿到星球后面的地方有台阶（应用图标没事，它仍是带底色的原图）。原因是 0.18.30 借用了 DeepSeek 的轮廓去抠 Grok：两幅图的星球一样，光环的粗细和位置却不同，当时量到的"93% 在 2 px 以内"把这部分差别算成了星球左下角，判断错了。顺着这个问题把五套都和原图逐块比对，又查出几处：Kimi 光环左上那段很细，0.18.30 取边缘颜色时往里退 4 px，细的地方退不进去，取到旁边星球暗面的颜色，在黑色页面上就"消失"了；光环和星球之间的窄缝被补住（Kimi 右上方在壁纸上露出一个小黑点）；所有边缘因为换了颜色，位置偏了零点几个像素。叠回各自的底色后与原图相比（4×4 像素块的均值），0.18.30 最大差 Kimi 122.7、Grok 48.1、Gemini 35.2、DeepSeek 32.2。
- 改法（`scripts/gen_themes.py`）：不再借用别的皮肤的轮廓，每套只用自己的图稿。星球是圆的：用自己星球边缘清楚的部分拟合出圆（对边缘点做 RANSAC，再用最小二乘细化，种子固定，每次结果相同），只在边缘融进底色的地方补全（Grok 左下角，Kimi 也补了一点）。补全用的圆盘收进 1.5 px，边缘清楚的地方保持原样（DeepSeek、Gemini 和 0.18.30 逐像素相同）。轮廓只用来找围住的区域，窄缝保持敞开。每个保留的像素都取这样的不透明度和颜色：叠回底色时正好得到原图的像素。不透明度取"轮廓覆盖了多少"（内部为 1），但不低于能留住这个颜色的最小值；所以在页面上标志就是原图本身，只是去掉了底色的颗粒，在壁纸上图案不透明、边缘干净、没有底色的色边。离底色比图案阈值还近的像素一律透明，否则会在壁纸上变成星球四周一圈闪烁的杂点。五个标志共 63.5 KB。
- 测试：`tests/skin_ground_test.py` 增加一项：把标志叠回页面底色，在 Chrome 里与原图按 4×4 像素块比对，每块均值差不超过 16（浏览器缩放图稿的算法和生成时不同，锐利边缘处最多差到 10；丢掉或多出一块图案是 30 以上）。现在五套最大差 3.8–10.0；换回 0.18.30 的标志，Kimi、Grok、Gemini、DeepSeek 都失败（122.7、48.1、35.2、32.2）。其余检查照旧：四周透明、没有散落杂点，普通底色和壁纸下截图逐像素比对。
- 测试：核心 89 个（纯 Rust 与汇编各一遍）；C 链接、JNI、鸿蒙 NAPI、版本、界面测试、皮肤标志测试、Sailfish、zig、Linux 各项都通过；Android 65 个。iOS、鸿蒙、Windows、macOS 的原生界面没有渲染过。
- 版本：versionCode 加到 57（Android / 鸿蒙 / iOS 一致），各处版本号 0.18.31。

**0.18.30 皮肤标志和默认的一样只剩星球，四周透明**

- 问题（以默认的 Claude 为标准核对）：Claude 的标志只有星球，四周全透明，页面底色直接透出来，任何情况下都严格一致。0.18.29 之后，其余五套的标志仍是一整块不透明的圆角方块。方块外圈和页面完全相同，但图稿自己的底色不平整：在 Chrome 截图里，ChatGPT、DeepSeek、Gemini、Grok 方块内的底色只有 79%、51%、44%、40% 的像素与页面相同，其余差 1–4 个单位（Grok 最多 8，Kimi 最多 6），放大看是一个内框，Gemini 最明显（平均差约 1.3 个单位）。用作桌面启动器、显示系统壁纸时页面是透明的，五套都在壁纸上露出一整块方块，Claude 没有。
- 改法：`scripts/gen_themes.py` 生成新标签页标志时把底色抠掉，只留星球；应用图标不变，仍是带底色的方块。怎么认星球：比图稿边缘自身的颗粒再离底色远几个单位的像素，补上细缝、去掉碎点，再加上它围住的区域，除非那块也是底色（光环里露出的天空是底色，深色星球的暗面不是）。Grok 的星球左下角渐渐融进黑底，从像素上找不出边；它和 DeepSeek 是同一幅图（在 Grok 边缘清楚的地方，两者轮廓 93% 在 2 px 以内，缩到 192 px 不到 1 px），所以沿 DeepSeek 的轮廓抠。轮廓内保持原画；轮廓边上的颜色取自往里 4 px 处，壁纸上不会留一圈底色的边；贴着轮廓的光晕保留，按底色反混合成半透明。五个标志共 64 KB（每个 10–14 KB），比 0.18.29 的 81.6 KB 还小；Android 与 iOS 的图标文件逐字节不变，页面底色也不变。
- 测试：`tests/skin_ground_test.py` 改成以默认标志为标准，六套（包括 Claude 自己）都要通过。标志本身：四周 8 px 全透明，至少一半透明（Claude 66%），看得见的像素都贴着星球（离实心部分不超过 8 px）。渲染：在 Chrome 里分别截有标志和隐去标志的新标签页，普通底色和壁纸（启动器模式）两种；凡是标志透明的地方及其四周，两张图逐像素相同；隐去标志时那一块就是页面底色。换回 0.18.29 的方块标志，前两项失败；把比较范围强行扩到整块方块，截图比较也会报出只差 1 个单位的像素。
- 测试：核心 89 个（纯 Rust 与汇编各一遍）；C 链接、JNI、鸿蒙 NAPI、版本、界面测试、皮肤标志测试、Sailfish、zig、Linux 各项都通过；Android 65 个。iOS、鸿蒙、Windows、macOS 的原生界面没有渲染过。
- 版本：versionCode 加到 56（Android / 鸿蒙 / iOS 一致），各处版本号 0.18.30。

**0.18.29 皮肤底色就是图稿自己量出来的底色，标志改为无损**

- 问题：0.18.28 之后 ChatGPT、DeepSeek、Gemini、Grok 四套皮肤的新标签页上，中间的标志仍然带着一块看得出来的方块。原因有两层：一是 0.18.28 取的是 `scripts/gen_assets.py` 里的颜色，可皮肤真正用的图标是 `scripts/gen_themes.py` 按图稿边缘的中位色生成的，两边对不上（页面 ChatGPT `#EFEAFA`，图标 `#F0E7F8`；DeepSeek `#E0F2FC` 对 `#DEF1FA`；Gemini `#F6F8FA` 对 `#F3F7FA`；Grok `#16110E` 对 `#120C0A`）；二是新标签页的标志用有损 WebP，平整的底色也被压偏了一两个单位（Chrome 截图里 ChatGPT 方块是 `#F0E6F7`、Gemini `#F4F8FB`、Grok `#130C0A`）。Kimi（纯黑）和默认的 Claude（透明星球）本来就没问题。
- 改法：沿用 0.18.26 的做法，图稿一个像素都不改（深色皮肤的星球画在深色底上，底色是图稿的一部分），改的是页面的底色去配图稿。底色只在一个地方产生：`scripts/gen_themes.py` 从图稿边缘量出来，写进 `core/themes/grounds.rs`（核心的调色板直接引用这几个常量）和 Android 的 `theme_icons.xml`（自适应图标的背景色），两边不会再走样。现在的底色：ChatGPT `#F0E7F8`、DeepSeek `#DEF1FA`、Gemini `#F3F7FA`、Grok `#120C0A`、Kimi `#000000`。
- 新标签页的标志（`core/themes/*.webp`）改成无损 WebP，方块四周的底色正好等于页面底色。代价是体积：五个标志从共 14.4 KB 变成 81.6 KB（每个 11–19 KB），新标签页里的 data: URI 相应变大。Android 与 iOS 的图标文件没有变。
- 剩下的：图稿自己的底色不是绝对平整（颗粒、四周略亮），星球周围离底色最多差 1–4 个单位，Grok 星球旁的光晕处最多 13；不改图稿就去不掉，测试只报告这个数，不算失败。圆角边上半透明的抗锯齿像素经浏览器预乘混合，可能差 1 个单位，肉眼看不出。
- 新测试 `tests/skin_ground_test.py`（`make test` 和 Codemagic 都会跑）：用核心生成六套皮肤下真实的新标签页，在 headless Chrome 里渲染，检查页面底色等于从图稿量出的底色、标志方块的边缘不透明像素与页面底色完全一致，再从截图里取标志四周与四角四边的像素必须等于底色；同时检查 Android 图标底色、iOS 备用图标边缘也等于页面底色，并打印各皮肤图稿底色的偏差。在 0.18.28 上这项测试会失败。
- 测试：核心 89 个（纯 Rust 与汇编各一遍）；C 链接、JNI、鸿蒙 NAPI、版本、界面测试、皮肤底色测试、Sailfish、zig、Linux 各项都通过；Android 65 个。iOS、鸿蒙、Windows、macOS 的原生界面没有渲染过。

**0.18.29 退出再进来时，新标签页不见了**

- 复现：在新标签页上换皮肤（`theme://名字`），然后把应用退出再进来——新标签页没了，只剩别的标签页（开着网页标签时）。换不换皮肤都一样丢，但换皮肤时最容易撞上：换皮肤会把新标签页重画一遍，快照正好在这时写。
- 原因：退出时的快照只记"网页"，Fable 自己的页面（新标签页）不算网页，就没进快照；进来时按快照恢复，新标签页自然不在其中。Linux 上还有一处更早的时机：`gtk_notebook_insert_page()` 会立刻发出 "switch-page" 信号，而信号处理里就存快照——那一刻新标签页刚插进去，地址栏还不知道它是新标签页（要等网页视图报出第一个地址），于是它被当成"还不知道地址的标签"跳过。Android 同理：新标签页的 `pageUrl` 一开始是空的。
- 改法：快照里用**空地址**表示 Fable 自己的新标签页（`{"u":"","n":"新标签页"}`），进来时按空地址还原成新标签页。核心原来把"地址为空"当作坏数据、整份快照都拒绝（`parse_session` 里 `url.is_empty()` 就 `return None`），改成接受它；七个平台各自在存/取快照时多认这一种条目。
- 顺带：新标签页从建出来就知道自己是新标签页（Linux 在插进标签栏之前就写好地址，Android 在建标签时就把 `pageUrl` 设成首页），不用等网页视图报地址，快照也就不会漏掉它。
- 测试：核心的 `store.rs` 单元测试加了"空地址的条目能存能取"；`tests/linux_restore_test.sh` 加了真实的一轮：开两个网页标签、再开一个停在新标签页、在那儿换皮肤，然后硬杀进程，检查快照里有三个标签、其中一个是空地址（新标签页）——没有这条修复时这项检查失败（快照里只有两个标签）。Android 的 JVM 测试同样加了一条（新标签页与网页一起回来）。
- 顺带修的（本来就有的问题）：三个 Linux 测试（`linux_bridge_test.sh`、`linux_restore_test.sh`、`linux_theme_test.sh`）都只设了 `HOME`，没清 `XDG_DATA_HOME`。调用者的环境里若设了它，浏览器就把配置写在 `HOME` 之外：测试的"新标签页"会被上一轮的标签页挡住（`linux_bridge_test` 一直报"新标签页的搜索框没有加载地址"，与代码无关），`linux_theme_test` 也读到上一轮留下的皮肤，量出来的颜色是错的。现在三个测试都清掉这几个变量，配置只落在自己的 `HOME` 下。
- Linux 外壳 `make linux` 编译无警告。核心 89 个单元测试（纯 Rust 与汇编各一遍）、C 链接测试、界面测试（十项）、三个 Linux 端到端测试都通过。
- 版本：versionCode 加到 55（Android / 鸿蒙 / iOS 一致），各处版本号 0.18.29。

**0.18.28 皮肤底色对齐图标、地址栏留住输入的字、书签与下载的按钮贴底**

- 皮肤底色（openpangu，8d318d0）：五套皮肤的底色改成和各自图标图稿的底色一致，也就是 `scripts/gen_assets.py` 生成图标时用的颜色：ChatGPT `#EFEAFA`、DeepSeek `#E0F2FC`、Gemini `#F6F8FA`、Grok `#16110E`、Kimi 纯黑 `#000000`；Claude 本来就一致。只改底色这一项。这个提交有两处问题，本版修正：标题写 0.18.28，文件里的版本号却还是 0.18.27（`version_test.py --commit 8d318d0` 会报出来），版本号在本版补齐；核心单元测试把 Kimi 强调色上的颜色 `--on-spark` 也一起改成了 `#000000`，可它仍是 `#0B0B0D`，`cargo test` 因此不过，已改回。
- 地址栏留住输入的字（MiMo，c2d69ac）：Android 和鸿蒙按"前往"之后，输入的字留在地址栏里，等这次加载报出自己的网址再替换，不再先空一下（在新标签页上搜索时最明显）。本版修正：加载变成下载（输入的是文件地址）或只是页内跳转（`#锚点`）时，不会有"开始加载"的回调，原来地址栏会一直留着输入的字、盖住当前页的网址。现在这两种情况、关掉这个标签、或者再输入新地址时都会放开，地址栏回到当前页的网址。新增 Android 测试 `theAddressBarKeepsTheTypedWordsUntilTheLoadReportsItsUrl`；去掉本版的修正，它会在下载那一步失败。
- 书签与下载的按钮贴底（openpangu，9eb5cb1；MiMo，1808545）：书签页的"新建文件夹、导入、导出"和下载管理页的"刷新、打开下载文件夹"移到面板底部单独的一栏（`#foot`），不随列表滚动。这个提交的标题写"Android:"，但改的是各平台共用的 `ui/panel.html`，所以七个平台都变了。MiMo 随后让桌面弹出面板在底栏变化时也重新计算高度。手机尺寸和桌面尺寸都截图看过：按钮贴底，桌面弹窗的高度刚好容下列表和底栏。
- 测试环境：这台机器上的 Chrome for Testing 已是 153，没有 GPU 时不再自动退回软件 WebGL，面板测试里"元数据"读不到 GPU，有两项检查失败。0.18.27 上同样失败，和这几个提交无关。`tests/chrome_harness.py` 加上 `--enable-unsafe-swiftshader`，只在测试里使用。
- 测试：核心 89 个；C 链接、JNI、Sailfish、Linux（含皮肤截图取色）和十项界面测试都通过；Android 65 个。鸿蒙那边同样的修正只做了静态检查。
- 版本：versionCode 加到 54（Android / 鸿蒙 / iOS 一致），各处版本号 0.18.28。

**0.18.27 皮肤：换图标的同时换掉背景和整套界面配色，切换不再提示**

- 不再提示：换皮肤时不弹"图标已换成 …"，名字不对时也不提示、不改任何东西。`fable_theme_apply` 改成返回数字（1 已换上，0 名字不对，-1 不是 `theme://`），那两条提示语从字符串表里删了。（iOS 换应用图标时系统自己会弹一个窗，这是系统行为，应用没有接口关掉它。）
- 每套皮肤一整套配色，27 个颜色（底色、栏、卡片、文字、正文、次要文字、图标、提示、分隔线、强调色与其上的颜色、链接、引用条，以及面板的深色按钮、信息卡、开关、单选框等），定义在 `core/src/theme.rs`。默认 Claude 的配色就是原来各处写死的颜色。ChatGPT 淡紫、DeepSeek 海蓝、Gemini 靛紫是浅色皮肤；Grok（黑底金色）和 Kimi（黑底银白）是深色皮肤，强调色上的字和开关圆钮改用深色。核心的单元测试按 WCAG 检查每套的对比度：标题与正文对底色至少 7:1，次要文字、栏上的图标、阅读模式的链接至少 4.5:1，强调色按钮上的字与图标至少 3:1。
- 页面：新标签页和面板由核心在页面里补一段 `:root` 的 CSS 变量（默认皮肤不补，页面与原来逐字节相同），无痕模式自己的配色规则更具体，照旧生效；阅读模式的写死颜色改成从核心给的调色板取。面板和新标签页里画在强调色上的白色改成 `var(--on-spark, #fff)`。没有用 `color-scheme`：深色值会让浏览器把透明的面板画成深底，盖住后面的网页。
- 各平台的栏和按钮：核心新增 `fable_theme_palette`（JSON）和 `fable_theme_colour(名字)`。Android 底栏、地址框、图标、+ 按钮、进度条、状态栏和导航栏（深色皮肤时图标变浅）、网页背后的底色，启动时就按存下的皮肤上色；鸿蒙同样，深色皮肤用浅色图标，强调色上的 + 用新加的深色图标；iOS 同样；Linux 的 GTK 样式按皮肤生成；Windows 的工具栏底色和地址框，深色皮肤时标题栏变深；macOS 的工具栏是系统原生的，深色皮肤时窗口用系统深色外观；Sailfish 的栏是 Silica 的，跟随系统氛围。换皮肤后新标签页当场重绘，面板重新加载。
- 测试：核心 89 个（新增调色板完整、键不重复、对比度检查）；C 链接测试与 JNI 测试改成检查返回值和颜色；Android 64 个（换皮肤后底栏、地址文字、状态栏颜色与图标深浅、进度条、面板、新标签页底色都是 Kimi 的，没有提示；无痕仍是深色；换回默认后复原；带着存下的皮肤启动时底栏已是 Grok 的）；Sailfish 的 QML 用例；`tests/linux_theme_test.sh` 改为从真实 `build/fable` 的截图取像素：工具栏和新标签页正好是 Kimi 的颜色，窗口底部（提示出现的位置）只有一种颜色，名字不对时工具栏不变。故意把提示加回去，这项检查会失败。用 headless Chrome 把六套皮肤下的新标签页、菜单、设置都截图看过。iOS、鸿蒙、Windows、macOS 只做了静态检查。
- 版本：versionCode 加到 53（Android / 鸿蒙 / iOS 一致），各处版本号 0.18.27。

**0.18.26 图标包：`theme://名字` 换上 Gemini 做的配色图标**

- 地址栏输入 `theme://DeepSeek`、`theme://Gemini`、`theme://Grok`、`theme://Kimi`、`theme://ChatGPT`（大小写不限，末尾带 `/` 也行）换图标，`theme://Claude` 换回默认。当前页面不动，提示"图标已换成 …"；名字不对时提示可用的几个，什么也不改。`theme:kimi`（没有 `//`）仍按 0.18.25 当搜索词。
- 核心：新模块 `theme.rs` 记住选择（设置 `icon_theme`，默认不存），`fable_logo_uri` 和新标签页给出当前图标包的标志；新增 `fable_theme_apply`（只给用户输入的地址用，返回要提示的话，不是 `theme://` 时返回 NULL）和 `fable_theme_current`。提示语十二种语言。
- 图：Gemini 的六张图（`assets/icon-variants/`）各带底色，Grok、Kimi 的星球本身就是深色，抠掉底色星球也就没了，所以每套做成"原图连底色"的方块，边缘羽化进底色，不留接缝。`scripts/gen_themes.py` 生成：核心里的 192 px 圆角标志（`core/themes/`，共 15 KB）、Android 的自适应图标与 Android 7 用的旧式图标、iOS 的 1024 备用应用图标。默认的 Claude 仍用原来的透明星球，外观不变。
- 各平台：七个平台的新标签页标志、面板标签列表里新标签页的图标都跟着换，已打开的新标签页当场重绘。Android 另外换桌面启动器图标：启动入口改成六个 `activity-alias`（`.Icon_<名字>`），只启用当前那个，先启用新的再停用旧的，`DONT_KILL_APP`；启动时也对一遍（清过数据就回到默认图标）。iOS 用 `setAlternateIconName` 换备用应用图标（系统会弹窗）。鸿蒙、Sailfish、Linux、Windows、macOS 没有让应用换自己系统图标的接口（或只能换运行中的窗口图标），只换应用里的标志。
- 网页不能换图标：0.18.25 让 iOS、macOS、鸿蒙放行网页跳往 `theme://`（会落到引擎的错误页），现在各平台的导航拦截一律拒绝 `theme://`，只有地址栏（以及新标签页的搜索框）能用。
- 注意（Android）：换启动器入口后，有的桌面会把原来摆在桌面上的图标移除，新图标只出现在应用抽屉里，要重新拖到桌面；升级到这一版时也会这样一次，因为启动入口从 `MainActivity` 换成了 `.Icon_claude`。
- 顺带修的（收到的 0.18.25 里就有的问题）：
  - Android 编译不过：0.18.24（Muse）的传感器去重 `dedupeSensors` 会抛 `JSONException`，`sensors()` 没接住。现在出错就用系统给的原始列表；Muse 写的两个去重测试这才第一次真正跑起来，都通过。
  - 鸿蒙编译不过：扫码（Gemini）的 `n_qr_decode` 调用了不存在的 `null_result`。补上这个函数。新增 `tests/harmony_napi_test.sh`（并入 `make test`）：不用鸿蒙 SDK，对着一个 Node-API 声明的替身编译 `fable_napi.c`（`-Werror`），核对它调用的核心函数都存在、注册给 ArkTS 的和 `index.d.ts` 声明的一致。
  - JNI 测试失败：加了德语之后，"de-DE 回退英文"这条不再成立。改成德语、葡萄牙语各查一条，回退换意大利语查。
  - Sailfish 的 `harbour-fable.spec` 版本还停在 0.18.24：`tests/version_test.py` 现在也查它。
  - Gemini 的鸿蒙扫码提交标题写的是"0.18.23"，与已有的 0.18.23 重名；它没改版本号，只是标题标错。
- 测试：核心 88 个单元测试（新增 4 个：地址解析、切换与回退、base64、六张图都在）与 C 链接测试；Android 64 个（新增 3 个：地址栏换图标——启动器只列一个入口、图标对、网页链接不跟随、名字不对与换回默认；启动时按存下的设置对齐启动器图标；新装时只有默认入口且仍是"浏览器应用"）；JNI；Sailfish 的 QML 用例 13 个（新增 1 个）；新增 `tests/linux_theme_test.sh`：真实的 `build/fable` 里用键盘输入 `theme://Kimi`，设置落盘、新标签页截图前后不同（约 9000 像素），再开一个自己跳 `theme://grok` 的网页，设置不变；iOS 检查五个备用图标都是 1024 无透明 PNG、构建设置与代码里的名字一致。没有在 iPhone、鸿蒙、Windows、macOS 上运行过；Windows 的 `main.cpp` 这次没能编译检查（手写的 Win32 声明替身跟不上新加的头文件）。
- 体积：Android 安装包多约 70 KB（启动器图标 42 KB，核心里的标志两种 ABI 各 15 KB），现在约 2.2 MB。
- 版本：versionCode 加到 52（Android / 鸿蒙 / iOS 一致），各处版本号 0.18.26。

**0.18.25 把 `theme://` 加进协议白名单**

- Fable 自己的协议多了一个 `theme://`（主题页）。地址栏照原样交给网页视图（`theme://dark` 这样带主机名的才算网址，`theme:dark` 还是搜索词），也不再被当成"跳去别的应用"。
- 改的地方：核心 `external.rs` 的"浏览器自己处理的协议"名单加上 `theme`——六个平台共用这一份，所以"拦截外部应用跳转"开着时 `theme://` 也不会被拦；iOS 的导航协议表、macOS 的 `ours`、Android 的 `navigate()`、鸿蒙的 `loadIntercept` 各加一条。Linux 与 Windows 没有自己的协议表，走核心的判断。
- `theme://` 现在只是"浏览器认得、不会当成外部应用"，还没有谁真的提供主题页：网页视图里没有这个协议的处理器，导航过去会得到引擎自己的错误页。要做成能用的主题协议，还得注册处理器（Linux 的 `webkit_web_context_register_uri_scheme`、macOS/iOS 的 `setURLSchemeHandler`、Android 的 `shouldInterceptRequest`）并决定主题页给什么内容。
- 测试：核心 `external.rs` 的单元测试加了两条（`theme://dark`、`theme://light/` 不是外部应用跳转），C 链接测试同样加了断言。核心 84 个单元测试（纯 Rust 与汇编各一遍）与 C 链接测试通过，Linux 外壳 `make linux` 编译无警告。版本：versionCode 加到 51（Android / 鸿蒙 / iOS 一致），各处版本号 0.18.25。

**0.18.24 Android 传感器去重：同一个传感器不再出现两次**

- 元数据“传感器与相机”一节：有些设备的 HAL 会把同一个物理传感器报两次（唤醒版和非唤醒版，名字、厂商、类型完全一样），现在 `SystemInfo.sensors()` 按名字 + 厂商 + 类型分组，只留一条：优先留唤醒版，唤醒版缺的字段（功耗、量程）从另一条补上。
- 合并是保守的：只有一组里同时有唤醒和非唤醒才合；唤醒标志相同的同名条目不动，可能是两个同型号的真传感器。相机没有这个问题（每个相机 id 唯一），不动。
- 测试：`MainActivityTest` 新增 `duplicateSensorsAreMerged` 和 `sameWakeSensorsAreNotMerged`，直接测 `SystemInfo.dedupeSensors`（纯 JSON，不依赖真机传感器）。
- 验证：Android JVM 测试没跑（这台机器没有 Java/Android SDK）；核心测试和面板检查不受影响。版本：versionCode 加到 50（Android / 鸿蒙 / iOS 一致），各处版本号 0.18.24。

**0.18.23 Sailfish OS：把 Hy 的移植修到能用**

- 审阅 0.18.22 发现面板在设备上不会工作：面板在自己的脚本开始时只选一次走哪条桥，Hy 在页面加载完之后才注入 `FableUI`，面板于是落进预览模式，显示的是假数据；面板发出的动作外壳也没有接（`actionRequested` 没连），动作消息还多一个空字段，交给面板的状态里没有标签和设置。现在 `Panel.panelHtml()` 把替身放在 `<head>` 最前面，按 iOS 的消息协议走，用手机的底部弹出层。
- 消息怎么走：Sailfish 的 `runJavaScript` 在页面里执行（受页面 CSP 约束）还是在特权沙箱里执行（页面设的变量可能被 Xray 隔开），文档没写，所以做成两种情况都能用：消息放在 `<html>` 的一个属性里，发给面板的脚本作为 `fable-run` 事件由页面自己执行，面板和新标签页的 CSP 加上 `'unsafe-eval'`（两页都不加载外部内容）。
- 会让 QML 加载失败的错误：给 WebView 设了它没有的 `javascriptEnabled`；`property quint64` 不是 QML 的类型；`linkClicked` 的参数是 `url` 不是 `linkUrl`；主 QML 没有 `import "pages"`，找不到 `BrowserPage`；`qmlRegisterSingletonType` 用了带捕获的 lambda（Qt 5.6 要函数指针）。封面原来从按网址加载的文件里直接用窗口的 id，现在改成属性和信号，两个按钮也接上了。
- 设置键是编出来的（homepage、user_agent、images、cookies_third、dnt）：改成核心和面板实际用的 `data_saver`、`block_3p_cookies`、`ua_mode`/`ua_custom`、`home_button`、`restore_tabs`。
- 只显示 Sailfish 能做到的设置，面板新增三个 caps：`WebEngineSettings.javascriptEnabled` 管整个引擎，关掉会连面板一起停，所以不显示 JavaScript 开关（`javascript`）；没有文字缩放（`textSize`）；只有一个 WebView，后台标签本来就不加载（`tabSleep`）。清除数据只有历史（`clearSiteData`）。
- 恢复标签页：原来多开一个空白页、当前标签的序号错一位、不看开关、只在退出时保存。现在只保存普通标签里的网页，页面加载完、开关标签、应用转到后台、退出时都保存；Fable 自己的页面（新标签页）不算网页，不进历史，但**进快照**（记作一个空地址），这样开着新标签页退出再进来，它还在（0.18.29）。
- 补上的功能：核心的新标签页（搜索框经 `FableHost.go` 的替身交给外壳，只在显示新标签页时读）、主页按钮、书签导入（系统文件选择器）与导出（"下载"文件夹，不覆盖旧文件）、公网 IP、系统信息、阅读模式、复制、资源嗅探、桌面版网站。面板里的"下载"交给系统浏览器。图标换成 Fable 的标志（原来是占位的字母 F）。
- 打包：Sailjail 权限改成 `Internet;WebView;UserDirs;Audio`（原来的 Downloads、Pictures 不在 Harbour 允许的清单里，又缺 WebView）；链接补上 Rust 标准库要的 `-lpthread -ldl -lm`；去掉不存在的翻译文件；SPEC 里编的许可证（MPL-2.0）和 GitHub 地址去掉，项目还没选许可证，发布前要填；`scripts/build-sailfish-core.sh` 找源码目录多退了一级。
- 验证：新增 `tests/sailfish_test.sh` 并入 `make test`。C++ 按 C++11 编译，桥的检查 22 项；桥生成的面板页、新标签页在 Chrome 里按页面 CSP 跑 7 项（去掉 `'unsafe-eval'` 时这几项失败）；QML 用 Qt Quick Test 加替身模块跑 12 个用例，把 Hy 原来的两处错误（恢复时多开空白页、错的设置键）放回去，相应用例失败。面板 iOS 模式的检查加到 30 项（含 Sailfish 的 7 项）。核心交叉编译到 armv7hl、aarch64 通过。没有 Sailfish SDK 和设备：真实 Silica 的外观、`runJavaScript` 的实际行为、RPM 构建都没验证，见 `shell/sailfish/README.md`。
- 版本：versionCode 加到 49（Android / 鸿蒙 / iOS 一致），各处版本号 0.18.23。

**0.18.22 Sailfish OS 移植：Hy 把共享核心带到第七个平台**

- 新增 `shell/sailfish/`：Silica 的 `ApplicationWindow` + `Sailfish.WebView`（Gecko / embedlite）外壳，C++ 单例 `FableCore` 把核心的 60+ 个 `fable_*` C ABI 封装成 QML 可调用的 QObject，`PanelBridge` 用注入式 `FableUI` 队列 + `runJavaScript` 适配 Gecko 的面板消息桥。应用名遵守 Harbour 的 `harbour-` 前缀，图标 86/108/128/172 四种尺寸，Sailjail 权限按最小集声明。
- 核心逻辑完全复用：地址栏解析、书签/历史/设置、资源嗅探、元数据、阅读模式、新标签页与面板 HTML 都由共享 Rust 核心提供；只新写了平台外壳。`scripts/build-sailfish-core.sh` 把核心交叉编译到 armv7hl / aarch64。
- 能力分级，不做"开了没用"的开关：Sailfish WebView 基于 Gecko，没有 WebKit / Android 那样逐请求拦截的回调，网络层的追踪/广告拦截改为页面内 CSS/JS 隐藏广告位 + 导航守卫拦外部跳转，并通过 `state.caps.networkBlock=false` 在面板里隐藏不支持的开关。无痕、UA 伪装、图片/JS/Cookie 控制、页内查找之外的能力照常可用。
- 验证：Rust 核心 87 项测试全通过；C++ 桥接层用真实 Qt5 工具链（moc + g++）编译、链接核心库并运行测试通过（版本、地址解析、i18n、书签增删查、设置读写、`Fable.reply` 回推）；4 个 QML 文件通过 `qmllint`，12 个翻译 key 全部核对存在。沙箱内没有 Sailfish SDK 与设备，交叉编译与真机运行尚未执行——上线前待办见 `shell/sailfish/README.md`。
- 版本：versionCode 加到 48（Android / 鸿蒙 / iOS 一致），各处版本号 0.18.22。

**0.18.21 Android 扫码：Codex 的离线解码 + LongCat 的相机界面，修到能构建**

- Codex 在核心里加入离线二维码解码（内置 quircs 0.10.3，与 crates.io 原包校验和一致；改动只有防御性修复）。用 6000 张随机改坏的二维码图片测试，没有一次崩溃；一帧 1280×720 约 6 毫秒（本机）。只有 Android 用到它：arm64 库增加约 36 KB，其他平台链接时会去掉。
- LongCat 做了 Android 的扫码界面：第一次用时才申请相机权限，没有摄像头就不显示"扫码"，扫到网址直接打开、其他内容先显示出来让用户选。
- 修好 Android 编译：相机接口抛出的 `CameraAccessException` 要显式处理，有 5 处没处理，APK 构建不出来。
- 扫到的内容先按 UTF-8 解读，不是 UTF-8 时再按 GBK（GB18030）解读，最后按二维码标准默认的 ISO-8859-1。原来国内常见的 GBK 二维码会显示成乱码。
- 修好 LongCat 的两个测试：一个漏了 `throws Exception`，编译不过；另一个点完对话框按钮没有让主线程处理点击。
- 0.18.19 Command 那个提交的作者邮箱原来是 opencode 的默认值 `assistant@opencode.io`，已改成它自己说明里写的 `noreply@cohere.com`；说明里字面的 `\n` 也改成了换行，`Co-authored-by` 才生效。之后的提交内容不变，但哈希都变了。
- 测试：Rust 84 项和二维码 3 项（三种构建）、FFI、JNI、界面 10 轮、Android JVM 59 项、Linux 两个端到端测试都通过；APK、HAP、Linux、Windows 都编译通过。macOS 和 iOS 没有改动。

**0.18.20 审阅 0.18.17 之后的五个提交，修到各平台都能构建**

0.18.19 的提交保留原样、作者不变（版本说明见下面 0.18.19 一节）；只删掉了一个只加了 `version_bump.txt` 的提交（ef11db5）。0.18.19 在 Android、Linux、Windows、macOS 上都编译不过，Linux 的广告拦截也失效了，这一版逐项修好：

- 广告清单（Mistral 的改动）：只在需要域名原文的平台保留原文——iOS、macOS 要编进 WebKit 规则，Linux 要交给网页进程去拦截；Android、Windows、鸿蒙只留哈希，省下约 2 MB。原来的做法让 Linux 网页进程拿到空清单，广告完全不拦；三个测试被改成只在苹果平台编译，等于没人跑，FFI 测试也失败。现在改成一个常量 `KEEP_TEXT`，测试在哪都编译、都跑。
- Android 后台加载广告清单：修好编译错误（lambda 用了非 final 变量）；请求会等清单载入后再判断，启动后第一页的广告不会漏拦；每周更新也排在启动加载之后，不会被旧清单盖掉。
- 页内查找（Nemotron 的改动）：Linux 用的 `webkit_web_view_find_text`、Windows 用的 `ICoreWebView2::Find` 都不存在，改用 WebKitGTK 的 `WebKitFindController` 和 WebView2 的 `ICoreWebView2Find`；WebView2 运行时太旧时菜单不显示"查找"。macOS、iOS 改用 WKWebView 自己的 `find`，鸿蒙改用 ArkWeb 的 `searchAllAsync`，不再调用页面里能被改写的 `window.find`。原来记着的网页视图指针在关标签页后会悬空，现在每次都找当前标签页。面板的查找页从占九成屏幕、带遮罩的高面板改成矮面板，网页和高亮都看得见；匹配数（原来从没填）由各平台回报；补了 14 项面板测试。
- 扫码（Nemotron 的改动）：macOS 的扫码窗口类写在了另一个类的实现里面，编译不过，已移出；`AVCaptureMetadataOutput` 在 macOS 13 才有，旧系统上不显示"扫码"，也不会调用它；扫完关窗口时会在自己的回调里释放自己，改成回调结束后再释放。扫到的不是 http/https 网址时，先显示内容让用户选复制或搜索——原来 Wi‑Fi 密码、名片等会直接当搜索词发给搜索引擎。
- 文字：法语"页内查找"里混了西班牙语 *página*，已改；荷兰语加进了面板的语言列表；扫码结果对话框新增两条文字（十种语言）。
- 版本：0.18.19 的版本提交把 0.18.17 的说明直接改名成 0.18.19，测试注释里的版本号也一起改了，已改回；versionCode 加到 46。
- 测试：Rust 84 项（三种构建）、FFI、JNI、界面 10 轮（面板 165、桌面 35、iOS 23）、Android JVM 54 项（新增一项：启动后第一页的广告也被拦）、Linux 两个端到端测试都通过，Linux 的页内查找在真实窗口里试过（"第 1 处，共 3 处"，回车到第 2 处）；APK、HAP、Linux、Windows 都编译通过。macOS 和 iOS 只做了静态检查。

**0.18.19 省内存、页内查找、扫码、荷兰语（他人提交，0.18.20 修好后才能构建）**

- Mistral：非苹果平台不再保留广告域名原文；Android 在后台线程加载广告清单。
- Nemotron：六个平台的页内查找；iOS 与 macOS 扫二维码；核心与文本表加入荷兰语。
- Command：版本号改为 0.18.19。

**0.18.17 书签和恢复标签页补到所有平台**

- Android、Windows、macOS、iOS、鸿蒙都接好了书签和启动时恢复标签页，和 Linux 一样：菜单里有加星和书签列表，设置里有恢复标签页开关。导入导出走各平台自己的文件选择器：Android 用系统文档选择器，Windows 用系统打开/保存对话框，macOS 用打开/保存面板，iOS 和鸿蒙用"文件"。文件最大 4 MB，读不了或写不了会提示。
- 恢复标签页：只有之前在前台的那个标签页马上加载，其余标签页只带地址和标题，切过去时才加载（Linux 仍是全部加载，靠休眠回收）。无痕标签页、新标签页和别的应用分享来的文档都不记录。别的应用传来的链接会在恢复的标签页之上新开一页。Fable 作为 Android 桌面启动时，先显示主屏幕。
- 保存时机：页面加载完、关掉标签页时保存，应用切到后台或退出时也保存，所以进程被系统杀掉或崩溃后，标签页也能回来。macOS 上用 Cmd+Q 退出会保留标签页，关掉窗口就是关掉那些标签页。
- 关掉"启动时恢复上次标签页"后，核心会立刻删掉已存的标签页列表，之后也不再保存。
- 修了 0.18.9 Linux 恢复的问题：恢复前先关掉唯一的空白标签页，会把窗口一起关掉；第一个窗口的空白标签页还会先存一次空列表，把要恢复的列表覆盖掉；恢复的标签页顺序也是反的。Linux 带链接启动时，现在也会先恢复再打开链接。
- 鸿蒙新增四个原生接口（sessionCount、sessionActive、sessionUrl、sessionTitle），用来读取标签页列表；其余功能都走已有的 panelQuery。
- 新测试：Android 新增 5 项 JVM 测试（加星、导入导出、重启后恢复、开关关掉、作为桌面启动）；Linux 新增端到端测试 `tests/linux_restore_test.sh`（强行结束后再启动、带链接启动）；核心测试覆盖开关关掉的情况；桌面面板测试和 iOS 面板测试检查加星和导入导出；`tests/swift/main.swift` 检查 iOS 的会话和书签封装（有 swiftc 时才跑）。macOS 和 iOS 只做了静态检查。

**0.18.16 合并 0.18.9（书签、恢复标签页）与 0.18.15（下载管理、广告清单更新、全屏视频等）**

- 两条分支的提交都保留在历史里，作者不变：0.18.9（Muse、Mistral）带来书签和启动时恢复标签页，0.18.15（Codex、GLM）带来下载管理、广告清单每周更新、全屏视频和删除历史前的确认。
- 存储层同时保存下载、书签和会话；菜单里下载、加星和书签三个入口并存，书签用新的书本图标。
- 书签和恢复标签页目前只有 Linux 外壳接好，所以这两项按 caps 显示：外壳不支持时，菜单里没有加星和书签入口，设置里也没有恢复标签页开关，不会出现点了没反应的按钮。
- 搜索书签时文件夹自动展开，能看到里面命中的条目。
- 修好两份上传各自没过的测试：书签测试把文件夹里的行也算成顶层行，删除文件夹的检查删错了文件夹；桌面面板测试没跟上删除历史要先确认的新流程。
- 0.18.15 让文件写入返回结果，书签和会话的写入补上对结果的处理，编译不再有警告。
- 已知限制：苹果的 WKContentRuleList 单个列表最多 15 万条规则，核心上限是 20 万个域名；现在的清单约 4 万个，暂时碰不到。
- 测试：Rust 84 项（普通、汇编、Zig 三种构建）、FFI、JNI、版本检查、界面 10 轮（面板 147 项、桌面 30 项、iOS 17 项）、Android JVM 48 项全部通过；APK、HAP、Linux、Windows 均已构建。

**0.18.15 删除历史记录要先确认**

- 历史记录页里，点一条记录旁边的 × 不再直接删：先弹出确认页，写明要删的是哪一条（标题或网址），点「删除」才真的删，点「取消」或返回就什么都不删；「清空全部历史记录」也一样，先确认再清空，删完无法恢复
- 设置 ›「清除浏览数据」里也是：如果勾了历史记录，点「清除所选数据」会先问一句「确定要清除选中的数据吗？删除后无法恢复。」；只勾 Cookie 或缓存时不问，直接清（和原来一样）
- 确认页是面板里新加的一个页面，三个删除入口共用：单条删除、清空全部、清除数据里带历史记录。确认前什么都不删。搜索框的内容在确认来回之间还留着，列表的滚动位置也不变，不会因为多了一步就把正在搜的词丢了
- 删完之后列表会刷新：确认按钮先回到历史记录页再执行删除，删除的回调会重画当前列表（同步与异步的桥都一样）；如果用户已经离开了历史记录页，回调不会乱画别的页面
- 检查：Rust 核心测试 76/76（普通与 asm 两个变体；核心没动），C 链接测试通过，面板检查 123→130（新加 7 项：清除数据问不问、单条删除问不问、取消不删、确认回列表、清空全部问不问），在 WebKitGTK 里跑过 130/130；确认页在手机尺寸（390×844，简体中文）下渲染过，长标题换行显示完整，两个按钮没有截断。词条 477→482（新加 5 条：确认标题、取消、单条/清空/清除数据的确认文案，9 种语言）。六个外壳没有改（确认全在面板里），也不需要编译；Android JVM 测试需要 Java；真机表现未验证

**0.18.14 广告清单：纯自动更新，来源社区清单**

- 0.18.13 的手动更新和它的界面都拿掉了：更新页、地址框、「立即更新」按钮、设置里的「广告清单更新」一行、相关的 10 条词条，都不在了。面板里不再有任何广告清单的界面——更新是纯自动的
- 来源是内置的社区清单：EasyList 与 EasyPrivacy（`https://easylist.to/easylist/easylist.txt`、`https://easylist.to/easylist/easyprivacy.txt`，2026-11-21 确认两个地址都是通的，EasyList 当天刚更新过）。不用用户填地址，也不用替清单选来源
- 这两个是过滤器清单，不是域名清单，所以核心新增了一个解析器，只提整域名拦截：`||域名^` 规则（开头的 `*.` 与域名等价，因为拦截本来就是按后缀匹配）与纯域名行，减掉 `@@` 例外；跳过域名清单表达不了的东西：路径规则（`||域名/路径`）、按站生效的规则（`$domain=…`）、只对第一方生效的规则（`$~third-party`）、`badfilter`，以及所有的隐藏元素与地址样式规则。拦截本来就只拦第三方请求，所以裸 `||域名^` 与 `$third-party` 在这里是一回事
- 实测：在真实下载的部分文件上（EasyList 约 957KB、EasyPrivacy 约 416KB，这台机器的网络截断了完整下载），解析器从两份里共提出 40,653 个不重复域名，和独立写的参考解析结果逐个一致；完整清单只会更多（EasyList 全文约 2MB）。清单上限随之放宽：域名数 20,000 → 200,000，文件 1 MiB → 4 MiB；每个来源最多拉 8 MiB
- 触发条件不变：每周一次，启动时检查；但只在「拦截广告」开着的时候才拉——关着就不产生流量。某个来源失败就跳过它，用其余来源更新；下载坏了则什么都不换，旧清单继续用，下次启动再试。更新状态（上次更新时间、条数）仍记在用户数据里（`ads_updated_at`、`ads_domains` 与 `ads.txt`），可以查，但没有界面；0.18.13 留下的 `ads_update_url` 会被忽略
- 检查：Rust 核心测试 76/76（普通与 asm 两个变体；新增解析器测试：提取、例外、拒绝坏输入），C 链接测试通过，新 FFI 符号 `fable_ads_update_sources` 在包里，旧的 `fable_ads_update_url` 已不在。面板检查 129→123（拿掉的 6 项是更新页的检查），在 WebKitGTK 里跑过 123/123。六个外壳的代码是按各家现成取法改的，但这台机器没有它们的工具链（没有 Java/Gradle、Xcode、鸿蒙 SDK、MinGW），没有编译过；Android JVM 测试需要 Java；真机表现未验证

**0.18.13 广告清单自动更新**

- 设置 › 隐私 ›「广告清单更新」里可以填一个更新地址：填了之后，启动时如果距上次成功更新已过一周，浏览器会在后台拉取新清单；同一页里「立即更新」是马上拉一次。默认不填地址就是不开自动更新——清单是用户自己选的来源，浏览器不会替用户决定去哪家拉
- 拉回来的东西必须能当清单用（和 `ads.txt` 同样的规矩：一行一个 ASCII 域名，不超过 1 MiB、20,000 条），否则原样丢掉，旧清单继续用；成功才写进用户数据目录的 `ads.txt`（覆盖文件）并记下更新时间和条数。拉取不用 Cookie、不带缓存，10 秒超时，最多只读 1 MiB 多 1 字节
- 新清单立即生效：Android、Windows、鸿蒙每次请求都问核心，直接就用新的；macOS 与 iOS 重新编译内容规则；Linux 的网页进程收到新清单的消息，不必等它重启
- 核心自己没有 HTTP 客户端（刻意保持无依赖、离线可编），所以拉取在六个外壳里各做一份，用的都是各家现成的取法（Android 的 HttpURLConnection、Linux 的 libsoup、macOS 与 iOS 的 URLSession、Windows 的 WinHttp、鸿蒙的 @ohos.net.http）
- 检查：Rust 核心测试 74/74（普通与 asm 两个变体；新增 2 项：更新时机与安装/拒绝逻辑），C 链接测试通过，面板检查 123→129（新加 6 项：更新页的地址栏、两个按钮、更新中与失败的状态）。面板检查与手机尺寸渲染没有在这台机器上重跑（WebKit 测试包在虚拟机重启后没了）；六个外壳的代码是按各家现成取法写的，但这台机器没有它们的工具链（没有 Java/Gradle、Xcode、鸿蒙 SDK、MinGW），没有编译过；Android JVM 测试需要 Java 与 Android SDK

**0.18.12 “字体大小”滑块每 50% 一个刻度**

- “字体大小”（桌面端叫“页面缩放”）滑块下方原来只有 50%、100%、200%、300% 四个刻度，现在每 50% 一个：50%、100%、150%、200%、250%、300%，各在自己的值正下方；实现上把原来写死的四个值改成从 50 到 300 每 50 循环生成。滑块本身不变（50%–300%，步进 5%），刻度是数字，不需要新词条；RTL 下刻度随滑块一起镜像
- 检查：面板检查多 1 项（共 123 项：六个刻度与位置一次对完）；Rust 核心测试、C 链接测试通过。面板检查与手机尺寸渲染没有在这台机器上重跑（WebKit 测试包在虚拟机重启后没了）；Android JVM 测试需要 Java 与 Android SDK

**0.18.11 广告域名清单可独立更新**

六个平台都从独立的 `ads.txt` 加载广告域名。默认清单位于源码的 `rules/ads.txt`，随应用离线分发。Windows 分发时请把它放在 `fable.exe` 旁边。Linux 的 `make install` 会把它安装到 WebKit 扩展目录。

要覆盖默认清单，把自定义 `ads.txt` 放在与 `settings.tsv` 相同的用户数据目录，然后完全退出并重新启动浏览器。Linux 默认为 `~/.local/share/fable/`（遵循 `XDG_DATA_HOME`），Windows 为 `%LOCALAPPDATA%\Fable\`，macOS 为 `~/Library/Application Support/Fable/`。移动端使用应用私有数据目录。每行写一个 ASCII 域名，子域名自动匹配。支持空行、以 `#` 开头的注释、大小写和重复域名。文件上限为 1 MiB、20,000 行域名。删除覆盖文件可恢复默认清单；文件为空、格式错误或超限时也会使用默认清单。

**0.18.10 基于 0.18.8 修复 Cookie 与浏览历史**

- Android 的网页下载和资源面板下载都从发起下载的 WebView 读取 Cookie。第三方 Cookie 开关现在可以保存。
- 清除历史失败时保留记录并显示提示，用户可以重试。删除两次同网址访问之间的记录后，重启仍保留这两次访问。

**0.18.9：书签与退出后恢复标签页**

- 书签：核心新增书签表（数据目录里的 `bookmarks.tsv`），支持文件夹；面板新增书签页（搜索、折叠、删除、新建文件夹），菜单有书签入口，网页页可点星标收藏（Linux 地址栏右端星标）；支持 Chrome/Firefox 的 NETSCAPE HTML 书签导入/导出
- 会话快照：退出或崩溃后下次启动默认恢复上次的普通标签页（URL、标题、顺序，存于 `session.json`），设置 › 标签页里可关闭；无痕标签不会进入快照

**0.18.8 审阅 0.18.3 之后的九个提交（GLM、Kimi、Gemini、MCode、Grok、Qwen、OpenPangu）：修了什么**

- "阻止跳转到其他应用"一打开，iOS、macOS、Linux 的**新标签页就打不开了**：这三个平台的新标签页是 `fable://newtab`，外壳先问核心"这是不是跳去别的应用"，而核心的名单里没有 Fable 自己的 `fable:`，于是每个新标签都被拦下并提示"已阻止"。`fable` 加进核心的"浏览器自己处理"名单，测试补上 `fable://newtab`
- "屏蔽广告"的页面部分（隐藏广告框）**完全不起作用**：样式表里只有一串选择器，没有 `{display:none}`，浏览器把它当成无效规则整个丢掉，0 条规则生效。现在每个选择器各成一条 `display:none!important` 规则（一条不认识的选择器不会连累其他的）；在 Chrome 里用核心生成的脚本实测：`.adsbygoogle`、`.ad-container` 被隐藏，`.read` 这类正常内容不受影响；Rust 测试检查每条规则都带隐藏声明
- Windows **链接失败**：0.18.7 把 Rust 固定到 1.100.0，这一版的标准库要 `synchronization.lib`（`WaitOnAddress` 等），`shell/windows/CMakeLists.txt` 没有列它。已补上，交叉编译链接通过
- 鸿蒙构建在固定的工具链下找不到 `aarch64-unknown-linux-ohos`：`build-harmony.sh` 和 `build-android.sh` 一样先 `rustup target add`
- 文字大小滑块的刻度"100%""200%"是平均排开的，落在三分之一、三分之二处，而它们在滑轨上的位置是五分之一、五分之三：现在每个刻度放在自己的数值下面（阿拉伯语镜像），面板检查多一项
- Android 地址栏：0.18.7 里 Qwen 让 `ftp://`、`myapp://` 这类地址照原样通过，而 Android 只打开网页，结果是输入这类地址会**悄悄跳回主页**。现在提示"只打开网页链接，这个链接没有打开"，当前页面不变；JVM 测试多一步
- 审过没有改的：GLM 的 Material 刷新图标、Kimi 的连续滑块、Gemini 的 11 种 UA 与角标/RTL 修正、MCode 的广告域名表与按请求判断、Grok 的 CI 固定版本（Rust 1.100.0、Xcode 26.6、Zig 0.14.1、Chrome for Testing 都核对过存在）、页面桥接与协议加固、Qwen 的地址栏黑名单、OpenPangu 给新标签页加的 CSP（新标签页用到的内联脚本与样式、`data:`/https 图标、同源请求都在允许范围内）
- 检查：`make test` 全部通过（Rust 66 个，普通、汇编、Zig 三种；C、JNI、版本一致、界面测试 10 组，面板 122 项、冒烟脚本自检、Zig 表、Linux 桥接）；Android JVM 43 个；APK、鸿蒙 HAP、Linux、Windows 都能构建。iOS、macOS 只做了静态检查

**0.18.7 一份源码审计（针对 0.18.5）里的高危、中危问题：逐条核实、修复与验证**

审计报告列了高危 4 条、中危 10 条。每条都先在 0.18.6 上重新核实（有的 0.18.6 已经改掉一部分），确实存在的才改，并尽量补上一个修复前会失败、修复后通过的测试。第一遍只有各条的摘要；拿到报告全文后又逐条对了一遍报告里的位置、攻击路径和修复建议，补上了摘要里没有的部分（下面各条里"全文"之后的内容）。

- 高危 1（CI 不跑汇编，三种实现相等的测试自己和自己比）：属实。CI 只跑 `cargo test --release`，不开 `asm` 时 `fnv1a_lower` 就是 `fnv1a_lower_portable`。现在 CI 在 arm64 上跑 `--features asm`，再借 Rosetta 跑 x86_64 的汇编（没有 Rosetta 直接失败，因为通用版里带着 x86_64 的汇编）；新增 `asm_feature_links_the_routine`（开了 `asm` 而汇编没链进来就失败）和一组在仓库外（Python）算好的哈希值，参考实现自己也被检查。把汇编里的 FNV 质数改错一位，三个测试一起失败。全文还要求比对 Zig 与 Rust 两边建的拦截表：新增 `tables_in_use_equal_the_rust_built_ones`（表长一样、Rust 表里每一项 Zig 表都有、相邻的值不多认）和 `tests/zig_table_test.sh`（`zig build test`，再用 `--features zig-native` 链上 Zig 的表和汇编跑核心测试），CI 用固定版本、核对过 SHA-256 的 Zig 0.14.1（`scripts/ci/install-zig.sh`）跑它，`make test` 在有 zig 时也跑。故意让 Zig 少读一行，这个测试失败
- 高危 2（0.18.4 没把版本号写进文件）：属实。696bae9 的标题是 0.18.4，文件里全是 0.18.3 / versionCode 32，所以没有一个叫 0.18.4 的构建；0.18.5 的 README 版本号也还停在 0.18.3。已推送的历史不改写：versionCode 33 就是 0.18.5。新增 `tests/version_test.py`：各处版本号（Cargo.toml/lock、Android、鸿蒙、iOS 两处、两份 Java 测试、README）和 versionCode 一致，README 要有这一版的小节；`--commit REV` 还查"X.Y.Z: …"标题与文件一致（拿它查 696bae9 和 a3b10bf 都会报出来），CI 对 HEAD 跑；`scripts/hooks/commit-msg` 在提交时查
- 高危 3（UI 测试脚本总以 0 退出、make test 和 CI 都不跑、八份里三份失败）：前两点属实；"三份失败"在 0.18.5 上属实（面板测试直接 TypeError，桌面模式 2 项、iOS 模式 1 项断言不过），0.18.6 已改好。两个测试脚本现在出现 FAIL、抛错、没加载就以 1 退出（WebKitGTK 那边的页面日志原来写在网页进程的标准输出里，测试脚本看不到，改为在页面脚本之前装一个转发器）；`chrome_harness.py` 改成只用标准库；新增 `tests/ui_test.py` 跑全部十项并按已知检查数把关，`tests/ui_harness_selftest.py` 检查退出码本身；两者都接进 `make test` 和 CI（CI 里没有浏览器算失败）。另发现 0.18.6 的主屏幕测试在 WebKitGTK 里有一项不过，见上面"测试"一节
- 高危 4（CI 用 `curl | sh` 装不固定版本的工具链）：属实。改为 `scripts/ci/install-rust.sh`：固定版本的 rustup-init（1.29.3），运行前核对 SHA-256，装固定的 Rust 1.100.0 并核对 `rustc --version`。在 Linux 上实跑过，故意改错一位哈希会拒绝运行；核心在 1.100.0 上编译、测试通过，没有警告。全文另要求 `rust-toolchain.toml` 和固定 Xcode：新增 `rust-toolchain.toml`（`channel = "1.100.0"`，安装脚本从这里读版本，用 rustup 的本地构建也就是同一个编译器），`codemagic.yaml` 的 `xcode: latest` 改成 `26.6`；`version_test.py` 现在也查这两处是具体版本、CI 里没有 `curl | sh`。CI 的 Mac 镜像没有 Chrome，也不一定装了 Rosetta：页面测试用的 Chrome 改为固定版本、核对 SHA-256 的 Chrome for Testing headless shell（`scripts/ci/install-chrome.sh`，158.0.8127.36；谷歌不公布这些包的校验和，哈希是本机下载后记下的，linux64 那个下载两次一致，Mac 的两个只下载过一次），Rosetta 缺了就先装
- 中危 1（Linux 弹出窗口继承 JS 桥）：属实，而且比报告说的更直接：WebKitGTK 让弹出窗口用打开它的页面的消息处理器，就算给弹出窗口另配一个也一样（在 WebKitGTK 2.54 上实测），弹出窗口发的消息会落到打开者的标签上。端到端复现：网页开一个弹出窗口，再把自己跳到 `fable://newtab`，弹出窗口就能让这个标签打开它指定的地址。现在新标签页的 HTML 里带一个每次启动随机生成的口令，消息必须带着它（别的源读不到这页），并且标签当前必须真的是 `fable://newtab`（原来空地址也算）。`tests/linux_bridge_test.sh` 用真的 `build/fable` 在 Xvfb 里重放这次攻击并检查新标签页的搜索框照常能用：旧版本失败，新版本通过。全文建议给弹出窗口单独的 `WebKitUserContentManager`：试过，2.54 上不起作用（弹出窗口仍用打开者的），所以靠口令；全文要求的"精确匹配 `fable://newtab`"现在补上了：桥、导航策略、`fable:` 协议应答都只认 `fable://newtab`（或带一个 `/`），原来是前缀比较，`fable://newtab.x` 也算
- 中危 2（Android 导出的 Activity 接受任何协议；应用自己 `loadUrl` 绕过 `shouldOverrideUrlLoading`）：属实。显式 Intent 可以带 `javascript:`、`file:`、`content:`、`intent:` 等任意地址。现在 Intent 的地址只收 http(s)；分享来的文字照地址栏的规则处理；`navigate()` 自己只加载 http(s) 与 `about:blank`。全文要求"拒绝并提示"：现在不开的链接会提示"只打开网页链接"（测试也查这句提示）。"分享一个文本文件给 Fable"仍然能用：那是 manifest 里声明的功能，Fable 自己没有内容提供者，只拿发送方授给它的那一个地址，见中危 5
- 中危 3（Windows 面板桥不查来源，`IsHome` 把 `data:` 当主页）：属实，配合中危 4 能串起来：网页 `window.open("data://…")` 在新标签里加载，`data:` 被当成新标签页，就能用桥让标签打开任意地址。现在：只有外壳自己 `NavigateToString` 打开的新标签页（或回到这条历史记录）才能用桥，判断看发消息的文档（`args->get_Source`）；面板只允许外壳自己的那一次导航，消息也查来源；`IsHome` 只认 `about:blank` 与 `data:text/html`，并且只用于显示。全文还要求来源"精确匹配"和关掉面板的开发者工具：现在发消息的文档地址必须与外壳自己那次导航开始时（或加载完时）的地址完全相同，面板设了 `put_AreDevToolsEnabled(FALSE)`（标签页的开发者工具照旧，那是给用户的）
- 中危 4（地址栏默认放行未知协议）：属实，`xxx://` 一律照原样加载。改为白名单：http、https、`about:blank`、`file://`（桌面上手动打开本地文件；两个手机平台关着文件访问），其余（`intent:`、`content:`、`data:`、`chrome:`、`fable:`、各家应用的协议……）都当搜索词。全文建议只留 http、https、`about:blank`；`file:` 没有整个去掉，因为桌面版注册了打开 .html 文件（`fable.desktop` 的 `text/html`、macOS `Info.plist` 的文档类型），系统交给 Fable 的就是 `file://` 地址，去掉就打不开本机网页了。但收紧成：只在桌面平台的核心里有（Android、iOS、鸿蒙编出来的核心一律当搜索，编译期决定），只认本机的 `file:///…` 与 `file://localhost/…`，`file://别的主机/…` 当搜索（在 Windows 上那是网络共享，会去连那台机器并递上用户凭据）。全文里能把地址送进 `navigate()` 的网页通道（Linux 弹出窗口、Windows 的 `data:` 页）已经堵上，剩下的入口都是用户自己输入或系统交来的新标签页、面板不经过地址栏；下载是 http(s) 的响应；外部应用跳转由 0.18.6 的开关在页面导航时处理，不受影响。后按需放宽为黑名单：只拦会执行脚本或读本地/内部内容的协议（`javascript:`、`vbscript:`、`data:`、`blob:`、`filesystem:`、`intent:`、`content:`），其余格式正确的 `协议://…`、任意 `about:` 页和 `view-source:` 照原样交给网页视图，`file:` 的限制不变；外部应用跳转仍由 0.18.6 的开关管
- 中危 5（Android 没设 `setAllowContentAccess`）：属实，默认是开的。现在所有标签和面板都关；只有"分享一个文本文件给 Fable"打开的那个标签开，而且这个标签只能加载分享来的那一个 `content://` 地址，别的一律 403
- 中危 6（追踪器拦截不规范化主机名）：属实，`https://doubleclick%2Enet/` 不会被认出来。现在按浏览器解析网址的方式取主机：去掉制表符和换行、`\` 当 `/`、协议后任意个斜杠、百分号解码、小写、全角字母和"。"这类句点折成 ASCII，浏览器不认的主机直接不算。全文另要求 IDNA 映射和去掉全部尾点：现在把 IDNA（NFKC）会映射成 ASCII 字母、数字的字符也折过来（数学字母 `𝐝`、罗马数字 `ⅾ`、圈字母 `ⓓ`、上下标、开尔文符号 `K` 等，891 个码点逐个与 Python 的 NFKC 对过），软连字符、零宽字符这类 IDNA 删掉的也删掉，尾点全去；名单都是 ASCII，映射后仍不是 ASCII 的主机不会命中，不必转 punycode。各外壳交给拦截器的本来就是引擎规范化过的地址，这一层是兜底
- 中危 7（Windows 标签桥看顶层文档的 Source 而不是发消息的文档）：属实，改为 `args->get_Source`，见中危 3
- 中危 8（Windows 在 WebView2 控制器自己的回调里释放它）：属实：Ctrl+W 在 `AcceleratorKeyPressed` 里、`window.close()` 在 `WindowCloseRequested` 里直接 `Close()` 并释放控制器。现在先藏起来，回到消息循环再关（`WM_APP_RETIRE`），所在的窗口也等它关完再销毁
- 中危 9（Android / 鸿蒙面板桥的 `set` 没有键白名单和长度上限）：属实（鸿蒙走核心的 `fable_panel_query`，Linux、Windows、macOS、iOS 也是）。核心里加了白名单（面板和主屏幕页面会写的 23 个键，单元测试从两份页面里把键名扫出来对照）和长度上限（列表 256 KB，其余 4 KB），不收控制字符；Android 自己的 `set` 也问核心（新 C 接口 `fable_panel_setting_allowed`）。全文要求"复用 `home/set` 那套"：列表值现在也必须以 `[` 开头（与 `home/set` 一样），搜索引擎模板必须是带 `%s` 的 http(s) 地址（与面板页自己的检查、`set_search_template` 一致）
- 中危 10（CI 冒烟测试不会因为要紧的问题失败）：属实。macOS 冒烟脚本现在在这些情况下失败：不是双架构、签名校验不过、链接了系统以外的库、程序退出或 panic、某个页面没加载完（没有截图）、打开链接时起了第二个实例；iOS 的在模拟器起不来、装不上、截图失败、panic 时失败。`tests/smoke_selftest.sh` 在任何机器上用替身程序把这些情况各演一遍：旧脚本六种都照样通过，新脚本都失败。全文另要求 `set -euo pipefail`、截图非空、页面加载计时非空：两个脚本现在 `set -eu`，有 `pipefail` 的 shell（Mac 的 sh 是 bash）也开；macOS 的快照、iOS 的截图必须非空；iOS 日志里没有 `didGeneratePageLoadTiming`（一个页面都没加载完）就失败。自检扩成 macOS 9 种、iOS 9 种情形，sh 和 bash 各跑一遍；旧脚本在其中 10 种坏情形下照样通过
- 没做到的：Windows、macOS、iOS、鸿蒙这台机器上编不了。Windows 的改动用 MinGW 加官方 WebView2 SDK 头文件做过语法和类型检查（WRL 的 `Callback` 用替身，所以回调参数的类型没核对到），没有实际运行；`ICoreWebView2NavigationStartingEventArgs3` 需要 WebView2 SDK 1.0.2210 以上；macOS 与 iOS 的冒烟脚本只用替身演练过，没在真 Mac 上跑；鸿蒙只改了核心那一侧

**0.18.7 测试结果**（Debian 13，x86-64，无显示器；Linux 外壳在 Xvfb 里跑）

- `make test` 全部通过：Rust 核心 64 个单元测试（纯 Rust 与汇编各一遍，新增地址栏协议白名单与本机文件规则、主机名规范化与 IDNA 映射、面板设置白名单、汇编确实链入与独立哈希值、Zig 表与 Rust 表比对），C 链接测试，JNI 桥测试，iOS 工程检查（没有 `swiftc`，Swift 部分跳过），版本号检查，界面测试脚本的退出码自检（WebKitGTK 与 Chrome 各 5 种情形），页面交互测试 12 次运行全过（面板 121 项、桌面模式 25、iOS 模式 17 项，前两者 WebKitGTK 与 Chrome 各一遍；主屏幕 19、分页 1、编辑 6+6（中文、阿拉伯语）、抽屉 39+38、壁纸 7，在 Chrome 里），CI 冒烟脚本自检（macOS 9 种、iOS 9 种情形，sh 与 bash 各一遍），Zig 0.14.1 的 `zig build test` 与 `--features zig-native` 下的核心 64 个测试，Linux 外壳 `make linux` 编译无警告并通过新标签页桥的端到端测试
- Android 的 JVM 测试 43 个全过（`MainActivity` 33 个，其中新增 4 个：Intent 只开网页链接并提示、应用自己加载的只能是网页、`content://` 访问只给分享文件的那个标签且只限那个地址、面板只能设自己的设置、列表与搜索引擎的值合规；这 4 个在 0.18.6 的 `MainActivity` 上都失败）
- 核心另用固定的 Rust 1.100.0 编译测试一遍（CI 用的版本），没有警告；`install-rust.sh` 从 `rust-toolchain.toml` 读版本后在 Linux 上实装一遍；页面测试另用 `install-chrome.sh` 装的固定版 headless shell 跑过十项
- Windows 外壳用 MinGW-w64 与 WebView2 SDK 1.0.4314.35 的头文件做语法、类型检查通过

**0.18.6 广告拦截与外部应用跳转拦截：改了什么、验证到了哪一步**

- 设置 › 隐私里多了两个开关，都**默认关**：「拦截广告」与「拦截外部应用跳转」。默认关是为了不改变现有用户的行为，要用自己打开
- 广告拦截分两路。网络上一份广告域名清单（`native/ads.txt`，85 条，与追踪器清单分开），只拦第三方请求——站点自己域名上的广告是站点的内容，不是别人的广告；页面上再按样式把广告位本身藏起来（`.adsbygoogle`、`[id^="google_ads_"]`、`.ad-container` 这类容器，以及广告网络的 iframe）。规则是纯 CSS，所以页面后来才插进来的广告也会一并藏掉，不必用脚本盯着页面。样式用 CSSOM 装上（`document.adoptedStyleSheets`），页面有严格的 CSP 时退回 `<style>`；两条路都被 CSP 挡住时只是不隐藏广告位，拦网络的那一路照旧
- 外部应用跳转：网页想把用户带去别的应用时停在原地，并提示一句「已阻止跳转外部应用」。认得的是别的应用的自定义协议（Android 的 `intent://`、`market://`，iOS 的 `itms-apps://`，以及各家的 `myapp://`、`weixin://` 之类）和应用商店的链接（`apps.apple.com`、`play.google.com/store/apps`）。`tel:`、`mailto:`、`sms:` 这类约定俗成的链接照旧交给系统——用户点了电话号码本来就该拨号
- 六个平台都做了，所以面板里这两行在哪儿都出现。macOS 与 iOS 的广告域名走 WebKit 的内容规则列表（和追踪器一样，只是另一份清单），另外四个平台按请求问核心。Linux 的网页拦截跑在网页进程里，那边有一份核心自己的副本，所以开关由外壳一起送过去（追踪器与广告两个）
- 追踪器与广告是分开的两份清单、两个开关，核心按各自的开关判断；面板里的拦截计数是两者加起来
- 校验：Rust 核心 56 个单元测试通过（纯 Rust 与汇编各一遍），C 链接测试通过（新增广告与外部跳转的判定），Linux 外壳 `make linux` 编译通过、没有新警告；八个面板与主屏幕的交互测试共 235 项全过。面板那三份测试的期望值此前因为 0.18.4 扩充 UA 预设、0.18.4 把文字大小改成滑块而失效（一个直接崩、两个断言不过），这次一并修正，并补上两个新开关的检查
- 没做到的：广告位隐藏是在页面加载完之后装上去的，广告先闪一下；六个平台里只有 Linux 编译过并跑了单测，Android、鸿蒙、iOS、macOS、Windows 这次都没能在这台机器上构建

**0.18.5、0.18.4 此前没有单独的说明**

- 0.18.5：旧版 WebView 上的无痕标签计数角标改到正确的角；阿拉伯语里文字大小的滑块方向与原生控件一致
- 0.18.4：UA 预设扩充到所有平台（桌面 10 项、手机与 iOS 11 项，含 iPad 与各家浏览器）

**0.2 版 Android：真实运行并通过的部分**

- Rust 核心 31 个单元测试（设置/历史存储、新标签页生成、资源嗅探、语言识别与文本表完整性：每个词条八种语言都有，占位符一致），C 链接测试，JNI 桥在桌面 JVM 上的往返测试
- 0.8 无痕模式：`MainActivity` 新增两个测试走完整个流程（进入、底栏只数无痕标签、"+"开无痕标签、从标签页列表切回普通模式时无痕标签保留、再次进入回到原标签、关闭时由同模式标签接替、返回键逐个关闭无痕标签后回到普通模式原位置、退出无痕关闭全部、最后一个普通标签不被返回键关闭、截图限制随模式和设置开关）；面板 92 项检查覆盖两侧切换、深色、计数、空状态、全部关闭后自动转回普通一侧、两种模式下的菜单；无痕新标签页三种语言和"Cookie 共用"变体以手机尺寸看过。截图限制和深色导航栏只在模拟环境里检查了窗口标志，真机效果未看
- `MainActivity` 的 19 个 JVM 测试（含新标签页以标志为图标、普通页面和无痕标签不受影响；含在模拟设备上完整跑一遍系统信息采集：十五个部分都返回、不崩溃、不含 IMEI/序列号/MAC/SSID 等字段；含元数据：设备信息字段、UA 与标签实际发送的一致、用本地服务器模拟 Cloudflare 的 IP 查询及失败情况；含切换语言后底栏、提示、面板、新标签页全部换成新语言；已存图标随新标签页下发、无痕标签不带图标、清除历史后不再下发）和图标存储的 7 个测试（真实位图解码 + 本地网页服务器，含 .ico 解码、首页 `<link>` 图标发现、其他网站探测不到图标）：启动与新标签页、页面加载后的地址栏/标题/历史、第三方追踪拦截及开关、地址栏搜索与更换搜索引擎、面板打开与桥接、四种 UA 模式、无痕标签不记历史并变色、关闭最后一个标签、弹窗转标签、休眠与唤醒、阅读模式调用、设置持久化
- 底栏的五种状态（新标签页、加载中、普通页面、无痕、输入中）用 Android 的真实绘制代码渲染后逐张看过
- 面板的交互检查在 WebKit 里通过（0.7.1 时 76 项，0.8 为 92 项，0.8.1 为 93 项，0.8.2 仍为 93 项，语言列表改为八行、搜索引擎改为九个）（含简略/详细：默认简略且为 0.5.0 式单页、详细为分类与子页面、从子页面切回简略、复制内容跟随模式、选择被记住、开关只出现在元数据页；元数据页的分类摘要先显示读取中再就地填充、子页面、折叠与展开状态保留、各页复制内容；元数据页：分区顺序、各数据来源、IP 卡片的等待/成功/失败/重试/关闭后到达、点按复制、复制全部）；四种语言的新标签页、菜单、设置、语言选择、资源嗅探各以手机尺寸渲染看过（0.8.1：韩语、俄语的菜单、设置、无痕标签页、元数据、历史记录、两种新标签页也看过，修掉了俄语里被截断的标题和标签）（开关、单选、返回、快捷方式增删、历史搜索、标签切换与关闭，以及网页标题里的 HTML 不会被当成标记执行）；各个面板和两种新标签页以手机尺寸截图看过
- 阅读模式在真实网页上以手机尺寸试过：中文维基百科、Rust 官方博客、阮一峰的周刊可以提取并重排；Hacker News 首页、需要登录的知乎问题页、404 页正确判定为"没有正文"；进入再退出后原页面和样式表完整恢复
- 用真实的 SDK 34 / NDK r26d / AGP 8.5.2 构建出 APK，签名与上一版相同，可以直接覆盖安装

**0.8.2（法语、Seznam）：本次改动验证**

- Rust 核心 31 个单元测试通过（普通版与汇编版各一遍，含法语映射与文本表完整性：393 个词条七种语言都有，占位符一致），C 链接测试通过，版本号已是 0.8.2；法语填表按 `tests/web_harness.py` 的方式校验过（`settings` 为 Paramètres，`wiki_url` 为法语维基百科）
- 面板的 93 项 WebKit 交互检查与 Android JVM 测试没有在这台机器上重跑：前者要装的 WebKit 包一直下不下来，后者需要 Android SDK 与 Java。这两处只改了期望值（语言列表八行、搜索引擎九个），没有改逻辑。（0.8.3 时在另一台机器上补跑：93 项面板检查和 29 个 Android JVM 测试都通过）

**0.18.3 审阅 GitLab 分支 `android-plus-button-fix`（StepFun）：采用了什么、改了什么**

- 这个分支建在 GitLab 的 `main` 上（0.16.1 加上 SAST 配置的合并），只有一个提交，把 0.17–0.18.2 的内容连同它自己的改动一起压了进去，所以没有直接合并，而是把它的改动逐项搬到 0.18.2 上
- 采用：壁纸文案去掉"米白"——单选项与设置里的值为"Fable"，提示为"壁纸已设为 Fable"，九种语言一起改；移动端主页按钮换成 Google Material Symbols 的 home（outlined，Apache License 2.0，见文末"第三方素材"），Android 的 `ic_home.xml` 与鸿蒙的深浅两版 SVG 用同一条路径（从 960 格按 x/40、(y+960)/40 换算，逐段核对过）；iOS 仍用系统的 SF Symbol "house"
- 没有采用的写法：分支里的 `+` 按钮改动**会让应用一启动就崩溃**——`applyHomeButton()` 在创建 `+` 按钮之前就被调用，而它新加的第一行就是给 `+` 设背景（空指针）；在这个分支上跑 Android JVM 测试，31 个启动应用的测试全部因此失败。另外两处问题：显示主页按钮时 `+` 去掉了橙色底，却还保留白色图标，在米白底栏上看不见；去掉 52×40 的外层后，隐藏主页按钮时橙色底会撑满整格，比原来的胶囊大一圈
- 按它的意图重做：显示主页按钮（底栏六个按钮）时，`+` 和其他按钮一样是一个普通按钮，填满自己那一格，颜色跟着其他按钮（无痕时也一样）；不显示主页按钮（五个）时照旧是橙色胶囊加白色 `+`。`applyHomeButton()` 移到 `+` 创建之后调用
- 检查：Android JVM 测试 39 个通过：主页按钮那一项多检查 `+` 的大小与颜色（关：52dp 宽的胶囊、白色；开：填满格子、颜色同主页按钮；再关：回到胶囊和白色），截图测试新增"显示主页按钮"的普通与无痕两张（`bar-home-button*.png`）；面板检查 117 项（其中 5 处期望值随文案改）、桌面面板 25、iOS 面板 17；Rust、C 链接、JNI 通过；APK、鸿蒙 HAP 能构建

**0.18.2 系统壁纸页去掉说明、改文案**

- "系统壁纸"页不再有说明文字，改成两个单选项："Fable 米白"和"自定义"，当前是哪一个就选中哪一个；设置里这一行右边显示当前的选项。从米白选"自定义"：留着原来的壁纸（Android 8.1 以前）就直接换回去，否则打开系统的壁纸设置；已经是自定义时再选它，也是打开系统的壁纸设置。8.1 以前判断当前是不是米白色时直接看壁纸本身（那里应用可以读），8.1 起看系统报告的配色
- 提示改为"壁纸已设为 Fable 米白""已恢复原壁纸""壁纸设置失败"；九种语言一起改，去掉不再用的 4 个词条
- 检查：面板检查改写（共 117 项：设置里显示当前选项、子页只有两个单选项且没有说明、三种点法分别发出 `ground`、`restore`、`pick`）；Android 测试多一步（已是自定义时打开壁纸选择器）。其余检查重跑通过

**0.18.1 把系统壁纸设为米白色、再换回来：改了什么、验证到了哪一步**

- "设置 › 搜索与主页 › 系统壁纸"（只在 Fable 是默认主屏幕应用时出现）：两项操作，"设为米白色"和"恢复原来的壁纸"；当前是米白色时，这一行右边写"米白色"。只在用户点了才改，Fable 不会自己换壁纸
- 设为米白色：把主屏幕壁纸（`FLAG_SYSTEM`，不动锁屏的）设成一个米白色像素，由系统铺满；Android 只设主屏幕壁纸时一般会把原来的图留给锁屏。主屏幕、打开应用的过渡里看到的都是 Fable 的底色，文字自动用深色。需要的 `SET_WALLPAPER` 是安装时就有的普通权限，不弹窗
- 恢复原来的壁纸：要换回去，就得先留一份原来的壁纸，可读壁纸这件事 Android 管得很严——8.1–12 要存储权限，13 只给系统自带的壁纸，14 起除了"所有文件访问权限"一律拒绝。Fable 不为这个去要存储或所有文件的权限，所以：在 Android 8.1 以前，设成米白色之前先把原来的壁纸存一份，恢复时直接换回去；8.1 及以后（以及动态壁纸）存不了，"设为米白色"那一行会写明"无法自动换回"，恢复时打开系统的壁纸设置，让用户重新选
- 核心与页面：新增 8 个词条（九种语言）；面板新增"系统壁纸"子页；外壳给面板的状态里多了 `wallpaper`（`ground` 当前是不是米白色，由系统报告的壁纸配色判断，不读像素；`kept` 有没有留着原来的；`canKeep` 这台手机能不能留）
- 检查：Android 新增一个 JVM 测试（申请了 `SET_WALLPAPER`；不是主屏幕应用时面板没有这一项；Android 14 上 `canKeep` 为假；设为米白色后主屏幕壁纸是 1×1 的米白色、锁屏没动、没有留文件、提示正确；没有留存时恢复打开系统的壁纸选择器；有留存时恢复把它设回去并删掉留存）；面板检查多 6 项（共 116）。其余检查全部重跑通过
- **没有在真机上看过**：各厂商系统的壁纸设置页、只设主屏幕壁纸时锁屏是否真的保留原图，都要在手机上确认

**0.18 主屏幕显示壁纸：改了什么、验证到了哪一步**

- Fable 作为主屏幕应用时，主屏幕背后显示的是用户自己的系统壁纸，和其他桌面一样。做法是让窗口透出壁纸（`FLAG_SHOW_WALLPAPER`），窗口、根视图、主页这张网页和它的 WebView 都改成透明，状态栏也透明；壁纸由系统画，Fable 既不读取也不修改壁纸，不需要任何权限（这和 0.17.0 里 GLM 的做法不同：那是把系统壁纸换成米白色，已在 0.17.1 去掉）
- 主屏幕上的文字（应用名、标题）在深色壁纸上是白字加阴影，在浅色壁纸上是深色字：深浅由系统给出的壁纸配色判断（`WallpaperManager.getWallpaperColors`，Android 12 起用系统的"适合深色文字"提示，8.1–11 看主色亮度，8.1 以下一律白字）。换了壁纸时主页自动重建。状态栏图标跟着变。图标本身仍是白色圆角卡片；"所有应用"保留自己的米白底；底栏不变
- 因为主屏幕窗口透出壁纸，系统打开应用时会用它自己的"从桌面打开"过渡；0.17.2 的从图标展开的动画照旧
- 设置："设置 › 搜索与主页 › 主屏幕显示壁纸"（只在 Fable 是默认主屏幕应用时出现，默认开）；关掉就是原来的米白底色。普通网页、无痕标签、非主屏幕时的新标签页都不透明，和以前一样
- 核心接口：`fable_launcher_page` 多了一个参数 `wallpaper`（0 自己的底色，1 壁纸配白字，2 壁纸配深色字），页面里的 `LAUNCHER.wallpaper` 跟着带上；JNI 同步修改
- 检查：Rust、C 链接（含超出范围的值被限制在 0–2）、JNI 通过；Android JVM 测试改写了壁纸那一项：不是主屏幕应用时窗口不透出壁纸；是的时候页面带上 `"wallpaper":1`、窗口透出壁纸、状态栏透明且图标为浅色、WebView 透明；同一标签打开网页后恢复不透明；关掉设置后主页重建为不透明；仍然没有申请 `SET_WALLPAPER`，也没有设过壁纸。新增网页检查 `tests/newtab_wallpaper_test.js`（7 项：页面在绘制前就知道、背景透明、白字带阴影、标题、图标卡片、"所有应用"不透明、浅色壁纸用深色字）；面板检查多 2 项（共 110）。其余检查全部重跑通过
- **没有在真机上看过**：透明窗口在各厂商系统上的表现、切换动画、白字在花哨壁纸上的可读性都要在手机上确认；从桌面应用切回 Fable 主屏幕的一瞬间可能先看到主题的米白底色，再显示壁纸

**0.17.2 从主屏幕打开应用的动画：改了什么、验证到了哪一步**

- 问题：Fable 作为主屏幕应用时，打开应用用的是"应用之间跳转"的动画，而不是从桌面打开应用那种从图标里展开的动画
- 原因：系统自带桌面（Pixel 桌面等）那种图标变成窗口的动画，是桌面自己逐帧控制的，要一个只发给系统应用的权限（`CONTROL_REMOTE_APP_TRANSITION_ANIMATIONS`），第三方桌面拿不到；系统默认的"从桌面打开"过渡，又要求桌面窗口显示壁纸，而 Fable 的主屏幕是不透明的米白色页面
- 做法：和不带系统权限的 Launcher3 一样，用公开的 `ActivityOptions.makeClipRevealAnimation`：主页在启动应用时把所点图标的位置一起发给外壳（`home/launch?c=…&r=左,上,宽,高`，CSS 像素），外壳按屏幕密度换算，让应用从这个图标的位置展开；同时把图标在屏幕上的位置作为 `sourceBounds` 交给被打开的应用（桌面启动应用的惯例）。主屏幕上的图标和"所有应用"里的图标都这样；位置不合理（宽高为零、不是数字）时照旧普通启动
- 检查：主屏幕检查多一项（发出的位置等于所点图标的位置），抽屉检查的"点按启动"同时检查带了位置；Android JVM 测试检查：带位置时启动的 Intent 带上了换算后的屏幕位置和启动选项，不带位置时没有，错误的位置被忽略。全部检查重跑通过
- **没有在真机上看过**：动画的实际效果、各厂商系统（MIUI、ColorOS、HarmonyOS 的 Android 兼容层等）是否照用这个动画都要在手机上确认。从应用回到桌面的动画仍由系统决定，第三方桌面改不了

**0.17.1 审计 0.17.0：改了什么、验证到了哪一步**

- 0.17.0 上传的源码**编译不过**：GLM 和 MiMo 加的换壁纸代码调用了不存在的 `WallpaperManager.setBitmap(Bitmap, Rect, int)`（三个参数的版本最后一个是 `boolean`），所以这两次提交之后既没跑过测试，也打不出 APK
- 就算能编译，换壁纸的做法也有问题：它要先读出用户原来的壁纸做备份。可是读壁纸在 Android 8.1–12 上要存储权限（Fable 没有，会抛 `SecurityException`，而这段在 `onStart` 里没有捕获，作为主屏幕应用每次启动都会崩），Android 13 上拿到的是系统自带壁纸而不是用户的（备份的是错的，恢复时用户自己的壁纸就丢了），Android 14 起一律抛异常。另外 Fable 被换成别的桌面、或被卸载后，它没有机会把壁纸换回来
- 处理：去掉换壁纸、`SET_WALLPAPER` 权限和让窗口显示壁纸的标志（Fable 的界面不透明，只有在打开应用的过渡动画里才看得见壁纸，留着它只会在那一瞬间露出用户的壁纸，动态壁纸还会在 Fable 下面白白绘制）。0.17.0 留下的壁纸备份文件启动时删掉。MiMo 的返回键修复（按两下不会处理两次）保留，并补了测试
- Grok 的"所有应用"抽屉审过没有发现问题：应用名一律按文本放进页面（`Notes <b>` 原样显示），"应用信息"和启动应用一样只回答主页、只认列出的应用，设置只在 Fable 是默认主屏幕应用时出现，普通新标签页（iOS、桌面、非桌面模式的 Android）不会出现抽屉和九宫格按钮
- 新增 `tests/chrome_harness.py`：用无头 Chrome（带触摸）跑页面检查，参数同 `web_harness.py`。抽屉的检查用到 `Touch`/`TouchEvent`，WebKitGTK 的桌面版构造不了，以前 README 写"用无头 Chrome"却没有这个脚本
- 检查：Android 新增一个 JVM 测试（作为主屏幕应用启动后窗口不显示壁纸、没有申请 `SET_WALLPAPER`、壁纸没被改、旧备份被删），返回键测试多一步（主页还没回答时再按一次返回，不会再问、只关一个标签）；改回原样时这两处都会失败。全部重跑通过：Rust 两遍各 40 个、C 链接、JNI、iOS 工程检查（这台机器没有 swiftc，Swift 检查跳过）、Android JVM 37 个、网页检查（面板 108、桌面面板 25、iOS 面板 17、主屏幕 18、分页 1、编辑中文与阿拉伯语各 6、抽屉中文 39 与阿拉伯语 38）；APK、鸿蒙 HAP、Linux、Windows 都能构建
- Apple 两端只做了静态检查（这一轮没有在 Codemagic 上跑）：0.17.0 没有改 iOS、macOS 的代码，只改了版本号；共用的页面里，抽屉和新设置只在 Android 作为主屏幕时出现，iOS 和 macOS 的新标签页、面板不受影响

**0.17 主屏幕的"所有应用"：验证到了哪一步**

- 设计上的取舍：抽屉放在主页这张网页里（`ui/newtab.html`），和主屏幕共用图标、字体、圆角和语言，Android 外壳只多了两件事：一是"应用信息"请求（`home/info?c=…`，和启动应用一样只回答主页、只认列出的应用），二是返回键先问主页有没有要关的东西（`fableBack()`）。从主屏幕"移除"的应用以前就是"从主屏幕移除"而不是卸载或彻底隐藏（文字一直是这样写的），所以抽屉里照样列出它们，和 Pixel 一致；要从抽屉里也藏起来的"隐藏应用"没有做。新设置默认开，已有用户的主屏幕不会变；核心把 `home_new_apps` 作为 `addNew` 交给页面
- 检查：新增 `tests/newtab_drawer_test.js`（简体中文 39 项、阿拉伯语 38 项，用新的示例数据 `tests/launcher_drawer.json`：新应用不进主屏幕、一个应用已从主屏幕移除，名称有中文、阿拉伯文、带重音的拉丁字母和数字）：上滑打开且中途跟手、左右滑不打开、按钮位置随书写方向、全部应用都在、拼音/阿拉伯字母/数值/重音排序、列表方向、搜索（大小写、重音、包名、阿拉伯文、中文）、回车启动、找不到时的网页搜索、长按菜单与应用信息、加到主屏幕、拖到主屏幕（长按后的移动不被当作滚动）、编辑时不能上滑、返回键的顺序、下拉关闭、Home 键。改用浏览器默认排序（不按拼音）时拼音那一项会失败。面板检查多 4 项（共 108 项：只有主屏幕模式才有新开关、默认开、关掉存为 0、恢复移除的应用放回主屏幕末尾）；Android 新增一个 JVM 测试（共 36 个）：页面带上 `addNew`、面板的 `caps.homeScreen`、应用信息只开列出的应用且只回答主页、返回键先交给主页（主页说关掉了东西就停下，否则照旧）；C 链接测试检查 `addNew` 随设置变化。原有的主屏幕检查（18 项）、分页、编辑检查（中文与阿拉伯语）不改一行照样通过
- 全部检查重跑通过：Rust（两遍各 40 个）、C 链接、JNI、iOS 工程检查与 Swift 检查（49 项）、Android JVM 36 个、网页检查（主屏幕 18、分页 1、编辑中文与阿拉伯语各 6、抽屉中文 39 与阿拉伯语 38、面板 108、桌面面板 25、iOS 面板 17），网页检查照旧用无头 Chrome 代替 WebKitGTK
- **没有在真机上试过**：手势（上滑、下拉、长按后拖出）是用合成的触摸和指针事件在无头 Chrome 里测的，真机上 WebView 对 `touch-action` 和取消 `touchmove` 的处理、上滑的手感和阈值都还要在手机上看；拼音分组依赖 WebView 自带的 ICU 数据里有中文排序（Chrome for Android 带的是精简版，判断不出时会退回普通排序，不会出错，只是中文和英文名不再按首字母混排）；"应用信息"打开的系统页在各厂商系统上的样子没看过；抽屉里的图标第一次打开时才去取，应用很多时第一次打开可能先看到首字

**0.16.1 无痕时的状态栏、Codemagic：验证到了哪一步**

- 无痕模式下状态栏一律变深色、图标变浅色，不论地址栏在顶部还是底部（0.15 只在地址栏置顶时变色，置底时状态栏仍是米白色，和深色的底栏对不上）。Android 改在 `styleChrome`；iOS 同样处理（`preferredStatusBarStyle` 不再看地址栏位置，置底时状态栏后面的底色也跟着变深）
- 检查：Android 新增一个 JVM 测试（地址栏置底、置顶各走一遍：进入无痕后状态栏为深色且图标为浅色，退出后恢复米白或顶栏颜色、深色图标），Android 的 JVM 测试共 35 个，全部通过；Rust、C、JNI、iOS 工程检查与全部网页检查（面板 104、桌面面板 25、iOS 面板 17、主屏幕 18、编辑中文与阿拉伯语各 6）重跑通过
- 新增 `codemagic.yaml`：两条在 Codemagic 的 Mac（Mac mini M2，Xcode 最新版）上跑的流程，都不签名。`macos`：装 Rust、跑核心测试、`scripts/build-macos.sh` 构建通用版 Fable.app，再由 `scripts/ci/mac-smoke.sh` 启动（新标签页）、带网址启动（example.com）、再由 Launch Services 交给它一个链接，每一步确认仍在运行，保存窗口快照与日志；`ios-simulator`：`tests/ios_test.sh`（在 Mac 上会真正编译并运行 Swift 检查）、`scripts/build-ios.sh simulator`，再由 `scripts/ci/ios-smoke.sh` 在最新的 iPhone 模拟器上首次启动（6 秒、26 秒各一张）、深色模式、再次启动、带网址启动，各截一张图，并记下每次页面加载的耗时
- **Codemagic 上的结果**：macOS 版第一次在真 Mac 上编译就通过（arm64 + x86_64，没有警告），启动、带网址启动、由 Launch Services 交给它链接（在同一窗口组里新开一个原生标签）都正常，日志里没有错误；新标签页、example.com、iana.org 三张窗口快照和设计一致（工具栏、搜索框、八个快捷方式、地址栏里的网址）。快照里当前标签在标签栏上的标题没有画出来，另一个标签的"新标签页"有，可能只是快照方式（`cacheDisplayInRect`）画不出选中标签的样式，要在真机上看一眼。iOS 版第一次用 Xcode 编译就通过（只有 Xcode 自己的一条 AppIntents 提示），在模拟器上启动正常：底栏、地址栏、新标签页、带网址打开 example.com 都对。在 Mac 上跑 Swift 检查时查出核心的一个问题，已修：外壳补充的设备信息与核心的字段同名时，结果里会出现两个同名键，Apple 的 JSON 解析器取第一个、浏览器取最后一个；现在外壳给的值直接替换核心的（对象逐键合并），结果里不再有重名键。另外两处随之改动：iOS 版和 macOS 一样，启动时带的网址在第一个标签打开（`simctl openurl` 会把网址交给 Safari，测不到 Fable）；macOS 版加了只在设置 `FABLE_SNAPSHOT_DIR` 时才生效的窗口快照（CI 的代理进程不在登录会话里，`screencapture` 拿不到屏幕，放开屏幕录制权限也不行）
- 还要留意的：iOS 模拟器第一次冷启动时新标签页约 9 秒才画出来（WebKit 首次启动各个进程），再次启动只要 0.02 秒；"ChatGPT""DeepSeek""Gemini"三个快捷方式在 CI 上显示的是地球图标（网站图标没取到），各平台一样，是取图标的问题，不是外壳的问题
- 触控、无痕模式、面板等交互还没有在 Mac 或模拟器上实际操作过；iOS 没有上过真机（需要开发者账号签名）

**0.16 iOS：验证到了哪一步**

- 这台机器是 Linux（Debian 13），没有 Mac、没有 Xcode、没有 iOS SDK，所以 **iOS 版没有编译成 App，没有在模拟器或真机上运行过**。下面是在 Linux 上能做的检查
- 核心：rustup 装了 `aarch64-apple-ios`、`aarch64-apple-ios-sim`、`x86_64-apple-ios` 三个目标，`scripts/build-ios.sh core` 在 Linux 上编出三份带汇编哈希的静态库（汇编用 Swift 工具链自带的 clang 和 llvm-ar）；`llvm-objdump` 确认目标文件的平台（真机 `ios`、模拟器 `iossimulator`，最低 15.0），`llvm-nm` 确认头文件里的 46 个函数都导出了（`tests/ios_test.sh` 里也有这一项）。Linux 上没有 `lipo`，模拟器只放进了 arm64 一份
- Swift：用 swift.org 的 Linux 版 Swift 6.1.2。全部 6 个 Swift 文件语法检查通过；不依赖 UIKit 的 `Core.swift`（核心的 Swift 封装）和 `Panel.swift`（面板消息解析、面板状态与 caps、内容拦截规则、UA 与文字大小换算、下载文件名）通过同一个桥接头文件链接 Linux 版核心，由 `tests/swift/main.swift` 跑 49 项检查，全部通过。UIKit 和 WebKit 只在 Apple 的 SDK 里有：其余四个文件（界面与标签管理、单个标签、设备信息、启动）另外对着一份自己写的 UIKit/WebKit 接口桩做了类型检查，能查出 Swift 本身的错误和文件之间对不上的地方，查不出和真实 SDK 不一致的地方（这份桩不在仓库里）。代理方法的签名是对照 Apple 文档逐个核对的
- 工程：`Fable.xcodeproj` 由 XcodeGen 2.42（在 Linux 上编译）从 `project.yml` 生成；`tests/ios_test.sh` 解析 `project.pbxproj`，检查所有对象引用、三个构建阶段（核心、源码、资源）、每个 Swift 文件都参与编译、头文件和库的搜索路径、版本号；Info.plist、资源目录的 JSON、1024×1024 不透明图标也在检查之列
- 面板：新增 `tests/ios_prelude.js` 和 `tests/panel_ios_test.js`（17 项）：走消息桥但保持底部弹出层、不发 `size` 消息、关闭时先收起、240 ms 后通知外壳、手机才有的设置项都在、caps 藏起截图和第三方 Cookie 两个开关、iPad 藏起屏幕方向、历史与设备信息的请求和回复。旧版 `panel.html` 跑这份检查会失败
- 其他平台的检查照旧全部重跑并通过（同样用无头 Chrome 代替 WebKitGTK）：Rust 测试两遍、C 链接测试、JNI 测试、Android 的 JVM 测试，主屏幕、分页、编辑（中文与阿拉伯语）、面板、桌面面板。共享部分只改了 `panel.html`（`FableSheet`、`ios` 算手机、`viewport-fit=cover` 与底部安全区留白）和 `strings.tsv`（三个 iOS 用的词条，九种语言）
- 第一次在 Xcode 里构建最可能遇到的问题：Swift 和 UIKit/WebKit 接口对不上的编译错误（尤其是 Xcode 16 的 SDK 给 WebKit 代理加了 `@MainActor`、`@Sendable` 标注，Swift 5 模式下应该只是警告）；构建阶段里的 `cargo` 找不到（脚本会把 `~/.cargo/bin` 加进 PATH，rustup 装在别处时要自己加）；Rust 的 iOS 目标没装（脚本会 `rustup target add`，离线时会失败）；签名需要选团队。能编译之后要看的：面板里有输入框时键盘的表现（面板视图关掉了外层滚动）；面板和新标签页只在 Chrome 和 WebKitGTK 里看过，在 iOS 的 WebKit 上（尤其是底部安全区的留白）没有看过；工具栏状态（进度、前进后退、标签数）在真机上的刷新时机

**0.15 主屏幕编辑的"完成"、地址栏置于顶部：验证到了哪一步**

- 主屏幕编辑时的"完成"固定在右上角（阿拉伯语在左上角）。位置改用 `right` / `left` 加上从右到左时的覆盖写法，不再用 `inset-inline-end`：Chrome 87 以前的 WebView 不认识它，按钮会掉到页面最下面、看不见；"×"同样处理。编辑时每页的图标网格以页面底边为基准缩小一点（顶部空出 46 px），所以"完成"不会盖住第二页起第一行最右边那个图标的"×"，也不需要重新分页；缩放的是页里的网格而不是页本身，翻页对齐不受影响
- 设置 › 显示 里新增"地址栏置于顶部"（默认关，仍在底部）。打开后地址栏移到页面上方（像 Chrome），加载进度线在它下沿，状态栏换成同一颜色（无痕时为深色）；前进、后退、+、标签页、菜单仍在底栏，拇指够得着。对整个浏览器生效，不只是主屏幕：只在主屏幕上换位置，离开主屏幕时地址栏会上下跳。只有 Android 有这一项；鸿蒙的面板状态里带 `"caps":{"addressBarTop":false}`，开关不显示，桌面三个平台本来就在顶部
- 检查：主屏幕检查多一项（"完成"在右上角、在第一行之上），另有一份编辑检查（`tests/newtab_editing_test.js`，中文与阿拉伯语各跑一遍：位置、"×"所在的角、各页都不被挡、"完成"退出编辑）；面板多两项（手机上有这个开关且默认关、鸿蒙不显示），桌面面板检查确认没有这一项；Android 新增一个 JVM 测试（作为主屏幕应用时打开开关：地址栏在页面上方、按钮留在底栏、在上面输入照常打开网页、无痕时一起变色、关掉后回到原来的顺序），截图测试多两张（`bar-top-loading`、`bar-top-private`）
- 这台机器（Debian 13）装不上 WebKitGTK 的 Python 绑定（软件源不可用），所以网页检查是用无头 Chrome 照 `tests/web_harness.py` 的做法（同样填入文字表与主屏幕数据、同样的前置脚本）跑的：主屏幕 18 项、分页 1 项、编辑检查中文 6 项与阿拉伯语 6 项、面板 104 项、桌面面板 25 项，全部通过。Rust 测试（两遍各 40 个）、C 链接测试、JNI 测试、Android 的 34 个 JVM 测试（JDK 17、SDK 34、Gradle 8.7）通过
- **没有在真机上用过**，也没有构建 APK（没有 NDK）。鸿蒙只改了面板状态里的一个字符串，没有编译

**0.14 主页按钮：验证到了哪一步**

- 设置 › 显示 里新增"显示主页按钮"（五个平台都有，默认关）。打开后底栏（手机）或工具栏（桌面）在"前进"后面多一个主页按钮，点它在当前标签打开新标签页（无痕标签打开无痕新标签页），不另开标签；Linux、Windows 另有 Alt+Home，macOS 在"历史"菜单里有"主页"（⇧⌘H），工具栏上的按钮也可以通过"自定工具栏"拖进拖出
- 主屏幕编辑时的"×"移到图标右上角（从右到左的语言里在左上角）
- 检查：Android 新增一个 JVM 测试（默认隐藏、打开后显示、点按在当前标签打开主页、关掉后隐藏）；面板多两项（手机、桌面都有这个开关）；主屏幕检查多一项（"×"在图标右上角）。Linux 实际打开开关、点过按钮；鸿蒙、Windows 编译通过，macOS 做了语法与类型检查

**0.13.1 主屏幕新建页**

- 布局顺序里可以带"分页"（`|`：下一个图标另起一页），所以拖出来的新页在重新打开后还在；两头多余的分页、连续的分页在读入和保存时整理掉，不会出现空页；新装的应用接在最后一页后面
- 主屏幕检查增加到 16 项（在最后一页右边缘停留新建一页且只有这一个图标、分页被保存、重新排版后仍在、拖到前一页空白处后回到那一页且多出的页消失），另有一项检查读入带分页的布局

**0.13 主屏幕：验证到了哪一步**

- 主屏幕页面 12 项检查在 WebKit 里通过（30 个示例应用 + 8 个网站：分页与页码点、网站在前应用按名称排序、隐藏的应用不出现、应用名按文字显示不当作标记、点应用发出启动请求、长按进入编辑、移除应用与网站各自保存、拖动换位并保存顺序、"完成"、Home 键回第一页）；中文、编辑状态和阿拉伯语（从右到左）的页面都看过截图
- Android：新增一个 JVM 测试（共 31 个通过），覆盖：不是默认主屏幕时页面里没有应用；是的时候应用列表进入页面且名字里的 `<` 被转义；应用图标是 PNG；启动请求真的启动了对应应用；只能保存主页自己的三个设置、只能启动列出的应用；换成别的网站后同样的请求全部 404 且没有启动任何应用；Home 键复用已在主页的标签；在主页按返回键不退出
- **没有在真机上用过。** 拖动手感、长按与系统长按菜单的配合、不同厂商自适应图标的样子、Home 键动画，都只能在手机上确认
- 0.12.1 合并时去掉了"文档编辑器"的声明（`ACTION_EDIT`）：Fable 不能编辑 Word、PDF 等文件，声明后系统会把它列进"用什么编辑"的选项里，选了却只能当网页打开。分享文字和链接给 Fable（`ACTION_SEND`）保留

**0.12 显示设置：验证到了哪一步**

- 面板检查 101 项（新增：手机上"显示"一组四项、八档大小与示例文字随选择变化、屏幕方向三选一）、桌面面板检查 24 项（新增：桌面只有"页面缩放"，没有手机专属的三项）都通过；中文设置页和文字大小页以手机尺寸看过
- Android：新增一个 JVM 测试，覆盖文字大小作用到已开和新开的标签、三种屏幕方向、屏幕常亮的窗口标志、隐藏状态栏不出错（共 30 个测试通过）；状态栏的实际隐藏效果在模拟环境里看不到
- Linux：设为 150% 后启动，网页按 150% 显示（截图对比过）
- 鸿蒙：随 HAP 编译通过（ArkWeb 的 `textZoomRatio`，窗口的 `setPreferredOrientation`、`setWindowKeepScreenOn`、`setSpecificSystemBarEnabled`），没有在设备上运行过
- Windows（WebView2 的 `ZoomFactor`）编译通过，Wine 里没有 WebView2 无法实际运行；macOS（`pageZoom`）做了语法与类型检查

**0.11.1（西班牙语）：本次改动验证**

- Rust 核心 39 个单元测试通过（普通版与汇编版各一遍，含西班牙语映射与文本表完整性：425 个词条八种语言都有，占位符一致），C 链接测试通过，版本号已是 0.11.1；西班牙语填表按 `tests/web_harness.py` 的方式校验过（`settings` 为 Configuración，`wiki_url` 为西班牙语维基百科）
- 面板的 95 项 WebKit 交互检查与 22 项桌面面板检查都通过（语言列表九行）；又在 Linux 上用 WebKitGTK 以手机尺寸（390×844）把西班牙语的菜单、设置、元数据总览、新标签页各渲染看过，元数据数值卡的三个标签（Resolución、DPR、Frecuencia）都完整显示，菜单瓷砖、开关名称也没有被截断；法语的元数据总览也重看过，仍是完整的
- Android JVM 测试没有在这台机器上重跑：需要 Android SDK 与 Java。改的只是期望值（语言列表九行、版本号 0.11.1）与一处新增的西班牙语断言，没有改逻辑

**0.12.1（阿拉伯语）：本次改动验证**

- Rust 核心 39 个单元测试通过（普通版与汇编版各一遍，含阿拉伯语映射与文本表完整性：435 个词条九种语言都有，占位符一致），C 链接测试通过，版本号已是 0.12.1；阿拉伯语填表按 `tests/web_harness.py` 的方式校验过（`settings` 为 الإعدادات，`wiki_url` 为阿拉伯语维基百科）
- 面板的 101 项 WebKit 交互检查与 24 项桌面面板检查都通过（语言列表十行）；又在 Linux 上用 WebKitGTK 以手机尺寸（390×844）把阿拉伯语的菜单、设置、语言列表、元数据总览、新标签页（普通与无痕）各渲染看过：整页从右向左镜像（标题、开关滑块、返回与折叠箭头、角标都换向），元数据数值卡的标签（الدقة、DPR、التردد）都完整显示，IP 地址仍从左向右显示，新标签页的英文标语句号位置也修正了
- Android JVM 测试没有在这台机器上重跑：需要 Android SDK 与 Java。改的只是期望值（语言列表十行、版本号 0.12.1）与一处新增的阿拉伯语断言，没有改逻辑；AndroidManifest 新增的 `supportsRtl` 声明也未在真机上验证

**0.11 鸿蒙：验证到了哪一步**

这台机器没有鸿蒙真机，也没有模拟器（DevEco 的模拟器需要 Windows 或 macOS 版 DevEco Studio 和硬件虚拟化），HarmonyOS SDK 和签名证书都要华为开发者账号。能做的：

- 用 OpenHarmony 6.0 Release 的公开 SDK（API 20）和 hvigor 6.26 完整构建出 HAP：ArkTS 编译器的严格检查零警告（包括 API 版本检查：最低 API 14），Node-API 桥对 arm64-v8a 和 x86_64 零警告编译、链接上 Rust 核心、设备信息和电池两个系统库；HAP 里只有 `libfable.so`，不带 C++ 运行库
- Rust 核心为 `aarch64-unknown-linux-ohos`、`x86_64-unknown-linux-ohos` 带汇编哈希编译通过，测试程序也能链接（只是在这台 Linux 上跑不起来：需要鸿蒙的 libc）；新增的鸿蒙系统信息模块只在鸿蒙目标上编译
- 面板在鸿蒙下走和 Android 相同的 `FableUI` 同步桥，面板测试新增两项：鸿蒙下菜单有"桌面版网站"，设置里三个隐私开关都在（共 95 项，全部通过）
- **没有在任何鸿蒙设备上运行过。** 运行时才会暴露的问题（ArkWeb 回调的细节、下载文件夹授权、无痕存储的清理、底栏在真机上的样子）都没验证；`--openharmony` 编出的 HAP 和 DevEco 用 HarmonyOS SDK 编出的不是同一个包，后者才能装到华为手机上。第一次在 DevEco Studio 里编译或运行出错，把输出发给我

**0.10 各平台功能对齐：验证到了哪一步**

- Rust 核心 39 个单元测试通过（普通版与汇编版各一遍；新增面板请求、设置快照、IP 回复解析、Linux 系统信息采集、PCI 显卡名称表解析、页面扫描结果录入、拦截规则里的转义检查）；同一套测试编成 Windows 程序在 Wine 里跑，38 个通过（少的一个是只在 Linux 上编译的 PCI 测试）；C 链接测试检查了新增的七个导出函数；JNI 桥测试通过
- 面板：Android 桥的 93 项检查、桌面模式的 22 项检查（伪造 `chrome.webview` 消息通道：设置随状态下发、异步回复与过期回复丢弃、按 `caps` 和平台隐藏设置项、桌面布局与高度上报、元数据用系统给的 GPU 和核心数、没有数据的分区不显示、无痕深色）都在 WebKit 里通过
- Linux：在虚拟显示器里实际操作过——菜单（拦截计数来自网页进程、嗅探角标）、设置（按能力隐藏的项不出现）、元数据（经 libsoup 查到真实公网 IP，简略与详细两种，空分区隐藏）、无痕窗口（深色、无痕新标签页、不记历史、面板深色并带"退出无痕"，退出后关闭并提示）、切换到英语后工具栏、面板、新标签页一起换、资源嗅探（网络请求 + 页面扫描）、下载到"下载"文件夹、阅读模式提示、target=_blank 开新标签、切换标签后地址栏正确
- Windows：新外壳用 clang-cl + lld-link 对真实的 Windows SDK 和 WebView2 SDK 1.0.4314 零警告编译链接；在 Wine 里启动到窗口（普通与无痕两种配色），WebView2 不可用时弹出本地化的提示。**Wine 里没有 WebView2 Runtime，所以面板、标签、InPrivate、拦截、嗅探、下载、IP 查询这些在 Windows 上都没有实际跑过**；面板这一侧的消息协议由上面的桌面模式测试覆盖
- macOS：`main.m` 的新代码（面板、设置生效、历史、下载、IP、系统信息补充项）按之前的方法对 arm64 和 x86_64 做了语法与类型检查，零错误零警告；仍然没有在真 Mac 上编译和运行过
- Android：29 个 JVM 测试和 APK 构建通过；面板改动在 Android 上的行为由 93 项检查覆盖

**0.9 macOS：验证到了哪一步**

这台 Linux 机器没有 macOS SDK（Apple 只随 Xcode 授权提供），所以 **Fable.app 没有被真正编译、链接或运行过。** 能在这里做的都做了：

- 核心：用 Rust 的 `aarch64-apple-darwin` 和 `x86_64-apple-darwin` 目标、带汇编哈希编出了两份 macOS 静态库；两份汇编都生成了 Mach-O 目标文件，导出带下划线的 `_fable_fnv1a_lower`，反汇编与 Linux 版指令一致。Zig 原生层交叉编译到 `aarch64-macos`、`x86_64-macos` 成功
- 拦截规则：核心生成的 66 条规则交给 WebKitGTK 编译——WebKitGTK 和 macOS 的 WKWebView 用的是同一个 WebKit 内容拦截编译器——全部被接受；开启时两个追踪请求被"content blocker"拦下，普通网站和形似追踪域名的地址（`doubleclick.net.example.com`）照常加载，关闭时追踪请求也能加载
- `main.m`：用 Zig 自带的 macOS libc 头文件，加上我按 Apple 文档自写的 AppKit / WebKit 声明，以 ARC 和全部警告（含 11.0 部署目标下的可用性检查）对 arm64 和 x86_64 做了语法与类型检查，零错误零警告；故意改错一个方法名、去掉一处版本判断，都能被检查出来。但这些声明是我按理解写的，和真 SDK 可能有出入
- 图标（`.icns`）的结构用 Pillow 读回检查过；`Info.plist` 能被正常解析；构建脚本通过了 `sh -n` 语法检查

在 Mac 上第一次运行 `make macos` 时，最可能出问题的是编译这一步（API 名称或类型与真 SDK 不符）。如果报错，把输出发给我。

**0.2 版 Android：没有验证的部分**

- **APK 仍然没有在任何真机或模拟器上启动过。** JVM 测试里没有真正的网页引擎，所以这些只在真机上才能确认：面板的滑入动画和触摸手感、软键盘弹出时的布局、状态栏和导航栏的颜色、真实网页的加载表现
- 无痕标签的独立 Profile 走的是 `androidx.webkit` 的多 Profile 接口，代码能编译，但这条路径这里跑不到（测试环境没有 WebView），出错时会退回共用 Profile 并提示
- 下载、`X-Requested-With` 请求头的移除同样只做到了编译通过
- 图标抓取对真实网站只做过一次性检查：Claude、ChatGPT、Gemini、维基百科、哔哩哔哩、YouTube 能取到；DeepSeek 的首页不给出图标（访问一次后由 WebView 提供）；GitHub 被这台机器的网络代理拦截，没法验证
- 资源嗅探：网络请求这一路只在 JVM 测试里用模拟的请求验证过（带 Range 的视频请求、播放列表、分片、被拦截的广告、换页清空）；页面扫描脚本在一篇带视频的真实维基百科页面上跑过。没有在真机上对着真实的视频网站试过
- 面板和阅读模式是在 WebKit 里看的，Android 用的是 Chromium 内核，细节可能有出入

**桌面外壳（与 0.1 相同）**

- Linux：对真实的 GTK 3.24 / WebKitGTK 2.52 零警告编译，并在虚拟显示器里实际操作过（0.10 的逐项操作见上）
- Windows：见上面 0.10 一节
- Zig 0.14.1：`zig build test` 通过，交叉编译到 Android / Windows / Linux arm64 成功；三份汇编都执行过并与参考实现比对

## 已知限制

- 拦截名单是 66 个常见域名的起步名单，不是 EasyList。改 `native/trackers.txt`（一行一个域名）后重新编译即可。
- 系统信息里有不少值依机型而异，部分厂商会屏蔽（例如 CPU 频率、基带版本、电流）；取不到的项不显示。这些采集代码只在模拟环境跑过，真机上实际能显示多少未验证。
- 元数据页每次打开（以及点刷新）会向 cloudflare.com 发一次请求以获得公网 IP，不带 Cookie，失败时改问 api.ipify.org。不打开这一页就不会发。显示的 IP 是应用自身网络请求的出口，网页走的通常是同一条线路，但设了仅对浏览器生效的代理时可能不同。部分 WebView 会隐藏 GPU 型号，只显示通用名称。真实网络下的 IP 查询用应用代码实测过一次；页面在真机上的效果未验证。
- 资源嗅探靠网址和请求特征判断，会有漏判和误判；m3u8 / mpd 是播放列表，下载到的是列表文件而不是完整视频，适合复制链接交给播放器或下载工具；用 `blob:` 地址在页面内拼接的流和带 DRM 的视频无法保存；单页应用里切换视频时清单会累加。
- UA 伪装只改 UA 字符串和请求头，网站仍可以通过屏幕尺寸、触摸支持等特征识别出手机。
- 无痕数据的"清除"发生在关闭全部无痕标签（或退出无痕）之后；如果应用被系统直接杀掉，会在下次启动时清除。
- 没有做 Chrome 那条"关闭所有无痕标签页"的常驻通知：Android 13 起发通知要用户点同意。
- 关闭 JavaScript 后，新标签页上的快捷方式也不会显示（它们由脚本生成）。
- 新标签页第一次显示某个快捷方式时，会向那个网站请求它的图标（不带 Cookie）。默认的八个快捷方式（Claude、ChatGPT、DeepSeek、Gemini、维基百科、GitHub、哔哩哔哩、YouTube）也是如此；不想联系某个网站，把它从主页快捷方式里删掉即可。
- 桌面外壳的新标签页直接向网站请求 `/favicon.ico`，没有图标存储，靠 WebView 自身的缓存。
- 日语等较长的站点名在新标签页图标下会被截断。
- 全部翻译（繁体中文、日语、韩语、俄语、法语，以及 0.9 的 macOS 菜单、0.10 的桌面提示、0.11.1 的西班牙语、0.12.1 的阿拉伯语）都未经母语者校对。
- 0.8.3：中文、日语以外的语言改为拉丁字体优先，避免法语的 ’ 被中文字体排成全角而留出大块空白（在装有中文字体的 Linux 桌面上最明显）；法语元数据数值卡的"刷新率""最高频率"标签改短，不再被截断。
- 0.11.1：西班牙语的元数据数值卡标签同样取短写法（"Frecuencia"、"Frec. máx."），不照直译写全；菜单瓷砖、开关名称过长时本来就会换行，标题放不下时先缩小字号再折行，数值卡标签是唯一没有换行兜底、只能靠译文够短的地方。
- 0.12.1：阿拉伯语的元数据数值卡标签同样取短写法（"الدقة"、"التردد"、"أقصى تردد"、"المعالج"、"البنية"）；面板、新标签页、阅读模式用 `dir="rtl"` 整体镜像，开关滑块、返回与折叠箭头、退出无痕箭头在 RTL 下换向，网址类输入框仍从左向右。
- 俄语等较长的文字：标题放不下时先缩小字号，再折成两行；开关的名称过长时换行显示。
- 不带协议头的中文域名（如 `例子.中国`）会被当成搜索；加上 `https://` 就能直接打开。
- macOS 上由 WebKit 按规则拦截，没有拦截计数；WebKit 判断"第三方"按的是网页所在的站点，和核心的判断在少数情况下不同（例如在 google.com 上加载 adservice.google.com 不会被拦）。
- 桌面版都还没有"查找"（Ctrl/⌘+F）。网页的摄像头和麦克风请求走各 WebView 默认的询问。
- Windows 的无痕窗口需要 WebView2 Runtime 101 以上（InPrivate 接口），更旧的版本会退回普通数据并提示；"禁止截图"需要 Windows 10 2004 以上，更早的系统只能把窗口内容在截图里变黑。
- 鸿蒙版：标签页里 `window.open()` 打开的是一个普通新标签（拿得到网址，但拿不到 `window.opener`），和 Android 版不同；网页里的 `tel:`、`mailto:` 链接交给系统处理，其他自定义协议不跟随。元数据里 Wi-Fi 名称、信号这类要用户授权的信息不读。
- iOS 版：没有在 Xcode 里构建过（见上）。拦截没有计数；资源嗅探只有页面扫描；"文字大小"其实是页面缩放；iPad 上不能锁定屏幕方向；不能设为默认浏览器（需要 Apple 的权限）；没有禁止截图的办法，只在多任务预览里遮住无痕页面。元数据里的设备名在 iOS 16 起只是"iPhone"/"iPad"（系统不再给应用真实名称），型号是 `iPhone15,2` 这样的内部编号
- Android 主屏幕的"所有应用"（0.17）：手势只在无头 Chrome 里用合成事件测过，真机手感未调；没有侧边字母索引条和分组标题；没有"连抽屉里也藏起来"的隐藏应用；拼音分组要 WebView 的 ICU 带中文排序数据，否则退回普通排序。
- 桌面版的系统信息：Linux 读 `/proc`、`/sys` 和 `pci.ids`，Windows 读注册表，macOS 读 `sysctl` 和 IOKit；虚拟机里显卡等项显示的是虚拟设备。不读取序列号、MAC 地址等可识别个人的信息。

## 设置项（核心里的键）

`search_template`、`block_trackers`、`block_ads`、`block_external_apps` 由核心直接生效；其余由外壳读取：`address_top`（Android、iOS：1 为地址栏在顶部）、`home_order`、`home_hidden`（主屏幕的顺序与从主屏幕拿掉的应用，由主页自己写）、`home_new_apps`（Android 主屏幕：0 为新应用只进"所有应用"）、`home_wallpaper`（Android 主屏幕：0 为不显示壁纸、用 Fable 自己的米白底色）、`ua_mode`（default / desktop / iphone / custom）、`ua_custom`、`javascript`、`data_saver`、`block_3p_cookies`、`private_screenshots`、`sleep_minutes`、`shortcuts`（JSON 数组 `[{"n":名称,"u":网址}]`）。把值设为空串即恢复默认。数据是两份制表符分隔的文本文件：`settings.tsv` 和 `history.tsv`（最多 5000 条）。

## 目录

```
core/        Rust 核心 + C 头文件
native/      汇编哈希、Zig 名单表、trackers.txt（追踪器）
rules/       独立分发的广告域名清单 ads.txt
ui/          newtab.html、reader.js、panel.html（编译进核心）
shell/       linux/ windows/ android/ macos/ harmony/ ios/ 六个外壳
tests/       C 链接测试、JNI 测试、面板交互测试与渲染工具
scripts/     ci/（Codemagic 上启动 macOS 与 iOS 模拟器版、截图的脚本）、build-android.sh、build-macos.sh、build-harmony.sh、build-ios.sh、gen_assets.py（换图标后重新生成各平台图标，含 macOS 的 .icns、iOS 的 AppIcon 和鸿蒙的分层图标）、harmony_icons.py（从 Android 矢量图标生成鸿蒙底栏的 SVG）
build.zig    Zig 交叉编译入口      Makefile  Linux 构建与测试入口
```

## 第三方素材

- 移动端主页按钮的图标（`shell/android/app/src/main/res/drawable/ic_home.xml`、`shell/harmony/entry/src/main/resources/base/media/ic_home.svg`、`ic_home_dark.svg`）来自 Google Material Symbols 的 "home"（outlined），按 Apache License 2.0 使用：https://github.com/google/material-design-icons
- 扫码按钮的图标（`shell/android/app/src/main/res/drawable/ic_camera.xml`、`shell/harmony/entry/src/main/resources/base/media/ic_scan.svg`、`ic_scan_dark.svg`）来自 Google Material Symbols 的 "qr_code_scanner"（outlined），按 Apache License 2.0 使用：https://github.com/google/material-design-icons/blob/master/symbols/web/qr_code_scanner/materialsymbolsoutlined/qr_code_scanner_24px.svg（与 home 一样从 960 格按 x/40、(y+960)/40 换算到 24 格）；iOS 与 macOS 仍用系统的 SF Symbol "qrcode"，Windows 用 Segoe MDL2 的 QRCode（ED14），Sailfish 用主题图标 icon-m-qr
