//! Windows: kernel32, advapi32 (registry) — no WMI, no COM.

use super::{meaningful, Battery, Facts, Volume};
use std::os::raw::c_void;

#[repr(C)]
struct MemoryStatusEx {
    length: u32,
    memory_load: u32,
    total_phys: u64,
    avail_phys: u64,
    total_page_file: u64,
    avail_page_file: u64,
    total_virtual: u64,
    avail_virtual: u64,
    avail_extended_virtual: u64,
}

#[repr(C)]
struct SystemPowerStatus {
    ac_line_status: u8,
    battery_flag: u8,
    battery_life_percent: u8,
    system_status_flag: u8,
    battery_life_time: u32,
    battery_full_life_time: u32,
}

type Hkey = *mut c_void;
const HKEY_LOCAL_MACHINE: Hkey = 0x8000_0002u32 as i32 as isize as Hkey; // sign-extended, as in winreg.h
const RRF_RT_REG_SZ: u32 = 0x2;
const RRF_RT_REG_DWORD: u32 = 0x10;

#[link(name = "kernel32")]
extern "system" {
    fn GlobalMemoryStatusEx(status: *mut MemoryStatusEx) -> i32;
    fn GetSystemPowerStatus(status: *mut SystemPowerStatus) -> i32;
    fn GetTickCount64() -> u64;
    fn GetDiskFreeSpaceExW(dir: *const u16, avail: *mut u64, total: *mut u64, free: *mut u64) -> i32;
    fn GetLogicalDriveStringsW(len: u32, buf: *mut u16) -> u32;
    fn GetDriveTypeW(root: *const u16) -> u32;
    fn GetVolumeInformationW(root: *const u16, name: *mut u16, name_len: u32, serial: *mut u32, max_component: *mut u32, flags: *mut u32,
                             fs: *mut u16, fs_len: u32) -> i32;
    fn GetComputerNameExW(kind: i32, buf: *mut u16, len: *mut u32) -> i32;
    fn GetUserDefaultLocaleName(buf: *mut u16, len: i32) -> i32;
    fn GetWindowsDirectoryW(buf: *mut u16, len: u32) -> u32;
    fn IsProcessorFeaturePresent(feature: u32) -> i32;
    fn SetErrorMode(mode: u32) -> u32;
}

#[link(name = "advapi32")]
extern "system" {
    fn RegGetValueW(key: Hkey, sub: *const u16, value: *const u16, flags: u32, kind: *mut u32, data: *mut c_void, len: *mut u32) -> i32;
}

fn wide(s: &str) -> Vec<u16> {
    s.encode_utf16().chain(std::iter::once(0)).collect()
}

fn from_wide(buf: &[u16]) -> String {
    let end = buf.iter().position(|&c| c == 0).unwrap_or(buf.len());
    String::from_utf16_lossy(&buf[..end]).trim().to_string()
}

fn reg_text(sub: &str, value: &str) -> String {
    let (sub, value) = (wide(sub), wide(value));
    let mut buf = [0u16; 512];
    let mut len = (buf.len() * 2) as u32;
    let ok = unsafe { RegGetValueW(HKEY_LOCAL_MACHINE, sub.as_ptr(), value.as_ptr(), RRF_RT_REG_SZ, std::ptr::null_mut(), buf.as_mut_ptr() as *mut c_void, &mut len) };
    if ok == 0 { from_wide(&buf) } else { String::new() }
}

fn reg_dword(sub: &str, value: &str) -> u32 {
    let (sub, value) = (wide(sub), wide(value));
    let mut data = 0u32;
    let mut len = 4u32;
    let ok = unsafe { RegGetValueW(HKEY_LOCAL_MACHINE, sub.as_ptr(), value.as_ptr(), RRF_RT_REG_DWORD, std::ptr::null_mut(), &mut data as *mut u32 as *mut c_void, &mut len) };
    if ok == 0 { data } else { 0 }
}

const CURRENT: &str = r"SOFTWARE\Microsoft\Windows NT\CurrentVersion";
const BIOS: &str = r"HARDWARE\DESCRIPTION\System\BIOS";
const CPU0: &str = r"HARDWARE\DESCRIPTION\System\CentralProcessor\0";

fn os(f: &mut Facts) {
    let build: u32 = reg_text(CURRENT, "CurrentBuildNumber").parse().unwrap_or(0);
    let ubr = reg_dword(CURRENT, "UBR");
    let mut product = reg_text(CURRENT, "ProductName");
    if build >= 22000 {
        product = product.replacen("Windows 10", "Windows 11", 1); // the registry still says 10 on 11
    }
    let display = reg_text(CURRENT, "DisplayVersion");
    let display = if display.is_empty() { reg_text(CURRENT, "ReleaseId") } else { display };
    f.build = if ubr > 0 { format!("{build}.{ubr}") } else { build.to_string() };
    f.os = [product, display, if build > 0 { format!("({})", f.build) } else { String::new() }]
        .into_iter().filter(|s| !s.is_empty()).collect::<Vec<_>>().join(" ");
    let major = reg_dword(CURRENT, "CurrentMajorVersionNumber");
    let minor = reg_dword(CURRENT, "CurrentMinorVersionNumber");
    f.kernel = if major > 0 { format!("NT {major}.{minor}.{build}") } else { format!("NT {}", reg_text(CURRENT, "CurrentVersion")) };
    let edition = reg_text(CURRENT, "EditionID");
    let lab = reg_text(CURRENT, "BuildLabEx");
    f.kernel_full = [lab, edition].into_iter().filter(|s| !s.is_empty()).collect::<Vec<_>>().join(" · ");
}

fn cpu(f: &mut Facts) {
    f.cpu_name = reg_text(CPU0, "ProcessorNameString");
    let mhz = reg_dword(CPU0, "~MHz");
    if f.cores > 0 {
        f.clusters.push((f.cores, mhz, f.cpu_name.clone()));
    }
    // A few features worth showing, by their PF_ numbers.
    let known = [(6, "sse"), (10, "sse2"), (13, "sse3"), (36, "ssse3"), (37, "sse4_1"), (38, "sse4_2"), (39, "avx"), (40, "avx2"), (41, "avx512f"),
                 (17, "nx"), (12, "rdrand"), (20, "virt"), (19, "slat"), (43, "arm_v8_crypto"), (34, "arm_v81_atomic"), (44, "arm_v82_dp")];
    let flags: Vec<&str> = known.iter().filter(|(pf, _)| unsafe { IsProcessorFeaturePresent(*pf) } != 0).map(|(_, n)| *n).collect();
    f.flags = flags.join(" ");
}

fn disks(f: &mut Facts) {
    unsafe { SetErrorMode(0x0001 | 0x8000) }; // no "insert a disk" dialogs for empty card readers
    let mut windir = [0u16; 260];
    let n = unsafe { GetWindowsDirectoryW(windir.as_mut_ptr(), windir.len() as u32) } as usize;
    let system_root: String = if n >= 3 { String::from_utf16_lossy(&windir[..3]) } else { "C:\\".into() };
    let mut buf = [0u16; 512];
    let len = unsafe { GetLogicalDriveStringsW(buf.len() as u32, buf.as_mut_ptr()) } as usize;
    for root in buf[..len.min(buf.len())].split(|&c| c == 0).filter(|r| !r.is_empty()) {
        let root_w: Vec<u16> = root.iter().copied().chain(std::iter::once(0)).collect();
        let kind = unsafe { GetDriveTypeW(root_w.as_ptr()) }; // 2 removable, 3 fixed, 4 network, 5 cd, 6 ram
        if kind != 2 && kind != 3 {
            continue;
        }
        let mut label = [0u16; 128];
        let mut fs = [0u16; 32];
        let ok = unsafe { GetVolumeInformationW(root_w.as_ptr(), label.as_mut_ptr(), 128, std::ptr::null_mut(), std::ptr::null_mut(), std::ptr::null_mut(), fs.as_mut_ptr(), 32) };
        if ok == 0 {
            continue;
        }
        let root = String::from_utf16_lossy(root);
        let label = from_wide(&label);
        let primary = root.eq_ignore_ascii_case(&system_root);
        if primary {
            let (mut avail, mut total, mut free) = (0u64, 0u64, 0u64);
            if unsafe { GetDiskFreeSpaceExW(root_w.as_ptr(), &mut avail, &mut total, &mut free) } != 0 {
                f.disk_total = total;
                f.disk_free = avail;
            }
        }
        f.volumes.push(Volume {
            name: if label.is_empty() { root.trim_end_matches('\\').to_string() } else { format!("{} ({})", label, root.trim_end_matches('\\')) },
            fs: from_wide(&fs),
            primary,
            removable: kind == 2,
        });
    }
}

fn battery() -> Option<Battery> {
    let mut s: SystemPowerStatus = unsafe { std::mem::zeroed() };
    if unsafe { GetSystemPowerStatus(&mut s) } == 0 || s.battery_flag == 128 || s.battery_flag == 255 {
        return None; // 128: no battery, 255: unknown
    }
    let charging = s.battery_flag & 8 != 0;
    Some(Battery {
        level: if s.battery_life_percent <= 100 { Some(s.battery_life_percent as u32) } else { None },
        status: if charging { "charging" } else if s.ac_line_status == 1 && s.battery_life_percent == 100 { "full" } else if s.ac_line_status == 1 { "not_charging" } else { "discharging" },
        plugged: match s.ac_line_status { 1 => "ac", 0 => "none", _ => "" },
        ..Default::default()
    })
}

/// Display adapters from the device class key; the basic and remote display
/// drivers only when there is nothing else.
fn gpu(f: &mut Facts) {
    const CLASS: &str = r"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}";
    let mut names: Vec<String> = Vec::new();
    let mut vendors: Vec<String> = Vec::new();
    for i in 0..10 {
        let key = format!(r"{CLASS}\{i:04}");
        let name = reg_text(&key, "DriverDesc");
        if name.is_empty() || names.contains(&name) {
            continue;
        }
        let vendor = reg_text(&key, "ProviderName");
        names.push(name);
        if !vendor.is_empty() && !vendors.contains(&vendor) {
            vendors.push(vendor);
        }
    }
    let real: Vec<String> = names.iter().filter(|n| !n.starts_with("Microsoft Basic") && !n.starts_with("Microsoft Remote")).cloned().collect();
    f.gpu = if real.is_empty() { names.join(" + ") } else { real.join(" + ") };
    f.gpu_vendor = vendors.into_iter().filter(|v| v != "Microsoft" || real.is_empty()).collect::<Vec<_>>().join(" + ");
}

pub fn fill(f: &mut Facts) {
    os(f);
    cpu(f);
    gpu(f);
    f.manufacturer = meaningful(&reg_text(BIOS, "SystemManufacturer"));
    f.model = meaningful(&reg_text(BIOS, "SystemProductName"));
    f.board = meaningful(&reg_text(BIOS, "BaseBoardProduct"));
    f.firmware = [meaningful(&reg_text(BIOS, "BIOSVendor")), meaningful(&reg_text(BIOS, "BIOSVersion")), meaningful(&reg_text(BIOS, "BIOSReleaseDate"))]
        .into_iter().filter(|s| !s.is_empty()).collect::<Vec<_>>().join(" · ");
    let mut m: MemoryStatusEx = unsafe { std::mem::zeroed() };
    m.length = std::mem::size_of::<MemoryStatusEx>() as u32;
    if unsafe { GlobalMemoryStatusEx(&mut m) } != 0 {
        f.mem_total = m.total_phys;
        f.mem_avail = m.avail_phys;
    }
    disks(f);
    f.battery = battery();
    f.uptime_ms = unsafe { GetTickCount64() };
    let mut name = [0u16; 256];
    let mut len = name.len() as u32;
    if unsafe { GetComputerNameExW(5, name.as_mut_ptr(), &mut len) } != 0 {
        f.hostname = from_wide(&name);
    }
    let mut locale = [0u16; 85];
    if unsafe { GetUserDefaultLocaleName(locale.as_mut_ptr(), locale.len() as i32) } > 0 {
        f.locales = from_wide(&locale);
    }
}
