# Fable Browser End User License Agreement (EULA)

Version: V1.2
Effective Date: November 25, 2026

---

## Preamble and Definitions

This Agreement is an agreement between you and the Licensor regarding the license and use of this Software. By installing, copying, or otherwise using this Software, you acknowledge that you have read, understood, and agree to be bound by all terms of this Agreement. If you do not agree to this Agreement, please do not install or use this Software, and uninstall and delete any copies you have obtained.

**This Software**: The Fable Browser application and its installation packages for various platforms, including embedded core programs and interface resources, but excluding web engines provided by various platform systems (see Article 6).

**Licensor**: Fable browser team (Contact Email: [fable-browser-team@astermail.org](mailto:fable-browser-team@astermail.org)).


**You (User)**: A natural person or organization that obtains, installs, or uses this Software.

**Official Release Channel**: GitHub release page [https://github.com/Fable-browser/Fable-browser](https://github.com/Fable-browser/Fable-browser). Only installation packages obtained through the Official Release Channel are protected by this Agreement; copies obtained through other channels are not endorsed by the Licensor.

## Article 1 Acceptance of Agreement

1.1 Your first installation of this Software, or continued use through installation package updates, shall be deemed as acceptance of the current version of this Agreement.

1.2 Minors shall use this Software with the consent and accompaniment of their guardians.

1.3 When you obtain this Software through an app store, the rules between you and the store also apply; this Agreement does not alter your rights and obligations with the store.

1.4 When the installation package is launched for the first time, the full text of this Agreement, the Privacy Policy, and the Third-Party Statement will be displayed in a pop-up window. You must click "Agree" individually to continue using it; if you do not click "Agree", you cannot enter the main interface. When the agreement version number changes due to uninstallation and reinstallation or version update, you also need to click "Agree" again. Silent distribution of the installation package without the user clicking "Agree" does not constitute acceptance within the meaning of Article 1.1.

## Article 2 Grant of License

2.1 The Licensor grants you a **free, non-exclusive, non-transferable, non-sublicensable** license to download, install, and run this Software for personal, non-commercial purposes, and to copy the installation package for backup purposes.

2.2 You may install this Software on multiple devices you own or control; this license applies to installation packages for each platform respectively.

2.3 This Software is provided free of charge as is, and the Licensor does not charge you a license fee; the charging rules of the acquisition channel (such as an app store) itself have nothing to do with the Licensor.

## Article 3 Available Regions

3.1 This Software is released to global users, but the Licensor has not adapted it for local compliance in any country or region. This Software is not provided or directed to the following countries or regions:
(1) Member states of the European Union and countries of the European Economic Area;
(2) The United Kingdom;
(3) The State of California, United States of America;
(4) Mainland China;
(5) Other regions publicized by the Licensor on the Official Release Channel (effective from the date of publicity).
The above list is a commercial arrangement made by the Licensor based on compliance costs and does not constitute recognition or guarantee of compliance for any region outside the list.

3.2 If you are in the regions listed in the preceding paragraph and still obtain or use this Software on your own, you shall confirm and bear the obligation to comply with local laws on your own; the Licensor makes no representation or warranty regarding the availability or legality in such regions.

3.3 The Licensor may adjust the list in Article 3.1 or the available regions of this Software; the adjustment shall take effect after being publicized on the Official Release Channel.

## Article 4 Distribution and Prohibited Acts

4.1 You may forward the installation package of this Software to others as is, free of charge, and without modification, provided that this Agreement, the Privacy Policy, and the Third-Party Statement are attached.

4.2 You shall not:
(1) Reverse engineer, decompile, or disassemble this Software, except as expressly permitted by law;
(2) Remove or modify any rights notices or license marks on this Software;
(3) Modify, split, or reorganize this Software or its installation package for distribution, or sell the installation package itself as a target;
(4) Use this Software for any illegal purpose, or use this Software to harm the legitimate rights and interests of others;
(5) Circumvent the regional arrangements in Article 3 to obtain parts of this Software that cannot be legally used under local laws.

4.3 If you violate this Article, the Licensor may terminate the license granted in Article 2.

## Article 5 Intellectual Property and Skin Description

5.1 The copyright and all intellectual property rights of this Software (excluding third-party components mentioned in Article 6) belong to the Licensor. This Agreement does not transfer any ownership, but only grants a license to use.

5.2 The built-in skins of this Software are only appearance variants of interface color schemes and icons. The rights to third-party names, logos, or stylized patterns appearing in the skins belong to their respective rights holders, and this Software does not claim their rights; their presentation does not constitute affiliation, recognition, or endorsement. If relevant rights holders have objections, they can provide feedback according to Article 13.3, and the Licensor will adjust or remove relevant content as appropriate.

## Article 6 Third-Party Components and System Software

6.1 This Software does not have a built-in web rendering engine. Web content is loaded by the web engine provided by the platform system you are using; such engines do not belong to this Software, and their behavior and policies are determined by the platform provider.

6.2 The third-party materials, lists, and components used by this Software and their licenses are detailed in the Third-Party Statement; the Third-Party Statement is an integral part of this Agreement.

6.3 Blocklists are maintained by the community, and their blocking results are not guaranteed to be complete or accurate.

## Article 7 User Data and Privacy

7.1 Your browsing data is saved locally on your device. The Licensor does not operate any servers to receive or store user data.

7.2 The categories and destinations of network requests that this Software may generate are detailed in the Privacy Policy; the Privacy Policy is an integral part of this Agreement. Traffic that the system web engine (see Article 6.1) and the operating system itself may initiate does not belong to the application-layer requests of this Software and is subject to the privacy policy of the corresponding platform provider.

7.3 You can clear local data through settings at any time, or delete its data by uninstalling this Software.

## Article 8 Description of Functional Features

8.1 Incognito mode does not save browsing history, site icons, cookies, and website data on the device, but it is not equivalent to anonymity at the network level: the websites you visit, your employer or school, and your internet service provider may still see your activity; downloaded files will be retained; when older system engines on some platforms cannot isolate cookies, the app will truthfully prompt.

8.2 Tracking blocking and ad blocking are best-effort and do not guarantee blocking all ads, tracking, or harmful content.

8.3 The scanning function decodes offline on the device and does not rely on any online services.

8.4 The device information displayed by the "Metadata" function comes from your device; except for the requests listed in Article 2 of the Privacy Policy, this information is not sent to the Licensor or any third party.

## Article 9 Disclaimer

9.1 This Software is provided "as is" and "as available". To the maximum extent permitted by applicable law, the Licensor does not represent or warrant that this Software will be uninterrupted, error-free, defect-free, compatible with all web pages or websites, or meet your specific purposes.

9.2 The web content you access, files you download, and external services you jump to through this Software involve risks. You shall judge and bear the risks of use on your own, and take security measures such as anti-virus on your own.

9.3 For liabilities that cannot be excluded or limited under applicable law (such as certain mandatory consumer protection or personal injury liability rules), this Article and Article 10 do not exclude such liabilities.

## Article 10 Limitation of Liability

10.1 To the maximum extent permitted by applicable law, the Licensor shall not be liable for any indirect, incidental, special, or punitive damages (including loss of profits, loss of data) arising from the use or inability to use this Software.

10.2 Your browsing data is saved locally on your device. Device loss, damage, or accidental clearing may lead to data loss; please back up important data yourself.

10.3 Article 9.3 also applies to this Article.

## Article 11 Modification and Termination of Agreement

11.1 The Licensor may update this Agreement. The updated agreement will be released with the new version of the installation package and publicized on the Official Release Channel; your continued use of this Software after the update shall be deemed as acceptance of the updated agreement. For major changes, the Licensor will prominently prompt in the release notes.

11.2 You may stop using and uninstall and delete this Software at any time, and this license shall terminate.

11.3 If you violate this Agreement, the Licensor may terminate your license; after termination, you shall stop using and delete this Software and its copies.

## Article 12 Applicable Law and Dispute Resolution

12.1 This Agreement shall be governed by the laws of Singapore, excluding the application of its conflict of law rules.

12.2 Any dispute arising out of or in connection with this Agreement shall first be resolved through friendly consultation between the parties; if consultation fails, either party may submit the dispute to a court with jurisdiction in Singapore. This Article does not affect the application of Article 12.3.

12.3 When you are a consumer, the consumer protection rights mandatorily granted by the laws of your location are not excluded by this Article.

## Article 13 General Terms

13.1 If any provision of this Agreement is held to be invalid or unenforceable, the validity of the remaining provisions shall not be affected.

13.2 The headings of each article in this Agreement are for convenience of reading only and do not affect the interpretation of the provisions.

13.3 For opinions on this Software or this Agreement, feedback and complaints from third-party rights holders, please contact: [fable-browser-team@astermail.org](mailto:fable-browser-team@astermail.org).


13.4 This Agreement is published in Chinese. The Licensor may publish translations in other languages, which are for reference only; in case of inconsistency between the Chinese text and the translation, the Chinese text shall prevail.

---

© 2026 Fable browser team. All rights reserved.
