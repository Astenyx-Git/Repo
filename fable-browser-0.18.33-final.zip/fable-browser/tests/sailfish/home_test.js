// The new-tab page as the Sailfish bridge builds it (tests/sailfish/bridge_test.cpp
// writes it): a search typed there reaches the shell's queue as "go\tq".
(function () {
  var log = [];
  function check(name, ok) { log.push((ok ? 'ok   ' : 'FAIL ') + name); }
  check('the FableHost stand-in ran before the page', !!window.FableHost);
  document.getElementById('q').value = '  旗鱼 jolla ';
  document.getElementById('search').dispatchEvent(new Event('submit', { cancelable: true }));
  var got = JSON.parse(eval(SAILFISH.drain));
  check('a search is queued for the shell as go\\tq, and draining empties it',
        got.length === 1 && got[0] === 'go\t旗鱼 jolla' && document.documentElement.getAttribute('data-fable-queue') === null);
  return log.join('\n');
})();
