//! macOS: sysctl and getifaddrs. The shell adds what needs Cocoa or IOKit
//! (screen, battery, disk space) as extras.

use super::{Facts, Network};
use std::ffi::{CStr, CString};
use std::os::raw::{c_char, c_int, c_uint, c_void};

extern "C" {
    fn sysctlbyname(name: *const c_char, oldp: *mut c_void, oldlenp: *mut usize, newp: *mut c_void, newlen: usize) -> c_int;
    fn getifaddrs(out: *mut *mut IfAddrs) -> c_int;
    fn freeifaddrs(list: *mut IfAddrs);
}

#[repr(C)]
struct IfAddrs {
    ifa_next: *mut IfAddrs,
    ifa_name: *mut c_char,
    ifa_flags: c_uint,
    ifa_addr: *mut SockAddr,
    ifa_netmask: *mut SockAddr,
    ifa_dstaddr: *mut SockAddr,
    ifa_data: *mut c_void,
}

#[repr(C)]
struct SockAddr {
    len: u8,
    family: u8,
    data: [u8; 14],
}

const AF_INET: u8 = 2;
const AF_INET6: u8 = 30;
const IFF_UP: c_uint = 0x1;
const IFF_LOOPBACK: c_uint = 0x8;

fn raw(name: &str) -> Option<Vec<u8>> {
    let c = CString::new(name).ok()?;
    let mut len = 0usize;
    if unsafe { sysctlbyname(c.as_ptr(), std::ptr::null_mut(), &mut len, std::ptr::null_mut(), 0) } != 0 || len == 0 {
        return None;
    }
    let mut buf = vec![0u8; len];
    if unsafe { sysctlbyname(c.as_ptr(), buf.as_mut_ptr() as *mut c_void, &mut len, std::ptr::null_mut(), 0) } != 0 {
        return None;
    }
    buf.truncate(len);
    Some(buf)
}

fn text(name: &str) -> String {
    raw(name).map(|b| String::from_utf8_lossy(&b).trim_end_matches('\0').trim().to_string()).unwrap_or_default()
}

fn int(name: &str) -> u64 {
    match raw(name) {
        Some(b) if b.len() == 8 => u64::from_ne_bytes(b[..8].try_into().unwrap()),
        Some(b) if b.len() == 4 => u32::from_ne_bytes(b[..4].try_into().unwrap()) as u64,
        _ => 0,
    }
}

fn prefix_len(mask: &[u8]) -> u32 {
    mask.iter().map(|b| b.count_ones()).sum()
}

/// The first interface that is up with an IPv4 address (en0 on most Macs),
/// and its addresses.
fn network() -> Network {
    let mut n = Network::default();
    let mut list: *mut IfAddrs = std::ptr::null_mut();
    if unsafe { getifaddrs(&mut list) } != 0 {
        return n;
    }
    let mut entries: Vec<(String, String, bool)> = Vec::new(); // (iface, "addr/prefix", is_v4)
    let mut cur = list;
    while !cur.is_null() {
        let ifa = unsafe { &*cur };
        cur = ifa.ifa_next;
        if ifa.ifa_addr.is_null() || ifa.ifa_name.is_null() || ifa.ifa_flags & IFF_LOOPBACK != 0 || ifa.ifa_flags & IFF_UP == 0 {
            continue;
        }
        let name = unsafe { CStr::from_ptr(ifa.ifa_name) }.to_string_lossy().to_string();
        let family = unsafe { (*ifa.ifa_addr).family };
        let raw = ifa.ifa_addr as *const u8;
        let mask = ifa.ifa_netmask as *const u8;
        if family == AF_INET {
            let a = unsafe { std::slice::from_raw_parts(raw.add(4), 4) };
            let bits = if mask.is_null() { 32 } else { prefix_len(unsafe { std::slice::from_raw_parts(mask.add(4), 4) }) };
            entries.push((name, format!("{}.{}.{}.{}/{}", a[0], a[1], a[2], a[3], bits), true));
        } else if family == AF_INET6 {
            let a = unsafe { std::slice::from_raw_parts(raw.add(8), 16) };
            let bits = if mask.is_null() { 128 } else { prefix_len(unsafe { std::slice::from_raw_parts(mask.add(8), 16) }) };
            let mut seg = [0u16; 8];
            for i in 0..8 {
                seg[i] = u16::from_be_bytes([a[2 * i], a[2 * i + 1]]);
            }
            entries.push((name, format!("{}/{}", std::net::Ipv6Addr::from(seg), bits), false));
        }
    }
    unsafe { freeifaddrs(list) };
    let iface = entries.iter().find(|(i, _, v4)| *v4 && i.starts_with("en")).or_else(|| entries.iter().find(|(_, _, v4)| *v4)).map(|e| e.0.clone());
    match iface {
        None => n.offline = true,
        Some(iface) => {
            if iface.starts_with("utun") || iface.starts_with("ipsec") || iface.starts_with("ppp") {
                n.transports.push("vpn");
            }
            let mut mine: Vec<&(String, String, bool)> = entries.iter().filter(|e| e.0 == iface).collect();
            mine.sort_by_key(|e| !e.2);
            n.addresses = mine.into_iter().map(|e| e.1.clone()).collect();
            n.iface = iface;
        }
    }
    for line in std::fs::read_to_string("/etc/resolv.conf").unwrap_or_default().lines() {
        if let Some(server) = line.trim().strip_prefix("nameserver") {
            let server = server.trim().to_string();
            if !server.is_empty() && !n.dns.contains(&server) {
                n.dns.push(server);
            }
        }
    }
    n
}

pub fn fill(f: &mut Facts) {
    let version = text("kern.osproductversion");
    f.build = text("kern.osversion");
    f.os = if version.is_empty() { "macOS".into() } else if f.build.is_empty() { format!("macOS {version}") } else { format!("macOS {version} ({})", f.build) };
    f.manufacturer = "Apple".into();
    f.model = text("hw.model"); // e.g. Mac14,2
    f.kernel = format!("Darwin {}", text("kern.osrelease"));
    f.kernel_full = text("kern.version");
    f.hostname = text("kern.hostname");
    f.cpu_name = text("machdep.cpu.brand_string");
    let logical = int("hw.logicalcpu");
    if logical > 0 {
        f.cores = logical as u32;
    }
    // Apple silicon: performance level 0 is the P cores, level 1 the E cores.
    for (level, label) in [(0, "Performance"), (1, "Efficiency")] {
        let count = int(&format!("hw.perflevel{level}.logicalcpu"));
        if count > 0 {
            let name = text(&format!("hw.perflevel{level}.name"));
            f.clusters.push((count as u32, 0, if name.is_empty() { label.to_string() } else { name }));
        }
    }
    let hz = int("hw.cpufrequency_max"); // Intel Macs only
    if f.clusters.is_empty() && f.cores > 0 {
        f.clusters.push((f.cores, (hz / 1_000_000) as u32, f.cpu_name.clone()));
    }
    let features = [text("machdep.cpu.features"), text("machdep.cpu.leaf7_features")].join(" ");
    f.flags = features.trim().to_lowercase();
    f.mem_total = int("hw.memsize");
    let page = int("hw.pagesize").max(4096);
    f.mem_avail = (int("vm.page_free_count") + int("vm.page_speculative_count")) * page;
    if let Some(b) = raw("kern.boottime") {
        if b.len() >= 8 {
            let secs = i64::from_ne_bytes(b[..8].try_into().unwrap());
            let now = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_secs() as i64).unwrap_or(0);
            if secs > 0 && now > secs {
                f.uptime_ms = ((now - secs) * 1000) as u64;
            }
        }
    }
    f.network = Some(network());
}
