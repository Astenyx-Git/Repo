// What the browser keeps about tabs and the bar, observed by the UI.
import { webview } from '@kit.ArkWeb';
import { common, Want } from '@kit.AbilityKit';
import { window } from '@kit.ArkUI';

/** The new-tab page is served from here by onInterceptRequest; .invalid never resolves. */
export const FABLE_HOME: string = 'https://newtab.fable.invalid/';
export const FABLE_ICON_ENDPOINT: string = 'https://newtab.fable.invalid/icon?';
/** The panel's own page, served the same way, and only to the panel's web view. */
export const FABLE_PANEL_URL: string = 'https://panel.fable.invalid/';

/** Colours shared with the Android bar: the default skin's, and private mode's (the same in every skin). */
export class FableColors {
  static readonly GROUND: string = '#FDF7F0';
  static readonly BAR: string = '#FBF2E8';
  static readonly INK: string = '#2A1A14';
  static readonly MUTED: string = '#5E4A3F';
  static readonly HINT: string = '#8A766A';
  static readonly LINE: string = '#EBDDD0';
  static readonly SPARK: string = '#D9512C';
  static readonly WHITE: string = '#FFFFFF';
  static readonly DARK_BAR: string = '#211611';
  static readonly DARK_PILL: string = '#33241D';
  static readonly DARK_LINE: string = '#4A372D';
  static readonly DARK_INK: string = '#FBEFE4';
  static readonly DARK_MUTED: string = '#C9B5A6';
  static readonly TOAST: string = '#F22A1A14';
}

@Observed
export class BrowserTab {
  id: number = 0;                    // id in the core's tab table
  incognito: boolean = false;
  controller: webview.WebviewController = new webview.WebviewController();
  generation: number = 0;            // a new web view (and controller) after sleeping
  asleep: boolean = false;           // no web view: the page was dropped to save memory
  attached: boolean = false;         // the controller is bound to its web view
  src: string = '';                  // the first page of the current web view
  pending: string = '';              // a page asked for before the web view was ready
  url: string = '';                  // shown in the address field; '' for our own pages
  pageUrl: string = '';              // the document in the view, our own pages included
  title: string = '';
  loading: boolean = false;
  progress: number = 0;
  iconUri: string = '';              // the page's favicon as a data: URI, for the tab list
}

/** Everything the bar and the overlays show, kept in step by Browser. */
@Observed
export class ChromeState {
  activeId: number = 0;
  incognito: boolean = false;
  address: string = '';
  editing: boolean = false;
  secure: boolean = false;
  loading: boolean = false;
  progress: number = 0;
  canBack: boolean = false;
  canForward: boolean = false;
  tabCount: number = 0;
  panelOpen: boolean = false;
  toast: string = '';
  toastShown: boolean = false;
  hint: string = '';                 // address field placeholder, in the UI language
  javascript: boolean = true;
  images: boolean = true;
  textZoom: number = 100;            // percent: the "text size" setting
  homeButton: boolean = false;       // the optional Home button in the bar
  scanOpen: boolean = false;         // fallback Camera Kit QR scanner overlay
  // The skin's colours (theme://name; core/src/theme.rs), set by FableBrowser.loadSkin.
  ground: string = FableColors.GROUND;
  bar: string = FableColors.BAR;
  ink: string = FableColors.INK;
  muted: string = FableColors.MUTED;
  hintColour: string = FableColors.HINT;
  line: string = FableColors.LINE;
  spark: string = FableColors.SPARK;
  pill: string = FableColors.WHITE;
  darkSkin: boolean = false;         // light system icons and the bar's light icons, a dark + on the accent
}

/** What the ability hands to the page: its context, window and a link to open. */
export class FableApp {
  static context: common.UIAbilityContext | undefined = undefined;
  static mainWindow: window.Window | undefined = undefined;
  static launchUrl: string = '';
  static onLink: (url: string) => void = (url: string): void => {
    FableApp.launchUrl = url;
  };

  static linkOf(want: Want): string {
    const uri: string = want.uri ?? '';
    return uri.startsWith('http://') || uri.startsWith('https://') ? uri : '';
  }
}
