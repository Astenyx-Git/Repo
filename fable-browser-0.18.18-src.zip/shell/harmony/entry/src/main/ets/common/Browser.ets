// Fable for HarmonyOS: everything the browser does, apart from drawing.
//
// Pages are ArkWeb views (one per tab, dropped while a tab sleeps). The menu,
// tabs, settings, history, resource list and metadata are the same HTML panel
// as on every other platform, shown in a web view of its own that alone gets
// the privileged FableUI bridge. Logic — address resolution, tracker
// blocking, the sleep policy, settings, history, resource sniffing, system
// facts — is the Rust core, reached through libfable.so.
import fable from 'libfable.so';
import { webview } from '@kit.ArkWeb';
import { common } from '@kit.AbilityKit';
import { BusinessError, pasteboard } from '@kit.BasicServicesKit';
import { fileIo, fileUri, picker } from '@kit.CoreFileKit';
import { image } from '@kit.ImageKit';
import { connection, http } from '@kit.NetworkKit';
import { display, UIContext, window } from '@kit.ArkUI';
import { util } from '@kit.ArkTS';
import { BrowserTab, ChromeState, FABLE_HOME, FABLE_ICON_ENDPOINT, FABLE_PANEL_URL, FableApp, FableColors } from './Model';
import { FableIcons } from './Icons';

const SLEEP_CHECK_MS: number = 30000;
const ANDROID_UA: string = 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 ' +
  '(KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36';
const IPHONE_UA: string = 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 ' +
  '(KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1';
const IPAD_UA: string = 'Mozilla/5.0 (iPad; CPU OS 17_5 like Mac OS X) AppleWebKit/605.1.15 ' +
  '(KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1';
const CHROME_WIN_UA: string = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ' +
  '(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';
const CHROME_MAC_UA: string = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 ' +
  '(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';
const SAFARI_MAC_UA: string = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 ' +
  '(KHTML, like Gecko) Version/18.1 Safari/605.1.15';
const FIREFOX_UA: string = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0';
const EDGE_UA: string = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ' +
  '(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0';
/** Hosts of the built-in shortcuts (ui/newtab.html), for sending their icons along with the page. */
const DEFAULT_SHORTCUT_HOSTS: string[] = ['claude.ai', 'chatgpt.com', 'chat.deepseek.com', 'gemini.google.com',
  'zh.wikipedia.org', 'ja.wikipedia.org', 'en.wikipedia.org', 'ko.wikipedia.org', 'ru.wikipedia.org', 'fr.wikipedia.org', 'es.wikipedia.org', 'ar.wikipedia.org',
  'github.com', 'www.bilibili.com', 'www.youtube.com'];

/** The new-tab page's search box calls FableHost.go(text). Every page sees it, but it can only navigate its own tab. */
export class FableHostBridge {
  private browser: FableBrowser;
  private tab: BrowserTab;

  constructor(browser: FableBrowser, tab: BrowserTab) {
    this.browser = browser;
    this.tab = tab;
  }

  go(query: string): void {
    setTimeout((): void => this.browser.navigate(this.tab, query), 0);
  }
}

/** The privileged bridge, for the panel's own page only. */
export class FablePanelBridge {
  private browser: FableBrowser;

  constructor(browser: FableBrowser) {
    this.browser = browser;
  }

  query(name: string, arg: string): string {
    return this.browser.panelQuery(name, arg);
  }

  act(name: string, arg: string): void {
    setTimeout((): void => this.browser.panelAct(name, arg), 0);   // not inside the page's call
  }
}

export class FableBrowser {
  tabs: BrowserTab[] = [];
  chrome: ChromeState = new ChromeState();
  active: BrowserTab | undefined = undefined;
  panelController: webview.WebviewController = new webview.WebviewController();
  panelBridge: FablePanelBridge = new FablePanelBridge(this);
  onTabsChanged: () => void = (): void => {};
  private lastNormal: BrowserTab | undefined = undefined;
  private lastPrivate: BrowserTab | undefined = undefined;
  private panelReady: boolean = false;
  private pendingPanelScript: string = '';
  private defaultUa: string = '';
  private icons: FableIcons | undefined = undefined;
  private ui: UIContext | undefined = undefined;
  private toastTimer: number = -1;
  private privateScreenshots: boolean = false;
  private privateDownloads: webview.WebDownloadDelegate = new webview.WebDownloadDelegate();
  private downloads: webview.WebDownloadDelegate = new webview.WebDownloadDelegate();
  private homeIcons: string = '';
  private homeIconsFor: string = '';
  private started: boolean = false;
  private adsUpdating: boolean = false;   // one ad-list fetch at a time

  // ---- start ----------------------------------------------------------------

  start(ui: UIContext): void {
    if (this.started) {
      return;
    }
    this.started = true;
    this.ui = ui;
    const context: common.UIAbilityContext | undefined = FableApp.context;
    const files: string = context !== undefined ? context.filesDir : '';
    try {
      this.defaultUa = webview.WebviewController.getDefaultUserAgent();
    } catch (e) {
      this.defaultUa = '';
    }
    this.icons = new FableIcons(files + '/icons', this.defaultUa);
    this.privateScreenshots = fable.settingGet('private_screenshots') === '1';
    this.applySleepSetting();
    this.applyCookieSetting();
    this.chrome.javascript = fable.settingGet('javascript') !== '0';
    this.chrome.images = fable.settingGet('data_saver') !== '1';
    this.chrome.textZoom = FableBrowser.textSize();
    this.chrome.homeButton = fable.settingGet('home_button') === '1';
    this.chrome.hint = fable.tr('addr_hint');
    this.forgetPrivateData();   // left over if the app was stopped with private tabs open
    this.hookDownloads(this.downloads, false);
    this.hookDownloads(this.privateDownloads, true);
    const restored: boolean = this.restoreSession();   // the tabs of the last run, unless that is switched off
    if (!restored || FableApp.launchUrl.length > 0) {   // a link handed over opens on top of them
      this.newTab(FableApp.launchUrl, false);
    }
    FableApp.launchUrl = '';
    FableApp.onLink = (url: string): void => this.newTab(url, false);
    setInterval((): void => this.sleepIdleTabs(), SLEEP_CHECK_MS);
    if (fable.adsUpdateDue()) {   // a week since the last fetch, while ad blocking is on
      this.fetchAdList();
    }
  }

  private now(): number {
    return Date.now();
  }

  // ---- the bar ----------------------------------------------------------------

  /** Bring the bar in line with the tab in front. */
  refreshChrome(): void {
    const t: BrowserTab | undefined = this.active;
    if (t === undefined) {
      return;
    }
    const c: ChromeState = this.chrome;
    const changedMode: boolean = c.incognito !== t.incognito || c.activeId === 0;
    c.activeId = t.id;
    c.incognito = t.incognito;
    if (!c.editing) {
      c.address = t.url;
    }
    c.secure = t.url.startsWith('https://');
    c.loading = t.loading;
    c.progress = t.progress;
    c.canBack = false;
    c.canForward = false;
    if (t.attached) {
      try {
        c.canBack = t.controller.accessBackward();
        c.canForward = t.controller.accessForward();
      } catch (e) {
        // the view is being replaced
      }
    }
    c.tabCount = Math.min(this.tabsIn(t.incognito).length, 99);   // the tabs of this mode only
    if (changedMode) {
      this.styleWindow(t.incognito);
    }
  }

  /** Private mode: dark system bars, and kept out of screenshots unless allowed (as Chrome does). */
  private styleWindow(incognito: boolean): void {
    const win: window.Window | undefined = FableApp.mainWindow;
    if (win === undefined) {
      return;
    }
    const bars: window.SystemBarProperties = {
      statusBarColor: incognito ? FableColors.DARK_BAR : FableColors.GROUND,
      navigationBarColor: incognito ? FableColors.DARK_BAR : FableColors.BAR,
      statusBarContentColor: incognito ? '#FFFFFF' : '#000000',
      navigationBarContentColor: incognito ? '#FFFFFF' : '#000000'
    };
    win.setWindowSystemBarProperties(bars).catch((e: BusinessError): void => {});
    win.setWindowPrivacyMode(incognito && !this.privateScreenshots).catch((e: BusinessError): void => {});
  }

  toast(message: string): void {
    if (message.length === 0) {
      return;
    }
    clearTimeout(this.toastTimer);
    this.chrome.toast = message;
    this.chrome.toastShown = true;
    this.toastTimer = setTimeout((): void => {
      this.chrome.toastShown = false;
    }, 2600);
  }

  /** A UI string; reading chrome.hint first makes the bar redraw when the language changes. */
  label(key: string): string {
    return this.chrome.hint.length >= 0 ? fable.tr(key) : '';
  }

  private trWith(key: string, value: string): string {
    return fable.tr(key).replace('{n}', value);
  }

  leaveAddress(): void {
    if (this.chrome.editing && this.ui !== undefined) {
      this.ui.getFocusController().clearFocus();
    }
    this.chrome.editing = false;
    if (this.active !== undefined) {
      this.chrome.address = this.active.url;
    }
  }

  addressEdited(editing: boolean): void {
    this.chrome.editing = editing;
    if (!editing && this.active !== undefined) {
      this.chrome.address = this.active.url;
    }
  }

  addressSubmitted(text: string): void {
    this.leaveAddress();
    if (this.active !== undefined && text.trim().length > 0) {
      this.navigate(this.active, text);
    }
  }

  /** Runs fn on the tab's controller when its web view is attached; false if it is not (or went away meanwhile). */
  private withView(t: BrowserTab | undefined, fn: (c: webview.WebviewController) => void): boolean {
    if (t === undefined || !t.attached) {
      return false;
    }
    try {
      fn(t.controller);
      return true;
    } catch (e) {
      return false;   // 17100001: the controller lost its web view
    }
  }

  private canGoBack(t: BrowserTab | undefined): boolean {
    let can: boolean = false;
    this.withView(t, (c: webview.WebviewController): void => {
      can = c.accessBackward();
    });
    return can;
  }

  goBack(): void {
    this.withView(this.active, (c: webview.WebviewController): void => {
      if (c.accessBackward()) {
        c.backward();
      }
    });
  }

  goForward(): void {
    this.withView(this.active, (c: webview.WebviewController): void => {
      if (c.accessForward()) {
        c.forward();
      }
    });
  }

  /** The Home button: the new-tab page, in this tab. */
  goHomePage(): void {
    this.leaveAddress();
    if (this.active !== undefined) {
      this.navigate(this.active, '');
    }
  }

  reloadOrStop(): void {
    const loading: boolean = this.active !== undefined && this.active.loading;
    this.withView(this.active, (c: webview.WebviewController): void => {
      if (loading) {
        c.stop();
      } else {
        c.refresh();
      }
    });
  }

  /** The system back gesture. False: let the system leave the app. */
  back(): boolean {
    const t: BrowserTab | undefined = this.active;
    if (this.chrome.panelOpen) {
      this.runInPanel('Fable.back()');
      return true;
    }
    if (this.chrome.editing) {
      this.leaveAddress();
      return true;
    }
    if (this.canGoBack(t)) {
      this.goBack();
      return true;
    }
    if (t !== undefined && (t.incognito || this.tabsIn(false).length > 1)) {   // the last private tab hands back to normal mode
      this.close(t);
      return true;
    }
    return false;
  }

  // ---- tabs ---------------------------------------------------------------------

  find(id: number): BrowserTab | undefined {
    return this.tabs.find((t: BrowserTab): boolean => t.id === id);
  }

  tabsIn(incognito: boolean): BrowserTab[] {
    return this.tabs.filter((t: BrowserTab): boolean => t.incognito === incognito);
  }

  inPrivate(): boolean {
    return this.active !== undefined && this.active.incognito;
  }

  private addTab(incognito: boolean, first: string): BrowserTab {
    const t: BrowserTab = new BrowserTab();
    t.id = fable.tabsOpen(this.now());
    t.incognito = incognito;
    t.title = fable.tr('newtab');
    t.src = first;
    this.tabs.push(t);
    this.onTabsChanged();
    return t;
  }

  newTab(input: string, incognito: boolean): void {
    const url: string = fable.resolve(input);
    const t: BrowserTab = this.addTab(incognito, url.length > 0 ? url : FABLE_HOME);
    this.activate(t);
  }

  /** Enter private mode: back to the private tab last in front, or a new one if there is none. */
  enterPrivate(): void {
    let t: BrowserTab | undefined = this.lastPrivate !== undefined && this.tabs.indexOf(this.lastPrivate) >= 0 ? this.lastPrivate : undefined;
    if (t === undefined) {
      const open: BrowserTab[] = this.tabsIn(true);
      t = open.length > 0 ? open[open.length - 1] : undefined;
    }
    if (t !== undefined) {
      this.activate(t);
    } else {
      this.newTab('', true);
    }
  }

  /** Leave private mode: close every private tab (which drops their data) and go back to the normal tabs. */
  exitPrivate(): number {
    const front: BrowserTab | undefined = this.inPrivate() ? this.active : undefined;
    let closed: number = 0;
    for (const t of this.tabsIn(true)) {
      if (t !== front) {
        this.close(t);
        closed++;
      }
    }
    if (front !== undefined) {   // last, so normal mode resumes only once
      this.close(front);
      closed++;
    }
    if (closed > 0) {
      this.toast(fable.tr('private_closed'));
    }
    return closed;
  }

  activate(t: BrowserTab): void {
    const previous: BrowserTab | undefined = this.active;
    if (previous !== undefined && previous !== t && previous.attached) {
      try {
        previous.controller.onInactive();
      } catch (e) {
        // not attached after all
      }
    }
    this.active = t;
    if (t.incognito) {
      this.lastPrivate = t;
    } else {
      this.lastNormal = t;
    }
    fable.tabsActivate(t.id, this.now());
    if (t.asleep) {   // wake: a new web view loads where the tab was
      t.controller = new webview.WebviewController();
      t.src = t.pageUrl.length > 0 ? t.pageUrl : FABLE_HOME;
      t.pending = '';
      t.attached = false;
      t.generation++;
      t.asleep = false;
    } else if (t.attached) {
      try {
        t.controller.onActive();
      } catch (e) {
        // not attached after all
      }
    }
    this.refreshChrome();
  }

  close(t: BrowserTab | undefined): void {
    if (t === undefined) {
      return;
    }
    const index: number = this.tabs.indexOf(t);
    if (index < 0) {
      return;
    }
    let next: BrowserTab | undefined = undefined;   // for the tab in front: its neighbour of the same mode, right first, then left
    if (t === this.active) {
      const same: BrowserTab[] = this.tabsIn(t.incognito);
      const at: number = same.indexOf(t);
      if (same.length > 1) {
        next = same[at + 1 < same.length ? at + 1 : at - 1];
      }
    }
    fable.tabsClose(t.id);
    fable.sniffClear(t.id);
    this.tabs.splice(index, 1);
    t.attached = false;
    this.onTabsChanged();
    if (!t.incognito) {
      this.saveSession();
    }
    if (t === this.lastNormal) {
      this.lastNormal = undefined;
    }
    if (t === this.lastPrivate) {
      this.lastPrivate = undefined;
    }
    if (t.incognito && this.tabsIn(true).length === 0) {
      setTimeout((): void => this.forgetPrivateData(), 500);
    }
    if (t !== this.active) {
      this.refreshChrome();
      return;
    }
    this.active = undefined;
    if (next !== undefined) {
      this.activate(next);
    } else if (t.incognito && this.tabsIn(false).length > 0) {   // the last private tab: back to normal mode where it was left
      const normal: BrowserTab[] = this.tabsIn(false);
      const back: BrowserTab | undefined = this.lastNormal !== undefined && this.tabs.indexOf(this.lastNormal) >= 0 ? this.lastNormal : undefined;
      this.activate(back !== undefined ? back : normal[normal.length - 1]);
    } else {
      this.newTab('', false);   // normal mode always has a tab
    }
  }

  // ---- restoring tabs ----------------------------------------------------------------

  private static isWeb(url: string): boolean {
    return url.startsWith('http://') || url.startsWith('https://');
  }

  /** Snapshot the normal tabs for "restore tabs on start"; the core keeps nothing while it is off. Private tabs never enter it. */
  saveSession(): void {
    const front: BrowserTab | undefined = this.active !== undefined && !this.active.incognito ? this.active : this.lastNormal;
    const list: string[] = [];
    let at: number = 0;
    for (const t of this.tabs) {
      if (t.incognito || !FableBrowser.isWeb(t.url) || list.length >= 500) {   // 500: what the core accepts
        continue;
      }
      if (t === front) {
        at = list.length;
      }
      list.push('{"u":' + JSON.stringify(t.url) + ',"n":' + JSON.stringify(t.title) + '}');
    }
    fable.panelQuery('sessionSave', '{"a":' + at + ',"t":[' + list.join(',') + ']}', 0);
  }

  /** Reopen the normal tabs of the last run: asleep (an address and a title) except the one that was in front. */
  private restoreSession(): boolean {
    if (fable.settingGet('restore_tabs') === '0') {
      return false;
    }
    const count: number = fable.sessionCount();
    const wanted: number = fable.sessionActive();
    let front: BrowserTab | undefined = undefined;
    for (let i = 0; i < count; i++) {
      const url: string = fable.sessionUrl(i);
      if (!FableBrowser.isWeb(url)) {   // only web pages, whatever the file says
        continue;
      }
      const t: BrowserTab = new BrowserTab();
      t.id = fable.tabsOpen(this.now());
      t.asleep = true;   // no web view until it is shown
      t.pageUrl = url;
      t.url = url;
      const title: string = fable.sessionTitle(i);
      t.title = title.length > 0 ? title : url;
      this.tabs.push(t);
      if (front === undefined || i === wanted) {
        front = t;
      }
    }
    if (front === undefined) {
      return false;
    }
    this.onTabsChanged();
    this.activate(front);   // wakes it: a web view loads the page
    return true;
  }

  // ---- bookmarks ------------------------------------------------------------------

  /** The bookmark id of the tab's page: 0 for private tabs and pages not on the web. */
  private bookmarkId(t: BrowserTab | undefined): number {
    if (t === undefined || t.incognito || !FableBrowser.isWeb(t.url)) {
      return 0;
    }
    return Number(fable.panelQuery('bookmarkId', t.url, 0) ?? '0');
  }

  private toggleBookmark(): void {
    const t: BrowserTab | undefined = this.active;
    if (t === undefined || t.incognito || !FableBrowser.isWeb(t.url)) {
      return;
    }
    const id: number = this.bookmarkId(t);
    if (id > 0) {
      fable.panelQuery('bookmarkRemove', String(id), 0);
      this.toast(fable.tr('removed_bookmark'));
    } else {
      fable.panelQuery('bookmarkAdd', t.url + '\n' + t.title.replace(new RegExp('\n', 'g'), ' '), 0);
      this.toast(fable.tr('added_bookmark'));
    }
    if (this.chrome.panelOpen) {
      this.runInPanel('Fable.update(' + this.panelState() + ')');
    }
  }

  /** Import a Chrome/Firefox bookmark file (HTML, at most 4 MiB) picked in Files. */
  private importBookmarks(): void {
    const context: common.UIAbilityContext | undefined = FableApp.context;
    if (context === undefined) {
      return;
    }
    const options: picker.DocumentSelectOptions = new picker.DocumentSelectOptions();
    options.maxSelectNumber = 1;
    options.fileSuffixFilters = ['HTML|.html,.htm'];
    new picker.DocumentViewPicker(context).select(options).then((uris: string[]): void => {
      if (uris.length === 0) {
        return;   // cancelled
      }
      let html: string = '';
      try {
        const file: fileIo.File = fileIo.openSync(uris[0], fileIo.OpenMode.READ_ONLY);
        try {
          const size: number = fileIo.statSync(file.fd).size;
          if (size > 4 * 1024 * 1024) {
            throw new Error('too big');
          }
          const buffer: ArrayBuffer = new ArrayBuffer(size);
          fileIo.readSync(file.fd, buffer);
          html = util.TextDecoder.create('utf-8').decodeToString(new Uint8Array(buffer));
        } finally {
          fileIo.closeSync(file);
        }
      } catch (e) {
        this.toast(fable.tr('bookmark_import_failed'));
        return;
      }
      this.toast(this.trWith('bookmark_imported', fable.panelQuery('bookmarkImport', html, 0) ?? '0'));
      if (this.chrome.panelOpen) {
        this.runInPanel("Fable.refresh('bookmarks')");
      }
    }).catch((e: BusinessError): void => {
      this.toast(fable.tr('bookmark_import_failed'));
    });
  }

  /** Export the bookmarks as an HTML file Chrome and Firefox can import, saved where the user picks. */
  private exportBookmarks(): void {
    const context: common.UIAbilityContext | undefined = FableApp.context;
    if (context === undefined) {
      return;
    }
    const options: picker.DocumentSaveOptions = new picker.DocumentSaveOptions();
    options.newFileNames = ['bookmarks.html'];
    new picker.DocumentViewPicker(context).save(options).then((uris: string[]): void => {
      if (uris.length === 0) {
        return;   // cancelled
      }
      try {
        const file: fileIo.File = fileIo.openSync(uris[0], fileIo.OpenMode.WRITE_ONLY | fileIo.OpenMode.CREATE | fileIo.OpenMode.TRUNC);
        try {
          fileIo.writeSync(file.fd, fable.panelQuery('bookmarkExport', '', 0) ?? '');
        } finally {
          fileIo.closeSync(file);
        }
        this.toast(fable.tr('exported_bookmark'));
      } catch (e) {
        this.toast(fable.tr('bookmark_export_failed'));
      }
    }).catch((e: BusinessError): void => {
      this.toast(fable.tr('bookmark_export_failed'));
    });
  }

  /** Wipe what private tabs stored. All private web views share one incognito store. */
  private forgetPrivateData(): void {
    if (this.tabsIn(true).length > 0) {
      return;
    }
    try {
      webview.WebCookieManager.clearAllCookiesSync(true);
      webview.WebStorage.deleteAllData(true);
    } catch (e) {
      // nothing stored yet
    }
  }

  navigate(t: BrowserTab, input: string): void {
    const resolved: string = fable.resolve(input);
    const url: string = resolved.length > 0 ? resolved : FABLE_HOME;
    if (!t.attached) {
      t.pending = url;
      return;
    }
    try {
      t.controller.loadUrl(url);
    } catch (e) {
      t.pending = url;
    }
  }

  /** Background tabs the core reports as idle drop their web view; the URL stays. */
  private sleepIdleTabs(): void {
    for (const id of fable.tabsCollectSleepers(this.now())) {
      const t: BrowserTab | undefined = this.find(id);
      if (t === undefined || t === this.active || t.asleep) {
        continue;
      }
      t.attached = false;
      t.asleep = true;
    }
  }

  // ---- settings that shape the web views -----------------------------------------

  userAgent(): string {
    const mode: string = fable.settingGet('ua_mode');
    if (mode === 'desktop') {
      const match: RegExpMatchArray | null = this.defaultUa.match(new RegExp('Chrome/(\\d+)'));
      const major: string = match !== null && match.length > 1 ? match[1] : '132';
      return 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/' + major + '.0.0.0 Safari/537.36';
    }
    if (mode === 'android') {
      return ANDROID_UA;
    }
    if (mode === 'iphone') {
      return IPHONE_UA;
    }
    if (mode === 'ipad') {
      return IPAD_UA;
    }
    if (mode === 'chrome_win') {
      return CHROME_WIN_UA;
    }
    if (mode === 'chrome_mac') {
      return CHROME_MAC_UA;
    }
    if (mode === 'safari_mac') {
      return SAFARI_MAC_UA;
    }
    if (mode === 'firefox') {
      return FIREFOX_UA;
    }
    if (mode === 'edge') {
      return EDGE_UA;
    }
    if (mode === 'custom') {
      const custom: string = fable.settingGet('ua_custom').trim();
      if (custom.length > 0) {
        return custom;
      }
    }
    return this.defaultUa;
  }

  private applyUserAgent(t: BrowserTab): void {
    if (!t.attached) {
      return;
    }
    try {
      t.controller.setCustomUserAgent(this.userAgent());
    } catch (e) {
      // detached meanwhile
    }
  }

  /** The "text size" setting as ArkWeb's text zoom, in percent (50–300; 100 when unset). */
  static textSize(): number {
    const v: number = Number(fable.settingGet('text_size'));
    return Number.isNaN(v) || v <= 0 ? 100 : Math.max(50, Math.min(300, v));
  }

  /** Orientation, keeping the screen on, the status bar: settings of the window, applied when it exists and on change. */
  static applyWindowSettings(win: window.Window | undefined): void {
    if (win === undefined) {
      return;
    }
    const mode: string = fable.settingGet('orientation');
    const orientation: window.Orientation = mode === 'portrait' ? window.Orientation.AUTO_ROTATION_PORTRAIT_RESTRICTED
      : mode === 'landscape' ? window.Orientation.AUTO_ROTATION_LANDSCAPE_RESTRICTED : window.Orientation.UNSPECIFIED;
    try {
      win.setPreferredOrientation(orientation).catch((e: BusinessError): void => {});
      win.setWindowKeepScreenOn(fable.settingGet('keep_screen_on') === '1').catch((e: BusinessError): void => {});
      win.setSpecificSystemBarEnabled('status', fable.settingGet('hide_status_bar') !== '1').catch((e: BusinessError): void => {});
    } catch (e) {
      // a window being torn down
    }
  }

  private applySleepSetting(): void {
    const minutes: string = fable.settingGet('sleep_minutes');
    const value: number = minutes.length > 0 ? Number(minutes) : 10;
    fable.tabsSetSleepAfterMs((Number.isNaN(value) ? 10 : value) * 60000);
  }

  private applyCookieSetting(): void {
    try {   // third-party cookies are blocked unless switched off
      webview.WebCookieManager.putAcceptThirdPartyCookieEnabled(fable.settingGet('block_3p_cookies') === '0');
    } catch (e) {
      // older ArkWeb
    }
  }

  /** After the panel changed a setting. */
  private settingChanged(key: string): void {
    if (key === 'sleep_minutes') {
      this.applySleepSetting();
    } else if (key === 'home_button') {
      this.chrome.homeButton = fable.settingGet(key) === '1';
    } else if (key === 'text_size') {
      this.chrome.textZoom = FableBrowser.textSize();   // takes effect at once, no reload
    } else if (key === 'orientation' || key === 'keep_screen_on' || key === 'hide_status_bar') {
      FableBrowser.applyWindowSettings(FableApp.mainWindow);
    } else if (key === 'private_screenshots') {
      this.privateScreenshots = fable.settingGet(key) === '1';
      this.styleWindow(this.inPrivate());
    } else if (key === 'language') {
      this.chrome.hint = fable.tr('addr_hint');
      for (const t of this.tabs) {
        if (t.url.length === 0) {
          t.title = fable.tr('newtab');
          this.withView(t, (c: webview.WebviewController): void => c.refresh());   // the new-tab page in the new language
        }
      }
      this.panelReady = false;     // the panel is a page in the old language: load it again, back at the settings
      this.pendingPanelScript = this.chrome.panelOpen ? 'Fable.show("settings",' + this.panelState() + ')' : '';
      try {
        this.panelController.loadUrl(FABLE_PANEL_URL);
      } catch (e) {
        // not attached yet: it loads in the new language anyway
      }
    } else if (key === 'ua_mode' || key === 'ua_custom' || key === 'javascript' || key === 'data_saver' || key === 'block_3p_cookies') {
      this.chrome.javascript = fable.settingGet('javascript') !== '0';
      this.chrome.images = fable.settingGet('data_saver') !== '1';
      this.applyCookieSetting();
      for (const t of this.tabs) {
        this.applyUserAgent(t);
      }
      const front: BrowserTab | undefined = this.active;
      if (front !== undefined && front.url.length > 0) {
        this.withView(front, (c: webview.WebviewController): void => c.refresh());
      }
    }
  }

  private clearData(what: string): void {
    const historyCleared: boolean = !what.includes('history') || fable.historyClear();
    if (what.includes('history') && historyCleared) {
      this.icons?.clear();
    }
    if (what.includes('cookies')) {
      try {
        webview.WebCookieManager.clearAllCookiesSync();
        webview.WebStorage.deleteAllData();
      } catch (e) {
        // nothing stored
      }
    }
    const front: BrowserTab | undefined = this.active;
    if (what.includes('cache') && front !== undefined && front.attached) {
      try {
        front.controller.removeCache(true);
      } catch (e) {
        // detached meanwhile
      }
    }
    this.toast(fable.tr(historyCleared ? 'data_cleared' : 'history_clear_failed'));
  }

  // ---- page web views ----------------------------------------------------------------

  /** The web view of a tab is ready: user agent and downloads before its first page (src) loads. */
  attached(t: BrowserTab): void {
    t.attached = true;
    this.applyUserAgent(t);
    try {
      t.controller.setDownloadDelegate(t.incognito ? this.privateDownloads : this.downloads);
    } catch (e) {
      // downloads then go nowhere; the page still works
    }
    const asked: string = t.pending;   // navigated before the view was ready
    t.pending = '';
    if (asked.length > 0) {
      this.withView(t, (c: webview.WebviewController): void => c.loadUrl(asked));
    }
    if (t !== this.active) {
      try {
        t.controller.onInactive();
      } catch (e) {
        // fine
      }
    }
    if (t === this.active) {
      this.refreshChrome();
    }
  }

  /** What the address field shows for a page URL: nothing for our own pages. */
  private static shown(url: string): string {
    return url.startsWith(FABLE_HOME) || url.startsWith('about:') || url.startsWith('data:') ? '' : url;
  }

  private static respond(mime: string, data: string | ArrayBuffer, code: number, reason: string): WebResourceResponse {
    const r: WebResourceResponse = new WebResourceResponse();
    r.setResponseData(data);
    r.setResponseMimeType(mime);
    r.setResponseEncoding('utf-8');
    r.setResponseCode(code);
    r.setReasonMessage(reason);
    r.setResponseIsReady(true);
    return r;
  }

  private homeIconsJson(): string {
    const icons: FableIcons | undefined = this.icons;
    if (icons === undefined) {
      return '';
    }
    const shortcuts: string = fable.settingGet('shortcuts');
    const key: string = icons.version + '|' + shortcuts;
    if (key === this.homeIconsFor) {
      return this.homeIcons;
    }
    let hosts: string[] = [];
    if (shortcuts.length > 0) {
      const found: RegExpMatchArray | null = shortcuts.match(new RegExp('"u"\\s*:\\s*"([^"]*)"', 'g'));
      for (const item of found ?? []) {
        hosts.push(FableIcons.hostOf(item.replace(new RegExp('^"u"\\s*:\\s*"'), '')));
      }
    } else {
      hosts = DEFAULT_SHORTCUT_HOSTS;
    }
    this.homeIcons = icons.bundle(hosts);
    this.homeIconsFor = key;
    return this.homeIcons;
  }

  /**
   * Every request of a page: our new-tab page and its icons are served here,
   * trackers get an empty answer, and media goes to the resource list.
   * Undefined: load from the network as usual.
   */
  intercept(t: BrowserTab, request: WebResourceRequest): WebResourceResponse | undefined {
    const url: string = request.getRequestUrl();
    if (request.isMainFrame()) {
      t.pageUrl = url;            // the document itself is never blocked
      fable.sniffClear(t.id);     // a new page: start its resource list afresh
      fable.sniffNote(t.id, url, '');   // ...which may itself be a media file opened directly
      if (!url.startsWith(FABLE_HOME)) {
        return undefined;
      }
      return FableBrowser.respond('text/html', fable.newtabPage(t.incognito ? 1 : 0, t.incognito ? '' : this.homeIconsJson()), 200, 'OK');
    }
    if (url.startsWith(FABLE_ICON_ENDPOINT)) {
      // Shortcut icons for the new-tab page, and for that page only: answering any
      // other site would let it probe which hosts have been visited.
      let png: ArrayBuffer | undefined = undefined;
      const icons: FableIcons | undefined = this.icons;
      if (t.pageUrl.startsWith(FABLE_HOME) && icons !== undefined) {
        const origin: string = decodeURIComponent(url.substring(FABLE_ICON_ENDPOINT.length).replace(new RegExp('^u='), ''));
        png = icons.get(FableIcons.hostOf(origin));
        if (png === undefined) {
          icons.request(origin);
        }
      }
      return png !== undefined ? FableBrowser.respond('image/png', png, 200, 'OK') : FableBrowser.respond('text/plain', '', 404, 'Not Found');
    }
    if (fable.shouldBlock(url, t.pageUrl)) {
      return FableBrowser.respond('text/plain', '', 403, 'Blocked');
    }
    // Resource sniffing: players fetch media with Range requests; the core decides what to keep.
    let ranged: boolean = false;
    for (const h of request.getRequestHeader()) {
      if (h.headerKey.toLowerCase() === 'range') {
        ranged = true;
      }
    }
    if (fable.sniffNote(t.id, url, ranged ? 'range' : '') && this.chrome.panelOpen) {
      setTimeout((): void => this.runInPanel('Fable.refresh(\'sniff\')'), 0);
    }
    return undefined;
  }

  /** Links to things that are not web pages: tel:, mailto: go to their apps; other schemes are not followed. */
  loadIntercept(request: WebResourceRequest): boolean {
    const url: string = request.getRequestUrl();
    if (fable.blockExternalApp(url)) {
      // The page tried to leave the browser for another app and the setting says no.
      this.toast(fable.tr('external_app_blocked'));
      return true;
    }
    const scheme: string = url.substring(0, Math.max(0, url.indexOf(':'))).toLowerCase();
    if (scheme === 'http' || scheme === 'https' || scheme === 'about' || scheme === 'data' || scheme === 'blob') {
      return false;
    }
    if ((scheme === 'tel' || scheme === 'mailto') && FableApp.context !== undefined) {
      FableApp.context.openLink(url).catch((e: BusinessError): void => {});
    }
    return true;
  }

  pageBegin(t: BrowserTab, url: string): void {
    t.pageUrl = url;
    t.url = FableBrowser.shown(url);
    t.loading = true;
    t.progress = 5;
    t.iconUri = '';
    if (t === this.active) {
      this.refreshChrome();
    }
  }

  pageEnd(t: BrowserTab, url: string): void {
    t.loading = false;
    t.url = FableBrowser.shown(url);
    if (fable.settingGet('block_ads') === '1') {
      // Hide the ad boxes the page shows itself; the network side
      // (fable.shouldBlock) already stops the third-party ones.
      t.controller.runJavaScript(fable.adblockScript()).catch((e: BusinessError): void => {});
    }
    let title: string = '';
    try {
      title = t.controller.getTitle();
    } catch (e) {
      title = '';
    }
    this.remember(t, title);
    if (!t.incognito) {
      this.saveSession();   // the snapshot follows along, so a crash loses little
    }
    if (t === this.active) {
      this.refreshChrome();
    }
  }

  progressChanged(t: BrowserTab, percent: number): void {
    t.progress = percent;
    if (t === this.active && t.loading) {
      this.chrome.progress = percent;
    }
  }

  titleReceived(t: BrowserTab, title: string): void {
    t.title = t.pageUrl.startsWith(FABLE_HOME) ? fable.tr('newtab') : title.length > 0 ? title : t.url;
    this.remember(t, title);
  }

  historyChanged(t: BrowserTab, url: string): void {
    t.url = FableBrowser.shown(url);   // also fires for in-page navigation (single-page apps)
    if (t === this.active) {
      this.refreshChrome();
    }
  }

  faviconReceived(t: BrowserTab, icon: image.PixelMap): void {
    if (t.pageUrl.startsWith(FABLE_HOME)) {
      return;
    }
    const packer: image.ImagePacker = image.createImagePacker();
    const options: image.PackingOption = { format: 'image/png', quality: 100 };
    packer.packToData(icon, options).then((png: ArrayBuffer): void => {
      packer.release();
      t.iconUri = 'data:image/png;base64,' + new util.Base64Helper().encodeToStringSync(new Uint8Array(png));
    }).catch((e: BusinessError): void => {
      packer.release();
    });
    if (!t.incognito) {
      this.icons?.offer(FableIcons.hostOf(t.pageUrl), icon);   // private tabs leave no icon behind
    }
  }

  /** target=_blank and window.open(): a tab of our own, same privacy mode; no pop-ups the user did not ask for. */
  windowRequested(t: BrowserTab, url: string, byUser: boolean): void {
    if (!byUser) {
      return;
    }
    this.newTab(url, t.incognito);
  }

  /** Record the visit in the history, unless the tab is private or shows one of our own pages. */
  private remember(t: BrowserTab, title: string): void {
    if (t.incognito || t.url.length === 0 || !(t.url.startsWith('http://') || t.url.startsWith('https://'))) {
      return;
    }
    const named: boolean = title.length > 0 && !title.startsWith('http') && !t.url.includes(title);
    fable.historyAdd(t.url, named ? title : '', Date.now());
  }

  toggleReader(): void {
    const t: BrowserTab | undefined = this.active;
    if (t === undefined || !t.attached) {
      return;
    }
    t.controller.runJavaScript(fable.readerScript()).then((result: string): void => {
      if (result === '"none"') {
        this.toast(fable.tr('no_article'));
      } else if (result === '"on"') {
        this.toast(fable.tr('reader_on'));
      } else if (result !== '"off"') {
        this.toast(fable.tr('reader_unsupported'));
      }
    }).catch((e: BusinessError): void => {
      this.toast(fable.tr('reader_unsupported'));
    });
  }

  /** Resource sniffing, the part the network cannot show: the page's media elements, large images and resource list. */
  private scanPageForResources(): void {
    const t: BrowserTab | undefined = this.active;
    if (t === undefined || !t.attached) {
      return;
    }
    t.controller.runJavaScript(fable.sniffJs()).then((json: string): void => {
      if (fable.sniffNoteScan(t.id, json) > 0 && this.chrome.panelOpen) {
        this.runInPanel('Fable.refresh(\'sniff\')');
      }
    }).catch((e: BusinessError): void => {});   // the page blocked the script
  }

  // ---- downloads --------------------------------------------------------------------

  /** Files land in the app's cache first, then move to Download/Fable, which the Files app shows. */
  private hookDownloads(delegate: webview.WebDownloadDelegate, incognito: boolean): void {
    const records = new Map<string, number>();
    delegate.onBeforeDownload((item: webview.WebDownloadItem): void => {
      const context: common.UIAbilityContext | undefined = FableApp.context;
      if (context === undefined) {
        item.cancel();
        return;
      }
      const dir: string = context.cacheDir + '/downloads';
      try {
        fileIo.mkdirSync(dir, true);
      } catch (e) {
        // exists already
      }
      const name: string = FableBrowser.safeName(item.getSuggestedFileName());
      const guid = item.getGuid();
      const record = incognito ? 0 : fable.downloadBegin(name);
      records.set(guid, record);
      try {
        item.start(dir + '/' + guid + '-' + name);
      } catch (e) {
        records.delete(guid);
        fable.downloadFinish(record, 0);
        this.toast(fable.tr('dl_fail'));
        return;
      }
      this.toast(this.trWith('dl_start', name));
    });
    delegate.onDownloadFinish((item: webview.WebDownloadItem): void => {
      const guid = item.getGuid();
      const record = records.get(guid) ?? 0;
      records.delete(guid);
      this.publish(item.getFullPath(), FableBrowser.safeName(item.getSuggestedFileName()), record);
    });
    delegate.onDownloadFailed((item: webview.WebDownloadItem): void => {
      const guid = item.getGuid();
      fable.downloadFinish(records.get(guid) ?? 0, 0);
      records.delete(guid);
      this.toast(fable.tr('dl_fail'));
    });
  }

  private static safeName(name: string): string {
    const clean: string = name.replace(new RegExp('[\\\\/:*?"<>|\\u0000-\\u001f]', 'g'), '_').trim();
    return clean.length > 0 ? clean : 'download';
  }

  /** The public download folder (Download/Fable), asked for once through the system's download picker. */
  private downloadFolder(): Promise<string> {
    const known: string = fable.settingGet('harmony_download_dir');
    if (known.length > 0) {
      return Promise.resolve(known);
    }
    const context: common.UIAbilityContext | undefined = FableApp.context;
    if (context === undefined) {
      return Promise.reject(new Error('no context'));
    }
    const options: picker.DocumentSaveOptions = new picker.DocumentSaveOptions();
    options.pickerMode = picker.DocumentPickerMode.DOWNLOAD;
    return new picker.DocumentViewPicker(context).save(options).then((uris: string[]): string => {
      const path: string = uris.length > 0 ? new fileUri.FileUri(uris[0]).path : '';
      if (path.length === 0) {
        throw new Error('no folder');
      }
      fable.settingSet('harmony_download_dir', path);
      return path;
    });
  }

  private publish(source: string, name: string, record: number): void {
    this.downloadFolder().then((dir: string): void => {
      let target: string = dir + '/' + name;
      const dot: number = name.lastIndexOf('.');
      const stem: string = dot > 0 ? name.substring(0, dot) : name;
      const ext: string = dot > 0 ? name.substring(dot) : '';
      for (let i = 2; fileIo.accessSync(target) && i < 1000; i++) {   // name (2).ext …
        target = dir + '/' + stem + ' (' + i + ')' + ext;
      }
      fileIo.copyFileSync(source, target);
      fable.downloadFinish(record, 1);
      try { fileIo.unlinkSync(source); } catch (e) { /* already published */ }
      this.toast(this.trWith('mac_downloaded', target.substring(target.lastIndexOf('/') + 1)));
    }).catch((e: Error): void => {
      fable.downloadFinish(record, 0);
      this.toast(fable.tr('dl_fail'));
    });
  }

  // ---- metadata ------------------------------------------------------------------------

  private engine(): string {
    const ark: RegExpMatchArray | null = this.defaultUa.match(new RegExp('ArkWeb/([\\d.]+)'));
    const chrome: RegExpMatchArray | null = this.defaultUa.match(new RegExp('Chrome/([\\d.]+)'));
    const parts: string[] = [];
    if (ark !== null && ark.length > 1) {
      parts.push('ArkWeb ' + ark[1]);
    }
    if (chrome !== null && chrome.length > 1) {
      parts.push((parts.length > 0 ? '(Chromium ' : 'Chromium ') + chrome[1] + (parts.length > 0 ? ')' : ''));
    }
    return parts.length > 0 ? parts.join(' ') : 'ArkWeb';
  }

  /** The screen, the engine and the user agent: what only the shell can see. */
  private deviceExtras(): string {
    const parts: string[] = ['"engine":' + JSON.stringify(this.engine()), '"ua":' + JSON.stringify(this.userAgent()), '"cookies":true'];
    try {
      const d: display.Display = display.getDefaultDisplaySync();
      parts.push('"screenW":' + Math.min(d.width, d.height), '"screenH":' + Math.max(d.width, d.height));   // portrait order, as phones are specified
      parts.push('"dpi":' + d.densityDPI, '"refresh":' + Math.round(d.refreshRate));
    } catch (e) {
      // no display
    }
    return '{' + parts.join(',') + '}';
  }

  private systemExtras(): string {
    const parts: string[] = [];
    try {
      const d: display.Display = display.getDefaultDisplaySync();
      parts.push('"display":{"w":' + Math.min(d.width, d.height) + ',"h":' + Math.max(d.width, d.height) + ',"dpi":' + d.densityDPI +
        ',"refresh":' + Math.round(d.refreshRate) + ',"density":' + d.densityPixels + '}');
    } catch (e) {
      // no display
    }
    const network: string = this.networkFacts();
    if (network.length > 0) {
      parts.push('"network":' + network);
    }
    return '{' + parts.join(',') + '}';
  }

  /** Transports, interface, addresses, DNS and MTU of the default network. No Wi-Fi name: that needs the user's consent. */
  private networkFacts(): string {
    try {
      const net: connection.NetHandle = connection.getDefaultNetSync();
      if (net.netId === 0) {
        return '{"offline":true}';
      }
      const caps: connection.NetCapabilities = connection.getNetCapabilitiesSync(net);
      const props: connection.ConnectionProperties = connection.getConnectionPropertiesSync(net);
      const transports: string[] = [];
      for (const bearer of caps.bearerTypes) {
        if (bearer === connection.NetBearType.BEARER_WIFI) {
          transports.push('"wifi"');
        } else if (bearer === connection.NetBearType.BEARER_CELLULAR) {
          transports.push('"cellular"');
        } else if (bearer === connection.NetBearType.BEARER_ETHERNET) {
          transports.push('"ethernet"');
        } else if (bearer === connection.NetBearType.BEARER_VPN) {
          transports.push('"vpn"');
        } else if (bearer === connection.NetBearType.BEARER_BLUETOOTH) {
          transports.push('"bluetooth"');
        }
      }
      const addresses: string[] = props.linkAddresses.map((a: connection.LinkAddress): string => JSON.stringify(a.address.address + '/' + a.prefixLength));
      const dns: string[] = props.dnses.map((a: connection.NetAddress): string => JSON.stringify(a.address));
      return '{"transports":[' + transports.join(',') + '],"iface":' + JSON.stringify(props.interfaceName) +
        ',"addresses":[' + addresses.join(',') + '],"dns":[' + dns.join(',') + ']' + (props.mtu > 0 ? ',"mtu":' + props.mtu : '') + '}';
    } catch (e) {
      return '';
    }
  }

  private fetchText(url: string): Promise<string> {
    const client: http.HttpRequest = http.createHttp();
    const headers: Record<string, string> = { 'User-Agent': this.userAgent() };
    const options: http.HttpRequestOptions = {
      method: http.RequestMethod.GET,
      header: headers,
      expectDataType: http.HttpDataType.STRING,
      connectTimeout: 10000,
      readTimeout: 10000,
      usingCache: false
    };
    return client.request(url, options).then((reply: http.HttpResponse): string => {
      client.destroy();
      return reply.responseCode === 200 && typeof reply.result === 'string' ? reply.result as string : '';
    }).catch((e: BusinessError): string => {
      client.destroy();
      return '';
    });
  }

  /** Fetch the built-in community ad lists (at most 8 MiB each) and hand
   * them to the core, concatenated. A source that fails is skipped. The
   * shell fetches because the core builds offline and has no HTTP client. */
  private fetchAdList(): void {
    if (this.adsUpdating) {
      return;
    }
    const sources: string[] = fable.adsUpdateSources().split('\n');
    this.adsUpdating = true;
    let all: string = '';
    let i: number = 0;
    const next = (): void => {
      if (i >= sources.length) {
        this.adsUpdating = false;
        if (all.length > 0) {
          fable.adsUpdateApply(all);
        }
        return;
      }
      const url: string = sources[i++];
      if (url.length === 0) {
        next();
        return;
      }
      this.fetchText(url).then((body: string): void => {
        if (body.length > 0 && body.length <= 8 * 1024 * 1024 + 1) {
          all += body + '\n';
        }
        next();
      });
    };
    next();
  }

  /** Public IP for the metadata sheet: Cloudflare's trace, then ipify. No cookies. */
  private lookupIp(): void {
    this.fetchText('https://www.cloudflare.com/cdn-cgi/trace').then((body: string): Promise<string> => {
      const info: string = fable.parseIpReply(body, 'cloudflare.com');
      if (info.length > 0) {
        return Promise.resolve(info);
      }
      return this.fetchText('https://api.ipify.org?format=json').then((json: string): string => fable.parseIpReply(json, 'ipify.org'));
    }).then((info: string): void => {
      this.runInPanel('Fable.ip(' + (info.length > 0 ? info : '{}') + ')');
    });
  }

  private copy(text: string, message: string): void {
    try {
      const data: pasteboard.PasteData = pasteboard.createData(pasteboard.MIMETYPE_TEXT_PLAIN, text);
      pasteboard.getSystemPasteboard().setData(data).then((): void => this.toast(fable.tr(message)))
        .catch((e: BusinessError): void => {});
    } catch (e) {
      // nothing copied
    }
  }

  // ---- the panel: menu, tabs, settings, history, resources, metadata ----------------------

  panelLoaded(): void {
    this.panelReady = true;
    if (this.pendingPanelScript.length > 0) {
      const script: string = this.pendingPanelScript;
      this.pendingPanelScript = '';
      this.panelController.runJavaScript(script).catch((e: BusinessError): void => {});
    }
  }

  /** The panel's own page, and nothing else, for the panel's web view. */
  panelIntercept(request: WebResourceRequest): WebResourceResponse {
    if (request.getRequestUrl().startsWith(FABLE_PANEL_URL) && request.isMainFrame()) {
      return FableBrowser.respond('text/html', fable.panelPage(), 200, 'OK');
    }
    return FableBrowser.respond('text/plain', '', 404, 'Not Found');
  }

  runInPanel(script: string): void {
    if (this.panelReady) {
      this.panelController.runJavaScript(script).catch((e: BusinessError): void => {});
    } else {
      this.pendingPanelScript = script;
    }
  }

  private iconFor(t: BrowserTab): string {
    if (t.incognito) {
      return t.iconUri;
    }
    if (t.pageUrl.startsWith(FABLE_HOME)) {
      return fable.logoUri();
    }
    return t.iconUri.length > 0 ? t.iconUri : (this.icons?.dataUri(FableIcons.hostOf(t.url)) ?? '');
  }

  /** What the panel needs to know about the browser right now, as JSON. */
  panelState(): string {
    const front: BrowserTab | undefined = this.active;
    const list: string[] = this.tabs.map((t: BrowserTab): string =>
      '{"id":' + t.id + ',"title":' + JSON.stringify(t.title) + ',"url":' + JSON.stringify(t.url) + ',"icon":' + JSON.stringify(this.iconFor(t)) +
      ',"active":' + (t === front) + ',"private":' + t.incognito + ',"asleep":' + t.asleep + '}');
    return '{"tabs":[' + list.join(',') + '],"incognito":' + this.inPrivate() + ',"active":' + (front !== undefined ? front.id : 0) +
      ',"url":' + JSON.stringify(front !== undefined ? front.url : '') + ',"title":' + JSON.stringify(front !== undefined ? front.title : '') +
      ',"web":' + (front !== undefined && !front.incognito && front.url.length > 0) + ',"desktop":' + (fable.settingGet('ua_mode') === 'desktop') +
      ',"blocked":' + fable.blockedCount() + ',"sniffed":' + (front !== undefined ? fable.sniffCount(front.id) : 0) +
      ',"bookmarked":' + this.bookmarkId(front) + ',"version":' + JSON.stringify(fable.version()) + ',"platform":"harmony"' +
      ',"caps":{"addressBarTop":false,"bookmarks":true,"restoreTabs":true}}';   // the address bar stays at the bottom here (the top is an Android option)
  }

  showPanel(view: string): void {
    this.leaveAddress();
    this.chrome.panelOpen = true;
    this.runInPanel('Fable.show(' + JSON.stringify(view) + ',' + this.panelState() + ')');
  }

  /** Synchronous requests from the panel's page. */
  panelQuery(name: string, arg: string): string {
    if (name === 'icon') {   // a stored icon of a host as a data: URI; never fetches
      return this.icons?.dataUri(arg) ?? '';
    }
    if (name === 'device') {   // facts for the metadata sheet that pages cannot read
      return fable.deviceInfo(this.deviceExtras());
    }
    const answer: string | null = fable.panelQuery(name, arg, this.active !== undefined ? this.active.id : 0);
    if (name === 'set') {
      const key: string = arg.substring(0, Math.max(0, arg.indexOf('\n')));
      setTimeout((): void => this.settingChanged(key), 0);
    } else if (name === 'historyClear' && answer === '') {
      this.icons?.clear();
    }
    return answer ?? '';
  }

  /** Actions the panel asks for. */
  panelAct(name: string, arg: string): void {
    const front: BrowserTab | undefined = this.active;
    if (name === 'hidden') {
      this.chrome.panelOpen = false;
    } else if (name === 'newTab') {
      this.newTab('', false);
    } else if (name === 'newPrivate') {
      this.newTab('', true);
    } else if (name === 'enterPrivate') {
      this.enterPrivate();
    } else if (name === 'exitPrivate') {
      this.exitPrivate();
      if (this.chrome.panelOpen) {
        this.runInPanel('Fable.update(' + this.panelState() + ')');
      }
    } else if (name === 'switchTab') {
      const t: BrowserTab | undefined = this.find(Number(arg));
      if (t !== undefined) {
        this.activate(t);
      }
    } else if (name === 'closeTab') {
      this.close(this.find(Number(arg)));
      if (this.chrome.panelOpen) {
        this.runInPanel('Fable.update(' + this.panelState() + ')');
      }
    } else if (name === 'open') {
      if (front !== undefined) {
        this.navigate(front, arg);
      } else {
        this.newTab(arg, false);
      }
    } else if (name === 'openNew') {
      this.newTab(arg, front !== undefined && front.incognito);
    } else if (name === 'reader') {
      this.toggleReader();
    } else if (name === 'desktop') {
      const on: boolean = fable.settingGet('ua_mode') === 'desktop';
      fable.settingSet('ua_mode', on ? 'default' : 'desktop');
      this.settingChanged('ua_mode');
      this.toast(fable.tr(on ? 'mobile_on' : 'desktop_on'));
    } else if (name === 'clear') {
      this.clearData(arg);
    } else if (name === 'sniffScan') {
      this.scanPageForResources();
    } else if (name === 'download') {
      if (front !== undefined && front.attached) {
        try {
          front.controller.startDownload(arg);
        } catch (e) {
          this.toast(fable.tr('dl_fail'));
        }
      }
    } else if (name === 'copy') {
      this.copy(arg, 'link_copied');
    } else if (name === 'copyText') {
      this.copy(arg, 'm_copied');
    } else if (name === 'system') {   // everything else for the metadata sheet
      this.runInPanel('Fable.system(' + fable.systemInfo(this.systemExtras()) + ')');
    } else if (name === 'ip') {
      this.lookupIp();
    } else if (name === 'toast') {
      this.toast(arg);
    } else if (name === 'bookmarkToggle') {   // the star in the menu: the page in front
      this.toggleBookmark();
    } else if (name === 'bookmarkImportPick') {
      this.importBookmarks();
    } else if (name === 'bookmarkExport') {
      this.exportBookmarks();
    }
  }
}
