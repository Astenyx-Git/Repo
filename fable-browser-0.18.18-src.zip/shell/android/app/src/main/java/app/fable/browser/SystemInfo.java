package app.fable.browser;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.KeyguardManager;
import android.app.admin.DevicePolicyManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.FeatureInfo;
import android.content.res.Configuration;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.media.MediaDrm;
import android.net.ConnectivityManager;
import android.net.LinkAddress;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.LocaleList;
import android.os.PowerManager;
import android.os.StatFs;
import android.os.SystemClock;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.format.DateFormat;
import android.util.DisplayMetrics;
import android.util.Size;
import android.util.SizeF;
import android.view.Display;
import android.view.DisplayCutout;
import android.view.WindowInsets;
import android.view.accessibility.AccessibilityManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileReader;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeSet;
import java.util.UUID;

/**
 * Everything about the system an app can read without asking the user: no
 * runtime permission, only the two install-time ones in the manifest (network
 * and Wi-Fi state). Identifiers the system withholds (IMEI, serial number,
 * MAC address, the Widevine device ID) are not requested; neither is the
 * Wi-Fi name, which needs location permission.
 *
 * Every value is read on its own, so one call the device refuses or does not
 * have only leaves that value out. Facts that cannot change while the app
 * runs (codecs, sensors, cameras, CPU, DRM) are read once and kept.
 */
final class SystemInfo {
    private static final UUID WIDEVINE = new UUID(0xEDEF8BA979D64ACEL, 0xA3C827DCD51D21EDL);
    private static final UUID PLAYREADY = new UUID(0x9A04F07998404286L, 0xAB92E65BE0885F95L);
    private static final UUID CLEARKEY = new UUID(0xE2719D58A985B3C9L, 0x781AB030AF78D30EL);

    private static JSONObject staticPart;   // read once per process

    private interface Value { Object get() throws Exception; }

    private SystemInfo() {}

    private static void put(JSONObject o, String key, Value v) {
        try {
            Object value = v.get();
            if (value != null && !"".equals(value)) o.put(key, value);
        } catch (Throwable unavailable) {
            // Not on this device, not on this Android version, or not allowed: leave it out.
        }
    }

    /** What must be read on the UI thread: things that live on the window. */
    static JSONObject window(Activity a) {
        JSONObject o = new JSONObject();
        if (Build.VERSION.SDK_INT >= 28) {
            put(o, "cutout", () -> {
                WindowInsets insets = a.getWindow().getDecorView().getRootWindowInsets();
                DisplayCutout cutout = insets == null ? null : insets.getDisplayCutout();
                if (cutout == null) return "none";
                int top = cutout.getSafeInsetTop(), bottom = cutout.getSafeInsetBottom(), left = cutout.getSafeInsetLeft(), right = cutout.getSafeInsetRight();
                return top > 0 ? "top " + top : bottom > 0 ? "bottom " + bottom : left > 0 ? "left " + left : right > 0 ? "right " + right : "none";
            });
        }
        return o;
    }

    /** Everything else. Takes up to a few hundred milliseconds the first time: call off the UI thread. */
    static synchronized String collect(Activity a, JSONObject fromWindow) {
        JSONObject all = new JSONObject();
        try {
            if (staticPart == null) staticPart = readStatic(a);
            for (java.util.Iterator<String> keys = staticPart.keys(); keys.hasNext(); ) {
                String k = keys.next();
                all.put(k, staticPart.get(k));
            }
            JSONObject display = all.optJSONObject("display");
            if (display == null) display = new JSONObject();
            for (java.util.Iterator<String> keys = fromWindow.keys(); keys.hasNext(); ) {
                String k = keys.next();
                display.put(k, fromWindow.get(k));
            }
            all.put("display", display);
            all.put("system", system(a));
            all.put("memory", memory(a));
            all.put("storage", storage(a));
            all.put("network", network(a));
            all.put("wifi", wifi(a));
            all.put("carrier", carrier(a));
            all.put("battery", battery(a));
            all.put("audio", audio(a));
        } catch (JSONException impossible) { }
        return all.toString();
    }

    private static JSONObject readStatic(Activity a) throws JSONException {
        JSONObject o = new JSONObject();
        o.put("cpu", cpu());
        o.put("display", display(a));
        o.put("gl", graphics(a));
        o.put("media", media());
        o.put("sensors", sensors(a));
        o.put("cameras", cameras(a));
        o.put("features", features(a));
        return o;
    }

    // ---- system and firmware ---------------------------------------------------

    @SuppressWarnings("deprecation")
    private static JSONObject system(Activity a) {
        JSONObject o = new JSONObject();
        put(o, "brand", () -> Build.BRAND);
        put(o, "manufacturer", () -> Build.MANUFACTURER);
        put(o, "model", () -> Build.MODEL);
        put(o, "device", () -> Build.DEVICE);
        put(o, "product", () -> Build.PRODUCT);
        put(o, "board", () -> Build.BOARD);
        put(o, "hardware", () -> Build.HARDWARE);
        put(o, "bootloader", () -> Build.BOOTLOADER);
        put(o, "build", () -> Build.DISPLAY);
        put(o, "incremental", () -> Build.VERSION.INCREMENTAL);
        put(o, "fingerprint", () -> Build.FINGERPRINT);
        put(o, "type", () -> Build.TYPE);
        put(o, "tags", () -> Build.TAGS);
        put(o, "buildTime", () -> Build.TIME);
        put(o, "android", () -> Build.VERSION.RELEASE);
        put(o, "sdk", () -> Build.VERSION.SDK_INT);
        put(o, "patch", () -> Build.VERSION.SECURITY_PATCH);
        put(o, "baseband", Build::getRadioVersion);
        if (Build.VERSION.SDK_INT >= 31) {
            put(o, "socMaker", () -> Build.SOC_MANUFACTURER);
            put(o, "socModel", () -> Build.SOC_MODEL);
            put(o, "sku", () -> Build.SKU);
        }
        put(o, "vm", () -> System.getProperty("java.vm.name") + " " + System.getProperty("java.vm.version"));
        put(o, "kernel", () -> System.getProperty("os.version"));
        put(o, "kernelFull", () -> firstLine("/proc/version"));
        put(o, "uptime", SystemClock::elapsedRealtime);
        put(o, "bootTime", () -> System.currentTimeMillis() - SystemClock.elapsedRealtime());
        put(o, "androidId", () -> Settings.Secure.getString(a.getContentResolver(), Settings.Secure.ANDROID_ID));
        if (Build.VERSION.SDK_INT >= 25) put(o, "deviceName", () -> Settings.Global.getString(a.getContentResolver(), Settings.Global.DEVICE_NAME));
        put(o, "secure", () -> ((KeyguardManager) a.getSystemService(Context.KEYGUARD_SERVICE)).isDeviceSecure());
        put(o, "encryption", () -> {
            switch (((DevicePolicyManager) a.getSystemService(Context.DEVICE_POLICY_SERVICE)).getStorageEncryptionStatus()) {
                case DevicePolicyManager.ENCRYPTION_STATUS_ACTIVE_PER_USER: return "file";
                case DevicePolicyManager.ENCRYPTION_STATUS_ACTIVE:
                case DevicePolicyManager.ENCRYPTION_STATUS_ACTIVE_DEFAULT_KEY: return "on";
                case DevicePolicyManager.ENCRYPTION_STATUS_INACTIVE: return "off";
                default: return null;
            }
        });
        put(o, "devOptions", () -> Settings.Global.getInt(a.getContentResolver(), Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1);
        put(o, "adb", () -> Settings.Global.getInt(a.getContentResolver(), Settings.Global.ADB_ENABLED, 0) == 1);
        put(o, "a11y", () -> ((AccessibilityManager) a.getSystemService(Context.ACCESSIBILITY_SERVICE)).isEnabled());
        put(o, "screenReader", () -> ((AccessibilityManager) a.getSystemService(Context.ACCESSIBILITY_SERVICE)).isTouchExplorationEnabled());
        PowerManager power = (PowerManager) a.getSystemService(Context.POWER_SERVICE);
        put(o, "powerSave", power::isPowerSaveMode);
        put(o, "batteryOptimized", () -> !power.isIgnoringBatteryOptimizations(a.getPackageName()));
        if (Build.VERSION.SDK_INT >= 29) put(o, "thermal", power::getCurrentThermalStatus);
        put(o, "locales", () -> LocaleList.getDefault().toLanguageTags());
        put(o, "clock24", () -> DateFormat.is24HourFormat(a));
        put(o, "fontScale", () -> a.getResources().getConfiguration().fontScale);
        put(o, "animScale", () -> Settings.Global.getFloat(a.getContentResolver(), Settings.Global.ANIMATOR_DURATION_SCALE, 1f));
        put(o, "night", () -> (a.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES);
        return o;
    }

    // ---- processor ---------------------------------------------------------------

    /** ARM core names by MIDR part number (implementer 0x41). */
    private static final Map<Integer, String> ARM_CORES = new LinkedHashMap<>();
    static {
        Object[][] cores = {
            {0xd03, "Cortex-A53"}, {0xd04, "Cortex-A35"}, {0xd05, "Cortex-A55"}, {0xd07, "Cortex-A57"}, {0xd08, "Cortex-A72"},
            {0xd09, "Cortex-A73"}, {0xd0a, "Cortex-A75"}, {0xd0b, "Cortex-A76"}, {0xd0d, "Cortex-A77"}, {0xd41, "Cortex-A78"},
            {0xd44, "Cortex-X1"}, {0xd46, "Cortex-A510"}, {0xd47, "Cortex-A710"}, {0xd48, "Cortex-X2"}, {0xd4d, "Cortex-A715"},
            {0xd4e, "Cortex-X3"}, {0xd80, "Cortex-A520"}, {0xd81, "Cortex-A720"}, {0xd82, "Cortex-X4"},
        };
        for (Object[] c : cores) ARM_CORES.put((Integer) c[0], (String) c[1]);
    }

    private static JSONObject cpu() throws JSONException {
        JSONObject o = new JSONObject();
        int cores = Runtime.getRuntime().availableProcessors();
        o.put("cores", cores);
        o.put("abis", new JSONArray(Arrays.asList(Build.SUPPORTED_ABIS)));

        // /proc/cpuinfo: one block per core; older kernels add a "Hardware" line naming the chip.
        List<String> parts = new ArrayList<>();
        String implementer = "", features = "", hardware = "";
        try (BufferedReader in = new BufferedReader(new FileReader("/proc/cpuinfo"))) {
            for (String line; (line = in.readLine()) != null; ) {
                int colon = line.indexOf(':');
                if (colon < 0) continue;
                String key = line.substring(0, colon).trim(), value = line.substring(colon + 1).trim();
                if (key.equals("CPU part")) parts.add(value);
                else if (key.equals("CPU implementer")) implementer = value;
                else if (key.equals("Features") && features.isEmpty()) features = value;
                else if (key.equals("Hardware")) hardware = value;
            }
        } catch (Exception unreadable) { }
        if (!features.isEmpty()) o.put("flags", features);
        if (!hardware.isEmpty()) o.put("hardware", hardware);

        // Group cores into clusters by type and top frequency: "4 × 2.0 GHz Cortex-A520 + ...".
        JSONArray clusters = new JSONArray();
        String lastKey = null;
        JSONObject current = null;
        for (int i = 0; i < cores; i++) {
            long khz = 0;
            try { khz = Long.parseLong(firstLine("/sys/devices/system/cpu/cpu" + i + "/cpufreq/cpuinfo_max_freq").trim()); } catch (Exception unknown) { }
            String name = "";
            if (i < parts.size()) {
                try {
                    int part = Integer.decode(parts.get(i));
                    name = "0x41".equalsIgnoreCase(implementer) && ARM_CORES.containsKey(part) ? ARM_CORES.get(part) : "";
                } catch (NumberFormatException ignored) { }
            }
            String key = khz + "|" + name;
            if (!key.equals(lastKey)) {
                current = new JSONObject().put("count", 0).put("mhz", khz / 1000);
                if (!name.isEmpty()) current.put("name", name);
                clusters.put(current);
                lastKey = key;
            }
            current.put("count", current.getInt("count") + 1);
        }
        if (clusters.length() > 0 && !(clusters.length() == 1 && clusters.getJSONObject(0).getLong("mhz") == 0 && !clusters.getJSONObject(0).has("name"))) {
            o.put("clusters", clusters);
        }
        return o;
    }

    // ---- memory and storage ---------------------------------------------------------

    private static JSONObject memory(Activity a) {
        JSONObject o = new JSONObject();
        ActivityManager am = (ActivityManager) a.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo info = new ActivityManager.MemoryInfo();
        put(o, "total", () -> { am.getMemoryInfo(info); return info.totalMem > 0 ? info.totalMem : null; });   // 0 means unknown
        put(o, "avail", () -> info.totalMem > 0 ? info.availMem : null);
        put(o, "threshold", () -> info.threshold > 0 ? info.threshold : null);
        put(o, "low", () -> info.lowMemory);
        put(o, "lowRamDevice", am::isLowRamDevice);
        put(o, "appLimit", am::getMemoryClass);
        put(o, "appLimitLarge", am::getLargeMemoryClass);
        return o;
    }

    private static JSONObject storage(Activity a) {
        JSONObject o = new JSONObject();
        StatFs fs = new StatFs(a.getFilesDir().getPath());
        put(o, "total", () -> fs.getTotalBytes() > 0 ? fs.getTotalBytes() : null);   // 0 means unknown
        put(o, "free", () -> fs.getTotalBytes() > 0 ? fs.getAvailableBytes() : null);
        put(o, "volumes", () -> {
            JSONArray list = new JSONArray();
            for (StorageVolume v : ((StorageManager) a.getSystemService(Context.STORAGE_SERVICE)).getStorageVolumes()) {
                list.put(new JSONObject().put("name", v.getDescription(a)).put("primary", v.isPrimary())
                        .put("removable", v.isRemovable()).put("emulated", v.isEmulated()).put("state", v.getState()));
            }
            return list;
        });
        return o;
    }

    // ---- display and graphics -------------------------------------------------------

    @SuppressWarnings("deprecation")
    private static JSONObject display(Activity a) {
        JSONObject o = new JSONObject();
        Display d = a.getWindowManager().getDefaultDisplay();
        DisplayMetrics dm = new DisplayMetrics();
        d.getRealMetrics(dm);
        put(o, "name", d::getName);
        put(o, "w", () -> Math.min(dm.widthPixels, dm.heightPixels));
        put(o, "h", () -> Math.max(dm.widthPixels, dm.heightPixels));
        put(o, "dpi", () -> dm.densityDpi);
        put(o, "xdpi", () -> Math.round(dm.xdpi));
        put(o, "inches", () -> {
            double w = dm.widthPixels / dm.xdpi, h = dm.heightPixels / dm.ydpi;
            double inches = Math.sqrt(w * w + h * h);
            return inches > 1 && inches < 40 ? Math.round(inches * 10) / 10.0 : null;
        });
        put(o, "refresh", () -> Math.round(d.getRefreshRate()));
        put(o, "modes", () -> {
            TreeSet<Integer> rates = new TreeSet<>();
            for (Display.Mode m : d.getSupportedModes()) rates.add(Math.round(m.getRefreshRate()));
            return new JSONArray(rates);
        });
        put(o, "hdr", () -> {
            Display.HdrCapabilities caps = d.getHdrCapabilities();
            if (caps == null) return null;
            JSONArray types = new JSONArray();
            for (int t : caps.getSupportedHdrTypes()) {
                switch (t) {
                    case Display.HdrCapabilities.HDR_TYPE_DOLBY_VISION: types.put("Dolby Vision"); break;
                    case Display.HdrCapabilities.HDR_TYPE_HDR10: types.put("HDR10"); break;
                    case Display.HdrCapabilities.HDR_TYPE_HLG: types.put("HLG"); break;
                    case 4: types.put("HDR10+"); break;   // HDR_TYPE_HDR10_PLUS, API 29
                    default: break;
                }
            }
            return types;
        });
        put(o, "maxNits", () -> {
            Display.HdrCapabilities caps = d.getHdrCapabilities();
            float nits = caps == null ? 0 : caps.getDesiredMaxLuminance();
            return nits > 0 ? Math.round(nits) : null;
        });
        if (Build.VERSION.SDK_INT >= 26) put(o, "wideGamut", d::isWideColorGamut);
        return o;
    }

    private static JSONObject graphics(Activity a) {
        JSONObject o = new JSONObject();
        put(o, "gles", () -> ((ActivityManager) a.getSystemService(Context.ACTIVITY_SERVICE)).getDeviceConfigurationInfo().getGlEsVersion());
        put(o, "vulkan", () -> {
            for (FeatureInfo f : a.getPackageManager().getSystemAvailableFeatures()) {
                if ("android.hardware.vulkan.version".equals(f.name) && f.version > 0) {
                    int v = f.version;
                    return (v >> 22) + "." + ((v >> 12) & 0x3ff) + (((v & 0xfff) > 0) ? "." + (v & 0xfff) : "");
                }
            }
            return null;
        });
        return o;
    }

    // ---- network ---------------------------------------------------------------------

    private static JSONObject network(Activity a) {
        JSONObject o = new JSONObject();
        ConnectivityManager cm = (ConnectivityManager) a.getSystemService(Context.CONNECTIVITY_SERVICE);
        Network n = cm.getActiveNetwork();
        if (n == null) {
            put(o, "offline", () -> true);
            return o;
        }
        NetworkCapabilities caps = cm.getNetworkCapabilities(n);
        if (caps != null) {
            put(o, "transports", () -> {
                JSONArray t = new JSONArray();
                int[][] known = {{NetworkCapabilities.TRANSPORT_WIFI, 0}, {NetworkCapabilities.TRANSPORT_CELLULAR, 1}, {NetworkCapabilities.TRANSPORT_ETHERNET, 2},
                                 {NetworkCapabilities.TRANSPORT_VPN, 3}, {NetworkCapabilities.TRANSPORT_BLUETOOTH, 4}};
                String[] names = {"wifi", "cellular", "ethernet", "vpn", "bluetooth"};
                for (int[] k : known) if (caps.hasTransport(k[0])) t.put(names[k[1]]);
                return t;
            });
            put(o, "metered", () -> !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED));
            put(o, "validated", () -> caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED));
            put(o, "down", caps::getLinkDownstreamBandwidthKbps);
            put(o, "up", caps::getLinkUpstreamBandwidthKbps);
            if (Build.VERSION.SDK_INT >= 29) {
                put(o, "signal", () -> {
                    int s = caps.getSignalStrength();
                    return s == NetworkCapabilities.SIGNAL_STRENGTH_UNSPECIFIED ? null : s;
                });
            }
        }
        LinkProperties link = cm.getLinkProperties(n);
        if (link != null) {
            put(o, "iface", link::getInterfaceName);
            put(o, "addresses", () -> {
                JSONArray list = new JSONArray();
                for (LinkAddress la : link.getLinkAddresses()) list.put(la.getAddress().getHostAddress() + "/" + la.getPrefixLength());
                return list;
            });
            put(o, "dns", () -> {
                JSONArray list = new JSONArray();
                for (InetAddress dns : link.getDnsServers()) list.put(dns.getHostAddress());
                return list;
            });
            if (Build.VERSION.SDK_INT >= 28) {
                put(o, "privateDns", link::isPrivateDnsActive);
                put(o, "privateDnsServer", link::getPrivateDnsServerName);
            }
            if (Build.VERSION.SDK_INT >= 29) put(o, "mtu", () -> link.getMtu() > 0 ? link.getMtu() : null);
            put(o, "domains", link::getDomains);
            put(o, "proxy", () -> link.getHttpProxy() == null ? null : link.getHttpProxy().getHost() + ":" + link.getHttpProxy().getPort());
        }
        return o;
    }

    @SuppressWarnings("deprecation")   // getConnectionInfo: the one call that works on every supported version
    private static JSONObject wifi(Activity a) {
        JSONObject o = new JSONObject();
        WifiManager wm = (WifiManager) a.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if (wm == null) return o;
        put(o, "enabled", wm::isWifiEnabled);
        put(o, "band5", wm::is5GHzBandSupported);
        if (Build.VERSION.SDK_INT >= 30) put(o, "band6", wm::is6GHzBandSupported);
        WifiInfo info = wm.getConnectionInfo();
        if (info == null || info.getNetworkId() == -1 && info.getRssi() <= -127) return o;
        put(o, "speed", () -> info.getLinkSpeed() > 0 ? info.getLinkSpeed() : null);
        put(o, "freq", () -> info.getFrequency() > 0 ? info.getFrequency() : null);
        put(o, "rssi", () -> info.getRssi() > -127 ? info.getRssi() : null);
        if (Build.VERSION.SDK_INT >= 29) {
            put(o, "tx", () -> info.getTxLinkSpeedMbps() > 0 ? info.getTxLinkSpeedMbps() : null);
            put(o, "rx", () -> info.getRxLinkSpeedMbps() > 0 ? info.getRxLinkSpeedMbps() : null);
        }
        if (Build.VERSION.SDK_INT >= 30) {
            put(o, "standard", () -> {
                switch (info.getWifiStandard()) {
                    case 1: return "802.11a/b/g";   // LEGACY
                    case 4: return "Wi-Fi 4";       // 11N
                    case 5: return "Wi-Fi 5";       // 11AC
                    case 6: return "Wi-Fi 6";       // 11AX
                    case 7: return "WiGig";         // 11AD
                    case 8: return "Wi-Fi 7";       // 11BE
                    default: return null;
                }
            });
        }
        return o;
    }

    private static JSONObject carrier(Activity a) {
        JSONObject o = new JSONObject();
        TelephonyManager tm = (TelephonyManager) a.getSystemService(Context.TELEPHONY_SERVICE);
        if (tm == null) return o;
        put(o, "network", tm::getNetworkOperatorName);
        put(o, "sim", tm::getSimOperatorName);
        put(o, "netCountry", () -> tm.getNetworkCountryIso().toUpperCase(Locale.ROOT));
        put(o, "simCountry", () -> tm.getSimCountryIso().toUpperCase(Locale.ROOT));
        put(o, "roaming", tm::isNetworkRoaming);
        put(o, "phoneType", () -> {
            switch (tm.getPhoneType()) {
                case TelephonyManager.PHONE_TYPE_GSM: return "GSM";
                case TelephonyManager.PHONE_TYPE_CDMA: return "CDMA";
                case TelephonyManager.PHONE_TYPE_SIP: return "SIP";
                default: return null;
            }
        });
        put(o, "slots", () -> Build.VERSION.SDK_INT >= 30 ? tm.getActiveModemCount() : tm.getPhoneCount());
        if (Build.VERSION.SDK_INT >= 28) put(o, "signal", () -> tm.getSignalStrength() == null ? null : tm.getSignalStrength().getLevel());
        return o;
    }

    // ---- battery and audio -------------------------------------------------------------

    private static JSONObject battery(Activity a) {
        JSONObject o = new JSONObject();
        Intent b = a.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (b != null) {
            put(o, "level", () -> {
                int level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1), scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                return level >= 0 && scale > 0 ? Math.round(level * 100f / scale) : null;
            });
            put(o, "status", () -> {
                switch (b.getIntExtra(BatteryManager.EXTRA_STATUS, -1)) {
                    case BatteryManager.BATTERY_STATUS_CHARGING: return "charging";
                    case BatteryManager.BATTERY_STATUS_DISCHARGING: return "discharging";
                    case BatteryManager.BATTERY_STATUS_FULL: return "full";
                    case BatteryManager.BATTERY_STATUS_NOT_CHARGING: return "not_charging";
                    default: return null;
                }
            });
            put(o, "health", () -> {
                switch (b.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)) {
                    case BatteryManager.BATTERY_HEALTH_GOOD: return "good";
                    case BatteryManager.BATTERY_HEALTH_OVERHEAT: return "overheat";
                    case BatteryManager.BATTERY_HEALTH_DEAD: return "dead";
                    case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE: return "over_voltage";
                    case BatteryManager.BATTERY_HEALTH_COLD: return "cold";
                    case BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE: return "failure";
                    default: return null;
                }
            });
            put(o, "plugged", () -> {
                switch (b.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)) {
                    case BatteryManager.BATTERY_PLUGGED_AC: return "ac";
                    case BatteryManager.BATTERY_PLUGGED_USB: return "usb";
                    case BatteryManager.BATTERY_PLUGGED_WIRELESS: return "wireless";
                    case 8: return "dock";   // BATTERY_PLUGGED_DOCK, API 33
                    default: return "none";
                }
            });
            put(o, "temp", () -> { int t = b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Integer.MIN_VALUE); return t == Integer.MIN_VALUE ? null : t / 10.0; });
            put(o, "voltage", () -> { int v = b.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1); return v > 0 ? v : null; });
            put(o, "tech", () -> b.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY));
            put(o, "cycles", () -> { int c = b.getIntExtra("android.os.extra.CYCLE_COUNT", -1); return c >= 0 ? c : null; });   // API 34
        }
        BatteryManager bm = (BatteryManager) a.getSystemService(Context.BATTERY_SERVICE);
        if (bm != null) {
            put(o, "chargeCounter", () -> { int v = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER); return v > 0 && v != Integer.MIN_VALUE ? v : null; });
            put(o, "current", () -> { int v = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW); return v != 0 && v != Integer.MIN_VALUE ? v : null; });
            if (Build.VERSION.SDK_INT >= 28) put(o, "chargeTime", () -> { long t = bm.computeChargeTimeRemaining(); return t > 0 ? t : null; });
        }
        return o;
    }

    private static JSONObject audio(Activity a) {
        JSONObject o = new JSONObject();
        AudioManager am = (AudioManager) a.getSystemService(Context.AUDIO_SERVICE);
        if (am == null) return o;
        put(o, "rate", () -> am.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE));
        put(o, "buffer", () -> am.getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER));
        put(o, "lowLatency", () -> a.getPackageManager().hasSystemFeature("android.hardware.audio.low_latency"));
        put(o, "pro", () -> a.getPackageManager().hasSystemFeature("android.hardware.audio.pro"));
        put(o, "outputs", () -> {
            TreeSet<String> kinds = new TreeSet<>();
            for (AudioDeviceInfo d : am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
                switch (d.getType()) {
                    case AudioDeviceInfo.TYPE_BUILTIN_SPEAKER: kinds.add("speaker"); break;
                    case AudioDeviceInfo.TYPE_BUILTIN_EARPIECE: kinds.add("earpiece"); break;
                    case AudioDeviceInfo.TYPE_WIRED_HEADPHONES:
                    case AudioDeviceInfo.TYPE_WIRED_HEADSET: kinds.add("wired"); break;
                    case AudioDeviceInfo.TYPE_BLUETOOTH_A2DP:
                    case AudioDeviceInfo.TYPE_BLUETOOTH_SCO: kinds.add("bluetooth"); break;
                    case AudioDeviceInfo.TYPE_USB_DEVICE:
                    case AudioDeviceInfo.TYPE_USB_HEADSET: kinds.add("usb"); break;
                    case AudioDeviceInfo.TYPE_HDMI: kinds.add("hdmi"); break;
                    default: break;
                }
            }
            return new JSONArray(kinds);
        });
        if (Build.VERSION.SDK_INT >= 32) put(o, "spatial", () -> am.getSpatializer().isAvailable());
        return o;
    }

    // ---- media: codecs and DRM ------------------------------------------------------

    private static final String[] VIDEO = {"video/av01", "video/hevc", "video/avc", "video/x-vnd.on2.vp9", "video/x-vnd.on2.vp8", "video/dolby-vision", "video/mp4v-es", "video/3gpp"};

    @SuppressWarnings("deprecation")
    private static JSONObject media() throws JSONException {
        JSONObject o = new JSONObject();
        // Per type: best decoder and encoder (hardware beats software), largest decodable size.
        Map<String, JSONObject> byType = new LinkedHashMap<>();
        try {
            for (MediaCodecInfo info : new MediaCodecList(MediaCodecList.REGULAR_CODECS).getCodecInfos()) {
                String name = info.getName().toLowerCase(Locale.ROOT);
                boolean hw = Build.VERSION.SDK_INT >= 29 ? info.isHardwareAccelerated()
                        : !(name.startsWith("omx.google.") || name.startsWith("c2.android.") || name.contains(".sw."));
                for (String type : info.getSupportedTypes()) {
                    String mime = type.toLowerCase(Locale.ROOT);
                    JSONObject t = byType.get(mime);
                    if (t == null) byType.put(mime, t = new JSONObject().put("type", mime));
                    String role = info.isEncoder() ? "enc" : "dec";
                    if (!"hw".equals(t.optString(role))) t.put(role, hw ? "hw" : "sw");
                    if (!info.isEncoder() && mime.startsWith("video/")) {
                        try {
                            MediaCodecInfo.VideoCapabilities v = info.getCapabilitiesForType(type).getVideoCapabilities();
                            int w = v.getSupportedWidths().getUpper(), h = v.getSupportedHeights().getUpper();
                            if ((long) w * h > (long) t.optInt("w") * t.optInt("h")) t.put("w", w).put("h", h);
                        } catch (RuntimeException noCaps) { }
                    }
                }
            }
        } catch (RuntimeException noCodecs) { }
        // Video first, in a meaningful order, then everything else alphabetically.
        JSONArray codecs = new JSONArray();
        for (String v : VIDEO) if (byType.containsKey(v)) codecs.put(byType.remove(v));
        List<String> rest = new ArrayList<>(byType.keySet());
        Collections.sort(rest);
        for (String k : rest) codecs.put(byType.get(k));
        o.put("codecs", codecs);

        JSONObject drm = new JSONObject();
        put(drm, "playready", () -> MediaDrm.isCryptoSchemeSupported(PLAYREADY));
        put(drm, "clearkey", () -> MediaDrm.isCryptoSchemeSupported(CLEARKEY));
        if (MediaDrm.isCryptoSchemeSupported(WIDEVINE)) {
            MediaDrm widevine = null;
            try {
                widevine = new MediaDrm(WIDEVINE);
                final MediaDrm w = widevine;
                // Model-level properties only; the per-device unique ID is never read.
                put(drm, "level", () -> w.getPropertyString("securityLevel"));
                put(drm, "version", () -> w.getPropertyString(MediaDrm.PROPERTY_VERSION));
                put(drm, "vendor", () -> w.getPropertyString(MediaDrm.PROPERTY_VENDOR));
                put(drm, "hdcp", () -> w.getPropertyString("hdcpLevel"));
                put(drm, "maxHdcp", () -> w.getPropertyString("maxHdcpLevel"));
                put(drm, "systemId", () -> w.getPropertyString("systemId"));
            } catch (Throwable unavailable) {
                put(drm, "level", () -> "?");
            } finally {
                if (widevine != null) {
                    if (Build.VERSION.SDK_INT >= 28) widevine.close(); else widevine.release();
                }
            }
        }
        o.put("drm", drm);
        return o;
    }

    // ---- sensors, cameras, features --------------------------------------------------

    private static JSONArray sensors(Activity a) {
        JSONArray list = new JSONArray();
        try {
            SensorManager sm = (SensorManager) a.getSystemService(Context.SENSOR_SERVICE);
            for (Sensor s : sm.getSensorList(Sensor.TYPE_ALL)) {
                JSONObject o = new JSONObject();
                put(o, "name", s::getName);
                put(o, "vendor", s::getVendor);
                put(o, "type", () -> {
                    String t = s.getStringType();
                    return t == null ? null : t.replaceFirst("^android\\.sensor\\.", "");
                });
                put(o, "power", () -> s.getPower() > 0 ? Math.round(s.getPower() * 100) / 100.0 : null);
                put(o, "range", () -> s.getMaximumRange() > 0 ? s.getMaximumRange() : null);
                put(o, "wake", s::isWakeUpSensor);
                list.put(o);
            }
        } catch (RuntimeException unavailable) { }
        return list;
    }

    private static JSONArray cameras(Activity a) {
        JSONArray list = new JSONArray();
        try {
            CameraManager cm = (CameraManager) a.getSystemService(Context.CAMERA_SERVICE);
            for (String id : cm.getCameraIdList()) {
                CameraCharacteristics c = cm.getCameraCharacteristics(id);   // readable without the camera permission
                JSONObject o = new JSONObject().put("id", id);
                put(o, "facing", () -> {
                    Integer f = c.get(CameraCharacteristics.LENS_FACING);
                    return f == null ? null : f == CameraCharacteristics.LENS_FACING_FRONT ? "front" : f == CameraCharacteristics.LENS_FACING_BACK ? "back" : "external";
                });
                put(o, "mp", () -> {
                    Size s = c.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE);
                    return s == null ? null : Math.round(s.getWidth() * (double) s.getHeight() / 100000) / 10.0;
                });
                put(o, "focal", () -> {
                    float[] f = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
                    return f == null || f.length == 0 ? null : Math.round(f[0] * 100) / 100.0;
                });
                put(o, "aperture", () -> {
                    float[] f = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_APERTURES);
                    return f == null || f.length == 0 ? null : Math.round(f[0] * 100) / 100.0;
                });
                put(o, "sensorMm", () -> {
                    SizeF s = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE);
                    return s == null ? null : Math.round(s.getWidth() * 100) / 100.0 + "×" + Math.round(s.getHeight() * 100) / 100.0;
                });
                put(o, "flash", () -> c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE));
                put(o, "ois", () -> {
                    int[] modes = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION);
                    return modes != null && modes.length > 1;
                });
                put(o, "level", () -> {
                    Integer l = c.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL);
                    if (l == null) return null;
                    switch (l) {
                        case CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LEGACY: return "LEGACY";
                        case CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED: return "LIMITED";
                        case CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_FULL: return "FULL";
                        case CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_3: return "LEVEL_3";
                        case 4: return "EXTERNAL";
                        default: return null;
                    }
                });
                list.put(o);
            }
        } catch (Exception unavailable) { }
        return list;
    }

    private static JSONArray features(Activity a) {
        TreeSet<String> names = new TreeSet<>();
        try {
            for (FeatureInfo f : a.getPackageManager().getSystemAvailableFeatures()) {
                if (f.name != null) names.add(f.name);
            }
        } catch (RuntimeException unavailable) { }
        return new JSONArray(names);
    }

    private static String firstLine(String path) throws Exception {
        try (BufferedReader in = new BufferedReader(new FileReader(path))) {
            return in.readLine();
        }
    }
}
