// QR code scanning on HarmonyOS:
// Priority A: system Scan Kit (scanBarcode.startScanForResult).
// Fallback B: Camera Kit + ImageReceiver Y-plane decoded by the Rust core (fable.qrDecode).
import { scanBarcode, scanCore } from '@kit.ScanKit';
import { camera } from '@kit.CameraKit';
import { image } from '@kit.ImageKit';
import { abilityAccessCtrl, common, Permissions } from '@kit.AbilityKit';
import { BusinessError } from '@kit.BasicServicesKit';
import { util } from '@kit.ArkTS';
import fable from 'libfable.so';

/** Scan Kit error codes for user cancellation / abort (do not fall back to Camera Kit). */
const SCAN_CANCELLED_CODES: number[] = [1000500001, 1000500002];
const MAX_LUMA_AREA: number = 4_000_000;

export interface QrScanCallbacks {
  onResult: (text: string) => void;
  onCancel: () => void;
  onUnavailable: () => void;
}

/** Decode raw QR payload bytes: UTF-8 first, then GB18030 (common in China), then ISO-8859-1. */
export function decodeQrBytes(buffer: ArrayBuffer): string {
  const bytes: Uint8Array = new Uint8Array(buffer);
  const encodings: string[] = ['utf-8', 'gb18030', 'iso-8859-1'];
  for (let i = 0; i < encodings.length; i++) {
    try {
      const decoder: util.TextDecoder = util.TextDecoder.create(encodings[i], { fatal: i < 2, ignoreBOM: true });
      return decoder.decodeToString(bytes);
    } catch (_e) {
      // Try next charset.
    }
  }
  return '';
}

export class HarmonyQrScanner {
  private callbacks: QrScanCallbacks;
  private active: boolean = false;
  private decoded: boolean = false;
  private busyFrame: boolean = false;

  private receiver: image.ImageReceiver | undefined = undefined;
  private session: camera.PhotoSession | camera.VideoSession | undefined = undefined;
  private cameraInput: camera.CameraInput | undefined = undefined;
  private previewOutput: camera.PreviewOutput | undefined = undefined;
  private receiverOutput: camera.PreviewOutput | undefined = undefined;
  private previewSize: camera.Size = { width: 1280, height: 720 };

  constructor(callbacks: QrScanCallbacks) {
    this.callbacks = callbacks;
  }

  /**
   * Entry point: try Route A (Scan Kit) first; if Scan Kit is unavailable or fails
   * (other than explicit user cancellation), fall back to Route B (Camera Kit + Rust core).
   */
  async start(context: common.UIAbilityContext | undefined, openFallbackUi: () => void): Promise<void> {
    if (this.active) {
      return;
    }
    if (context === undefined) {
      this.callbacks.onUnavailable();
      return;
    }

    // Route A: system Scan Kit.
    try {
      const options: scanBarcode.ScanOptions = {
        scanTypes: [scanCore.ScanType.QR_CODE],
        enableMultiMode: false,
        enableAlbum: true
      };
      const result: scanBarcode.ScanResult = await scanBarcode.startScanForResult(context, options);
      const value: string = (result?.originalValue ?? '').trim();
      if (value.length > 0) {
        this.callbacks.onResult(value);
      } else {
        this.callbacks.onCancel();
      }
      return;
    } catch (err) {
      const code: number = (err as BusinessError)?.code ?? 0;
      if (SCAN_CANCELLED_CODES.indexOf(code) >= 0) {
        this.callbacks.onCancel();
        return;
      }
      // Route A unavailable or failed: fall through to Route B.
    }

    // Route B: request camera permission, then open our XComponent + ImageReceiver overlay.
    const granted: boolean = await this.ensureCameraPermission(context);
    if (!granted) {
      this.callbacks.onUnavailable();
      return;
    }
    this.active = true;
    this.decoded = false;
    this.busyFrame = false;
    openFallbackUi();
  }

  private async ensureCameraPermission(context: common.UIAbilityContext): Promise<boolean> {
    try {
      const atManager: abilityAccessCtrl.AtManager = abilityAccessCtrl.createAtManager();
      const perms: Array<Permissions> = ['ohos.permission.CAMERA'];
      const res = await atManager.requestPermissionsFromUser(context, perms);
      return res.authResults.length > 0 && res.authResults[0] === abilityAccessCtrl.GrantStatus.PERMISSION_GRANTED;
    } catch (_e) {
      return false;
    }
  }

  /** Called by Index.ets when the fallback XComponent surface is ready. */
  async startCamera(context: common.UIAbilityContext | undefined, surfaceId: string): Promise<void> {
    if (!this.active || context === undefined || surfaceId.length === 0) {
      return;
    }
    try {
      const mgr: camera.CameraManager = camera.getCameraManager(context);
      const cameras: Array<camera.CameraDevice> = mgr.getSupportedCameras();
      if (cameras.length === 0) {
        await this.stopCamera();
        this.callbacks.onUnavailable();
        return;
      }
      let target: camera.CameraDevice = cameras[0];
      for (let i = 0; i < cameras.length; i++) {
        if (cameras[i].cameraPosition === camera.CameraPosition.CAMERA_POSITION_BACK) {
          target = cameras[i];
          break;
        }
      }

      const capability: camera.CameraOutputCapability =
        mgr.getSupportedOutputCapability(target, camera.SceneMode.NORMAL_VIDEO);
      const profile: camera.Profile | undefined = this.pickPreviewProfile(capability.previewProfiles);
      if (profile === undefined) {
        await this.stopCamera();
        this.callbacks.onUnavailable();
        return;
      }
      this.previewSize = profile.size;

      this.receiver = image.createImageReceiver(
        { width: profile.size.width, height: profile.size.height },
        image.ImageFormat.YCBCR_420_SP,
        2
      );
      this.receiver.on('imageArrival', (): void => {
        this.onImageArrival();
      });
      const receiverSurfaceId: string = await this.receiver.getReceivingSurfaceId();

      this.cameraInput = mgr.createCameraInput(target);
      await this.cameraInput.open();
      this.previewOutput = mgr.createPreviewOutput(profile, surfaceId);
      this.receiverOutput = mgr.createPreviewOutput(profile, receiverSurfaceId);

      const session: camera.VideoSession = mgr.createSession(camera.SceneMode.NORMAL_VIDEO) as camera.VideoSession;
      this.session = session;
      session.beginConfig();
      session.addInput(this.cameraInput);
      session.addOutput(this.previewOutput);
      session.addOutput(this.receiverOutput);
      await session.commitConfig();
      await session.start();
    } catch (_e) {
      await this.stopCamera();
      this.callbacks.onUnavailable();
    }
  }

  private pickPreviewProfile(profiles: Array<camera.Profile>): camera.Profile | undefined {
    let best: camera.Profile | undefined = undefined;
    let bestScore: number = Number.MAX_SAFE_INTEGER;
    for (let i = 0; i < profiles.length; i++) {
      const p: camera.Profile = profiles[i];
      const area: number = p.size.width * p.size.height;
      if (area <= 0 || area > MAX_LUMA_AREA) {
        continue;
      }
      const score: number = Math.abs(area - 1280 * 720);
      if (score < bestScore) {
        bestScore = score;
        best = p;
      }
    }
    return best ?? (profiles.length > 0 ? profiles[0] : undefined);
  }

  private onImageArrival(): void {
    if (!this.active || this.decoded || this.busyFrame || this.receiver === undefined) {
      return;
    }
    this.busyFrame = true;
    this.receiver.readLatestImage((err: BusinessError, img: image.Image): void => {
      if (err || img === undefined) {
        this.busyFrame = false;
        return;
      }
      img.getComponent(image.ComponentType.YUV_Y, (compErr: BusinessError, comp: image.Component): void => {
        try {
          if (!compErr && comp !== undefined && !this.decoded && this.active) {
            const decodedBytes: ArrayBuffer | null = fable.qrDecode(
              comp.byteBuffer,
              this.previewSize.width,
              this.previewSize.height,
              comp.rowStride,
              comp.pixelStride
            );
            if (decodedBytes !== null && decodedBytes.byteLength > 0) {
              const text: string = decodeQrBytes(decodedBytes).trim();
              if (text.length > 0) {
                this.decoded = true;
                this.stopCamera().then((): void => {
                  this.callbacks.onResult(text);
                });
                return;
              }
            }
          }
        } finally {
          img.release();
          this.busyFrame = false;
        }
      });
    });
  }

  async stopCamera(): Promise<void> {
    this.active = false;
    try {
      if (this.session !== undefined) {
        await this.session.stop();
        await this.session.release();
      }
    } catch (_e) {}
    this.session = undefined;
    try {
      if (this.cameraInput !== undefined) {
        await this.cameraInput.close();
      }
    } catch (_e) {}
    this.cameraInput = undefined;
    try {
      if (this.previewOutput !== undefined) {
        await this.previewOutput.release();
      }
    } catch (_e) {}
    this.previewOutput = undefined;
    try {
      if (this.receiverOutput !== undefined) {
        await this.receiverOutput.release();
      }
    } catch (_e) {}
    this.receiverOutput = undefined;
    try {
      if (this.receiver !== undefined) {
        await this.receiver.release();
      }
    } catch (_e) {}
    this.receiver = undefined;
  }
}
