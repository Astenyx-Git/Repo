package app.fable.browser;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;

/**
 * FullscreenVideo, without any of the browser around it: the view a page hands
 * over on fullscreen is shown over the whole activity, Back or the page ending
 * fullscreen puts it back, and a second request while one is showing is refused.
 */
@RunWith(RobolectricTestRunner.class)
public class FullscreenVideoTest {
    private Activity activity;
    private FullscreenVideo fullscreen;
    private int barsRestored;          // how often the user's status-bar setting was applied again

    /** A page's callback, recording what the WebView was told. */
    private static class PageCallback implements WebChromeClient.CustomViewCallback {
        int hidden;
        @Override public void onCustomViewHidden() { hidden++; }
    }

    @Before public void setUp() {
        activity = Robolectric.buildActivity(Activity.class).setup().get();
        barsRestored = 0;
        fullscreen = new FullscreenVideo(activity, () -> barsRestored++);
    }

    private ViewGroup decor() {
        return (ViewGroup) activity.getWindow().getDecorView();
    }

    @Test public void showAddsTheViewOverEverything() {
        int before = decor().getChildCount();
        View view = new View(activity);
        PageCallback callback = new PageCallback();
        fullscreen.show(view, callback);
        assertTrue(fullscreen.showing());
        assertEquals(before + 1, decor().getChildCount());
        assertSame(view, decor().getChildAt(decor().getChildCount() - 1));   // on top of the app
        assertEquals(0, callback.hidden);   // the page is not told its view was dropped
        assertEquals(0, barsRestored);      // the bars are only restored when the video ends
    }

    @Test public void hideRemovesTheViewAndTellsThePage() {
        View view = new View(activity);
        PageCallback callback = new PageCallback();
        fullscreen.show(view, callback);
        assertTrue(fullscreen.hide());
        assertFalse(fullscreen.showing());
        assertNull(view.getParent());   // off the activity
        assertEquals(1, callback.hidden);     // the page learns its fullscreen view is gone
        assertEquals(1, barsRestored);        // and the user's status-bar setting is applied again
    }

    @Test public void aSecondShowWhileShowingIsRefused() {
        fullscreen.show(new View(activity), new PageCallback());
        View second = new View(activity);
        PageCallback refused = new PageCallback();
        int before = decor().getChildCount();
        fullscreen.show(second, refused);
        assertTrue(fullscreen.showing());
        assertEquals(before, decor().getChildCount());   // the first view stays, nothing added
        assertEquals(1, refused.hidden);                 // the second page is told straight away
    }

    @Test public void hideWithNothingShowingDoesNothing() {
        assertFalse(fullscreen.hide());
        assertEquals(0, barsRestored);
    }

    @Test public void showsAgainAfterHide() {
        PageCallback first = new PageCallback();
        fullscreen.show(new View(activity), first);
        fullscreen.hide();
        View second = new View(activity);
        PageCallback secondCallback = new PageCallback();
        fullscreen.show(second, secondCallback);
        assertTrue(fullscreen.showing());
        assertSame(second, decor().getChildAt(decor().getChildCount() - 1));
        assertEquals(0, secondCallback.hidden);   // this one is showing, not refused
    }
}
