//! UI text in fifteen languages, shared by every shell and every bundled page.
//!
//! The table is `ui/strings.tsv` (key, Simplified Chinese, Traditional
//! Chinese, Japanese, English, Korean, Russian, French, Spanish, Arabic,
//! Dutch, German, Portuguese, Italian, Hindi, Indonesian). Arabic is the first right-to-left language: the bundled pages set
//! `dir="rtl"` for it (see `ui/panel.html`). The language is the `language`
//! setting when set, otherwise the system locale the shell reported.

use crate::store::{self, json_string};
use std::collections::HashMap;
use std::sync::atomic::{AtomicU8, Ordering};
use std::sync::OnceLock;

static TABLE: &str = include_str!("../../ui/strings.tsv");

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Lang {
    ZhHans = 0,
    ZhHant = 1,
    Ja = 2,
    En = 3,
    Ko = 4,
    Ru = 5,
    Fr = 6,
    Es = 7,
    Ar = 8,
    Nl = 9,
    De = 10,
    Pt = 11,
    It = 12,
    Hi = 13,
    Id = 14,
}

const ALL: [Lang; 15] = [Lang::ZhHans, Lang::ZhHant, Lang::Ja, Lang::En, Lang::Ko, Lang::Ru, Lang::Fr, Lang::Es, Lang::Ar, Lang::Nl, Lang::De, Lang::Pt, Lang::It, Lang::Hi, Lang::Id];

impl Lang {
    /// From a locale or language tag such as "zh-TW", "zh_Hant_HK", "ja-JP", "en".
    /// Unknown languages get English.
    pub fn from_tag(tag: &str) -> Lang {
        let t = tag.trim().to_ascii_lowercase().replace('_', "-");
        let mut parts = t.split('-');
        match parts.next().unwrap_or("") {
            "zh" => {
                let rest: Vec<&str> = parts.collect();
                if rest.contains(&"hans") {
                    Lang::ZhHans
                } else if rest.iter().any(|p| matches!(*p, "hant" | "tw" | "hk" | "mo")) {
                    Lang::ZhHant
                } else {
                    Lang::ZhHans
                }
            }
            "ja" => Lang::Ja,
            "ko" => Lang::Ko,
            "ru" => Lang::Ru,
            "fr" => Lang::Fr,
            "es" => Lang::Es,
            "ar" => Lang::Ar,
            "nl" => Lang::Nl,
            "de" => Lang::De,
            "pt" => Lang::Pt,
            "it" => Lang::It,
            "hi" => Lang::Hi,
            "id" | "in" => Lang::Id,
            _ => Lang::En,
        }
    }

    pub fn tag(self) -> &'static str {
        ["zh-Hans", "zh-Hant", "ja", "en", "ko", "ru", "fr", "es", "ar", "nl", "de", "pt", "it", "hi", "id"][self as usize]
    }
}

static SYSTEM: AtomicU8 = AtomicU8::new(Lang::En as u8);

/// The shell reports the device language once at start.
pub fn set_system_locale(tag: &str) {
    SYSTEM.store(Lang::from_tag(tag) as u8, Ordering::Relaxed);
}

/// The language in effect: the user's choice, else the system's.
pub fn current() -> Lang {
    let chosen = store::setting_get("language");
    if !chosen.is_empty() {
        return Lang::from_tag(&chosen);
    }
    ALL[SYSTEM.load(Ordering::Relaxed) as usize % ALL.len()]
}

fn table() -> &'static HashMap<&'static str, [&'static str; 15]> {
    static PARSED: OnceLock<HashMap<&'static str, [&'static str; 15]>> = OnceLock::new();
    PARSED.get_or_init(|| {
        let mut map = HashMap::new();
        for line in TABLE.lines().filter(|l| !l.starts_with('#') && !l.trim().is_empty()) {
            let cols: Vec<&str> = line.split('\t').collect();
            if cols.len() == 16 {
                map.insert(cols[0], [cols[1], cols[2], cols[3], cols[4], cols[5], cols[6], cols[7], cols[8], cols[9], cols[10], cols[11], cols[12], cols[13], cols[14], cols[15]]);
            }
        }
        map
    })
}

/// `{brand}` and `{motto}` in `s`: the name and the motto of the skin in use (theme.rs).
pub(crate) fn named(s: &str) -> String {
    if !s.contains("{brand}") && !s.contains("{motto}") {
        return s.to_owned();
    }
    s.replace("{brand}", crate::theme::brand_name()).replace("{motto}", crate::theme::motto())
}

/// The text for `key` in `lang`; the key itself if it is unknown.
pub fn text(lang: Lang, key: &str) -> String {
    table().get(key).map_or_else(|| key.to_owned(), |row| named(row[lang as usize]))
}

/// Every string in `lang` as one JSON object, plus `"_lang"` with the language tag.
pub fn strings_json(lang: Lang) -> String {
    let mut keys: Vec<&&str> = table().keys().collect();
    keys.sort();
    let mut out = format!("{{\"_lang\":\"{}\"", lang.tag());
    for key in keys {
        out.push_str(&format!(",{}:{}", json_string(key), json_string(table()[*key][lang as usize])));
    }
    out.push('}');
    named(&out)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn maps_locales_to_languages() {
        for (tag, want) in [
            ("zh-CN", Lang::ZhHans), ("zh", Lang::ZhHans), ("zh_SG", Lang::ZhHans), ("zh-Hans-HK", Lang::ZhHans),
            ("zh-TW", Lang::ZhHant), ("zh_HK", Lang::ZhHant), ("zh-Hant", Lang::ZhHant), ("zh-Hant-CN", Lang::ZhHant), ("ZH-MO", Lang::ZhHant),
            ("ja", Lang::Ja), ("ja-JP", Lang::Ja), ("ko-KR", Lang::Ko), ("ko", Lang::Ko), ("ru-RU", Lang::Ru), ("ru_BY", Lang::Ru), ("fr", Lang::Fr), ("fr-FR", Lang::Fr), ("fr-CA", Lang::Fr), ("es", Lang::Es), ("es-ES", Lang::Es), ("es-MX", Lang::Es), ("ar", Lang::Ar), ("ar-EG", Lang::Ar), ("ar-SA", Lang::Ar), ("nl", Lang::Nl), ("nl-NL", Lang::Nl), ("de", Lang::De), ("de-DE", Lang::De), ("de-AT", Lang::De), ("pt", Lang::Pt), ("pt-PT", Lang::Pt), ("pt-BR", Lang::Pt), ("it", Lang::It), ("it-IT", Lang::It), ("it-CH", Lang::It), ("hi", Lang::Hi), ("hi-IN", Lang::Hi), ("id", Lang::Id), ("id-ID", Lang::Id), ("in", Lang::Id), ("in_ID", Lang::Id), ("en-US", Lang::En), ("", Lang::En),
        ] {
            assert_eq!(Lang::from_tag(tag), want, "{tag}");
        }
    }

    #[test]
    fn every_row_is_complete() {
        let rows = TABLE.lines().filter(|l| !l.starts_with('#') && !l.trim().is_empty()).count();
        assert!(rows > 80);
        assert_eq!(table().len(), rows, "a row with the wrong number of columns, or a duplicate key");
        for (key, row) in table() {
            for cell in row {
                assert!(!cell.trim().is_empty(), "{key}");
            }
            // A placeholder must survive into every translation.
            let has = row[0].contains("{n}");
            assert!(row.iter().all(|c| c.contains("{n}") == has), "{key}");
        }
    }

    #[test]
    fn looks_up_text() {
        assert_eq!(text(Lang::ZhHans, "settings"), "设置");
        assert_eq!(text(Lang::ZhHant, "settings"), "設定");
        assert_eq!(text(Lang::Ja, "history"), "履歴");
        assert_eq!(text(Lang::En, "private_tab"), "Private tab");
        assert_eq!(text(Lang::Ko, "settings"), "설정");
        assert_eq!(text(Lang::Ru, "history"), "История");
        assert_eq!(text(Lang::Fr, "settings"), "Paramètres");
        assert_eq!(text(Lang::Fr, "search_engine"), "Moteur de recherche");
        assert_eq!(text(Lang::Fr, "wiki_url"), "https://fr.wikipedia.org/");
        assert_eq!(text(Lang::Es, "settings"), "Configuración");
        assert_eq!(text(Lang::Es, "search_engine"), "Motor de búsqueda");
        assert_eq!(text(Lang::Es, "wiki_url"), "https://es.wikipedia.org/");
        assert_eq!(text(Lang::Es, "m_refresh_rate"), "Frecuencia");
        assert_eq!(text(Lang::Ar, "settings"), "الإعدادات");
        assert_eq!(text(Lang::Ar, "search_engine"), "محرك البحث");
        assert_eq!(text(Lang::Ar, "wiki_url"), "https://ar.wikipedia.org/");
        assert_eq!(text(Lang::Ar, "m_refresh_rate"), "التردد");
        assert_eq!(text(Lang::Ar, "m_max_freq"), "أقصى تردد");
        assert_eq!(text(Lang::Nl, "settings"), "Instellingen");
        assert_eq!(text(Lang::Nl, "search_engine"), "Zoekmachine");
        assert_eq!(text(Lang::Nl, "wiki_url"), "https://en.wikipedia.org/");
        assert_eq!(text(Lang::Nl, "m_refresh_rate"), "Verversingsfrequentie");
        assert_eq!(text(Lang::De, "settings"), "Einstellungen");
        assert_eq!(text(Lang::De, "search_engine"), "Suchmaschine");
        assert_eq!(text(Lang::De, "wiki_url"), "https://de.wikipedia.org/");
        assert_eq!(text(Lang::De, "m_refresh_rate"), "Bildrate");
        assert_eq!(text(Lang::Pt, "settings"), "Definições");
        assert_eq!(text(Lang::Pt, "search_engine"), "Motor de pesquisa");
        assert_eq!(text(Lang::Pt, "wiki_url"), "https://pt.wikipedia.org/");
        assert_eq!(text(Lang::Pt, "m_refresh_rate"), "Frequência");
        assert_eq!(text(Lang::It, "settings"), "Impostazioni");
        assert_eq!(text(Lang::It, "search_engine"), "Motore di ricerca");
        assert_eq!(text(Lang::It, "wiki_url"), "https://it.wikipedia.org/");
        assert_eq!(text(Lang::It, "m_refresh_rate"), "Frequenza di aggiornamento");
        assert_eq!(text(Lang::It, "scan_image"), "Scansiona da immagine");
        assert_eq!(text(Lang::De, "scan_image"), "Aus Bild scannen");
        assert_eq!(text(Lang::Pt, "scan_image"), "Digitalizar de imagem");
        assert_eq!(text(Lang::Hi, "settings"), "सेटिंग्स");
        assert_eq!(text(Lang::Hi, "search_engine"), "सर्च इंजन");
        assert_eq!(text(Lang::Hi, "wiki_url"), "https://hi.wikipedia.org/");
        assert_eq!(text(Lang::Id, "settings"), "Pengaturan");
        assert_eq!(text(Lang::Id, "search_engine"), "Mesin pencari");
        assert_eq!(text(Lang::Id, "wiki_url"), "https://id.wikipedia.org/");
        assert!(strings_json(Lang::Id).starts_with("{\"_lang\":\"id\","));
        assert!(strings_json(Lang::Hi).starts_with("{\"_lang\":\"hi\","));
        assert!(strings_json(Lang::It).starts_with("{\"_lang\":\"it\","));
        assert!(strings_json(Lang::De).starts_with("{\"_lang\":\"de\","));
        assert!(strings_json(Lang::Pt).starts_with("{\"_lang\":\"pt\","));
        assert!(strings_json(Lang::Nl).starts_with("{\"_lang\":\"nl\","));
        assert!(strings_json(Lang::Ar).starts_with("{\"_lang\":\"ar\","));
        assert!(strings_json(Lang::Ru).starts_with("{\"_lang\":\"ru\","));
        assert!(strings_json(Lang::Fr).starts_with("{\"_lang\":\"fr\","));
        assert!(strings_json(Lang::Es).starts_with("{\"_lang\":\"es\","));
        assert_eq!(text(Lang::En, "no-such-key"), "no-such-key");
        let json = strings_json(Lang::Ja);
        assert!(json.starts_with("{\"_lang\":\"ja\",") && json.ends_with('}'));
        assert!(json.contains("\"tabs\":\"タブ\"") && !json.contains('<'));
    }
}
