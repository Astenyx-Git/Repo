/* Fable for HarmonyOS: the Node-API bridge between ArkTS and the Rust core.
 *
 * ArkTS imports this as 'libfable.so' (types in types/libfable/index.d.ts).
 * Every function is a thin wrapper: strings cross as UTF-8, strings the core
 * allocates are freed here, and the one tab table lives here too, because
 * every call arrives on the ArkTS main thread. */

#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include "napi/native_api.h"
#include "fable_core.h"

static FableTabs *g_tabs;

/* ---- arguments --------------------------------------------------------- */

#define MAX_ARGS 4

typedef struct {
    size_t count;
    napi_value v[MAX_ARGS];
} Args;

static Args args_of(napi_env env, napi_callback_info info) {
    Args a;
    a.count = MAX_ARGS;
    memset(a.v, 0, sizeof(a.v));
    napi_get_cb_info(env, info, &a.count, a.v, NULL, NULL);
    return a;
}

/* Argument i as a new UTF-8 string ("" when missing or not a string); free() it. */
static char *str_arg(napi_env env, const Args *a, size_t i) {
    size_t len = 0;
    napi_valuetype type = napi_undefined;
    if (i >= a->count || napi_typeof(env, a->v[i], &type) != napi_ok || type != napi_string ||
        napi_get_value_string_utf8(env, a->v[i], NULL, 0, &len) != napi_ok) {
        return calloc(1, 1);
    }
    char *s = malloc(len + 1);
    if (!s) return calloc(1, 1);
    napi_get_value_string_utf8(env, a->v[i], s, len + 1, &len);
    return s;
}

static double num_arg(napi_env env, const Args *a, size_t i) {
    double d = 0;
    if (i < a->count) napi_get_value_double(env, a->v[i], &d);
    return d;
}

/* ---- results ----------------------------------------------------------- */

static napi_value str_result(napi_env env, const char *s) {
    napi_value out;
    napi_create_string_utf8(env, s ? s : "", NAPI_AUTO_LENGTH, &out);
    return out;
}

/* A string the core allocated: returned, then freed. */
static napi_value owned_result(napi_env env, char *s) {
    napi_value out = str_result(env, s);
    if (s) fable_string_free(s);
    return out;
}

static napi_value num_result(napi_env env, double d) {
    napi_value out;
    napi_create_double(env, d, &out);
    return out;
}

static napi_value bool_result(napi_env env, int b) {
    napi_value out;
    napi_get_boolean(env, b != 0, &out);
    return out;
}

static napi_value undefined(napi_env env) {
    napi_value out;
    napi_get_undefined(env, &out);
    return out;
}

/* ---- wrappers ---------------------------------------------------------- */

/* () -> string, for the core's allocating getters */
#define GETTER(fn, call)                                                   \
    static napi_value fn(napi_env env, napi_callback_info info) {          \
        (void)info;                                                        \
        return owned_result(env, call());                                  \
    }

/* (string) -> string */
#define STR1(fn, call)                                                     \
    static napi_value fn(napi_env env, napi_callback_info info) {          \
        Args a = args_of(env, info);                                       \
        char *s = str_arg(env, &a, 0);                                     \
        napi_value out = owned_result(env, call(s));                       \
        free(s);                                                           \
        return out;                                                        \
    }

GETTER(n_language, fable_language)
GETTER(n_reader_script, fable_reader_script)
GETTER(n_panel_page, fable_panel_page)
GETTER(n_logo_uri, fable_logo_uri)
GETTER(n_settings_json, fable_settings_json)
STR1(n_tr, fable_tr)
STR1(n_resolve, fable_resolve)
STR1(n_setting_get, fable_setting_get)
STR1(n_device_info, fable_device_info)
STR1(n_system_info, fable_system_info)
STR1(n_json_string, fable_json_string)

static napi_value n_version(napi_env env, napi_callback_info info) {
    (void)info;
    return str_result(env, fable_version());
}

static napi_value n_sniff_js(napi_env env, napi_callback_info info) {
    (void)info;
    return str_result(env, fable_sniff_js());
}

static napi_value n_set_system_locale(napi_env env, napi_callback_info info) {
    Args a = args_of(env, info);
    char *tag = str_arg(env, &a, 0);
    fable_set_system_locale(tag);
    free(tag);
    return undefined(env);
}

static napi_value n_newtab_page(napi_env env, napi_callback_info info) {
    Args a = args_of(env, info);
    char *icons = str_arg(env, &a, 1);
    napi_value out = owned_result(env, fable_newtab_page((int)num_arg(env, &a, 0), icons[0] ? icons : NULL));
    free(icons);
    return out;
}

static napi_value n_should_block(napi_env env, napi_callback_info info) {
    Args a = args_of(env, info);
    char *url = str_arg(env, &a, 0), *page = str_arg(env, &a, 1);
    int block = fable_should_block(url, page);
    free(url);
    free(page);
    return bool_result(env, block);
}

static napi_value n_blocked_count(napi_env env, napi_callback_info info) {
    (void)info;
    return num_result(env, (double)fable_blocked_count());
}

static napi_value n_adblock_script(napi_env env, napi_callback_info info) {
    (void)info;
    return owned_result(env, fable_adblock_script());
}

static napi_value n_block_external_app(napi_env env, napi_callback_info info) {
    Args a = args_of(env, info);
    char *url = str_arg(env, &a, 0);
    int block = fable_block_external_app(url);
    free(url);
    return bool_result(env, block);
}

static napi_value n_store_open(napi_env env, napi_callback_info info) {
    Args a = args_of(env, info);
    char *dir = str_arg(env, &a, 0);
    fable_store_open(dir);
    free(dir);
    return undefined(env);
}

static napi_value n_setting_set(napi_env env, napi_callback_info info) {
    Args a = args_of(env, info);
    char *key = str_arg(env, &a, 0), *value = str_arg(env, &a, 1);
    fable_setting_set(key, value);
    free(key);
    free(value);
    return undefined(env);
}

static napi_value n_history_add(napi_env env, napi_callback_info info) {
    Args a = args_of(env, info);
    char *url = str_arg(env, &a, 0), *title = str_arg(env, &a, 1);
    fable_history_add(url, title, (uint64_t)num_arg(env, &a, 2));
    free(url);
    free(title);
    return undefined(env);
}

static napi_value n_history_json(napi_env env, napi_callback_info info) {
    Args a = args_of(env, info);
    char *query = str_arg(env, &a, 0);
    napi_value out = owned_result(env, fable_history_json(query, (size_t)num_arg(env, &a, 1)));
    free(query);
    return out;
}

static napi_value n_history_clear(napi_env env, napi_callback_info info) {
    (void)info;
    fable_history_clear();
    return undefined(env);
}

/* (name, arg, tab) -> string, or null when the request is the shell's to answer */
static napi_value n_panel_query(napi_env env, napi_callback_info info) {
    Args a = args_of(env, info);
    char *name = str_arg(env, &a, 0), *arg = str_arg(env, &a, 1);
    char *answer = fable_panel_query(name, arg, (uint32_t)num_arg(env, &a, 2));
    free(name);
    free(arg);
    if (!answer) {
        napi_value null_value;
        napi_get_null(env, &null_value);
        return null_value;
    }
    return owned_result(env, answer);
}

static napi_value n_parse_ip_reply(napi_env env, napi_callback_info info) {
    Args a = args_of(env, info);
    char *body = str_arg(env, &a, 0), *source = str_arg(env, &a, 1);
    napi_value out = owned_result(env, fable_parse_ip_reply(body, source));
    free(body);
    free(source);
    return out;
}

static napi_value n_sniff_note(napi_env env, napi_callback_info info) {
    Args a = args_of(env, info);
    char *url = str_arg(env, &a, 1), *hint = str_arg(env, &a, 2);
    int added = fable_sniff_note((uint32_t)num_arg(env, &a, 0), url, hint);
    free(url);
    free(hint);
    return bool_result(env, added);
}

static napi_value n_sniff_note_scan(napi_env env, napi_callback_info info) {
    Args a = args_of(env, info);
    char *json = str_arg(env, &a, 1);
    size_t added = fable_sniff_note_scan((uint32_t)num_arg(env, &a, 0), json);
    free(json);
    return num_result(env, (double)added);
}

static napi_value n_sniff_count(napi_env env, napi_callback_info info) {
    Args a = args_of(env, info);
    return num_result(env, (double)fable_sniff_count((uint32_t)num_arg(env, &a, 0)));
}

static napi_value n_sniff_json(napi_env env, napi_callback_info info) {
    Args a = args_of(env, info);
    return owned_result(env, fable_sniff_json((uint32_t)num_arg(env, &a, 0)));
}

static napi_value n_sniff_clear(napi_env env, napi_callback_info info) {
    Args a = args_of(env, info);
    fable_sniff_clear((uint32_t)num_arg(env, &a, 0));
    return undefined(env);
}

/* ---- tabs and sleep (one table for the app) ---------------------------- */

static FableTabs *tabs(void) {
    if (!g_tabs) g_tabs = fable_tabs_new();
    return g_tabs;
}

static napi_value n_tabs_open(napi_env env, napi_callback_info info) {
    Args a = args_of(env, info);
    return num_result(env, fable_tabs_open(tabs(), (uint64_t)num_arg(env, &a, 0)));
}

static napi_value n_tabs_activate(napi_env env, napi_callback_info info) {
    Args a = args_of(env, info);
    return bool_result(env, fable_tabs_activate(tabs(), (uint32_t)num_arg(env, &a, 0), (uint64_t)num_arg(env, &a, 1)));
}

static napi_value n_tabs_close(napi_env env, napi_callback_info info) {
    Args a = args_of(env, info);
    return bool_result(env, fable_tabs_close(tabs(), (uint32_t)num_arg(env, &a, 0)));
}

static napi_value n_tabs_set_sleep_after_ms(napi_env env, napi_callback_info info) {
    Args a = args_of(env, info);
    fable_tabs_set_sleep_after_ms(tabs(), (uint64_t)num_arg(env, &a, 0));
    return undefined(env);
}

static napi_value n_tabs_collect_sleepers(napi_env env, napi_callback_info info) {
    Args a = args_of(env, info);
    uint32_t ids[64];
    size_t n = fable_tabs_collect_sleepers(tabs(), (uint64_t)num_arg(env, &a, 0), ids, sizeof ids / sizeof ids[0]);
    napi_value list;
    napi_create_array_with_length(env, n, &list);
    for (size_t i = 0; i < n; i++) napi_set_element(env, list, (uint32_t)i, num_result(env, ids[i]));
    return list;
}

/* ---- module ------------------------------------------------------------ */

static napi_value init(napi_env env, napi_value exports) {
    napi_property_descriptor list[] = {
        {"version", NULL, n_version, NULL, NULL, NULL, napi_default, NULL},
        {"setSystemLocale", NULL, n_set_system_locale, NULL, NULL, NULL, napi_default, NULL},
        {"language", NULL, n_language, NULL, NULL, NULL, napi_default, NULL},
        {"tr", NULL, n_tr, NULL, NULL, NULL, napi_default, NULL},
        {"readerScript", NULL, n_reader_script, NULL, NULL, NULL, napi_default, NULL},
        {"panelPage", NULL, n_panel_page, NULL, NULL, NULL, napi_default, NULL},
        {"logoUri", NULL, n_logo_uri, NULL, NULL, NULL, napi_default, NULL},
        {"newtabPage", NULL, n_newtab_page, NULL, NULL, NULL, napi_default, NULL},
        {"sniffJs", NULL, n_sniff_js, NULL, NULL, NULL, napi_default, NULL},
        {"resolve", NULL, n_resolve, NULL, NULL, NULL, napi_default, NULL},
        {"shouldBlock", NULL, n_should_block, NULL, NULL, NULL, napi_default, NULL},
        {"adblockScript", NULL, n_adblock_script, NULL, NULL, NULL, napi_default, NULL},
        {"blockExternalApp", NULL, n_block_external_app, NULL, NULL, NULL, napi_default, NULL},
        {"blockedCount", NULL, n_blocked_count, NULL, NULL, NULL, napi_default, NULL},
        {"storeOpen", NULL, n_store_open, NULL, NULL, NULL, napi_default, NULL},
        {"settingGet", NULL, n_setting_get, NULL, NULL, NULL, napi_default, NULL},
        {"settingSet", NULL, n_setting_set, NULL, NULL, NULL, napi_default, NULL},
        {"settingsJson", NULL, n_settings_json, NULL, NULL, NULL, napi_default, NULL},
        {"historyAdd", NULL, n_history_add, NULL, NULL, NULL, napi_default, NULL},
        {"historyJson", NULL, n_history_json, NULL, NULL, NULL, napi_default, NULL},
        {"historyClear", NULL, n_history_clear, NULL, NULL, NULL, napi_default, NULL},
        {"panelQuery", NULL, n_panel_query, NULL, NULL, NULL, napi_default, NULL},
        {"parseIpReply", NULL, n_parse_ip_reply, NULL, NULL, NULL, napi_default, NULL},
        {"deviceInfo", NULL, n_device_info, NULL, NULL, NULL, napi_default, NULL},
        {"systemInfo", NULL, n_system_info, NULL, NULL, NULL, napi_default, NULL},
        {"jsonString", NULL, n_json_string, NULL, NULL, NULL, napi_default, NULL},
        {"sniffNote", NULL, n_sniff_note, NULL, NULL, NULL, napi_default, NULL},
        {"sniffNoteScan", NULL, n_sniff_note_scan, NULL, NULL, NULL, napi_default, NULL},
        {"sniffCount", NULL, n_sniff_count, NULL, NULL, NULL, napi_default, NULL},
        {"sniffJson", NULL, n_sniff_json, NULL, NULL, NULL, napi_default, NULL},
        {"sniffClear", NULL, n_sniff_clear, NULL, NULL, NULL, napi_default, NULL},
        {"tabsOpen", NULL, n_tabs_open, NULL, NULL, NULL, napi_default, NULL},
        {"tabsActivate", NULL, n_tabs_activate, NULL, NULL, NULL, napi_default, NULL},
        {"tabsClose", NULL, n_tabs_close, NULL, NULL, NULL, napi_default, NULL},
        {"tabsSetSleepAfterMs", NULL, n_tabs_set_sleep_after_ms, NULL, NULL, NULL, napi_default, NULL},
        {"tabsCollectSleepers", NULL, n_tabs_collect_sleepers, NULL, NULL, NULL, napi_default, NULL},
    };
    napi_define_properties(env, exports, sizeof list / sizeof list[0], list);
    return exports;
}

static napi_module fable_module = {
    .nm_version = 1,
    .nm_flags = 0,
    .nm_filename = NULL,
    .nm_register_func = init,
    .nm_modname = "fable",
    .nm_priv = NULL,
    .reserved = {0},
};

__attribute__((constructor)) static void register_fable(void) {
    napi_module_register(&fable_module);
}
