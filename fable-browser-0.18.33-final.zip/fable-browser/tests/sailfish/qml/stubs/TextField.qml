import QtQuick 2.0
TextInput {
    property string placeholderText: ""
    width: 300; height: 40
}
