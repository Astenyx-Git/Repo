#!/bin/sh
# Fable for HarmonyOS (HarmonyOS NEXT / 5.0 and later, arm64 phones and tablets,
# x86_64 emulator).
#
#   scripts/build-harmony.sh               core for both ABIs, then the HAP with hvigor
#   scripts/build-harmony.sh --core-only   just the core, e.g. before opening shell/harmony in DevEco Studio
#   scripts/build-harmony.sh --openharmony the HAP against the public OpenHarmony SDK instead of the
#                                          HarmonyOS one (a build check that needs no Huawei account)
#
# Needs Rust (rustup target add aarch64-unknown-linux-ohos x86_64-unknown-linux-ohos)
# and the SDK's native toolchain: OHOS_NDK=<sdk>/native, found by default in
# DevEco Studio's SDK ($DEVECO_SDK_HOME/default/openharmony/native) or
# $OHOS_SDK/<api>/native. The HAP step needs hvigor: DevEco Studio's, or
# HVIGOR=<path to hvigor.js>. The HAP is unsigned; sign it in DevEco Studio
# (File > Project Structure > Signing Configs) to install it on a device.
set -e
cd "$(dirname "$0")/.."
ROOT=$(pwd)
MODE=${1:-}

if [ -z "$OHOS_NDK" ]; then
  for c in "$DEVECO_SDK_HOME/default/openharmony/native" "$OHOS_SDK"/*/native /opt/ohos-sdk/*/native; do
    [ -x "$c/llvm/bin/clang" ] && OHOS_NDK=$c && break
  done
fi
[ -x "$OHOS_NDK/llvm/bin/clang" ] || { echo "Set OHOS_NDK to the SDK's native directory" >&2; exit 1; }
LLVM=$OHOS_NDK/llvm/bin

# 1. The Rust core, with the assembly hash, for each ABI.
for pair in arm64-v8a:aarch64 x86_64:x86_64; do
  abi=${pair%%:*}; arch=${pair##*:}; target=$arch-unknown-linux-ohos
  echo "core: $abi"
  # The pinned toolchain (rust-toolchain.toml) needs the target too, as build-android.sh does.
  (cd core && rustup target add "$target" >/dev/null 2>&1 || true)
  (cd core && FABLE_CC="$LLVM/$target-clang" FABLE_AR="$LLVM/llvm-ar" \
    CARGO_TARGET_DIR="$ROOT/build/harmony-core" cargo build --release --features asm --target "$target" -q)
  mkdir -p "shell/harmony/entry/src/main/cpp/lib/$abi"
  cp "build/harmony-core/$target/release/libfable_core.a" "shell/harmony/entry/src/main/cpp/lib/$abi/"
done
[ "$MODE" = "--core-only" ] && exit 0

# 2. The HAP.
PROJECT=shell/harmony
if [ "$MODE" = "--openharmony" ]; then
  # A copy with the OpenHarmony runtime and its device types; the code is the same.
  rm -rf build/harmony-oh && mkdir -p build/harmony-oh
  (cd shell/harmony && tar cf - --exclude=./entry/build --exclude=./.hvigor --exclude=./oh_modules --exclude=./entry/oh_modules --exclude=./entry/.cxx .) | (cd build/harmony-oh && tar xf -)
  PROJECT=build/harmony-oh
  API=$(basename "$(dirname "$OHOS_NDK")")
  sed -i 's/"compatibleSdkVersion": "5.0.2(14)",/"compileSdkVersion": '"$API"', "compatibleSdkVersion": 14,/; s/"targetSdkVersion": "6.0.0(20)",/"targetSdkVersion": '"$API"',/; s/"runtimeOS": "HarmonyOS"/"runtimeOS": "OpenHarmony"/' $PROJECT/build-profile.json5
  sed -i 's/"deviceTypes": \["phone", "tablet", "2in1"\]/"deviceTypes": ["default", "tablet"]/' $PROJECT/entry/src/main/module.json5
  sed -i 's|"-DOHOS_STL=none"|"-DOHOS_STL=none -DFABLE_ROOT='"$ROOT"'"|' $PROJECT/entry/build-profile.json5   # the copy is outside the tree
  echo "sdk.dir=$(dirname "$(dirname "$OHOS_NDK")")" > $PROJECT/local.properties
fi
# ohpm links the native module's type package into oh_modules; without ohpm, do the same by hand.
mkdir -p $PROJECT/entry/oh_modules
ln -sfn ../src/main/cpp/types/libfable $PROJECT/entry/oh_modules/libfable.so
HVIGOR=${HVIGOR:-$(ls "$DEVECO_HOME"/tools/hvigor/bin/hvigorw.js 2>/dev/null || true)}
[ -n "$HVIGOR" ] || { echo "Set HVIGOR to hvigor.js (DevEco Studio's tools/hvigor, or npm @ohos/hvigor)" >&2; exit 1; }
# A bare hvigor from npm: its plugin sits in the same node_modules.
NM=$(cd "$(dirname "$HVIGOR")/../../.." 2>/dev/null && pwd)
[ -d "$NM/@ohos/hvigor-ohos-plugin" ] && [ ! -e $PROJECT/node_modules ] && ln -s "$NM" $PROJECT/node_modules
(cd $PROJECT && node "$HVIGOR" --mode module -p module=entry@default -p product=default -p buildMode=release assembleHap --no-daemon)
find $PROJECT/entry/build -name "*.hap" -newer core/Cargo.toml
