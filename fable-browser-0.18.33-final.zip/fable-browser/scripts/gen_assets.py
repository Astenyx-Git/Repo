#!/usr/bin/env python3
"""Regenerate platform icons and the icon embedded in ui/newtab.html.
Usage: gen_assets.py <icon.png> [--theme claude|gemini|chatgpt|deepseek|kimi|grok] [--preview]"""
import argparse, base64, io, pathlib, re, sys
from PIL import Image, ImageDraw, ImageFilter

THEMES = {
    "claude":   ((253, 247, 240), (142, 47, 20),  (228, 88, 42),  (253, 224, 198)),
    # Gemini: cyan-blue -> royal indigo -> violet-pink sweep on crisp off-white
    "gemini":   ((246, 248, 250), (36, 72, 214),  (108, 128, 246),(244, 168, 214)),
    "chatgpt":  ((239, 234, 250), (138, 108, 198), (182, 152, 228),(252, 224, 236)),
    "deepseek": ((224, 242, 252), (10, 61, 158),  (22, 104, 224), (73, 182, 246)),
    # Kimi: pure black ground with high-contrast silver-white lunar shading
    "kimi":     ((0, 0, 0),       (26, 28, 32),   (150, 156, 166),(250, 251, 253)),
    "grok":     ((22, 17, 14),    (94, 23, 32),   (118, 92, 74),  (236, 218, 162)),
}

ap = argparse.ArgumentParser()
ap.add_argument("icon")
ap.add_argument("--theme", choices=sorted(THEMES), default="claude")
ap.add_argument("--preview", action="store_true")
args = ap.parse_args()

root = pathlib.Path(__file__).resolve().parent.parent
raw_src = Image.open(args.icon).convert("RGB")
ground_rgb, c_dark, c_mid, c_light = THEMES[args.theme]

def _lerp(a, b, t):
    return (int(round(a[0] + (b[0] - a[0]) * t)), int(round(a[1] + (b[1] - a[1]) * t)), int(round(a[2] + (b[2] - a[2]) * t)))

if args.theme == "claude":
    src = raw_src
else:
    KEY_T = (255, 0, 255)
    m_t = raw_src.filter(ImageFilter.GaussianBlur(3))
    wt, ht = m_t.size
    for corner in [(0, 0), (wt - 1, 0), (0, ht - 1), (wt - 1, ht - 1)]:
        ImageDraw.floodfill(m_t, corner, KEY_T, thresh=7)
    a_t = Image.new("L", raw_src.size, 255)
    a_t.putdata([0 if px == KEY_T else 255 for px in (m_t.get_flattened_data() if hasattr(m_t, "get_flattened_data") else m_t.getdata())])
    a_t = a_t.filter(ImageFilter.GaussianBlur(1.0))
    px_in, a_in = raw_src.load(), a_t.load()
    src = Image.new("RGB", (wt, ht), ground_rgb)
    px_out = src.load()
    for y in range(ht):
        for x in range(wt):
            av = a_in[x, y] / 255.0
            if av <= 0.01:
                continue
            r, g, b = px_in[x, y]
            lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255.0
            t = max(0.0, min(1.0, (lum - 0.28) / (0.95 - 0.28)))
            if args.theme == "gemini":
                # Cyan-blue (left/top) -> royal indigo (mid) -> violet-pink (right/bottom)
                u = max(0.0, min(1.0, (x / wt * 0.8 + y / ht * 0.2)))
                base = _lerp((38, 138, 250), (138, 96, 232), u * 1.3) if u < 0.6 else _lerp((138, 96, 232), (242, 136, 198), (u - 0.6) / 0.4)
                fg = _lerp((28, 52, 178), base, t * 2.0) if t < 0.5 else _lerp(base, (218, 240, 255), (t - 0.5) * 1.8)
            else:
                fg = _lerp(c_dark, c_mid, t * 2.0) if t < 0.5 else _lerp(c_mid, c_light, (t - 0.5) * 2.0)
            px_out[x, y] = _lerp(ground_rgb, fg, av)

def sized(n): return src.resize((n, n), Image.LANCZOS)

# Android launcher icons
for name, n in {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}.items():
    d = root / f"shell/android/app/src/main/res/mipmap-{name}"
    d.mkdir(parents=True, exist_ok=True)
    sized(n).save(d / "ic_launcher.png", optimize=True)
# Windows / Linux
sized(256).save(root / "shell/windows/fable.ico", sizes=[(16, 16), (32, 32), (48, 48), (64, 64), (256, 256)])
sized(256).save(root / "shell/linux/fable.png", optimize=True)
# New-tab page: inline WebP so the page needs no network and no extra file
# The artwork sits on a flat cream ground. Flood-fill that ground from the four
# corners and make it transparent, so the icon blends into any page colour.
KEY = (255, 0, 255)
marked = src.filter(ImageFilter.GaussianBlur(3))   # smooth out grain so a tight threshold still fills the ground
w, h = marked.size
for corner in [(0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1)]:
    ImageDraw.floodfill(marked, corner, KEY, thresh=7)
alpha = Image.new("L", src.size, 255)
alpha.putdata([0 if px == KEY else 255 for px in (marked.get_flattened_data() if hasattr(marked, "get_flattened_data") else marked.getdata())])
alpha = alpha.filter(ImageFilter.GaussianBlur(1.2))
cutout = src.convert("RGBA"); cutout.putalpha(alpha)
buf = io.BytesIO(); cutout.resize((192, 192), Image.LANCZOS).save(buf, "WEBP", quality=90)

# Android adaptive icon: the artwork alone, inside the 66/108 safe zone that
# survives every launcher mask; the cream ground comes from a colour resource.
art = cutout.crop(cutout.getbbox())
for name, n in {"mdpi": 108, "hdpi": 162, "xhdpi": 216, "xxhdpi": 324, "xxxhdpi": 432}.items():
    scale = n * 0.52 / max(art.size)
    small = art.resize((round(art.width * scale), round(art.height * scale)), Image.LANCZOS)
    canvas = Image.new("RGBA", (n, n), (0, 0, 0, 0))
    canvas.paste(small, ((n - small.width) // 2, (n - small.height) // 2), small)
    canvas.save(root / f"shell/android/app/src/main/res/mipmap-{name}/ic_launcher_foreground.png", optimize=True)
uri = "data:image/webp;base64," + base64.b64encode(buf.getvalue()).decode()
page = root / "ui/newtab.html"
html = page.read_text(encoding="utf-8")
html, n = re.subn(r'(<img id="icon" src=")[^"]*(")', lambda m: m.group(1) + uri + m.group(2), html)
assert n == 1, "icon <img> not found in newtab.html"
page.write_text(html, encoding="utf-8")
print("icon bytes:", len(buf.getvalue()))

# macOS: an .icns of PNGs. The artwork sits on a cream rounded square inside
# the 1024 grid Apple uses (824 tile, 100 margin, soft shadow below), so it
# lines up with other Dock icons. Pillow cannot write .icns, so the container
# is assembled here: "icns", total length, then (type, length, PNG) entries.
import struct
def mac_icon(n):
    k = n / 1024
    tile = Image.new("RGBA", (n, n), (0, 0, 0, 0))
    box = [round(100 * k), round(100 * k), round(924 * k), round(924 * k)]
    shadow = Image.new("RGBA", (n, n), (0, 0, 0, 0))
    ImageDraw.Draw(shadow).rounded_rectangle([box[0], box[1] + round(12 * k), box[2], box[3] + round(12 * k)], radius=round(185 * k), fill=(42, 26, 20, 70))
    tile.alpha_composite(shadow.filter(ImageFilter.GaussianBlur(max(1, 14 * k))))
    ImageDraw.Draw(tile).rounded_rectangle(box, radius=round(185 * k), fill=(*ground_rgb, 255))
    scale = 824 * k * 0.74 / max(art.size)
    small = art.resize((max(1, round(art.width * scale)), max(1, round(art.height * scale))), Image.LANCZOS)
    tile.alpha_composite(small, ((n - small.width) // 2, (n - small.height) // 2))
    return tile
def png(im):
    b = io.BytesIO(); im.save(b, "PNG", optimize=True); return b.getvalue()
entries = b""
for kind, n in [("icp4", 16), ("icp5", 32), ("ic11", 32), ("icp6", 64), ("ic12", 64), ("ic07", 128),
                ("ic08", 256), ("ic13", 256), ("ic09", 512), ("ic14", 512), ("ic10", 1024)]:
    data = png(mac_icon(n))
    entries += kind.encode() + struct.pack(">I", 8 + len(data)) + data
(root / "shell/macos").mkdir(parents=True, exist_ok=True)
(root / "shell/macos/Fable.icns").write_bytes(b"icns" + struct.pack(">I", 8 + len(entries)) + entries)
mac_icon(512).save(root / "shell/macos/icon-preview.png") if args.preview else None

# iOS: one opaque 1024 PNG; the system rounds the corners, and the App Store
# refuses alpha. The artwork has the macOS tile's proportions, full bleed.
ios = root / "shell/ios/Fable/Assets.xcassets/AppIcon.appiconset"
ios.mkdir(parents=True, exist_ok=True)
canvas = Image.new("RGBA", (1024, 1024), (*ground_rgb, 255))
scale = 1024 * 0.74 / max(art.size)
small = art.resize((round(art.width * scale), round(art.height * scale)), Image.LANCZOS)
canvas.alpha_composite(small, ((1024 - small.width) // 2, (1024 - small.height) // 2))
canvas.convert("RGB").save(ios / "AppIcon.png", optimize=True)

# HarmonyOS: the app icon (a plain PNG for AppScope) and a layered icon for
# the launcher (artwork on a transparent foreground, cream background), 1024
# grid with the artwork inside the 2/3 safe zone the system masks to.
hm = root / "shell/harmony"
for d in ["AppScope/resources/base/media", "entry/src/main/resources/base/media"]:
    (hm / d).mkdir(parents=True, exist_ok=True)
def small_png(im, path):   # 256-colour PNGs: a third of the size, no visible difference at icon sizes
    im.quantize(256, method=Image.Quantize.FASTOCTREE if im.mode == "RGBA" else Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE).save(path, optimize=True)
small_png(sized(512), hm / "AppScope/resources/base/media/app_icon.png")
media = hm / "entry/src/main/resources/base/media"
fg = Image.new("RGBA", (1024, 1024), (0, 0, 0, 0))
scale = 1024 * 0.5 / max(art.size)
small = art.resize((round(art.width * scale), round(art.height * scale)), Image.LANCZOS)
fg.paste(small, ((1024 - small.width) // 2, (1024 - small.height) // 2), small)
small_png(fg, media / "icon_foreground.png")
Image.new("RGB", (1024, 1024), ground_rgb).save(media / "icon_background.png", optimize=True)
small_png(sized(288), media / "startIcon.png")
