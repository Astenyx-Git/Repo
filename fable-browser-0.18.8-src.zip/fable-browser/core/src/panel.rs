//! The part of the panel bridge (ui/panel.html) that is the same on every
//! platform, so a shell only forwards what it gets: settings, history and the
//! resource list are answered here. Shell-specific requests (tabs, the system
//! facts that need platform calls, the public-IP fetch) stay in the shells.

use crate::store::{self, json_string};

/// Answers a panel request, or `None` when the shell has to.
/// `tab` is the tab in front, for the resource list.
pub fn query(name: &str, arg: &str, tab: u32) -> Option<String> {
    let (first, rest) = arg.split_once('\n').unwrap_or((arg, ""));
    Some(match name {
        "get" => store::setting_get(arg),
        "set" => {
            if arg.contains('\n') && setting_allowed(first, rest) {
                store::setting_set(first, rest);
            }
            String::new()
        }
        "settings" => settings_json(),
        "history" => store::history_json(arg, 300),
        "historyDelete" => {
            // "time\nurl"; a time of 0 removes every visit to the URL
            if let Ok(time) = first.parse::<u64>() {
                store::history_delete(rest, time);
            }
            String::new()
        }
        "historyClear" => {
            store::history_clear();
            String::new()
        }
        "sniff" => crate::sniff::json(tab),
        _ => return None,
    })
}

/// The settings the panel page (ui/panel.html) and the home screen
/// (ui/newtab.html) write. Nothing else may be set through the bridge: a
/// setting the shells keep for themselves (a download folder, say) is not the
/// page's to change, and an unknown key would only grow the settings file.
const PANEL_SETTINGS: &[&str] = &[
    // switches
    "address_top", "block_ads", "block_external_apps", "block_trackers", "data_saver",
    "hide_status_bar", "home_button", "home_new_apps", "home_wallpaper", "javascript",
    "keep_screen_on", "private_screenshots",
    // choices and text
    "language", "meta_mode", "orientation", "search_template", "sleep_minutes", "text_size",
    "ua_custom", "ua_mode",
    // lists (JSON)
    "home_hidden", "home_order", "shortcuts",
];

/// The JSON lists can hold many shortcuts and apps; everything else is short.
const LIST_SETTINGS: &[&str] = &["home_hidden", "home_order", "shortcuts"];
const MAX_LIST_LEN: usize = 256 * 1024;
const MAX_VALUE_LEN: usize = 4096;

/// Whether the panel bridge may store `value` under `key`: a known key, a value
/// of bounded length without control characters (JSON lists escape theirs);
/// the lists must be JSON arrays, the search engine an http(s) template with
/// `%s`. An empty value (back to the default) is always fine for a known key.
pub fn setting_allowed(key: &str, value: &str) -> bool {
    if !PANEL_SETTINGS.contains(&key) {
        return false;
    }
    if value.is_empty() {
        return true;
    }
    if value.chars().any(|c| c.is_control()) {
        return false;
    }
    if LIST_SETTINGS.contains(&key) {
        // The rule the Android home page's own channel (home/set) has always had.
        return value.len() < MAX_LIST_LEN && value.starts_with('[');
    }
    if key == "search_template" {
        // What omnibox::set_search_template accepts, so a bad one is never stored.
        return value.len() <= MAX_VALUE_LEN
            && (value.starts_with("https://") || value.starts_with("http://"))
            && value.contains("%s");
    }
    value.len() <= MAX_VALUE_LEN
}

/// Every stored setting as one JSON object, for shells whose panel bridge is
/// asynchronous: the panel reads settings from this snapshot without waiting.
pub fn settings_json() -> String {
    let all = store::settings_all();
    let mut out = String::from("{");
    for (i, (key, value)) in all.iter().enumerate() {
        if i > 0 {
            out.push(',');
        }
        out.push_str(&json_string(key));
        out.push(':');
        out.push_str(&json_string(value));
    }
    out.push('}');
    out
}

/// Turns the reply of a public-IP service into the panel's IP card data:
/// Cloudflare's `/cdn-cgi/trace` (key=value lines) or ipify's `{"ip":"..."}`.
/// `source` is the host it came from. "" when there is no address in it.
pub fn parse_ip_reply(body: &str, source: &str) -> String {
    let mut ip = "";
    let (mut loc, mut colo, mut http, mut tls) = ("", "", "", "");
    for line in body.lines() {
        if let Some((key, value)) = line.split_once('=') {
            match key.trim() {
                "ip" => ip = value.trim(),
                "loc" => loc = value.trim(),
                "colo" => colo = value.trim(),
                "http" => http = value.trim(),
                "tls" => tls = value.trim(),
                _ => {}
            }
        }
    }
    if ip.is_empty() {
        // {"ip":"203.0.113.7"}
        if let Some(start) = body.find("\"ip\"") {
            let after = &body[start + 4..];
            if let Some(open) = after.find('"') {
                let value = &after[open + 1..];
                if let Some(close) = value.find('"') {
                    ip = &value[..close];
                }
            }
        }
    }
    let valid = !ip.is_empty() && ip.len() <= 45 && ip.bytes().all(|b| b.is_ascii_hexdigit() || b == b'.' || b == b':');
    if !valid {
        return String::new();
    }
    let mut out = format!("{{\"ip\":{}", json_string(ip));
    for (key, value) in [("loc", loc), ("colo", colo), ("http", http), ("tls", tls), ("src", source)] {
        if !value.is_empty() {
            out.push_str(&format!(",{}:{}", json_string(key), json_string(value)));
        }
    }
    out.push('}');
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn answers_store_requests_and_leaves_the_rest() {
        // A key of the panel's own (only those may be set) that no other test uses.
        assert_eq!(query("set", "ua_custom\nvalue one", 0).as_deref(), Some(""));
        assert_eq!(query("get", "ua_custom", 0).as_deref(), Some("value one"));
        assert!(query("settings", "", 0).unwrap().contains(r#""ua_custom":"value one""#));
        query("set", "ua_custom\n", 0);
        assert!(!query("settings", "", 0).unwrap().contains("ua_custom"));
        assert!(query("history", "", 0).unwrap().starts_with('['));
        assert_eq!(query("sniff", "", 0).as_deref(), Some("[]"));
        assert_eq!(query("historyDelete", "not-a-number\nhttps://a/", 0).as_deref(), Some(""));
        assert_eq!(query("switchTab", "3", 0), None);
        assert_eq!(query("device", "", 0), None);
    }

    #[test]
    fn set_takes_only_known_keys_and_bounded_values() {
        // A known key goes through ("" afterwards puts the default back).
        query("set", "meta_mode\ndetailed", 0);
        assert_eq!(store::setting_get("meta_mode"), "detailed");
        query("set", "meta_mode\n", 0);
        assert_eq!(store::setting_get("meta_mode"), "");
        // Unknown keys, including the ones shells keep for themselves, do not.
        assert_eq!(query("set", "panel_evil_key\nx", 0).as_deref(), Some(""));
        assert_eq!(store::setting_get("panel_evil_key"), "");
        query("set", "harmony_download_dir\n/data/evil", 0);
        assert_eq!(store::setting_get("harmony_download_dir"), "");
        // Over-long values and control characters are refused.
        assert!(!setting_allowed("ua_custom", &"x".repeat(MAX_VALUE_LEN + 1)));
        assert!(setting_allowed("ua_custom", &"x".repeat(MAX_VALUE_LEN)));
        assert!(!setting_allowed("ua_custom", "Mozilla\r\nX-Evil: 1"));
        assert!(!setting_allowed("ua_mode", "a\tb"));
        assert!(setting_allowed("shortcuts", &format!("[{}]", "\"x\",".repeat(20_000)).replace(",]", "]")));
        assert!(!setting_allowed("shortcuts", &"x".repeat(MAX_LIST_LEN + 1)));
        assert!(!setting_allowed("", "1"));
        // The lists are JSON arrays, as the home page's own channel requires.
        assert!(setting_allowed("home_hidden", "[]"));
        assert!(!setting_allowed("home_order", "{\"a\":1}"));
        assert!(!setting_allowed("shortcuts", "x"));
        assert!(setting_allowed("shortcuts", ""));
        // The search engine: an http(s) template with %s, nothing else.
        assert!(setting_allowed("search_template", "https://example.com/?q=%s"));
        assert!(!setting_allowed("search_template", "javascript:alert(1)//%s"));
        assert!(!setting_allowed("search_template", "https://example.com/search"));
        query("set", "search_template\nfile:///etc/passwd?%s", 0);
        assert_eq!(store::setting_get("search_template"), "");
        // Every key ui/panel.html and ui/newtab.html write is allowed.
        for page in [include_str!("../../ui/panel.html"), include_str!("../../ui/newtab.html")] {
            for pattern in ["set('", "save('"] {
                for part in page.split(pattern).skip(1) {
                    let key = &part[..part.find('\'').unwrap()];
                    assert!(PANEL_SETTINGS.contains(&key), "{key} is written by a page but not allowed");
                }
            }
        }
        // switchRow(T('title'), note, 'key', 'fallback'): the quoted words not inside T(...).
        for part in include_str!("../../ui/panel.html").split("switchRow(").skip(2) {
            let args = &part[..part.find("\n").unwrap_or(part.len())];
            let mut rest = args;
            while let Some(open) = rest.find('\'') {
                let after = &rest[open + 1..];
                let Some(close) = after.find('\'') else { break };
                let word = &after[..close];
                let in_t = rest[..open].ends_with("T(");
                if !in_t && word.len() > 1 && word.bytes().all(|b| b.is_ascii_lowercase() || b == b'_') {
                    assert!(PANEL_SETTINGS.contains(&word), "switch {word} is not allowed");
                }
                rest = &after[close + 1..];
            }
        }
    }

    #[test]
    fn reads_both_ip_services() {
        let trace = "fl=12f1\nh=www.cloudflare.com\nip=203.0.113.42\nts=1\nvisit_scheme=https\nuag=x\ncolo=SIN\nsliver=none\nhttp=http/3\nloc=SG\ntls=TLSv1.3\n";
        assert_eq!(parse_ip_reply(trace, "cloudflare.com"),
                   r#"{"ip":"203.0.113.42","loc":"SG","colo":"SIN","http":"http/3","tls":"TLSv1.3","src":"cloudflare.com"}"#);
        assert_eq!(parse_ip_reply(r#"{"ip":"2001:db8::7"}"#, "ipify.org"), r#"{"ip":"2001:db8::7","src":"ipify.org"}"#);
        assert_eq!(parse_ip_reply("<html>blocked</html>", "x"), "");
        assert_eq!(parse_ip_reply(r#"{"ip":"<script>"}"#, "x"), "");
    }
}
