/* The Rust core's C API for Swift. The header search path points at core/include. */
#include "fable_core.h"
