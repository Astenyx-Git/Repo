import QtQuick 2.0
// IconButton.icon: image://theme/... exists only on the device.
Item { property string source: "" }
