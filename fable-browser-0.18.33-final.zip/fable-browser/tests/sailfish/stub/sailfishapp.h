// Compile-only stand-in for libsailfishapp (Sailfish SDK), for tests/sailfish_test.sh.
#pragma once
#include <QGuiApplication>
#include <QQuickView>
#include <QUrl>
namespace SailfishApp {
QGuiApplication *application(int &argc, char **argv);
QQuickView *createView();
QUrl pathTo(const QString &path);
}
