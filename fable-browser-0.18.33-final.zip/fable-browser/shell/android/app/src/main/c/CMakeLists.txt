# libfable_jni.so = JNI glue (C) + the Rust core built for the same ABI.
cmake_minimum_required(VERSION 3.22)
project(fable_jni C)

if(ANDROID_ABI STREQUAL "arm64-v8a")
  set(RUST_TRIPLE aarch64-linux-android)
elseif(ANDROID_ABI STREQUAL "x86_64")
  set(RUST_TRIPLE x86_64-linux-android)
elseif(ANDROID_ABI STREQUAL "armeabi-v7a")
  set(RUST_TRIPLE armv7-linux-androideabi)
elseif(ANDROID_ABI STREQUAL "x86")
  set(RUST_TRIPLE i686-linux-android)
else()
  message(FATAL_ERROR "Unsupported ABI: ${ANDROID_ABI}")
endif()

set(FABLE_CORE_LIB "${FABLE_ROOT}/core/target/${RUST_TRIPLE}/release/libfable_core.a")
if(NOT EXISTS "${FABLE_CORE_LIB}")
  message(FATAL_ERROR "Missing ${FABLE_CORE_LIB}; run scripts/build-android.sh first")
endif()

add_library(fable_jni SHARED fable_jni.c)
target_include_directories(fable_jni PRIVATE "${FABLE_ROOT}/core/include")
target_link_libraries(fable_jni PRIVATE "${FABLE_CORE_LIB}" dl m)
# Export only the JNI entry points; everything unused in the Rust archive is dropped.
target_link_options(fable_jni PRIVATE -Wl,--gc-sections -Wl,--exclude-libs,ALL)
