// Fable for HarmonyOS: the window. Pages fill it; the bar sits at the bottom,
// drawn here with the same shapes, colours and icons as on Android; the panel
// (menu, tabs, settings, history, resources, metadata) is a web view laid
// over everything, which draws its own scrim and sheet.
import { webview } from '@kit.ArkWeb';
import { BrowserTab, ChromeState, FABLE_PANEL_URL, FableColors } from '../common/Model';
import { FableBrowser, FableHostBridge } from '../common/Browser';

@Component
struct FableTabView {
  @ObjectLink tab: BrowserTab;
  @Prop activeId: number = 0;
  @Prop javascript: boolean = true;
  @Prop images: boolean = true;
  @Prop textZoom: number = 100;
  browser: FableBrowser | undefined = undefined;
  private host: FableHostBridge | undefined = undefined;

  aboutToAppear(): void {
    if (this.browser !== undefined) {
      this.host = new FableHostBridge(this.browser, this.tab);
    }
  }

  private hostProxy(): JavaScriptProxy {
    const proxy: JavaScriptProxy = {
      object: this.host as FableHostBridge,
      name: 'FableHost',
      methodList: ['go'],
      controller: this.tab.controller
    };
    return proxy;
  }

  private shown(): Visibility {
    return this.tab.id === this.activeId ? Visibility.Visible : Visibility.Hidden;
  }

  private ground(): string {
    return this.tab.incognito ? FableColors.DARK_BAR : FableColors.GROUND;
  }

  build() {
    Stack() {
      if (!this.tab.asleep && this.browser !== undefined) {
        Web({ src: this.tab.src, controller: this.tab.controller, incognitoMode: this.tab.incognito })
          .width('100%')
          .height('100%')
          .backgroundColor(this.ground())
          .javaScriptAccess(this.javascript)
          .imageAccess(this.images)
          .onlineImageAccess(this.images)
          .textZoomRatio(this.textZoom)
          .domStorageAccess(true)
          .fileAccess(false)
          .mixedMode(MixedMode.None)
          .zoomAccess(true)
          .multiWindowAccess(true)
          .javaScriptProxy(this.hostProxy())
          .onControllerAttached((): void => {
            this.browser?.attached(this.tab);
          })
          .onInterceptRequest((event: OnInterceptRequestEvent): WebResourceResponse => {
            return this.browser?.intercept(this.tab, event.request) as WebResourceResponse;
          })
          .onLoadIntercept((event: OnLoadInterceptEvent): boolean => {
            return this.browser?.loadIntercept(event.data) ?? false;
          })
          .onPageBegin((event: OnPageBeginEvent): void => {
            this.browser?.pageBegin(this.tab, event.url);
          })
          .onPageEnd((event: OnPageEndEvent): void => {
            this.browser?.pageEnd(this.tab, event.url);
          })
          .onProgressChange((event: OnProgressChangeEvent): void => {
            this.browser?.progressChanged(this.tab, event.newProgress);
          })
          .onTitleReceive((event: OnTitleReceiveEvent): void => {
            this.browser?.titleReceived(this.tab, event.title);
          })
          .onRefreshAccessedHistory((event: OnRefreshAccessedHistoryEvent): void => {
            this.browser?.historyChanged(this.tab, event.url);
          })
          .onFaviconReceived((event: OnFaviconReceivedEvent): void => {
            this.browser?.faviconReceived(this.tab, event.favicon);
          })
          .onWindowNew((event: OnWindowNewEvent): void => {
            this.browser?.windowRequested(this.tab, event.targetUrl, event.isUserTrigger);
          })
          .onWindowExit((): void => {
            this.browser?.close(this.tab);
          })
      }
    }
    .width('100%')
    .height('100%')
    .backgroundColor(this.ground())
    .visibility(this.shown())
  }
}

@Entry
@Component
struct Index {
  private browser: FableBrowser = new FableBrowser();
  @State chrome: ChromeState = this.browser.chrome;
  @State tabs: BrowserTab[] = [];

  aboutToAppear(): void {
    this.browser.onTabsChanged = (): void => {
      this.tabs = this.browser.tabs.slice();
    };
    this.browser.start(this.getUIContext());
  }

  onBackPress(): boolean {
    return this.browser.back();
  }

  // ---- colours of the mode in front --------------------------------------------------

  private barColor(): string {
    return this.chrome.incognito ? FableColors.DARK_BAR : FableColors.BAR;
  }

  private pillColor(): string {
    return this.chrome.incognito ? FableColors.DARK_PILL : FableColors.WHITE;
  }

  private lineColor(): string {
    return this.chrome.incognito ? FableColors.DARK_LINE : FableColors.LINE;
  }

  private inkColor(): string {
    return this.chrome.incognito ? FableColors.DARK_INK : FableColors.INK;
  }

  private mutedColor(): string {
    return this.chrome.incognito ? FableColors.DARK_MUTED : FableColors.MUTED;
  }

  private hintColor(): string {
    return this.chrome.incognito ? FableColors.DARK_MUTED : FableColors.HINT;
  }

  private icon(name: string): Resource {
    const dark: boolean = this.chrome.incognito;
    if (name === 'back') {
      return dark ? $r('app.media.ic_back_dark') : $r('app.media.ic_back');
    } else if (name === 'forward') {
      return dark ? $r('app.media.ic_forward_dark') : $r('app.media.ic_forward');
    } else if (name === 'menu') {
      return dark ? $r('app.media.ic_menu_dark') : $r('app.media.ic_menu');
    } else if (name === 'home') {
      return dark ? $r('app.media.ic_home_dark') : $r('app.media.ic_home');
    } else if (name === 'stop') {
      return dark ? $r('app.media.ic_stop_dark') : $r('app.media.ic_stop');
    } else if (name === 'reload') {
      return dark ? $r('app.media.ic_reload_dark') : $r('app.media.ic_reload');
    } else if (name === 'mask') {
      return $r('app.media.ic_mask_dark');
    } else if (name === 'lock') {
      return $r('app.media.ic_lock');
    }
    return dark ? $r('app.media.ic_search_dark') : $r('app.media.ic_search');
  }

  private siteIcon(): Resource {
    if (this.chrome.incognito) {
      return this.icon('mask');
    }
    return this.chrome.secure ? this.icon('lock') : this.icon('search');
  }

  private progressWidth(): string {
    return Math.max(8, Math.min(100, this.chrome.progress)) + '%';
  }

  private progressOpacity(): number {
    return this.chrome.loading ? 1 : 0;
  }

  private dimmed(enabled: boolean): number {
    return enabled ? 1 : 0.35;
  }

  private panelShown(): Visibility {
    return this.chrome.panelOpen ? Visibility.Visible : Visibility.Hidden;
  }

  private panelProxy(): JavaScriptProxy {
    const proxy: JavaScriptProxy = {
      object: this.browser.panelBridge,
      name: 'FableUI',
      methodList: ['query', 'act'],
      controller: this.browser.panelController
    };
    return proxy;
  }

  // ---- the bar --------------------------------------------------------------------------

  @Builder
  NavButton(name: string, enabled: boolean, label: string, action: () => void) {
    Column() {
      Image(this.icon(name))
        .width(24)
        .height(24)
        .opacity(this.dimmed(enabled))
    }
    .layoutWeight(1)
    .height(48)
    .justifyContent(FlexAlign.Center)
    .accessibilityText(label)
    .onClick((): void => action())
  }

  @Builder
  BottomBar() {
    Column() {
      // Loading progress: a thin line along the top edge of the bar.
      Row()
        .width(this.progressWidth())
        .height(2)
        .backgroundColor(FableColors.SPARK)
        .opacity(this.progressOpacity())
        .animation({ duration: 250 })
        .alignSelf(ItemAlign.Start)

      // Address pill: site icon, text, reload/stop.
      Row() {
        Image(this.siteIcon())
          .width(20)
          .height(20)
          .margin({ left: 14, right: 10 })
        TextInput({ text: this.chrome.address, placeholder: this.chrome.hint })
          .type(InputType.URL)
          .enterKeyType(EnterKeyType.Go)
          .selectAll(true)
          .layoutWeight(1)
          .height(48)
          .padding(0)
          .fontSize(15)
          .fontColor(this.inkColor())
          .placeholderColor(this.hintColor())
          .caretColor(FableColors.SPARK)
          .backgroundColor(Color.Transparent)
          .borderRadius(0)
          .onChange((value: string): void => {
            this.chrome.address = value;
          })
          .onEditChange((editing: boolean): void => {
            this.browser.addressEdited(editing);
          })
          .onSubmit((key: EnterKeyType, event: SubmitEvent): void => {
            this.browser.addressSubmitted(this.chrome.address);
          })
        Column() {
          if (this.chrome.loading) {
            Image(this.icon('stop')).width(22).height(22)
          } else {
            Image(this.icon('reload')).width(22).height(22)
          }
        }
        .width(48)
        .height(48)
        .justifyContent(FlexAlign.Center)
        .accessibilityText(this.browser.label(this.chrome.loading ? 'stop' : 'reload'))
        .onClick((): void => this.browser.reloadOrStop())
      }
      .height(48)
      .margin({ left: 12, right: 12, top: 8, bottom: 2 })
      .borderRadius(24)
      .border({ width: 1, color: this.lineColor() })
      .backgroundColor(this.pillColor())

      // Navigation row: back, forward, new tab, tabs, menu. Hidden while typing, to give the keyboard room.
      if (!this.chrome.editing) {
        Row() {
          this.NavButton('back', this.chrome.canBack, this.browser.label('go_back'), (): void => this.browser.goBack())
          this.NavButton('forward', this.chrome.canForward, this.browser.label('go_forward'), (): void => this.browser.goForward())
          if (this.chrome.homeButton) {
            this.NavButton('home', true, this.browser.label('go_home'), (): void => this.browser.goHomePage())
          }
          Column() {
            Column() {
              Image($r('app.media.ic_plus_white')).width(22).height(22)
            }
            .width(52)
            .height(40)
            .borderRadius(20)
            .justifyContent(FlexAlign.Center)
            .backgroundColor(FableColors.SPARK)
          }
          .layoutWeight(1)
          .height(48)
          .justifyContent(FlexAlign.Center)
          .accessibilityText(this.browser.label(this.chrome.incognito ? 'new_private' : 'new_tab_btn'))
          .onClick((): void => this.browser.newTab('', this.chrome.incognito))
          Column() {
            Text(this.chrome.tabCount.toString())
              .fontSize(12)
              .fontWeight(FontWeight.Bold)
              .fontColor(this.mutedColor())
              .textAlign(TextAlign.Center)
              .width(24)
              .height(24)
              .borderRadius(7)
              .border({ width: 2, color: this.mutedColor() })
          }
          .layoutWeight(1)
          .height(48)
          .justifyContent(FlexAlign.Center)
          .accessibilityText(this.browser.label('tabs'))
          .onClick((): void => this.browser.showPanel('tabs'))
          this.NavButton('menu', true, this.browser.label('menu'), (): void => this.browser.showPanel('menu'))
        }
        .height(52)
        .padding({ left: 4, right: 4, bottom: 2 })
      }
    }
    .width('100%')
    .backgroundColor(this.barColor())
  }

  build() {
    Stack({ alignContent: Alignment.Bottom }) {
      Column() {
        Stack() {
          ForEach(this.tabs, (tab: BrowserTab) => {
            FableTabView({
              tab: tab,
              activeId: this.chrome.activeId,
              javascript: this.chrome.javascript,
              images: this.chrome.images,
              textZoom: this.chrome.textZoom,
              browser: this.browser
            })
          }, (tab: BrowserTab): string => tab.id.toString())
        }
        .layoutWeight(1)
        .width('100%')

        this.BottomBar()
      }
      .width('100%')
      .height('100%')

      // Our own message pill instead of a system toast.
      Text(this.chrome.toast)
        .fontSize(14)
        .fontColor(FableColors.DARK_INK)
        .backgroundColor(FableColors.TOAST)
        .borderRadius(22)
        .padding({ left: 18, right: 18, top: 11, bottom: 11 })
        .margin({ left: 24, right: 24, bottom: 132 })
        .opacity(this.chrome.toastShown ? 1 : 0)
        .animation({ duration: 180 })
        .hitTestBehavior(HitTestMode.Transparent)

      // The panel: hidden until asked for, but loaded ahead of its first use.
      Web({ src: FABLE_PANEL_URL, controller: this.browser.panelController })
        .width('100%')
        .height('100%')
        .backgroundColor(Color.Transparent)
        .javaScriptAccess(true)
        .domStorageAccess(true)
        .fileAccess(false)
        .zoomAccess(false)
        .textZoomRatio(100)
        .overScrollMode(OverScrollMode.NEVER)
        .javaScriptProxy(this.panelProxy())
        .onInterceptRequest((event: OnInterceptRequestEvent): WebResourceResponse => {
          return this.browser.panelIntercept(event.request);
        })
        .onLoadIntercept((event: OnLoadInterceptEvent): boolean => {
          return !event.data.getRequestUrl().startsWith(FABLE_PANEL_URL);   // never navigate away from the bundled page
        })
        .onPageEnd((): void => {
          this.browser.panelLoaded();
        })
        .visibility(this.panelShown())
    }
    .width('100%')
    .height('100%')
    .backgroundColor(this.barColor())
  }
}
