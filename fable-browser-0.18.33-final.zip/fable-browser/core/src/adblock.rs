//! Cosmetic ad blocking: hiding the ad boxes themselves.
//!
//! The network side (core/src/blocker.rs) stops third-party ad requests, but
//! an ad served by the site's own domain still shows up — an empty box, a
//! "sponsored" label, a video the site hosts itself. This module hides those
//! with a stylesheet: the rules are plain CSS, so they apply to elements that
//! appear later too, and no script has to watch the page.
//!
//! The stylesheet is injected by the shell as a script that installs it
//! through the CSSOM. A page with a strict Content-Security-Policy may refuse
//! a <style> element; the script then falls back to a constructed stylesheet
//! (document.adoptedStyleSheets), which such a policy does not govern.

use crate::store::json_string;

/// The rules. Kept conservative: only containers that are advertisements by
/// name, by id, or by the ad network they load.
const CSS: &str = r##"
.adsbygoogle, ins.adsbygoogle,
[id^="google_ads_iframe_"], [id^="google_ads_"], div[id^="div-gpt-ad"],
iframe[src*="googlesyndication.com"], iframe[src*="doubleclick.net"],
iframe[src*="googleadservices.com"], iframe[src*="amazon-adsystem.com"],
.taboola-container, .outbrain, .criteo-ad-container,
[data-lp-replacement-content-id],
.ad-container, .ad-wrapper, .ad-placement, .ad-unit, .ad-slot, .ad-box,
.ad-block, .advert, .advertisement, .advert-box, .ad-banner, .ad-frame,
.ads-container, .ads-box, .ads-placement, .banner-ad,
.sponsored, .sponsored-content, .promoted, .promoted-content,
[data-ad-slot], [data-ad-client], [data-ad-type], [data-ad],
#ad-banner, #ad-slot, #ad-content, #advert, #advertisement, #ads,
#banner-ad, #sponsored,
[aria-label="Advertisement"], [aria-label="Sponsored"]
"##;

/// The stylesheet: every selector above hidden, one rule each, so that a
/// selector one engine does not know does not void the others (a selector
/// list with one invalid member is dropped whole).
pub fn css() -> String {
    CSS.split(',')
        .map(str::trim)
        .filter(|s| !s.is_empty())
        .map(|s| format!("{s}{{display:none!important}}"))
        .collect::<Vec<_>>()
        .join("\n")
}

/// The script a shell injects into the page. It returns "on" when the rules
/// are in place and "none" when the page would not take them.
pub fn script() -> String {
    format!(
        r#"// Fable: cosmetic ad blocking. Installs the stylesheet; a page that
// refuses it (a strict Content-Security-Policy) is simply left alone.
(function () {{
  var CSS = {css};
  if (window.__fableAdblock) return 'on';
  window.__fableAdblock = true;
  try {{
    if (document.adoptedStyleSheets && typeof CSSStyleSheet === 'function') {{
      var sheet = new CSSStyleSheet();
      sheet.replaceSync(CSS);
      document.adoptedStyleSheets = document.adoptedStyleSheets.concat([sheet]);
      return 'on';
    }}
  }} catch (e) {{}}
  try {{
    var style = document.createElement('style');
    style.textContent = CSS;
    (document.head || document.documentElement).appendChild(style);
    return 'on';
  }} catch (e2) {{}}
  return 'none';
}})();"#,
        css = json_string(&css())
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_script_carries_the_rules() {
        let js = script();
        assert!(js.contains("ad-container"));
        assert!(js.contains("google_ads_"));
        assert!(js.starts_with("// Fable"));
        assert!(js.ends_with("})();"));
        // The stylesheet is one JSON string on one line, so no quote or line
        // break in it can break out of the string.
        let line = js.lines().find(|l| l.trim_start().starts_with("var CSS = ")).expect("the stylesheet line");
        let line = line.trim();
        assert!(line.starts_with("var CSS = \""), "{line}");
        assert!(line.ends_with("\";"), "{line}");
    }

    #[test]
    fn the_script_is_a_whole_expression() {
        // It is evaluated as an expression, so it must be bracketed and end
        // with a semicolon.
        let js = script();
        assert!(js.contains("(function () {"));
        assert!(js.ends_with("})();"));
        assert!(!js.contains("</script"), "the script must not close the tag it lives in");
    }

    #[test]
    fn every_selector_is_a_rule_that_hides() {
        // A bare selector list is not a stylesheet: it would parse to no rules at all.
        let css = css();
        let rules: Vec<&str> = css.lines().collect();
        assert_eq!(rules.len(), CSS.split(',').filter(|s| !s.trim().is_empty()).count());
        assert!(rules.iter().all(|r| r.ends_with("{display:none!important}")), "{css}");
        assert!(rules.contains(&".adsbygoogle{display:none!important}"));
    }

    #[test]
    fn the_rules_name_ads_only() {
        let css = css();
        assert!(css.contains(".adsbygoogle"));
        assert!(css.contains("[id^=\"google_ads_\"]"));
        // A bare ".ad" would hide real content (a class name like "ad" or
        // "read" contains it), so the short names are not used.
        assert!(!css.lines().any(|r| r.starts_with(".ad{") || r.starts_with(".ads{")));
    }
}
