/* Fable web-process extension for WebKitGTK.
 *
 * WebKit loads this shared object into every web process. It sees each
 * outgoing request before it is sent:
 *  - a third-party request to a listed tracker or ad domain is cancelled (the
 *    core decides), and the shell is told so it can count it;
 *  - anything that looks like media goes to the shell's resource list.
 *
 * This is a web process, so it has a copy of the core of its own and knows
 * nothing of the settings: the shell sends them ("fable.block") and the core
 * is told what to block.
 *
 * The top-level document itself is not cancelled: WebKit sets the page URI to
 * the URL being loaded when a navigation starts, before the request is sent,
 * so the document request is first-party to itself.
 */
#include <webkit2/webkit-web-extension.h>
#include <string.h>
#include "fable_core.h"

static void tell_view(WebKitWebPage *page, WebKitUserMessage *message) {
    webkit_web_page_send_message_to_view(page, message, NULL, NULL, NULL);
}

static gboolean on_send_request(WebKitWebPage *page, WebKitURIRequest *request,
                                WebKitURIResponse *redirected_response, gpointer data) {
    (void)redirected_response; (void)data;
    const char *uri = webkit_uri_request_get_uri(request);
    if (fable_should_block(uri, webkit_web_page_get_uri(page))) {
        tell_view(page, webkit_user_message_new("fable.blocked", NULL));
        return TRUE;
    }
    /* Players fetch media in ranges; that is the hint for URLs without an extension. */
    SoupMessageHeaders *headers = webkit_uri_request_get_http_headers(request);
    const char *hint = headers && soup_message_headers_get_one(headers, "Range") ? "range" : "";
    if (fable_sniff_note((uint32_t)webkit_web_page_get_id(page), uri, hint))   /* new for this page */
        tell_view(page, webkit_user_message_new("fable.sniff", g_variant_new("(ss)", uri, hint)));
    return FALSE;
}

/* A new document: what was seen on the last one may be reported again. */
static void on_page_uri(WebKitWebPage *page, GParamSpec *pspec, gpointer data) {
    (void)pspec; (void)data;
    fable_sniff_clear((uint32_t)webkit_web_page_get_id(page));
}

static void on_page_created(WebKitWebExtension *extension, WebKitWebPage *page, gpointer data) {
    (void)extension; (void)data;
    g_signal_connect(page, "send-request", G_CALLBACK(on_send_request), NULL);
    g_signal_connect(page, "notify::uri", G_CALLBACK(on_page_uri), NULL);
}

/* "trackers:ads", both "0" or "1". */
static void block_from(const char *state) {
    if (!state || strlen(state) < 3) return;
    fable_set_blocking(state[0] == '1', state[2] == '1');
}

static gboolean on_message(WebKitWebExtension *extension, WebKitUserMessage *message, gpointer data) {
    (void)extension; (void)data;
    GVariant *p = webkit_user_message_get_parameters(message);
    if (g_strcmp0(webkit_user_message_get_name(message), "fable.block") == 0 && p && g_variant_is_of_type(p, G_VARIANT_TYPE_STRING))
        block_from(g_variant_get_string(p, NULL));
    if (g_strcmp0(webkit_user_message_get_name(message), "fable.ads") == 0 && p && g_variant_is_of_type(p, G_VARIANT_TYPE_STRING)) {
        /* The UI process fetched a new list: swap this copy in, so the update
         * takes effect without waiting for the web process to restart. */
        const char *domains = g_variant_get_string(p, NULL);
        fable_ad_list_asset(NULL, (const uint8_t *)domains, strlen(domains));
    }
    return TRUE;
}

G_MODULE_EXPORT void webkit_web_extension_initialize_with_user_data(WebKitWebExtension *extension, GVariant *user_data) {
    if (user_data && g_variant_is_of_type(user_data, G_VARIANT_TYPE("(ss)"))) {
        const char *state, *domains;
        g_variant_get(user_data, "(&s&s)", &state, &domains);
        fable_ad_list_asset(NULL, (const uint8_t *)domains, strlen(domains));
        block_from(state);
    }
    g_signal_connect(extension, "page-created", G_CALLBACK(on_page_created), NULL);
    g_signal_connect(extension, "user-message-received", G_CALLBACK(on_message), NULL);
}
