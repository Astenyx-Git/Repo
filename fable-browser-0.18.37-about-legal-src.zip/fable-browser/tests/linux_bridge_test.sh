#!/bin/sh
# The Linux shell's new-tab bridge (webkit.messageHandlers.fable) under attack
# and in normal use, end to end with the real build/fable (make linux):
#
# 1. A web page opens a pop-up, then sends itself to fable://newtab. WebKitGTK
#    gives the pop-up the opener's message handler, so whatever it posts lands
#    on the opener's tab, which now shows the new-tab page. Before 0.18.7 that
#    navigated the tab to the address the pop-up chose (audit finding Medium-1).
#    The local server must never see /pwned-*.
# 2. The new-tab page's own search box still works: typing an address there
#    loads it (/legit-search).
#
# Needs xvfb-run, xdotool and python3; skips (exit 0) without them or without
# build/fable, unless FABLE_REQUIRE_UI=1.
set -u
cd "$(dirname "$0")/.."
skip() { echo "linux_bridge_test: $1, skipped"; [ "${FABLE_REQUIRE_UI:-0}" = 1 ] && exit 1; exit 0; }
[ -x build/fable ] || skip "no build/fable (make linux)"
for tool in xvfb-run xdotool python3; do command -v $tool >/dev/null 2>&1 || skip "no $tool"; done

WORK=$(mktemp -d)
PORT=$(python3 -c 'import socket; s = socket.socket(); s.bind(("127.0.0.1", 0)); print(s.getsockname()[1])')
cp tests/linux_bridge/attack.html "$WORK/"
sed "s/PORT/$PORT/g" tests/linux_bridge/popup.html > "$WORK/popup.html"
cat > "$WORK/run.sh" <<SCRIPT
#!/bin/sh
cd "$WORK"
python3 -m http.server $PORT --bind 127.0.0.1 > server.log 2>&1 &
SERVER=\$!
export HOME="$WORK/home"; mkdir -p "\$HOME"
unset XDG_DATA_HOME XDG_CONFIG_HOME XDG_CACHE_HOME   # the profile goes under HOME, not the caller's
mkdir -p "$WORK/home/.local/share/fable"
printf 'accepted_eula\tV1.2\n' > "$WORK/home/.local/share/fable/settings.tsv"
"$PWD/build/fable" http://127.0.0.1:$PORT/attack.html > fable1.log 2>&1 &
APP=\$!
sleep 6; xdotool mousemove 400 400 click 1   # the page may open a pop-up on a click only
sleep 8; kill \$APP; wait \$APP 2>/dev/null
export HOME="$WORK/home2"; mkdir -p "\$HOME"   # a fresh profile: no tabs of the first run come back in front of the new-tab page
mkdir -p "$WORK/home2/.local/share/fable"   # with the terms accepted, as the first profile
printf 'accepted_eula\tV1.2\n' > "$WORK/home2/.local/share/fable/settings.tsv"
"$PWD/build/fable" > fable2.log 2>&1 &
APP=\$!
sleep 6; xdotool mousemove 562 422 click 1   # the new-tab page's search box
sleep 0.5; xdotool type --delay 20 "http://127.0.0.1:$PORT/legit-search"; xdotool key Return
sleep 4; kill \$APP \$SERVER; wait \$APP 2>/dev/null
SCRIPT
timeout 120 xvfb-run -a -s "-screen 0 1280x900x24" sh "$WORK/run.sh"
fail=0
grep -q "GET /popup.html" "$WORK/server.log" || { echo "FAIL linux_bridge_test: the pop-up never opened, so nothing was tested"; fail=1; }
if grep -q "GET /pwned" "$WORK/server.log"; then echo "FAIL linux_bridge_test: a pop-up navigated the new-tab page's tab through the bridge"; fail=1; fi
grep -q "GET /legit-search" "$WORK/server.log" || { echo "FAIL linux_bridge_test: the new-tab page's search box did not load the address"; fail=1; }
[ $fail = 0 ] || { grep "GET" "$WORK/server.log"; rm -rf "$WORK"; exit 1; }
rm -rf "$WORK"
echo "linux_bridge_test: pop-up blocked from the bridge, search box works"
