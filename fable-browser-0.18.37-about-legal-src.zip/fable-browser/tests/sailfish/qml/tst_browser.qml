// shell/sailfish/qml with the real core and stand-in Sailfish modules (qml_test.cpp).
// The fake WebView finishes every load at once and answers runJavaScript through
// answer() below: what the panel and the new-tab page queued, and what the page
// scripts (media scan, reader) return.
import QtQuick 2.0
import QtTest 1.0
import Sailfish.WebEngine 1.0
import harbour.fable.Core 1.0
import Fake 1.0

Item {
    id: root
    width: 540
    height: 960

    readonly property string panelUrl: "https://fable.invalid/panel.html"
    property var page: null
    property var win: null
    property var panelOut: []     // messages the panel "queued"
    property var homeOut: []      // ... the new-tab page
    property var webOut: []       // ... a web page that pretends to be one of them
    property var sniffResult: undefined

    function answer(view, script) {
        if (script === Panel.drainScript()) {
            var url = String(view.url), out = url === panelUrl ? panelOut : Panel.isHome(url) ? homeOut : webOut;
            return JSON.stringify(out.splice(0, out.length));
        }
        if (script === Fable.sniffJs()) return sniffResult;
        if (script === Fable.readerScript()) return "on";
        return undefined;
    }

    function make() {
        var c = Qt.createComponent(probe.shell + "/pages/BrowserPage.qml");
        if (c.status !== Component.Ready) { console.log(c.errorString()); return null; }
        return c.createObject(root, { width: 540, height: 960 });
    }

    function panelView() {
        for (var i = FakeWeb.views.length - 1; i >= 0; --i) if (String(FakeWeb.views[i].url) === panelUrl) return FakeWeb.views[i];
        return null;
    }

    // What QML ran in the panel, unwrapped from Panel.runScript.
    function panelScripts() {
        var v = panelView(), out = [], head = "document.dispatchEvent(new CustomEvent('fable-run',{detail:";
        if (!v) return out;
        for (var i = 0; i < v.scripts.length; ++i) {
            var s = v.scripts[i];
            if (s.indexOf(head) === 0) out.push(JSON.parse(s.slice(head.length, s.length - 4)));
        }
        return out;
    }

    function lastState(fn) {
        var list = panelScripts();
        for (var i = list.length - 1; i >= 0; --i) {
            if (list[i].indexOf(fn + "(") === 0) {
                var s = list[i], body = fn === "Fable.show" ? s.slice(s.indexOf(",") + 1, s.length - 1) : s.slice(fn.length + 1, s.length - 1);
                return JSON.parse(body);
            }
        }
        return null;
    }

    function said(prefix) {
        var list = panelScripts();
        for (var i = 0; i < list.length; ++i) if (list[i].indexOf(prefix) === 0) return true;
        return false;
    }

    function lastCall(view) { return view.calls[view.calls.length - 1] || ""; }

    TestCase {
        name: "SailfishShell"

        function init() {
            Fable.sessionClear();
            Fable.historyClear();
            Fable.settingSet("restore_tabs", "");
            Fable.settingSet("ua_mode", "");
            Fable.settingSet("data_saver", "");
            Fable.settingSet("icon_theme", "");
            FakeWeb.answer = root.answer;
            root.panelOut = []; root.homeOut = []; root.webOut = []; root.sniffResult = undefined;
            root.page = root.make();
            verify(root.page, "BrowserPage loads");
        }

        function cleanup() {
            if (root.page) root.page.destroy();
            root.page = null;
            if (root.win) root.win.destroy();
            root.win = null;
            wait(0);
        }

        function test_01_starts_on_the_new_tab_page() {
            var web = root.page.web;
            compare(root.page.tabCount, 1);
            compare(web.calls[0], "loadHtml https://fable.invalid/newtab");
            verify(web.html.indexOf("window.FableHost=") > 0, "with the stand-in for FableHost");
            verify(root.page.homeShown);
            compare(probe.find(root.page, "address").text, "");
            compare(Fable.sessionCount(), 1, "the new-tab page is kept");
        }

        function test_02_address_bar_history_session() {
            var field = probe.find(root.page, "address"), web = root.page.web;
            field.text = "jolla.com";
            verify(probe.enter(field), "Enter in the address field");
            verify(lastCall(web).indexOf("load https://jolla.com") === 0, lastCall(web));
            verify(!root.page.homeShown);
            verify(root.page.current().url.indexOf("https://jolla.com") === 0);
            verify(Fable.historyJson("jolla", 10).indexOf("jolla.com") > 0, "in history");
            compare(Fable.sessionCount(), 1, "kept for the next start");
            web.title = "Jolla";
            compare(root.page.current().title, "Jolla");
            compare(root.page.coverTitle, "Jolla");
        }

        function test_03_panel_state_and_messages() {
            root.page.navigate("jolla.com");
            root.page.showPanel("menu");
            var pv = panelView();
            verify(pv, "the panel has its own WebView");
            verify(!pv.privateMode, "never private");
            verify(pv.html.indexOf("window.FableSheet=true") > 0);
            var state = lastState("Fable.show");
            verify(state, "Fable.show ran once the panel loaded");
            compare(state.platform, "sailfish");
            compare(state.caps.networkBlock, false);
            compare(state.caps.javascript, false);
            compare(state.web, true);
            compare(state.tabs.length, 1);
            compare(state.tabs[0]["private"], false);
            verify(state.url.indexOf("https://jolla.com") === 0);
            compare(typeof state.settings, "object");

            root.panelOut = ["q\t7\tget\tlanguage", "a\tnewTab\t"];
            tryCompare(root.page, "tabCount", 2);
            tryVerify(function () { return said("Fable.reply(7,"); }, 2000, "the question is answered");
            var update = lastState("Fable.update");
            verify(update && update.tabs.length === 2 && update.url === "", "the panel sees the new tab");

            root.panelOut = ["a\thidden\t"];
            tryVerify(function () { return !pv.parent.parent.visible; }, 2000, "the panel closes when it says so");
        }

        function test_04_private_tabs() {
            root.page.navigate("jolla.com");
            root.page.act("newPrivate", "");
            verify(root.page.incognito);
            verify(FakeWeb.last().privateMode, "a private WebView");
            verify(FakeWeb.last().html.indexOf("INCOGNITO = true") > 0, "the private new-tab page");
            root.page.navigate("https://private.example/");
            compare(Fable.historyJson("private.example", 10), "[]", "not in history");
            verify(Fable.sessionJson().indexOf("private.example") < 0, "not kept");
            compare(root.page.tabCount, 2);
            root.page.act("exitPrivate", "");
            compare(root.page.tabCount, 1);
            verify(!root.page.incognito);
            verify(!FakeWeb.last().privateMode, "back to a normal WebView");
            verify(lastCall(FakeWeb.last()).indexOf("load https://jolla.com") === 0, "on the normal tab");
            compare(root.page.toastText, Fable.tr("private_closed"));
        }

        function test_05_user_agent() {
            root.page.showPanel("settings");
            root.panelOut = ["q\t9\tset\tua_mode\ndesktop"];
            tryVerify(function () { return FakeWeb.last().httpUserAgent.indexOf("Firefox") > 0; }, 2000, "a new WebView with a desktop user agent");
            root.page.act("desktop", "");
            compare(Fable.settingGet("ua_mode"), "default");
            compare(FakeWeb.last().httpUserAgent, "", "the WebView's own again");
            compare(root.page.toastText, Fable.tr("mobile_on"));
        }

        function test_06_new_tab_search_and_web_pages() {
            var web = root.page.web;
            root.homeOut = ["go\tjolla phone"];
            tryVerify(function () { return lastCall(web).indexOf("load ") === 0; }, 2000, "the search box opens a search");
            verify(lastCall(web).indexOf("jolla") > 0, lastCall(web));
            verify(!root.page.homeShown);
            var drains = web.scripts.filter(function (s) { return s === Panel.drainScript(); }).length;
            root.webOut = ["go\thttps://evil.example/"];
            wait(400);
            compare(web.scripts.filter(function (s) { return s === Panel.drainScript(); }).length, drains, "a web page is never drained");
            verify(lastCall(web).indexOf("evil") < 0);
        }

        function test_07_bookmarks() {
            root.page.navigate("https://bookmark.example/");
            var url = root.page.current().url;
            root.page.act("bookmarkToggle", "");
            verify(Fable.bookmarkId(url) > 0, "starred");
            compare(root.page.toastText, Fable.tr("added_bookmark"));
            root.page.act("bookmarkExport", "");
            compare(root.page.toastText, Fable.tr("exported_bookmark"));
            var file = probe.downloads() + "/bookmarks.html";
            verify(Panel.readText(file).indexOf("bookmark.example") > 0, "exported to Downloads");
            root.page.act("bookmarkToggle", "");
            compare(Fable.bookmarkId(url), 0, "unstarred");
            root.page.act("bookmarkImportPick", "");
            verify(probe.last, "the file picker is pushed");
            var picker = probe.last.createObject(root);
            picker.selectedContentProperties = { filePath: file };
            verify(Fable.bookmarkId(url) > 0, "imported from the picked file");
            compare(root.page.toastText, Fable.tr("bookmark_imported").replace("{n}", "1"));
            picker.selectedContentProperties = { filePath: file + ".missing" };
            compare(root.page.toastText, Fable.tr("bookmark_import_failed"));
            picker.destroy();
        }

        function test_08_clear_history_copy_reader() {
            root.page.navigate("jolla.com");
            verify(Fable.historyJson("", 10) !== "[]");
            root.page.act("clear", "history");
            compare(Fable.historyJson("", 10), "[]");
            compare(root.page.toastText, Fable.tr("data_cleared"));
            root.page.act("copy", "https://jolla.com/");
            compare(root.page.toastText, Fable.tr("link_copied"));
            root.page.act("reader", "");
            tryCompare(root.page, "toastText", Fable.tr("reader_on"));
        }

        function test_09_media_scan() {
            root.page.navigate("https://media.example/");
            root.page.showPanel("sniff");
            root.sniffResult = [["video", "https://cdn.example/a.mp4"]];
            root.page.act("sniffScan", "");
            tryVerify(function () { return Fable.sniffCount(root.page.frontId()) === 1; }, 2000, "the scan is recorded");
            tryVerify(function () { return said("Fable.refresh('sniff')"); }, 2000, "and the panel asked to show it");
        }

        function test_10_restore_tabs() {
            root.page.navigate("https://a.example/");
            root.page.openTab("https://b.example/", false);
            root.page.openTab("", false);
            root.page.openTab("https://p.example/", true);
            root.page.show(1);
            root.page.destroy();
            root.page = null;
            wait(0);
            root.page = root.make();
            compare(root.page.tabCount, 3, "the two web pages and the new-tab page");
            compare(root.page.tabs[2].url, "");
            compare(root.page.front, 1);
            verify(root.page.current().url.indexOf("https://b.example") === 0);
            verify(lastCall(root.page.web).indexOf("load https://b.example") === 0, "the tab in front is loaded");

            Panel.handleMessage("q\t3\tset\trestore_tabs\n0", 0, "{}");
            compare(Fable.sessionCount(), 0, "switched off: nothing kept");
            root.page.destroy();
            root.page = null;
            wait(0);
            root.page = root.make();
            compare(root.page.tabCount, 1);
            compare(root.page.current().url, "", "a new-tab page");
        }

        function test_11_closing_tabs() {
            root.page.navigate("https://a.example/");
            root.page.openTab("https://b.example/", false);
            var a = root.page.tabs[0].id, b = root.page.tabs[1].id;
            root.page.act("closeTab", String(b));
            compare(root.page.tabCount, 1);
            verify(lastCall(root.page.web).indexOf("load https://a.example") === 0, "the neighbour comes to the front");
            root.page.act("closeTab", String(a));
            compare(root.page.tabCount, 1, "closing the last tab leaves a new one");
            compare(root.page.current().url, "");
            compare(lastCall(root.page.web), "loadHtml https://fable.invalid/newtab");
        }

        function test_13_skins() {
            var plain = Fable.logoUri();
            root.page.navigate("jolla.com");
            root.page.showPanel("menu");
            var pv = panelView(), web = root.page.web, loads = web.calls.length, toastBefore = root.page.toastText;
            root.page.navigate("theme://Kimi");
            compare(Fable.themeCurrent(), "kimi");
            compare(root.page.toastText, toastBefore, "nothing is said");
            compare(web.calls.length, loads, "the page stays where it was");
            verify(lastCall(pv).indexOf("loadHtml ") === 0 && pv.html.indexOf("<style id=\"fable-skin\">:root{--ground:#000000;") > 0,
                   "the panel is loaded again in Kimi's colours");
            verify(Fable.logoUri() !== plain);
            root.page.openTab("", false);
            verify(web.html.indexOf(Fable.logoUri()) > 0 && web.html.indexOf("--ground:#000000") > 0, "a new tab: Kimi's logo and colours");
            compare(root.page.openTab("theme://grok", false), null, "no tab for a skin");
            compare(root.page.tabCount, 2);
            compare(Fable.themeCurrent(), "grok");
            compare(JSON.parse(Fable.themePalette()).bar, "#1C1512");
            var html = web.html;
            root.page.navigate("theme://nope");
            compare(Fable.themeCurrent(), "grok", "a name that is no skin changes nothing");
            compare(web.html, html);
            compare(root.page.toastText, toastBefore, "and says nothing");
            root.page.navigate("theme://claude");
            // The default skin's page carries only its private-mode colours (:root.incog), no :root{...} of a skin.
            verify(web.html.indexOf(plain) > 0 && web.html.indexOf("fable-skin\">:root{") < 0, "the new-tab page in front is drawn again, in the default skin");
            root.page.showPanel("tabs");
            var state = lastState("Fable.show");
            compare(state.tabs[1].icon, plain, "the new-tab tab's icon in the panel");
        }

        function test_14_scan() {
            var field = probe.find(root.page, "address"), web = root.page.web;
            var camera = probe.find(root.page, "scanCamera"), image = probe.find(root.page, "scanImage");
            verify(camera && image, "the scan buttons are there");
            compare(field.text, "");
            verify(camera.visible && image.visible, "a blank address bar shows the camera and the picture buttons");
            field.text = "jolla";
            verify(!camera.visible && !image.visible, "with an address in it, neither");
            field.text = "";
            var depth = probe.depth;
            image.clicked(null);
            compare(probe.depth, depth + 1, "the picture button pushes the picker");
            camera.clicked(null);
            compare(probe.depth, depth + 2, "the QR button pushes the scanner");

            var loads = web.calls.length;
            root.page.scanResult("  https://example.com/a  ");
            compare(web.calls.length, loads + 1);
            verify(lastCall(web).indexOf("https://example.com/a") >= 0, "a web address opens in the tab in front");
            depth = probe.depth; loads = web.calls.length;
            root.page.scanResult("WIFI:S:home;T:WPA;P:secret;;");
            compare(probe.depth, depth + 1, "anything else: a page of its own");
            compare(web.calls.length, loads, "and nothing is looked up");
            root.page.scanResult("");
            compare(root.page.toastText, Fable.tr("scan_unknown"), "no code: said so");
            root.page.toastText = "";
            root.page.scanImageFile("/nowhere/none.png");
            compare(root.page.toastText, Fable.tr("scan_unknown"), "a picture that cannot be read: the same");
        }

        function test_12_window_settings_and_cover() {
            root.page.destroy();
            root.page = null;
            Fable.panelQuery("legalAccept", "", 0);
            var c = Qt.createComponent(probe.shell + "/harbour-fable.qml");
            compare(c.status, Component.Ready, c.errorString());
            root.win = c.createObject(root);
            verify(root.win.browser && root.win.browser === root.win.pageItem, "app.browser is the page");
            compare(WebEngineSettings.cookieBehavior, WebEngineSettings.BlockThirdParty);
            compare(WebEngineSettings.autoLoadImages, true);
            compare(WebEngineSettings.colorScheme, WebEngineSettings.FollowsAmbience);
            compare(WebEngineSettings.javascriptEnabled, true, "never switched off: the panel needs it");
            Panel.handleMessage("q\t4\tset\tdata_saver\n1", 0, "{}");
            compare(WebEngineSettings.autoLoadImages, false, "don't load images");
            Panel.handleMessage("q\t5\tset\tblock_3p_cookies\n0", 0, "{}");
            compare(WebEngineSettings.cookieBehavior, WebEngineSettings.AcceptAll);
            Panel.handleMessage("q\t6\tset\tblock_3p_cookies\n1", 0, "{}");

            var cover = root.win.coverItem;
            verify(cover, "the cover is made");
            root.win.browser.navigate("https://jolla.com/");
            root.win.browser.web.title = "Jolla";
            compare(cover.title, "Jolla");
            cover.newTab();
            compare(root.win.browser.tabCount, 2);
            compare(root.win.activations, 1, "the app comes to the front");
            cover.reloadPage();
            compare(lastCall(root.win.browser.web), "loadHtml https://fable.invalid/newtab");
        }
    }
}
