//! External app redirects: would this navigation open another application?
//!
//! A page can try to bounce the user out of the browser — into its own app
//! ("open in our app"), into the app store, or into whatever app a custom
//! scheme names. On Android that is `intent://`, on iOS `itms-apps://`, and
//! everywhere a custom scheme like `myapp://`.
//!
//! The setting "block external apps" (off by default) stops those
//! navigations. The rules are the same on every platform so that a page
//! cannot be blocked on one and not on another.

use std::sync::atomic::{AtomicBool, Ordering};

static BLOCKING: AtomicBool = AtomicBool::new(false);

/// Turn the blocking of external app redirects on or off (the
/// "block_external_apps" setting).
pub fn set_blocking(on: bool) {
    BLOCKING.store(on, Ordering::Relaxed);
}

/// Whether external app redirects are blocked.
pub fn blocking() -> bool {
    BLOCKING.load(Ordering::Relaxed)
}

/// Schemes the browser handles itself: they never open another application.
/// http and https are not here: they are looked at for app store links.
/// `fable` is the browser's own scheme (the new-tab page on iOS, macOS and
/// Linux is fable://newtab), checked before the shells' own scheme handling.
/// `theme` is Fable's own scheme for theme pages (theme://…): the browser
/// serves them, so leaving for another app is not what they do.
const INTERNAL: &[&str] = &[
    "about", "data", "blob", "file", "javascript", "view-source", "chrome", "favicon", "fable", "theme",
];

/// Schemes that open another application on purpose: the user taps a phone
/// number or a mail address and expects the dialler or the mail app. They are
/// left alone.
const HANDOFF: &[&str] = &["tel", "mailto", "sms"];

/// The scheme of a URL, if it has one. A relative address has none.
pub fn scheme_of(url: &str) -> Option<&str> {
    let url = url.trim();
    let end = url.find(['/', '?', '#']).unwrap_or(url.len());
    let head = &url[..end];
    let colon = head.find(':')?;
    let scheme = &head[..colon];
    if scheme.is_empty() {
        return None;
    }
    let mut chars = scheme.bytes();
    let first = chars.next()?;
    if !first.is_ascii_alphabetic() {
        return None;
    }
    if !chars.all(|c| c.is_ascii_alphanumeric() || matches!(c, b'+' | b'-' | b'.')) {
        return None;
    }
    Some(scheme)
}

fn in_list(scheme: &str, list: &[&str]) -> bool {
    list.iter().any(|s| s.eq_ignore_ascii_case(scheme))
}

/// True when the URL points at an app store.
fn is_app_store(url: &str) -> bool {
    let Some((_, rest)) = url.split_once("://") else { return false };
    let end = rest.find(['/', '?', '#']).unwrap_or(rest.len());
    let authority = &rest[..end];
    let host_port = authority.rsplit_once('@').map_or(authority, |(_, h)| h);
    let host = host_port.split(':').next().unwrap_or(host_port).to_ascii_lowercase();
    if host == "apps.apple.com" || host == "itunes.apple.com" || host == "apps.google.com" {
        return true;
    }
    if host == "play.google.com" {
        let path = &rest[end..];
        return path.starts_with("/store/apps");
    }
    false
}

/// True when following this URL would leave the browser for another app:
/// a custom scheme, or a link to an app store.
pub fn is_external_app_url(url: &str) -> bool {
    let url = url.trim();
    if url.is_empty() {
        return false;
    }
    let Some(scheme) = scheme_of(url) else {
        return false; // a relative address stays in the page
    };
    // A web address is only external when it points at an app store.
    if scheme.eq_ignore_ascii_case("http") || scheme.eq_ignore_ascii_case("https") {
        return is_app_store(url);
    }
    if in_list(scheme, INTERNAL) || in_list(scheme, HANDOFF) {
        return false;
    }
    true
}

/// The decision the shells use: 1 when the navigation has to be stopped.
pub fn blocks(url: &str) -> bool {
    blocking() && is_external_app_url(url)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn reads_the_scheme() {
        assert_eq!(scheme_of("https://example.com/"), Some("https"));
        assert_eq!(scheme_of("Intent://x#Intent;end"), Some("Intent"));
        assert_eq!(scheme_of("mailto:a@b.c"), Some("mailto"));
        assert_eq!(scheme_of("/relative/path"), None);
        assert_eq!(scheme_of("example.com"), None);
        assert_eq!(scheme_of("example.com/path"), None);
        assert_eq!(scheme_of("1abc://x"), None);   // a scheme starts with a letter
        assert_eq!(scheme_of("://x"), None);
    }

    #[test]
    fn ordinary_addresses_are_not_external() {
        for u in [
            "https://example.com/",
            "http://example.com/a?b=c#d",
            "about:blank",
            "data:text/html,hi",
            "blob:https://example.com/2f1c",
            "file:///tmp/a.html",
            "javascript:alert(1)",
            "view-source:https://example.com",
            "fable://newtab",
            "fable://newtab/",
            "theme://dark",
            "theme://light/",
            "/relative/path",
            "example.com",
            "",
        ] {
            assert!(!is_external_app_url(u), "{u}");
        }
    }

    #[test]
    fn the_conventional_handoffs_are_left_alone() {
        for u in ["tel:+123456", "mailto:a@b.c", "sms:+123456"] {
            assert!(!is_external_app_url(u), "{u}");
        }
    }

    #[test]
    fn custom_schemes_open_another_app() {
        for u in [
            "intent://scan/#Intent;scheme=zxing;package=com.x;end",
            "market://details?id=com.example",
            "android-app://com.example/",
            "itms-apps://itunes.apple.com/app/id1",
            "itms-appss://itunes.apple.com/app/id1",
            "myapp://open/thing",
            "weixin://dl/business/?t=x",
            "baiduboxapp://sbox/1",
            "vnd.ms-word:ofe|u|http://x/y.docx",
        ] {
            assert!(is_external_app_url(u), "{u}");
        }
    }

    #[test]
    fn app_stores_are_external() {
        for u in [
            "https://apps.apple.com/us/app/id123",
            "https://itunes.apple.com/app/id123",
            "https://apps.google.com/detail?id=x",
            "https://play.google.com/store/apps/details?id=com.example",
            "http://play.google.com/store/apps/details?id=com.example",
        ] {
            assert!(is_external_app_url(u), "{u}");
        }
        // The rest of the store's web site is ordinary browsing.
        assert!(!is_external_app_url("https://play.google.com/"));
        assert!(!is_external_app_url("https://play.google.com/store/games"));
        assert!(!is_external_app_url("https://example.com/apps.apple.com"));
    }

    #[test]
    fn nothing_is_blocked_until_the_setting_is_on() {
        let _guard = {
            static LOCK: std::sync::Mutex<()> = std::sync::Mutex::new(());
            LOCK.lock().unwrap_or_else(|e| e.into_inner())
        };
        set_blocking(false);
        assert!(!blocking());
        assert!(!blocks("intent://scan/"));
        set_blocking(true);
        assert!(blocking());
        assert!(blocks("intent://scan/"));
        assert!(!blocks("https://example.com/"));
        assert!(!blocks("fable://newtab/"), "our own new-tab page is never an app redirect");
        assert!(!blocks("theme://dark"), "a theme page is ours too, not an app redirect");
        set_blocking(false);
    }
}
