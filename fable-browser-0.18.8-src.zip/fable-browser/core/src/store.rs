//! User data kept between runs: settings (opaque key/value strings) and the
//! browsing history. Plain tab-separated files in a directory chosen by the
//! shell; without a directory everything still works, in memory only.
//!
//! `Store` is an ordinary value (tested directly); the shells go through the
//! process-wide instance behind the free functions at the bottom, which also
//! apply the settings the core itself acts on.

use std::collections::BTreeMap;
use std::fs::{self, OpenOptions};
use std::io::Write;
use std::path::PathBuf;
use std::sync::{Mutex, MutexGuard};

/// Oldest visits beyond this are dropped.
const HISTORY_CAP: usize = 5000;
/// How far the list may overshoot the cap before it is trimmed and rewritten.
const HISTORY_SLACK: usize = 500;

struct Visit {
    time_ms: u64,
    url: String,
    title: String,
}

pub struct Store {
    dir: Option<PathBuf>,
    settings: BTreeMap<String, String>,
    history: Vec<Visit>, // oldest first
}

impl Store {
    pub const fn in_memory() -> Self {
        Store { dir: None, settings: BTreeMap::new(), history: Vec::new() }
    }

    /// Load (or start) the store in `dir`. Unreadable files count as empty.
    pub fn open(dir: impl Into<PathBuf>) -> Self {
        let dir = dir.into();
        let _ = fs::create_dir_all(&dir);
        let mut store = Store { dir: Some(dir), settings: BTreeMap::new(), history: Vec::new() };

        for line in store.read("settings.tsv").lines() {
            if let Some((key, value)) = line.split_once('\t') {
                store.settings.insert(unescape(key), unescape(value));
            }
        }

        let text = store.read("history.tsv");
        let mut lines = 0;
        for line in text.lines() {
            lines += 1;
            let mut fields = line.splitn(3, '\t');
            let (Some(time), Some(url)) = (fields.next(), fields.next()) else { continue };
            let Ok(time_ms) = time.parse::<u64>() else { continue };
            let visit = Visit { time_ms, url: unescape(url), title: unescape(fields.next().unwrap_or("")) };
            match store.history.last_mut() {
                Some(last) if last.url == visit.url => *last = visit, // later line updates the same visit
                _ => store.history.push(visit),
            }
        }
        let over = store.history.len().saturating_sub(HISTORY_CAP);
        store.history.drain(..over);
        if lines != store.history.len() {
            store.rewrite_history(); // compact what the append-only log accumulated
        }
        store
    }

    // ---- settings ----------------------------------------------------------

    /// "" when unset.
    pub fn get(&self, key: &str) -> &str {
        self.settings.get(key).map_or("", String::as_str)
    }

    /// Setting a key to "" removes it.
    pub fn set(&mut self, key: &str, value: &str) {
        if key.is_empty() {
            return;
        }
        if value.is_empty() {
            self.settings.remove(key);
        } else {
            self.settings.insert(key.to_owned(), value.to_owned());
        }
        let mut text = String::new();
        for (k, v) in &self.settings {
            text.push_str(&format!("{}\t{}\n", escape(k), escape(v)));
        }
        self.write_atomic("settings.tsv", &text);
    }

    // ---- history -----------------------------------------------------------

    /// Record a visit. A repeat of the most recent URL updates that visit
    /// (pages report their title after they start loading) instead of adding one.
    pub fn history_add(&mut self, url: &str, title: &str, time_ms: u64) {
        let url = url.trim();
        if url.is_empty() {
            return;
        }
        match self.history.last_mut() {
            Some(last) if last.url == url => {
                last.time_ms = time_ms;
                if !title.trim().is_empty() {
                    last.title = title.trim().to_owned();
                }
            }
            _ => self.history.push(Visit { time_ms, url: url.to_owned(), title: title.trim().to_owned() }),
        }
        if self.history.len() > HISTORY_CAP + HISTORY_SLACK {
            let over = self.history.len() - HISTORY_CAP;
            self.history.drain(..over);
            self.rewrite_history();
        } else if let (Some(path), Some(last)) = (self.path("history.tsv"), self.history.last()) {
            if let Ok(mut file) = OpenOptions::new().create(true).append(true).open(path) {
                let _ = file.write_all(line(last).as_bytes());
            }
        }
    }

    /// Newest first, as a JSON array of `{"t": ms, "u": url, "n": title}`.
    /// `query` filters by case-insensitive substring of URL or title.
    pub fn history_json(&self, query: &str, limit: usize) -> String {
        let needle = query.trim().to_lowercase();
        let mut out = String::from("[");
        let matching = self
            .history
            .iter()
            .rev()
            .filter(|v| needle.is_empty() || v.url.to_lowercase().contains(&needle) || v.title.to_lowercase().contains(&needle))
            .take(limit);
        for (i, v) in matching.enumerate() {
            if i > 0 {
                out.push(',');
            }
            out.push_str(&format!("{{\"t\":{},\"u\":{},\"n\":{}}}", v.time_ms, json_string(&v.url), json_string(&v.title)));
        }
        out.push(']');
        out
    }

    /// Remove the visit with this URL and time; `time_ms == 0` removes every visit to the URL.
    pub fn history_delete(&mut self, url: &str, time_ms: u64) {
        let before = self.history.len();
        self.history.retain(|v| !(v.url == url && (time_ms == 0 || v.time_ms == time_ms)));
        if self.history.len() != before {
            self.rewrite_history();
        }
    }

    pub fn history_clear(&mut self) {
        self.history.clear();
        self.rewrite_history();
    }

    pub fn history_len(&self) -> usize {
        self.history.len()
    }

    // ---- files -------------------------------------------------------------

    fn path(&self, name: &str) -> Option<PathBuf> {
        self.dir.as_ref().map(|d| d.join(name))
    }

    fn read(&self, name: &str) -> String {
        self.path(name).and_then(|p| fs::read(p).ok()).map(|b| String::from_utf8_lossy(&b).into_owned()).unwrap_or_default()
    }

    /// Write to a temporary file and rename, so a crash never leaves half a file.
    fn write_atomic(&self, name: &str, text: &str) {
        let Some(path) = self.path(name) else { return };
        let tmp = path.with_extension("tmp");
        if fs::write(&tmp, text).is_ok() {
            let _ = fs::rename(&tmp, &path);
        }
    }

    fn rewrite_history(&self) {
        let text: String = self.history.iter().map(line).collect();
        self.write_atomic("history.tsv", &text);
    }
}

fn line(v: &Visit) -> String {
    format!("{}\t{}\t{}\n", v.time_ms, escape(&v.url), escape(&v.title))
}

/// Keep a field on one line and free of tabs.
fn escape(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    for c in s.chars() {
        match c {
            '\\' => out.push_str("\\\\"),
            '\t' => out.push_str("\\t"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            c => out.push(c),
        }
    }
    out
}

fn unescape(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    let mut chars = s.chars();
    while let Some(c) = chars.next() {
        if c != '\\' {
            out.push(c);
            continue;
        }
        match chars.next() {
            Some('t') => out.push('\t'),
            Some('n') => out.push('\n'),
            Some('r') => out.push('\r'),
            Some(other) => out.push(other),
            None => out.push('\\'),
        }
    }
    out
}

/// A JSON string literal that is also safe inside an HTML `<script>` block.
pub fn json_string(s: &str) -> String {
    let mut out = String::with_capacity(s.len() + 2);
    out.push('"');
    for c in s.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            '<' | '>' | '&' | '\u{2028}' | '\u{2029}' => out.push_str(&format!("\\u{:04x}", c as u32)),
            c if (c as u32) < 0x20 => out.push_str(&format!("\\u{:04x}", c as u32)),
            c => out.push(c),
        }
    }
    out.push('"');
    out
}

// ---- the process-wide store the shells use ---------------------------------

static STORE: Mutex<Store> = Mutex::new(Store::in_memory());

fn store() -> MutexGuard<'static, Store> {
    STORE.lock().unwrap_or_else(|e| e.into_inner())
}

/// Settings the core itself acts on; everything else is only stored for the shell.
fn apply(key: &str, value: &str) {
    match key {
        "search_template" => {
            if !crate::omnibox::set_search_template(value) {
                crate::omnibox::reset_search_template(); // unset or unusable: the default engine
            }
        }
        "block_trackers" => crate::blocker::set_enabled(value != "0"),
        // These two are off unless the user turned them on, so only "1" opens them.
        "block_ads" => crate::blocker::set_ads_enabled(value == "1"),
        "block_external_apps" => crate::external::set_blocking(value == "1"),
        _ => {}
    }
}

pub fn open(dir: &str) {
    let loaded = Store::open(dir);
    for key in ["search_template", "block_trackers", "block_ads", "block_external_apps"] {
        apply(key, loaded.get(key)); // "" restores the default
    }
    *store() = loaded;
}

pub fn setting_get(key: &str) -> String {
    store().get(key).to_owned()
}

/// Every setting, in key order.
pub fn settings_all() -> Vec<(String, String)> {
    store().settings.iter().map(|(k, v)| (k.clone(), v.clone())).collect()
}

pub fn setting_set(key: &str, value: &str) {
    store().set(key, value);
    apply(key, value);
}

pub fn history_add(url: &str, title: &str, time_ms: u64) {
    store().history_add(url, title, time_ms);
}

pub fn history_json(query: &str, limit: usize) -> String {
    store().history_json(query, limit)
}

pub fn history_delete(url: &str, time_ms: u64) {
    store().history_delete(url, time_ms);
}

pub fn history_clear() {
    store().history_clear();
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::{AtomicU32, Ordering};

    fn temp_dir() -> PathBuf {
        static N: AtomicU32 = AtomicU32::new(0);
        let dir = std::env::temp_dir().join(format!("fable-store-{}-{}", std::process::id(), N.fetch_add(1, Ordering::Relaxed)));
        let _ = fs::remove_dir_all(&dir);
        dir
    }

    #[test]
    fn settings_round_trip_through_disk() {
        let dir = temp_dir();
        let mut s = Store::open(&dir);
        assert_eq!(s.get("ua_mode"), "");
        s.set("ua_mode", "desktop");
        s.set("shortcuts", "[{\"n\":\"a\\tb\",\"u\":\"https://x/\"}]\nsecond line\\");
        s.set("gone", "x");
        s.set("gone", "");
        s.set("", "ignored");

        let s = Store::open(&dir);
        assert_eq!(s.get("ua_mode"), "desktop");
        assert_eq!(s.get("shortcuts"), "[{\"n\":\"a\\tb\",\"u\":\"https://x/\"}]\nsecond line\\");
        assert_eq!(s.get("gone"), "");
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn history_records_updates_filters_and_persists() {
        let dir = temp_dir();
        let mut s = Store::open(&dir);
        s.history_add("https://a.example/", "", 1000);
        s.history_add("https://a.example/", "站点 A", 1500); // title arrives later: same visit
        s.history_add("https://b.example/x", "B <page> \"quoted\"", 2000);
        s.history_add("https://a.example/", "站点 A", 3000); // a new visit after going elsewhere
        s.history_add("   ", "blank", 4000);
        assert_eq!(s.history_len(), 3);

        assert_eq!(
            s.history_json("", 10),
            "[{\"t\":3000,\"u\":\"https://a.example/\",\"n\":\"站点 A\"},\
             {\"t\":2000,\"u\":\"https://b.example/x\",\"n\":\"B \\u003cpage\\u003e \\\"quoted\\\"\"},\
             {\"t\":1500,\"u\":\"https://a.example/\",\"n\":\"站点 A\"}]"
        );
        assert_eq!(s.history_json("B.EXAMPLE", 10).matches("\"t\":").count(), 1);
        assert_eq!(s.history_json("站点", 10).matches("\"t\":").count(), 2);
        assert_eq!(s.history_json("", 1).matches("\"t\":").count(), 1);
        assert_eq!(s.history_json("nothing", 10), "[]");

        // Reopening sees the same three visits (the log had four lines).
        let mut s = Store::open(&dir);
        assert_eq!(s.history_len(), 3);
        s.history_delete("https://a.example/", 1500);
        assert_eq!(s.history_len(), 2);
        s.history_delete("https://a.example/", 0);
        assert_eq!(s.history_len(), 1);
        assert_eq!(Store::open(&dir).history_len(), 1);
        s.history_clear();
        assert_eq!(Store::open(&dir).history_len(), 0);
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn history_is_capped() {
        let dir = temp_dir();
        let mut s = Store::open(&dir);
        for i in 0..(HISTORY_CAP + HISTORY_SLACK + 1) as u64 {
            s.history_add(&format!("https://example.com/{i}"), "t", i);
        }
        assert_eq!(s.history_len(), HISTORY_CAP);
        assert!(s.history_json("", 1).contains(&format!("/{}", HISTORY_CAP + HISTORY_SLACK)));
        assert_eq!(Store::open(&dir).history_len(), HISTORY_CAP);
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn works_without_a_directory() {
        let mut s = Store::in_memory();
        s.set("k", "v");
        s.history_add("https://a/", "A", 1);
        assert_eq!(s.get("k"), "v");
        assert_eq!(s.history_len(), 1);
        s.history_clear();
        assert_eq!(s.history_json("", 5), "[]");
    }

    #[test]
    fn escaping_round_trips() {
        for s in ["", "plain", "tab\there", "line\nbreak\r", "back\\slash", "\\t literal", "混合\t\\\n"] {
            assert_eq!(unescape(&escape(s)), s);
            assert!(!escape(s).contains(['\t', '\n', '\r']));
        }
        assert_eq!(json_string("a\u{1}</script>&\u{2028}"), "\"a\\u0001\\u003c/script\\u003e\\u0026\\u2028\"");
    }
}
