//! Bookmarks: a flat list of entries (bookmarks and folders) with a parent
//! id, plus the NETSCAPE bookmark-file format Chrome and Firefox write and
//! read (`<!DOCTYPE NETSCAPE-Bookmark-file-1>`, `<DL>`/`<DT><A HREF>`/
//! `<H3>` folders). Parsing and export are pure functions over strings; the
//! persistence lives in store.rs (bookmarks.tsv), like the history.

use crate::store::json_string;

/// One row of the bookmark table. `parent == 0` is the root (the toolbar).
/// The order inside the flat list is the order among siblings.
pub struct Entry {
    pub id: u64,
    pub folder: bool,
    pub parent: u64,
    pub title: String,
    pub url: String, // "" for folders
}

/// A parsed node of an imported file, before it is flattened into entries.
pub struct Node {
    pub folder: bool,
    pub title: String,
    pub url: String,
    pub children: Vec<Node>,
}

// ---- JSON for the panel ----------------------------------------------------

/// The root's children as a nested JSON array: bookmarks are
/// `{"i":id,"u":url,"n":title}`, folders `{"i":id,"f":1,"n":name,"c":[...]}`.
/// `query` keeps the bookmarks whose title or URL contains it (case
/// insensitive) and the folders that still hold something; a folder whose
/// own name matches keeps its whole subtree.
pub fn tree_json(items: &[Entry], query: &str) -> String {
    let needle = query.trim().to_lowercase();
    fn kids<'a>(items: &'a [Entry], parent: u64) -> Vec<&'a Entry> {
        items.iter().filter(|e| e.parent == parent).collect()
    }
    fn bookmark_json(e: &Entry, out: &mut String) {
        out.push_str(&format!("{{\"i\":{},\"u\":{},\"n\":{}}}", e.id, json_string(&e.url), json_string(&e.title)));
    }
    fn emit_all(e: &Entry, items: &[Entry], out: &mut String) {
        out.push_str(&format!("{{\"i\":{},\"f\":1,\"n\":{},\"c\":[", e.id, json_string(&e.title)));
        for (i, c) in kids(items, e.id).iter().enumerate() {
            if i > 0 {
                out.push(',');
            }
            if c.folder {
                emit_all(c, items, out);
            } else {
                bookmark_json(c, out);
            }
        }
        out.push_str("]}");
    }
    /// Emits the folder with only the matching descendants; false when nothing matched.
    fn emit_filtered(e: &Entry, items: &[Entry], needle: &str, out: &mut String) -> bool {
        out.push_str(&format!("{{\"i\":{},\"f\":1,\"n\":{},\"c\":[", e.id, json_string(&e.title)));
        let mut any = false;
        for c in kids(items, e.id) {
            if c.folder {
                if needle.is_empty() || c.title.to_lowercase().contains(needle) {
                    if any {
                        out.push(',');
                    }
                    any = true;
                    emit_all(c, items, out);
                } else {
                    let mut sub = String::new();
                    if emit_filtered(c, items, needle, &mut sub) {
                        if any {
                            out.push(',');
                        }
                        any = true;
                        out.push_str(&sub);
                    }
                }
            } else if needle.is_empty() || c.title.to_lowercase().contains(needle) || c.url.to_lowercase().contains(needle) {
                if any {
                    out.push(',');
                }
                any = true;
                bookmark_json(c, out);
            }
        }
        out.push_str("]}");
        any
    }
    let mut out = String::from("[");
    let mut first = true;
    for e in kids(items, 0) {
        if e.folder {
            if needle.is_empty() || e.title.to_lowercase().contains(&needle) {
                if !first {
                    out.push(',');
                }
                first = false;
                emit_all(e, items, &mut out);
            } else {
                let mut sub = String::new();
                if emit_filtered(e, items, &needle, &mut sub) {
                    if !first {
                        out.push(',');
                    }
                    first = false;
                    out.push_str(&sub);
                }
            }
        } else if needle.is_empty() || e.title.to_lowercase().contains(&needle) || e.url.to_lowercase().contains(&needle) {
            if !first {
                out.push(',');
            }
            first = false;
            bookmark_json(e, &mut out);
        }
    }
    out.push(']');
    out
}

// ---- NETSCAPE bookmark file -------------------------------------------------

/// Parses a Chrome/Firefox bookmark export into root nodes. Anything that is
/// not `<DL>`/`<DT><A HREF>`/`<H3>` structure is skipped; entities in titles
/// and URLs are decoded.
pub fn parse_netscape(html: &str) -> Vec<Node> {
    let c: Vec<char> = html.chars().collect();
    let mut pos = 0;
    // Find the first <dl ...>.
    while pos < c.len() {
        if c[pos] == '<' {
            if let Some((name, _, end)) = peek_tag(&c, pos) {
                if name == "dl" {
                    pos = end;
                    return parse_dl(&c, &mut pos);
                }
                pos = end;
                continue;
            }
        }
        pos += 1;
    }
    Vec::new()
}

/// A tag read without consuming it: (lowercase name, raw attributes, index
/// just past '>'). "</x" comes back as name "/x".
fn peek_tag(c: &[char], pos: usize) -> Option<(String, String, usize)> {
    if c.get(pos) != Some(&'<') {
        return None;
    }
    let mut end = pos + 1;
    while end < c.len() && c[end] != '>' {
        end += 1;
    }
    if end >= c.len() {
        return None;
    }
    let inner: String = c[pos + 1..end].iter().collect();
    let inner = inner.trim_end_matches('/').trim_end();
    let name_len = inner.find(|ch: char| ch.is_whitespace()).unwrap_or(inner.len());
    let name = inner[..name_len].to_lowercase();
    let attrs = inner[name_len..].trim().to_owned();
    Some((name, attrs, end + 1))
}

/// Reads text until the closing tag `name`, decoding entities; consumes it.
fn read_text_to_close(c: &[char], pos: &mut usize, name: &str) -> String {
    let mut out = String::new();
    while *pos < c.len() {
        if c[*pos] == '<' {
            if let Some((tag, _, end)) = peek_tag(c, *pos) {
                if tag == format!("/{name}") {
                    *pos = end;
                    break;
                }
                *pos = end; // skip a nested tag
                continue;
            }
        }
        out.push(c[*pos]);
        *pos += 1;
    }
    decode_entities(out.trim())
}

/// The children of one `<dl>` level.
fn parse_dl(c: &[char], pos: &mut usize) -> Vec<Node> {
    let mut out = Vec::new();
    while *pos < c.len() {
        if c[*pos] != '<' {
            *pos += 1; // text between tags (whitespace, stray words)
            continue;
        }
        let Some((name, attrs, end)) = peek_tag(c, *pos) else { break };
        if name.starts_with('/') {
            *pos = end;
            if name == "/dl" {
                return out;
            }
            continue;
        }
        match name.as_str() {
            "a" => {
                *pos = end;
                let url = attr(&attrs, "href").unwrap_or_default();
                let title = read_text_to_close(c, pos, "a");
                out.push(Node { folder: false, title, url, children: Vec::new() });
            }
            "h3" => {
                *pos = end;
                let title = read_text_to_close(c, pos, "h3");
                // The folder's <dl> follows; anything else ends it (left for the outer loop).
                let mut children = Vec::new();
                loop {
                    while *pos < c.len() && c[*pos] != '<' {
                        *pos += 1;
                    }
                    if *pos >= c.len() {
                        break;
                    }
                    match peek_tag(c, *pos) {
                        Some((tag, _, tag_end)) if tag == "dl" => {
                            *pos = tag_end;
                            children = parse_dl(c, pos);
                            break;
                        }
                        Some((tag, _, _)) if tag.starts_with('/') => {
                            // </dl> of this level with an empty folder: leave it to the outer loop
                            break;
                        }
                        Some(_) => break, // a new entry: not consumed
                        None => break,
                    }
                }
                out.push(Node { folder: true, title, url: String::new(), children });
            }
            _ => {
                *pos = end; // dt, p, meta, comments, ...
            }
        }
    }
    out
}

/// `name="value"` or `name='value'` (case-insensitive name) from a tag's raw attributes.
fn attr(attrs: &str, want: &str) -> Option<String> {
    let a = attrs.to_lowercase();
    let w = want.to_lowercase();
    let mut from = 0;
    while let Some(at) = a[from..].find(&w) {
        let at = from + at;
        let before_ok = at == 0 || a.as_bytes()[at - 1].is_ascii_whitespace();
        let mut i = at + w.len();
        if before_ok && a[i..].starts_with('=') {
            i += 1;
            while i < a.len() && a.as_bytes()[i].is_ascii_whitespace() {
                i += 1;
            }
            if i < a.len() && (a.as_bytes()[i] == b'"' || a.as_bytes()[i] == b'\'') {
                let q = a.as_bytes()[i];
                if let Some(close) = a[i + 1..].find(q as char) {
                    return Some(decode_entities(&attrs[i + 1..i + 1 + close]));
                }
            }
        }
        from = at + w.len();
    }
    None
}

/// The HTML entities bookmark files use (plus numeric ones).
pub fn decode_entities(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    let mut rest = s;
    while let Some(at) = rest.find('&') {
        out.push_str(&rest[..at]);
        let after = &rest[at + 1..];
        let semi = after.find(';');
        let (entity, consumed) = match semi {
            Some(si) if si <= 10 => (&after[..si], si + 1),
            _ => {
                out.push('&');
                rest = after;
                continue;
            }
        };
        match entity {
            "amp" => out.push('&'),
            "lt" => out.push('<'),
            "gt" => out.push('>'),
            "quot" => out.push('"'),
            "apos" | "#39" => out.push('\''),
            "nbsp" => out.push('\u{a0}'),
            num if num.starts_with("#x") || num.starts_with("#X") => {
                if let Ok(n) = u32::from_str_radix(&num[2..], 16) {
                    out.push(char::from_u32(n).unwrap_or('\u{fffd}'));
                } else {
                    out.push('&');
                    out.push_str(entity);
                    out.push(';');
                }
            }
            num if num.starts_with('#') => {
                if let Ok(n) = num[1..].parse::<u32>() {
                    out.push(char::from_u32(n).unwrap_or('\u{fffd}'));
                } else {
                    out.push('&');
                    out.push_str(entity);
                    out.push(';');
                }
            }
            _ => {
                out.push('&');
                out.push_str(entity);
                out.push(';');
            }
        }
        rest = &after[consumed..];
    }
    out.push_str(rest);
    out
}

pub fn escape_html(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    for ch in s.chars() {
        match ch {
            '&' => out.push_str("&amp;"),
            '<' => out.push_str("&lt;"),
            '>' => out.push_str("&gt;"),
            '"' => out.push_str("&quot;"),
            c => out.push(c),
        }
    }
    out
}

/// The root's children as a NETSCAPE bookmark file, the format Chrome and
/// Firefox export (and import back).
pub fn export_html(items: &[Entry]) -> String {
    let mut out = String::from(
        "<!DOCTYPE NETSCAPE-Bookmark-file-1>\n\
         <!-- This is an automatically generated file.\n\
         It will be read and overwritten.\n\
         DO NOT EDIT! -->\n\
         <META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=UTF-8\">\n\
         <TITLE>Bookmarks</TITLE>\n\
         <H1>Bookmarks</H1>\n\
         <DL><p>\n",
    );
    write_nodes(items, 0, 1, &mut out);
    out.push_str("</DL><p>\n");
    out
}

fn write_nodes(items: &[Entry], parent: u64, depth: usize, out: &mut String) {
    let pad = "    ".repeat(depth);
    for e in items.iter().filter(|e| e.parent == parent) {
        if e.folder {
            out.push_str(&format!("{pad}<DT><H3>{}</H3>\n{pad}<DL><p>\n", escape_html(&e.title)));
            write_nodes(items, e.id, depth + 1, out);
            out.push_str(&format!("{pad}</DL><p>\n"));
        } else {
            out.push_str(&format!("{pad}<DT><A HREF=\"{}\">{}</A>\n", escape_html(&e.url), escape_html(&e.title)));
        }
    }
}


// ---- CSV bookmark file ------------------------------------------------------

/// RFC4180 quoting: wrap a field in quotes when it holds a comma, quote or
/// newline, doubling any quote inside.
fn csv_field(s: &str) -> String {
    if s.contains(',') || s.contains('"') || s.contains('\n') || s.contains('\r') {
        format!("\"{}\"", s.replace('"', "\"\""))
    } else {
        s.to_owned()
    }
}

/// The ancestor folder titles of `parent`, "/" joined (root is "").
fn folder_path(items: &[Entry], parent: u64) -> String {
    let mut names: Vec<&str> = Vec::new();
    let mut p = parent;
    while p != 0 {
        match items.iter().find(|e| e.id == p) {
            Some(e) => { names.push(&e.title); p = e.parent; }
            None => break,
        }
    }
    names.reverse();
    names.join("/")
}

/// The bookmarks as CSV (`folder,title,url`), one row per bookmark; folders
/// become the path. Spreadsheet-friendly and round-trips through parse_csv.
pub fn export_csv(items: &[Entry]) -> String {
    let mut out = String::from("folder,title,url\n");
    fn walk(items: &[Entry], parent: u64, out: &mut String) {
        for e in items.iter().filter(|e| e.parent == parent) {
            if e.folder {
                walk(items, e.id, out);
            } else {
                out.push_str(&format!("{},{},{}\n", csv_field(&folder_path(items, e.parent)), csv_field(&e.title), csv_field(&e.url)));
            }
        }
    }
    walk(items, 0, &mut out);
    out
}

/// One CSV record from `pos`: RFC4180 fields, ending at a line break or EOF.
fn csv_record(c: &[char], pos: &mut usize) -> Option<Vec<String>> {
    if *pos >= c.len() {
        return None;
    }
    let mut fields = Vec::new();
    let mut field = String::new();
    let mut quoted = false;
    loop {
        if *pos >= c.len() {
            fields.push(field);
            return Some(fields);
        }
        let ch = c[*pos];
        if quoted {
            if ch == '"' {
                if c.get(*pos + 1) == Some(&'"') { field.push('"'); *pos += 2; }
                else { quoted = false; *pos += 1; }
            } else { field.push(ch); *pos += 1; }
        } else if ch == '"' && field.is_empty() {
            quoted = true; *pos += 1;
        } else if ch == ',' {
            fields.push(std::mem::take(&mut field)); *pos += 1;
        } else if ch == '\n' || ch == '\r' {
            if ch == '\r' && c.get(*pos + 1) == Some(&'\n') { *pos += 1; }
            *pos += 1;
            fields.push(field);
            return Some(fields);
        } else {
            field.push(ch); *pos += 1;
        }
    }
}

/// Parse a CSV bookmark file: a header naming a url column (url/href/address)
/// plus optional title/name and folder/path columns. Folder paths rebuild the
/// tree; rows without a url are skipped.
pub fn parse_csv(text: &str) -> Vec<Node> {
    let c: Vec<char> = text.chars().collect();
    let mut pos = 0;
    let header = match csv_record(&c, &mut pos) { Some(h) => h, None => return Vec::new() };
    let lower: Vec<String> = header.iter().map(|h| h.trim().to_lowercase()).collect();
    let col = |names: &[&str]| -> Option<usize> {
        for n in names { if let Some(i) = lower.iter().position(|h| h == n) { return Some(i); } }
        None
    };
    let i_url = match col(&["url", "href", "address", "uri"]) { Some(i) => i, None => return Vec::new() };
    let i_title = col(&["title", "name"]).unwrap_or(usize::MAX);
    let i_folder = col(&["folder", "path", "category"]).unwrap_or(usize::MAX);
    let mut roots: Vec<Node> = Vec::new();
    while let Some(rec) = csv_record(&c, &mut pos) {
        if rec.iter().all(|f| f.trim().is_empty()) { continue; }
        let get = |i: usize| -> String { if i < rec.len() { rec[i].trim().to_owned() } else { String::new() } };
        let url = get(i_url);
        if url.is_empty() { continue; }
        let title = if i_title != usize::MAX { get(i_title) } else { String::new() };
        let path = if i_folder != usize::MAX { get(i_folder) } else { String::new() };
        let parts: Vec<&str> = path.split('/').filter(|s| !s.is_empty()).collect();
        let mut level = &mut roots;
        for part in parts {
            let idx = match level.iter().position(|n| n.folder && n.title == part) {
                Some(i) => i,
                None => { level.push(Node { folder: true, title: part.to_owned(), url: String::new(), children: Vec::new() }); level.len() - 1 }
            };
            level = &mut level[idx].children;
        }
        level.push(Node { folder: false, title, url, children: Vec::new() });
    }
    roots
}

// ---- JSON bookmark file -----------------------------------------------------

/// A minimal JSON value (the core keeps no serde dependency).
enum JVal {
    Str(String),
    Num(f64),
    Bool(bool),
    Null,
    Arr(Vec<JVal>),
    Obj(Vec<(String, JVal)>),
}

impl JVal {
    fn get(&self, key: &str) -> Option<&JVal> {
        if let JVal::Obj(pairs) = self { pairs.iter().find(|(k, _)| k == key).map(|(_, v)| v) } else { None }
    }
    fn as_str(&self) -> Option<&str> { if let JVal::Str(s) = self { Some(s) } else { None } }
    fn as_arr(&self) -> Option<&Vec<JVal>> { if let JVal::Arr(a) = self { Some(a) } else { None } }
}

struct JParser<'a> { c: &'a [char], pos: usize }

impl<'a> JParser<'a> {
    fn ws(&mut self) { while self.pos < self.c.len() && self.c[self.pos].is_whitespace() { self.pos += 1; } }
    fn value(&mut self) -> Option<JVal> {
        self.ws();
        match self.c.get(self.pos)? {
            '"' => self.string().map(JVal::Str),
            '{' => self.object(),
            '[' => self.array(),
            't' => self.lit("true", JVal::Bool(true)),
            'f' => self.lit("false", JVal::Bool(false)),
            'n' => self.lit("null", JVal::Null),
            _ => self.number(),
        }
    }
    fn lit(&mut self, word: &str, v: JVal) -> Option<JVal> {
        for ch in word.chars() { if self.c.get(self.pos) != Some(&ch) { return None; } self.pos += 1; }
        Some(v)
    }
    fn string(&mut self) -> Option<String> {
        if self.c.get(self.pos) != Some(&'"') { return None; }
        self.pos += 1;
        let mut out = String::new();
        while let Some(&ch) = self.c.get(self.pos) {
            self.pos += 1;
            match ch {
                '"' => return Some(out),
                '\\' => {
                    let e = *self.c.get(self.pos)?; self.pos += 1;
                    match e {
                        '"' => out.push('"'), '\\' => out.push('\\'), '/' => out.push('/'),
                        'b' => out.push('\u{8}'), 'f' => out.push('\u{c}'), 'n' => out.push('\n'),
                        'r' => out.push('\r'), 't' => out.push('\t'),
                        'u' => {
                            let mut n: u32 = 0;
                            for _ in 0..4 { let d = *self.c.get(self.pos)?; self.pos += 1; n = n * 16 + d.to_digit(16)?; }
                            if (0xD800..=0xDBFF).contains(&n) && self.c.get(self.pos) == Some(&'\\') && self.c.get(self.pos + 1) == Some(&'u') {
                                self.pos += 2;
                                let mut lo: u32 = 0;
                                for _ in 0..4 { let d = *self.c.get(self.pos)?; self.pos += 1; lo = lo * 16 + d.to_digit(16)?; }
                                let cp = 0x10000 + ((n - 0xD800) << 10) + (lo - 0xDC00);
                                out.push(char::from_u32(cp).unwrap_or('\u{fffd}'));
                            } else {
                                out.push(char::from_u32(n).unwrap_or('\u{fffd}'));
                            }
                        }
                        _ => return None,
                    }
                }
                _ => out.push(ch),
            }
        }
        None
    }
    fn number(&mut self) -> Option<JVal> {
        let start = self.pos;
        if self.c.get(self.pos) == Some(&'-') { self.pos += 1; }
        while let Some(&ch) = self.c.get(self.pos) {
            if ch.is_ascii_digit() || ch == '.' || ch == 'e' || ch == 'E' || ch == '+' || ch == '-' { self.pos += 1; } else { break; }
        }
        let s: String = self.c[start..self.pos].iter().collect();
        s.parse::<f64>().ok().map(JVal::Num)
    }
    fn array(&mut self) -> Option<JVal> {
        self.pos += 1;
        let mut out = Vec::new();
        self.ws();
        if self.c.get(self.pos) == Some(&']') { self.pos += 1; return Some(JVal::Arr(out)); }
        loop {
            out.push(self.value()?);
            self.ws();
            match self.c.get(self.pos)? {
                ',' => { self.pos += 1; }
                ']' => { self.pos += 1; return Some(JVal::Arr(out)); }
                _ => return None,
            }
        }
    }
    fn object(&mut self) -> Option<JVal> {
        self.pos += 1;
        let mut out = Vec::new();
        self.ws();
        if self.c.get(self.pos) == Some(&'}') { self.pos += 1; return Some(JVal::Obj(out)); }
        loop {
            self.ws();
            let key = self.string()?;
            self.ws();
            if self.c.get(self.pos) != Some(&':') { return None; }
            self.pos += 1;
            let val = self.value()?;
            out.push((key, val));
            self.ws();
            match self.c.get(self.pos)? {
                ',' => { self.pos += 1; }
                '}' => { self.pos += 1; return Some(JVal::Obj(out)); }
                _ => return None,
            }
        }
    }
}

/// One JSON object as a node: Fable shape (`n`/`u`/`f`/`c`) or Chrome backup
/// shape (`name`/`url`/`type`/`children`).
fn json_node(v: &JVal) -> Option<Node> {
    let title = v.get("n").and_then(|x| x.as_str())
        .or_else(|| v.get("name").and_then(|x| x.as_str()))
        .unwrap_or("").to_owned();
    let kids = v.get("c").or_else(|| v.get("children"));
    let folder = matches!(v.get("f"), Some(JVal::Num(n)) if *n != 0.0)
        || v.get("type").and_then(|x| x.as_str()) == Some("folder")
        || (kids.is_some() && v.get("u").is_none() && v.get("url").is_none());
    if folder {
        let children = kids.and_then(|x| x.as_arr()).map(|a| a.iter().filter_map(json_node).collect()).unwrap_or_default();
        Some(Node { folder: true, title, url: String::new(), children })
    } else {
        let url = v.get("u").and_then(|x| x.as_str())
            .or_else(|| v.get("url").and_then(|x| x.as_str()))
            .unwrap_or("").to_owned();
        if url.is_empty() { return None; }
        Some(Node { folder: false, title, url, children: Vec::new() })
    }
}

/// Parse a JSON bookmark file: a Fable export (`{roots:[...]}` or a bare
/// array) or a Chrome backup (`{roots:{bookmark_bar:{children:[...]},...}}`).
pub fn parse_json(text: &str) -> Vec<Node> {
    let c: Vec<char> = text.chars().collect();
    let mut p = JParser { c: &c, pos: 0 };
    let v = match p.value() { Some(v) => v, None => return Vec::new() };
    if let Some(a) = v.as_arr() {
        return a.iter().filter_map(json_node).collect();
    }
    if let Some(roots) = v.get("roots") {
        match roots {
            JVal::Arr(a) => return a.iter().filter_map(json_node).collect(),
            JVal::Obj(pairs) => {
                let mut out = Vec::new();
                for (_, folder) in pairs {
                    if let Some(kids) = folder.get("children").and_then(|x| x.as_arr()) {
                        out.extend(kids.iter().filter_map(json_node));
                    }
                }
                return out;
            }
            _ => {}
        }
    }
    json_node(&v).into_iter().collect()
}

/// The bookmarks as Fable JSON (`{format,version,roots:[...]}`), round-tripping
/// through parse_json; folders carry `f:1` and `c:[...]`.
pub fn export_json(items: &[Entry]) -> String {
    fn node_json(e: &Entry, items: &[Entry], out: &mut String) {
        if e.folder {
            out.push_str(&format!("{{\"n\":{},\"f\":1,\"c\":[", json_string(&e.title)));
            for (i, c) in items.iter().filter(|x| x.parent == e.id).enumerate() {
                if i > 0 { out.push(','); }
                node_json(c, items, out);
            }
            out.push_str("]}");
        } else {
            out.push_str(&format!("{{\"n\":{},\"u\":{}}}", json_string(&e.title), json_string(&e.url)));
        }
    }
    let mut out = String::from("{\"format\":\"fable-bookmarks\",\"version\":1,\"roots\":[");
    for (i, e) in items.iter().filter(|e| e.parent == 0).enumerate() {
        if i > 0 { out.push(','); }
        node_json(e, items, &mut out);
    }
    out.push_str("]}\n");
    out
}

/// Detect the format by content (not file name) and parse: JSON, NETSCAPE
/// HTML, or CSV. This is what import uses, so every shell reads all three.
pub fn parse_any(text: &str) -> Vec<Node> {
    let t = text.trim_start_matches('\u{feff}').trim_start();
    if t.starts_with('{') || t.starts_with('[') {
        return parse_json(t);
    }
    let lower = t.to_lowercase();
    if lower.contains("<dl") || lower.contains("<!doctype netscape") || lower.contains("<h3") || lower.contains("<a ") {
        return parse_netscape(t);
    }
    if lower.lines().next().map(|l| l.contains("url")).unwrap_or(false) {
        return parse_csv(t);
    }
    let n = parse_netscape(t);
    if !n.is_empty() { return n; }
    parse_csv(t)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn entry(id: u64, folder: bool, parent: u64, title: &str, url: &str) -> Entry {
        Entry { id, folder, parent, title: title.to_owned(), url: url.to_owned() }
    }

    const CHROME: &str = r##"<!DOCTYPE NETSCAPE-Bookmark-file-1>
<!-- This is an automatically generated file. -->
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>Bookmarks</TITLE>
<H1>Bookmarks</H1>
<DL><p>
    <DT><A HREF="https://example.com/" ADD_DATE="1700000000">Example &amp; Co</A>
    <DT><H3 ADD_DATE="1700000001" PERSONAL_TOOLBAR_FOLDER="true">Toolbar</H3>
    <DL><p>
        <DT><A HREF="https://a.example/x?q=1&lt;2">A &lt;page&gt;</A>
        <DT><H3>Sub &#x1F600;</H3>
        <DL><p>
            <DT><A HREF='https://b.example/'>B</A>
        </DL><p>
    </DL><p>
    <DT><A HREF="javascript:alert(1)">not imported</A>
</DL><p>
"##;

    #[test]
    fn parses_chrome_and_firefox_files() {
        let roots = parse_netscape(CHROME);
        assert_eq!(roots.len(), 3);
        assert_eq!(roots[0].url, "https://example.com/");
        assert_eq!(roots[0].title, "Example & Co");
        assert!(!roots[0].folder);
        assert!(roots[1].folder);
        assert_eq!(roots[1].title, "Toolbar");
        assert_eq!(roots[1].children.len(), 2);
        assert_eq!(roots[1].children[0].url, "https://a.example/x?q=1<2");
        assert_eq!(roots[1].children[0].title, "A <page>");
        assert!(roots[1].children[1].folder);
        assert_eq!(roots[1].children[1].title, "Sub \u{1f600}");
        assert_eq!(roots[1].children[1].children[0].url, "https://b.example/");
        assert_eq!(roots[2].url, "javascript:alert(1)");

        // Firefox shape: lowercase tags, no <p>, extra whitespace.
        let ff = "<dl><dt><a href=\"https://ff.example/\">FF</a><dt><h3>Dir</h3><dl><dt><a href=\"https://ff.example/2\">2</a></dl></dl>";
        let roots = parse_netscape(ff);
        assert_eq!(roots.len(), 2);
        assert_eq!(roots[0].title, "FF");
        assert_eq!(roots[1].children[0].url, "https://ff.example/2");
        assert!(parse_netscape("").is_empty());
        assert_eq!(parse_netscape("<html><body>no list</body></html>").len(), 0);
    }

    #[test]
    fn export_import_round_trip() {
        let items = vec![
            entry(1, false, 0, "Example & <Co>", "https://example.com/?a=1&b=2"),
            entry(2, true, 0, "Dir \"quoted\"", ""),
            entry(3, false, 2, "A", "https://a.example/"),
            entry(4, true, 2, "Sub", ""),
            entry(5, false, 4, "B", "https://b.example/"),
        ];
        let html = export_html(&items);
        assert!(html.starts_with("<!DOCTYPE NETSCAPE-Bookmark-file-1>"));
        assert!(html.contains("HREF=\"https://example.com/?a=1&amp;b=2\""));
        assert!(html.contains("Example &amp; &lt;Co&gt;"));
        let roots = parse_netscape(&html);
        assert_eq!(roots.len(), 2);
        assert_eq!(roots[0].url, "https://example.com/?a=1&b=2");
        assert_eq!(roots[0].title, "Example & <Co>");
        assert_eq!(roots[1].title, "Dir \"quoted\"");
        assert_eq!(roots[1].children.len(), 2);
        assert_eq!(roots[1].children[1].children[0].url, "https://b.example/");
    }

    #[test]
    fn tree_json_nests_and_filters() {
        let items = vec![
            entry(1, false, 0, "Example", "https://example.com/"),
            entry(2, true, 0, "News", ""),
            entry(3, false, 2, "Paper", "https://paper.example/"),
            entry(4, true, 2, "Old", ""),
            entry(5, false, 4, "Archive", "https://archive.example/"),
        ];
        assert_eq!(tree_json(&items, ""),
            "[{\"i\":1,\"u\":\"https://example.com/\",\"n\":\"Example\"},\
              {\"i\":2,\"f\":1,\"n\":\"News\",\"c\":[\
                {\"i\":3,\"u\":\"https://paper.example/\",\"n\":\"Paper\"},\
                {\"i\":4,\"f\":1,\"n\":\"Old\",\"c\":[{\"i\":5,\"u\":\"https://archive.example/\",\"n\":\"Archive\"}]}]}]");
        // a URL match keeps the folder chain
        assert_eq!(tree_json(&items, "ARCHIVE.example"),
            "[{\"i\":2,\"f\":1,\"n\":\"News\",\"c\":[{\"i\":4,\"f\":1,\"n\":\"Old\",\"c\":[{\"i\":5,\"u\":\"https://archive.example/\",\"n\":\"Archive\"}]}]}]");
        // a folder name match keeps its whole subtree
        assert_eq!(tree_json(&items, "old").matches("\"i\":").count(), 3); // the News chain plus Old and Archive
        assert_eq!(tree_json(&items, "nothing"), "[]");
        assert_eq!(tree_json(&[], ""), "[]");
    }

    #[test]
    fn entities_decode() {
        assert_eq!(decode_entities("a &amp; b &lt;c&gt; &quot;d&quot; &#65;&#x42; &nbsp;e &unknown; &"), "a & b <c> \"d\" AB \u{a0}e &unknown; &");
    }

    #[test]
    fn csv_round_trip_and_folders() {
        let items = vec![
            entry(1, false, 0, "Root", "https://root.example/"),
            entry(2, true, 0, "News", ""),
            entry(3, false, 2, "Paper, A", "https://paper.example/?x=1&y=2"),
            entry(4, true, 2, "Sub \"q\"", ""),
            entry(5, false, 4, "Deep", "https://deep.example/"),
        ];
        let csv = export_csv(&items);
        assert!(csv.starts_with("folder,title,url\n"));
        assert!(csv.contains("\"Paper, A\""));
        assert!(csv.contains("\"News/Sub \"\"q\"\"\""));
        let roots = parse_csv(&csv);
        assert_eq!(roots.len(), 2);
        assert_eq!(roots[0].url, "https://root.example/");
        assert!(roots[1].folder);
        assert_eq!(roots[1].title, "News");
        assert_eq!(roots[1].children[0].title, "Paper, A");
        assert_eq!(roots[1].children[0].url, "https://paper.example/?x=1&y=2");
        assert_eq!(roots[1].children[1].title, "Sub \"q\"");
        assert_eq!(roots[1].children[1].children[0].url, "https://deep.example/");
        let alt = "name,url\nA,https://a.example/\nB,https://b.example/\n";
        let r = parse_csv(alt);
        assert_eq!(r.len(), 2);
        assert_eq!(r[0].title, "A");
        assert!(parse_csv("no,url,header\nx,https://x.example/\n").len() == 1);
        assert!(parse_csv("title\nnothing\n").is_empty());
    }

    #[test]
    fn json_round_trip_and_chrome() {
        let items = vec![
            entry(1, false, 0, "Example & <Co>", "https://example.com/?a=1&b=2"),
            entry(2, true, 0, "Dir", ""),
            entry(3, false, 2, "A", "https://a.example/"),
            entry(4, true, 2, "Sub", ""),
            entry(5, false, 4, "B \u{1f600}", "https://b.example/"),
        ];
        let json = export_json(&items);
        assert!(json.starts_with("{\"format\":\"fable-bookmarks\""));
        let roots = parse_json(&json);
        assert_eq!(roots.len(), 2);
        assert_eq!(roots[0].title, "Example & <Co>");
        assert_eq!(roots[0].url, "https://example.com/?a=1&b=2");
        assert_eq!(roots[1].children[1].children[0].title, "B \u{1f600}");
        let chrome = r#"{"roots":{"bookmark_bar":{"children":[{"type":"url","name":"C","url":"https://c.example/"},{"type":"folder","name":"F","children":[{"type":"url","name":"D","url":"https://d.example/"}]}]},"other":{"children":[{"type":"url","name":"E","url":"https://e.example/"}]}}}"#;
        let r = parse_json(chrome);
        assert_eq!(r.len(), 3);
        assert_eq!(r[0].url, "https://c.example/");
        assert!(r[1].folder);
        assert_eq!(r[1].children[0].url, "https://d.example/");
        assert_eq!(r[2].url, "https://e.example/");
        let esc = r#"[{"n":"a\"b\\c\n\u0041\ud83d\ude00","u":"https://x.example/"}]"#;
        let r = parse_json(esc);
        assert_eq!(r[0].title, "a\"b\\c\nA\u{1f600}");
        assert!(parse_json("not json").is_empty());
        assert!(parse_json("").is_empty());
    }

    #[test]
    fn parse_any_detects_format() {
        let html = "<!DOCTYPE NETSCAPE-Bookmark-file-1>\n<DL><p><DT><A HREF=\"https://h.example/\">H</A></DL><p>";
        let json = "{\"roots\":[{\"n\":\"J\",\"u\":\"https://j.example/\"}]}";
        let csv = "folder,title,url\n,J,https://j.example/\n";
        assert_eq!(parse_any(html)[0].url, "https://h.example/");
        assert_eq!(parse_any(json)[0].url, "https://j.example/");
        assert_eq!(parse_any(csv)[0].url, "https://j.example/");
        assert_eq!(parse_any("\u{feff}" + json)[0].url, "https://j.example/");
        assert!(parse_any("").is_empty());
    }

}
