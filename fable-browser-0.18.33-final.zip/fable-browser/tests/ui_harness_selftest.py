#!/usr/bin/env python3
"""The UI harnesses must fail when a page check fails: before 0.18.7 they
always exited 0, so a failing check could only be seen by reading the output.
Runs each harness that can run here against tests/harness/ and checks its
exit code, then checks tests/ui_test.py's verdict on harness output.
Skips an engine that is missing (exit 0), unless FABLE_REQUIRE_UI=1."""
import os, subprocess, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import ui_test

CASES = [  # page, script, expected exit code
    ("tests/harness/page.html", "tests/harness/pass.js", 0),
    ("tests/harness/page.html", "tests/harness/fail_result.js", 1),
    ("tests/harness/page.html", "tests/harness/fail_async.js", 1),
    ("tests/harness/page.html", "tests/harness/throws.js", 1),
    ("tests/harness/page.html#throw", "tests/harness/pass.js", 1),
]

def main():
    os.chdir(os.path.dirname(HERE))
    failures = 0
    # The verdict on output alone: FAIL lines, a bad exit code, too few checks.
    for code, output, minimum, want in [(0, "js result: ok a\nok b", 2, True), (0, "js result: ok a\nFAIL b", 1, False),
                                        (1, "js result: ok a", 1, False), (0, "js result: started", 1, False),
                                        (0, "ok a", 2, False), (0, "", 0, True)]:
        got = ui_test.verdict(code, output, minimum)[0]
        if got != want:
            print("FAIL verdict(%d, %r, %d) = %s" % (code, output, minimum, got)); failures += 1
    engines = [e for e, have in (("webkit", ui_test.have_webkit()), ("chrome", ui_test.have_chrome())) if have]
    for engine in engines:
        for page, script, want in CASES:
            cmd = ui_test.command(engine, page, ["--js", script, "--wait", "0.5"], "/tmp/fable-harness-selftest.png")
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
            ok = r.returncode == want
            print("%-4s %-6s %s %s -> exit %d (want %d)" % ("ok" if ok else "FAIL", engine, page, script, r.returncode, want))
            if not ok:
                failures += 1
                print(r.stdout[-2000:], r.stderr[-2000:])
    if not engines:
        print("ui_harness_selftest: no WebKitGTK or Chrome here, harness runs skipped")
        if os.environ.get("FABLE_REQUIRE_UI") == "1": return 1
    print("ui_harness_selftest: %s" % ("%d failure(s)" % failures if failures else "all checks passed"))
    return 1 if failures else 0

if __name__ == "__main__":
    sys.exit(main())
