/*
 * FableCore - Qt/QML bridge for the Fable browser Rust core.
 *
 * The Rust core (fable_core) exposes a plain C ABI in core/include/fable_core.h.
 * This singleton wraps the calls that a QML shell needs and exposes them as
 * Q_INVOKABLE slots, so the Silica UI can drive all the shared logic without
 * knowing about C strings or manual memory management.
 *
 * Ownership: every fable_* function returning char* is copied into a QString
 * and immediately released with fable_string_free().
 */
#ifndef FABLECORE_H
#define FABLECORE_H

#include <QObject>
#include <QString>
#include <QStringList>
#include <QVariant>

#include <cstddef>
#include <cstdint>

class FableCore : public QObject
{
    Q_OBJECT
    // Read once by QML to build state.caps so unsupported features stay hidden.
    Q_PROPERTY(QString version READ version CONSTANT)
    Q_PROPERTY(QString language READ language NOTIFY languageChanged)
    Q_PROPERTY(bool nativeHash READ nativeHash CONSTANT)

public:
    static FableCore *instance(QObject *parent = nullptr);

    QString version() const;
    QString language() const;
    bool nativeHash() const;

public slots:
    // --- internationalisation ------------------------------------------------
    QString tr(const QString &key) const;

    // --- address bar ---------------------------------------------------------
    // Turns typed text into a URL/search URL; empty string for blank input.
    QString resolve(const QString &input) const;
    bool setSearchTemplate(const QString &url);

    // --- bundled, localised pages and scripts --------------------------------
    QString readerScript() const;
    QString logoUri() const;
    // theme://name typed by the user: 1 the skin is now on (restyle, say nothing),
    // 0 a name that is no skin (nothing changes); load nothing for either.
    // -1 any other address, loaded as usual.
    int themeApply(const QString &url);
    QString themeCurrent() const;
    QString themePalette() const;   // the skin's colours, JSON (core/src/theme.rs)
    QString panelPage() const;
    QString newTabPage(int incognito, const QString &iconsJson) const;
    QString sniffJs() const;
    QString adblockScript() const;
    QString contentRules() const;
    QString adsContentRules() const;

    // --- blocking ------------------------------------------------------------
    bool shouldBlock(const QString &requestUrl, const QString &pageUrl) const;
    bool blockExternalApp(const QString &url) const;
    void setBlocking(bool trackers, bool ads);
    quint64 blockedCount() const;
    quint64 adsBlockedCount() const;

    // --- panel bridge (shared with ui/panel.html) ----------------------------
    // Returns a null QString when the answer belongs to the shell itself.
    QString panelQuery(const QString &name, const QString &arg, quint32 tab) const;
    bool panelSettingAllowed(const QString &key, const QString &value) const;
    QString settingsJson() const;
    QString panelReply(quint32 id, const QString &answer) const;
    QString jsonString(const QString &s) const;
    QString parseIpReply(const QString &body, const QString &source) const;

    // --- persistent store: settings / history --------------------------------
    void storeOpen(const QString &dir);
    QString settingGet(const QString &key) const;
    void settingSet(const QString &key, const QString &value);
    void historyAdd(const QString &url, const QString &title, quint64 timeMs);
    QString historyJson(const QString &query, int limit) const;
    void historyDelete(const QString &url, quint64 timeMs);
    bool historyClear();

    // --- bookmarks -----------------------------------------------------------
    quint64 bookmarkAdd(const QString &url, const QString &title, quint64 parent);
    quint64 bookmarkFolder(const QString &name, quint64 parent);
    void bookmarkRemove(quint64 id);
    void bookmarkMove(quint64 id, quint64 parent, int index);
    void bookmarkRename(quint64 id, const QString &title);
    quint64 bookmarkId(const QString &url) const;
    QString bookmarksJson(const QString &query) const;
    int bookmarkImport(const QString &html);
    QString bookmarkExport() const;
    QString bookmarkExportFmt(const QString &fmt) const;

    // --- session snapshot ----------------------------------------------------
    bool sessionSave(const QString &json);
    QString sessionJson() const;
    void sessionClear();
    int sessionCount() const;
    QString sessionUrl(int i) const;
    QString sessionTitle(int i) const;
    int sessionActive() const;

    // --- resource sniffing ---------------------------------------------------
    bool sniffNote(quint32 tab, const QString &url, const QString &hint);
    int sniffCount(quint32 tab) const;
    int sniffNoteScan(quint32 tab, const QString &json);
    QString sniffJson(quint32 tab) const;
    void sniffClear(quint32 tab);

    // --- ad list -------------------------------------------------------------
    bool adListFile(const QString &profileDir, const QString &file);
    bool adListAsset(const QByteArray &data);
    QString adListText() const;
    bool adsUpdateDue() const;
    QString adsUpdateSources() const;
    int adsUpdateApply(const QByteArray &data);
    quint64 adsDomainCount() const;

    // --- metadata ------------------------------------------------------------
    QString deviceInfo(const QString &extras) const;
    QString systemInfo(const QString &extras) const;

    // --- downloads -----------------------------------------------------------
    quint32 downloadBegin(const QString &name);
    void downloadFinish(quint32 id, bool success);

    // --- QR code -------------------------------------------------------------
    // The text in a QR code in an image file; empty when it cannot be read.
    QString qrDecodeImage(const QString &path) const;
    // The text in a QR code in an 8-bit luma plane; empty when it cannot be
    // read. One decode for an image file and for camera frames: the plane must
    // stay valid for the call. Width and height each at most 4096, and at most
    // 4 MP in all (the core's limits).
    static QString qrDecodeLuma(const uint8_t *luma, size_t len,
                                size_t width, size_t height,
                                size_t rowStride, size_t pixelStride);

    // --- tabs / sleep policy -------------------------------------------------
    // The FableTabs handle must stay on one thread; the QML GUI thread owns it.
    quint64 tabsNew();
    void tabsFree(quint64 handle);
    void tabsSetSleepAfterMs(quint64 handle, quint64 ms);
    quint32 tabsOpen(quint64 handle, quint64 nowMs);
    bool tabsActivate(quint64 handle, quint32 id, quint64 nowMs);
    bool tabsTouch(quint64 handle, quint32 id, quint64 nowMs);
    bool tabsClose(quint64 handle, quint32 id);
    int tabsCount(quint64 handle) const;
    bool tabsIsAsleep(quint64 handle, quint32 id) const;
    // Returns a QVariantList of tab ids that should go to sleep now.
    QVariantList tabsCollectSleepers(quint64 handle, quint64 nowMs);

    // --- locale --------------------------------------------------------------
    void setSystemLocale(const QString &tag);

signals:
    void languageChanged();

private:
    explicit FableCore(QObject *parent = nullptr);
    QString languageValue() const;
};

#endif // FABLECORE_H
