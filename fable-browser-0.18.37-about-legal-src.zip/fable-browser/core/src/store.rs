//! User data kept between runs: settings (opaque key/value strings), the
//! browsing history, the bookmarks and the last session's tabs. Plain
//! tab-separated files (and one JSON file for the session) in a directory
//! chosen by the shell; without a directory everything still works, in
//! memory only.
//!
//! `Store` is an ordinary value (tested directly); the shells go through the
//! process-wide instance behind the free functions at the bottom, which also
//! apply the settings the core itself acts on.

pub mod downloads;

use crate::bookmarks::{self, Entry};
use std::collections::BTreeMap;
use std::fs::{self, OpenOptions};
use std::io::Write;
use std::path::PathBuf;
use std::sync::{Mutex, MutexGuard};

/// Oldest visits beyond this are dropped.
const HISTORY_CAP: usize = 5000;
/// How far the list may overshoot the cap before it is trimmed and rewritten.
const HISTORY_SLACK: usize = 500;
/// Bookmarks and folders beyond this are refused (a corrupt file stays loadable).
const BOOKMARK_CAP: usize = 10_000;
/// Longest bookmark URL / title.
const BOOKMARK_URL_MAX: usize = 2048;
const BOOKMARK_TITLE_MAX: usize = 256;
/// Largest bookmark file read. Chrome's and Firefox's HTML exports carry every
/// site's icon inline, a few KB per bookmark, so a real one runs to megabytes
/// (the icons are dropped before parsing).
pub const BOOKMARK_FILE_MAX: usize = 32 * 1024 * 1024;
/// The session snapshot: {"a":active index,"t":[{"u":url,"n":title}, ...]}.
const SESSION_MAX_LEN: usize = 256 * 1024;
const SESSION_MAX_TABS: usize = 500;

struct Visit {
    time_ms: u64,
    url: String,
    title: String,
}

pub struct Store {
    downloads: downloads::Downloads,
    dir: Option<PathBuf>,
    settings: BTreeMap<String, String>,
    history: Vec<Visit>,   // oldest first
    bookmarks: Vec<Entry>, // flat; the order among same-parent entries is the sibling order
    next_bookmark_id: u64,
    session: String,       // the raw session JSON, "" when none
}

impl Store {
    pub const fn in_memory() -> Self {
        Store { downloads: downloads::Downloads::new(), dir: None, settings: BTreeMap::new(), history: Vec::new(), bookmarks: Vec::new(), next_bookmark_id: 1, session: String::new() }
    }

    /// Load (or start) the store in `dir`. Unreadable files count as empty.
    pub fn open(dir: impl Into<PathBuf>) -> Self {
        let dir = dir.into();
        let _ = fs::create_dir_all(&dir);
        let mut store = Store { dir: Some(dir), ..Self::in_memory() };

        for line in store.read("settings.tsv").lines() {
            if let Some((key, value)) = line.split_once('\t') {
                store.settings.insert(unescape(key), unescape(value));
            }
        }

        let text = store.read("history.tsv");
        let mut lines = 0;
        for line in text.lines() {
            lines += 1;
            let mut fields = line.splitn(3, '\t');
            let (Some(time), Some(url)) = (fields.next(), fields.next()) else { continue };
            let Ok(time_ms) = time.parse::<u64>() else { continue };
            let visit = Visit { time_ms, url: unescape(url), title: unescape(fields.next().unwrap_or("")) };
            match store.history.last_mut() {
                Some(last) if !time.starts_with('+') && last.url == visit.url => *last = visit,
                _ => store.history.push(visit),
            }
        }
        let over = store.history.len().saturating_sub(HISTORY_CAP);
        store.history.drain(..over);
        if lines != store.history.len() {
            store.rewrite_history(); // compact what the append-only log accumulated
        }

        for line in store.read("bookmarks.tsv").lines() {
            let mut fields = line.splitn(5, '\t');
            let (Some(id), Some(folder), Some(parent), Some(title), Some(url)) =
                (fields.next(), fields.next(), fields.next(), fields.next(), fields.next())
            else {
                continue;
            };
            let (Ok(id), Ok(parent)) = (id.parse::<u64>(), parent.parse::<u64>()) else { continue };
            if store.bookmarks.iter().any(|e| e.id == id) {
                continue; // a duplicate id would corrupt moves and deletes
            }
            store.bookmarks.push(Entry { id, folder: folder == "1", parent, title: unescape(title), url: unescape(url) });
            store.next_bookmark_id = store.next_bookmark_id.max(id + 1);
        }

        store.session = store.read("session.json");
        if !session_valid(&store.session) {
            store.session.clear();
        }
        store
    }

    // ---- settings ----------------------------------------------------------

    /// "" when unset.
    pub fn get(&self, key: &str) -> &str {
        self.settings.get(key).map_or("", String::as_str)
    }

    /// Setting a key to "" removes it.
    pub fn set(&mut self, key: &str, value: &str) {
        if key.is_empty() {
            return;
        }
        if value.is_empty() {
            self.settings.remove(key);
        } else {
            self.settings.insert(key.to_owned(), value.to_owned());
        }
        if key == "restore_tabs" && value == "0" {
            self.session_clear();   // switched off: the tabs of the last run are not kept either
        }
        let mut text = String::new();
        for (k, v) in &self.settings {
            text.push_str(&format!("{}\t{}\n", escape(k), escape(v)));
        }
        let _ = self.write_atomic("settings.tsv", &text);
    }

    // ---- history -----------------------------------------------------------

    /// Record a visit. A repeat of the most recent URL updates that visit
    /// (pages report their title after they start loading) instead of adding one.
    pub fn history_add(&mut self, url: &str, title: &str, time_ms: u64) {
        let url = url.trim();
        if url.is_empty() {
            return;
        }
        match self.history.last_mut() {
            Some(last) if last.url == url => {
                last.time_ms = time_ms;
                if !title.trim().is_empty() {
                    last.title = title.trim().to_owned();
                }
            }
            _ => self.history.push(Visit { time_ms, url: url.to_owned(), title: title.trim().to_owned() }),
        }
        if self.history.len() > HISTORY_CAP + HISTORY_SLACK {
            let over = self.history.len() - HISTORY_CAP;
            self.history.drain(..over);
            self.rewrite_history();
        } else if let (Some(path), Some(last)) = (self.path("history.tsv"), self.history.last()) {
            if let Ok(mut file) = OpenOptions::new().create(true).append(true).open(path) {
                let _ = file.write_all(line(last).as_bytes());
            }
        }
    }

    /// Newest first, as a JSON array of `{"t": ms, "u": url, "n": title}`.
    /// `query` filters by case-insensitive substring of URL or title.
    pub fn history_json(&self, query: &str, limit: usize) -> String {
        let needle = query.trim().to_lowercase();
        let mut out = String::from("[");
        let matching = self
            .history
            .iter()
            .rev()
            .filter(|v| needle.is_empty() || v.url.to_lowercase().contains(&needle) || v.title.to_lowercase().contains(&needle))
            .take(limit);
        for (i, v) in matching.enumerate() {
            if i > 0 {
                out.push(',');
            }
            out.push_str(&format!("{{\"t\":{},\"u\":{},\"n\":{}}}", v.time_ms, json_string(&v.url), json_string(&v.title)));
        }
        out.push(']');
        out
    }

    /// Remove the visit with this URL and time; `time_ms == 0` removes every visit to the URL.
    pub fn history_delete(&mut self, url: &str, time_ms: u64) {
        let before = self.history.len();
        self.history.retain(|v| !(v.url == url && (time_ms == 0 || v.time_ms == time_ms)));
        if self.history.len() != before {
            self.rewrite_history();
        }
    }

    pub fn history_clear(&mut self) -> bool {
        if self.write_atomic("history.tsv", "").is_err() {
            return false;
        }
        self.history.clear();
        true
    }

    pub fn history_len(&self) -> usize {
        self.history.len()
    }

    // ---- bookmarks ---------------------------------------------------------

    fn valid_bookmark_url(url: &str) -> bool {
        !url.is_empty() && url.len() <= BOOKMARK_URL_MAX && !url.chars().any(|c| c.is_control())
    }

    fn valid_bookmark_title(title: &str) -> bool {
        !title.is_empty() && title.len() <= BOOKMARK_TITLE_MAX && !title.chars().any(|c| c.is_control())
    }

    /// The folder `parent` must exist, else the root (0) is used.
    fn folder_parent(&self, parent: u64) -> u64 {
        if parent != 0 && self.bookmarks.iter().any(|e| e.id == parent && e.folder) {
            parent
        } else {
            0
        }
    }

    /// Add a bookmark (the star). An existing bookmark for the same URL is
    /// kept where it is and only gets the new title; returns its id. 0 when
    /// the URL is unusable.
    pub fn bookmark_add(&mut self, url: &str, title: &str, parent: u64) -> u64 {
        let url = url.trim();
        if !Self::valid_bookmark_url(url) || self.bookmarks.len() >= BOOKMARK_CAP {
            return 0;
        }
        if let Some(pos) = self.bookmarks.iter().position(|e| !e.folder && e.url == url) {
            let title = title.trim();
            let changed = Self::valid_bookmark_title(title) && self.bookmarks[pos].title != title;
            if changed {
                self.bookmarks[pos].title = title.to_owned();
            }
            let id = self.bookmarks[pos].id;
            if changed {
                self.rewrite_bookmarks();
            }
            return id;
        }
        let id = self.next_bookmark_id;
        self.next_bookmark_id += 1;
        let title = title.trim();
        let title = if Self::valid_bookmark_title(title) { title.to_owned() } else { host_of(url) };
        self.bookmarks.push(Entry { id, folder: false, parent: self.folder_parent(parent), title, url: url.to_owned() });
        self.rewrite_bookmarks();
        id
    }

    /// A new folder; 0 when the name is unusable.
    pub fn bookmark_folder(&mut self, name: &str, parent: u64) -> u64 {
        let name = name.trim();
        if !Self::valid_bookmark_title(name) || self.bookmarks.len() >= BOOKMARK_CAP {
            return 0;
        }
        let id = self.next_bookmark_id;
        self.next_bookmark_id += 1;
        self.bookmarks.push(Entry { id, folder: true, parent: self.folder_parent(parent), title: name.to_owned(), url: String::new() });
        self.rewrite_bookmarks();
        id
    }

    /// Remove an entry and everything inside a folder.
    pub fn bookmark_remove(&mut self, id: u64) {
        if id == 0 || !self.bookmarks.iter().any(|e| e.id == id) {
            return;
        }
        let mut doomed = vec![id];
        loop {
            let n = doomed.len();
            for e in &self.bookmarks {
                if doomed.contains(&e.parent) && !doomed.contains(&e.id) {
                    doomed.push(e.id);
                }
            }
            if doomed.len() == n {
                break;
            }
        }
        let before = self.bookmarks.len();
        self.bookmarks.retain(|e| !doomed.contains(&e.id));
        if self.bookmarks.len() != before {
            self.rewrite_bookmarks();
        }
    }

    /// Move an entry to `parent` (0 = root), at sibling position `index`
    /// (past the end = last). A folder cannot move into itself or its own
    /// descendants.
    pub fn bookmark_move(&mut self, id: u64, parent: u64, index: usize) {
        if id == 0 || parent == id {
            return;
        }
        let Some(pos) = self.bookmarks.iter().position(|e| e.id == id) else { return };
        if parent != 0 && !self.bookmarks.iter().any(|e| e.id == parent && e.folder) {
            return;
        }
        // descendants of id
        let mut doomed = vec![id];
        loop {
            let n = doomed.len();
            for e in &self.bookmarks {
                if doomed.contains(&e.parent) && !doomed.contains(&e.id) {
                    doomed.push(e.id);
                }
            }
            if doomed.len() == n {
                break;
            }
        }
        if doomed.contains(&parent) {
            return;
        }
        let mut entry = self.bookmarks.remove(pos);
        entry.parent = parent;
        let mut insert_at = self.bookmarks.len();
        let mut seen = 0;
        for (i, e) in self.bookmarks.iter().enumerate() {
            if e.parent == parent {
                if seen == index {
                    insert_at = i;
                    break;
                }
                seen += 1;
                insert_at = i + 1; // past the last child when index runs out
            }
        }
        if insert_at == self.bookmarks.len() {
            if let Some(pi) = self.bookmarks.iter().position(|e| e.id == parent) {
                insert_at = pi + 1; // a folder with no children yet: right after it
            }
        }
        self.bookmarks.insert(insert_at.min(self.bookmarks.len()), entry);
        self.rewrite_bookmarks();
    }

    pub fn bookmark_rename(&mut self, id: u64, title: &str) {
        let title = title.trim();
        if !Self::valid_bookmark_title(title) {
            return;
        }
        if let Some(e) = self.bookmarks.iter_mut().find(|e| e.id == id) {
            if e.title != title {
                e.title = title.to_owned();
                self.rewrite_bookmarks();
            }
        }
    }

    /// The id of the bookmark for `url`, 0 when it is not bookmarked.
    pub fn bookmark_id(&self, url: &str) -> u64 {
        let url = url.trim();
        self.bookmarks.iter().find(|e| !e.folder && e.url == url).map_or(0, |e| e.id)
    }

    /// The bookmark tree as nested JSON (see bookmarks::tree_json).
    pub fn bookmarks_json(&self, query: &str) -> String {
        bookmarks::tree_json(&self.bookmarks, query)
    }

    /// Import a bookmark file (NETSCAPE HTML, JSON or CSV, auto-detected) into the root.
    /// Returns how many bookmarks were added; URLs already bookmarked and
    /// unusable entries are skipped.
    pub fn bookmark_import(&mut self, text: &str) -> usize {
        if text.len() > BOOKMARK_FILE_MAX {
            return 0;
        }
        let nodes = bookmarks::parse_any(text);
        let (before, mut count) = (self.bookmarks.len(), 0);
        self.import_nodes(nodes, 0, &mut count);
        if self.bookmarks.len() != before {
            self.rewrite_bookmarks();
        }
        count
    }

    /// Imports `nodes` into the folder `parent` (0, the root, or one made by
    /// this import); true when anything was added there. Only web addresses
    /// come in (bookmarklets, `chrome://`, `place:` and the like would not open
    /// here), and an address already bookmarked is skipped. A folder goes into
    /// the folder of the same name already in that place, so importing a file
    /// twice, or one exported from here and back, makes no second copy; a
    /// folder that ends up with nothing new in it is not made at all, unless it
    /// was empty in the file too.
    fn import_nodes(&mut self, nodes: Vec<bookmarks::Node>, parent: u64, count: &mut usize) -> bool {
        let mut added = false;
        for node in nodes {
            if self.bookmarks.len() >= BOOKMARK_CAP {
                break;
            }
            if node.folder {
                let name = import_title(&node.title).unwrap_or_else(|| "Folder".to_owned());
                if let Some(id) = self.bookmarks.iter().find(|e| e.folder && e.parent == parent && e.title == name).map(|e| e.id) {
                    added |= self.import_nodes(node.children, id, count);
                    continue;
                }
                let id = self.next_bookmark_id;
                self.next_bookmark_id += 1;
                let at = self.bookmarks.len();
                self.bookmarks.push(Entry { id, folder: true, parent, title: name, url: String::new() });
                let empty_in_file = node.children.is_empty();
                if self.import_nodes(node.children, id, count) || empty_in_file {
                    added = true;
                } else {
                    self.bookmarks.truncate(at); // nothing was added after it
                }
            } else {
                let url = node.url.trim();
                if Self::valid_bookmark_url(url) && is_web_address(url) && self.bookmark_id(url) == 0 {
                    let id = self.next_bookmark_id;
                    self.next_bookmark_id += 1;
                    let title = import_title(&node.title).unwrap_or_else(|| host_of(url));
                    self.bookmarks.push(Entry { id, folder: false, parent, title, url: url.to_owned() });
                    *count += 1;
                    added = true;
                }
            }
        }
        added
    }

    /// The whole tree as a NETSCAPE bookmark file (for export).
    pub fn bookmark_export(&self, format: &str) -> String {
        match format {
            "json" => bookmarks::export_json(&self.bookmarks),
            "csv" => bookmarks::export_csv(&self.bookmarks),
            _ => bookmarks::export_html(&self.bookmarks),
        }
    }

    // ---- session (the tabs of the last run; private tabs never reach it) --

    /// Store the session snapshot `{"a":active,"t":[{"u":..,"n":..},...]}`.
    /// Returns false (and stores nothing) when it is not that shape, or when
    /// "restore tabs on start" is switched off: then no tab list is kept at all.
    pub fn session_save(&mut self, json: &str) -> bool {
        if self.get("restore_tabs") == "0" || !session_valid(json) {
            return false;
        }
        self.session = json.to_owned();
        let _ = self.write_atomic("session.json", &self.session);
        true
    }

    /// The raw snapshot, "" when there is none (or it was refused).
    pub fn session_json(&self) -> &str {
        &self.session
    }

    pub fn session_clear(&mut self) {
        self.session.clear();
        let _ = self.write_atomic("session.json", "");
    }

    pub fn session_count(&self) -> usize {
        parse_session(&self.session).map_or(0, |(_, tabs)| tabs.len())
    }

    /// ("url", "title") of the i-th tab of the snapshot.
    pub fn session_tab(&self, i: usize) -> Option<(String, String)> {
        parse_session(&self.session).and_then(|(_, tabs)| tabs.get(i).cloned())
    }

    /// The index of the tab that was in front.
    pub fn session_active(&self) -> usize {
        parse_session(&self.session).map_or(0, |(a, _)| a)
    }

    // ---- files -------------------------------------------------------------

    fn path(&self, name: &str) -> Option<PathBuf> {
        self.dir.as_ref().map(|d| d.join(name))
    }

    fn read(&self, name: &str) -> String {
        self.path(name).and_then(|p| fs::read(p).ok()).map(|b| String::from_utf8_lossy(&b).into_owned()).unwrap_or_default()
    }

    /// Write to a temporary file and rename, so a crash never leaves half a file.
    fn write_atomic(&self, name: &str, text: &str) -> std::io::Result<()> {
        let Some(path) = self.path(name) else { return Ok(()) };
        let tmp = path.with_extension("tmp");
        fs::write(&tmp, text)?;
        fs::rename(&tmp, &path)
    }

    fn rewrite_history(&self) {
        // Each row in a snapshot starts a distinct visit, even when deletion
        // brings two visits to the same URL together. A leading plus keeps
        // the timestamp numeric. Unmarked log rows retain their update semantics.
        let mut text = String::new();
        for visit in &self.history {
            text.push('+');
            text.push_str(&line(visit));
        }
        let _ = self.write_atomic("history.tsv", &text);
    }

    fn rewrite_bookmarks(&self) {
        let mut text = String::new();
        for e in &self.bookmarks {
            text.push_str(&format!("{}\t{}\t{}\t{}\t{}\n", e.id, e.folder as u8, e.parent, escape(&e.title), escape(&e.url)));
        }
        let _ = self.write_atomic("bookmarks.tsv", &text);
    }
}

fn line(v: &Visit) -> String {
    format!("{}\t{}\t{}\n", v.time_ms, escape(&v.url), escape(&v.title))
}

/// The host of a URL, without "www.", for a bookmark added without a title.
/// http: or https: (any case).
fn is_web_address(url: &str) -> bool {
    let lower = url.get(..8).unwrap_or(url).to_ascii_lowercase();
    lower.starts_with("http://") || lower.starts_with("https://")
}

/// A title from another browser's file, as stored here: control characters
/// (a stray newline) become spaces, and a long one is cut at a character
/// boundary rather than dropped. None when nothing is left.
fn import_title(title: &str) -> Option<String> {
    let clean: String = title.chars().map(|c| if c.is_control() { ' ' } else { c }).collect();
    let mut t = clean.trim();
    if t.len() > BOOKMARK_TITLE_MAX {
        let mut end = BOOKMARK_TITLE_MAX;
        while !t.is_char_boundary(end) {
            end -= 1;
        }
        t = t[..end].trim_end();
    }
    (!t.is_empty()).then(|| t.to_owned())
}

fn host_of(url: &str) -> String {
    let after_scheme = url.split("://").nth(1).unwrap_or(url);
    let host: String = after_scheme.chars().take_while(|c| !matches!(c, '/' | '?' | '#' | ':' )).collect();
    let host = host.strip_prefix("www.").unwrap_or(&host);
    if host.is_empty() {
        url.chars().take(64).collect()
    } else {
        host.to_owned()
    }
}

// ---- the session snapshot ---------------------------------------------------
//
// The shells write {"a":active index,"t":[{"u":url,"n":title}, ...]} — the
// normal tabs only, never the private ones. The parser here is deliberately
// tiny: it accepts exactly that shape (unknown keys are skipped) and refuses
// anything else, so a bad file can never become the next session.

fn session_valid(json: &str) -> bool {
    let t = json.trim();
    t.len() <= SESSION_MAX_LEN
        && t.starts_with('{')
        && t.ends_with('}')
        && !t.chars().any(|c| c.is_control())
        && parse_session(t).is_some()
}

fn parse_session(json: &str) -> Option<(usize, Vec<(String, String)>)> {
    let b = json.as_bytes();
    let mut i = 0;
    fn ws(b: &[u8], i: &mut usize) {
        while *i < b.len() && b[*i].is_ascii_whitespace() {
            *i += 1;
        }
    }
    fn jstr(b: &[u8], i: &mut usize) -> Option<String> {
        ws(b, i);
        if b.get(*i) != Some(&b'"') {
            return None;
        }
        *i += 1;
        let mut out = String::new();
        while *i < b.len() {
            match b[*i] {
                b'"' => {
                    *i += 1;
                    return Some(out);
                }
                b'\\' => {
                    *i += 1;
                    match b.get(*i)? {
                        b'"' => out.push('"'),
                        b'\\' => out.push('\\'),
                        b'/' => out.push('/'),
                        b'b' => out.push('\u{8}'),
                        b'f' => out.push('\u{c}'),
                        b'n' => out.push('\n'),
                        b'r' => out.push('\r'),
                        b't' => out.push('\t'),
                        b'u' => {
                            let hex = b.get(*i + 1..*i + 5)?;
                            let n = u32::from_str_radix(std::str::from_utf8(hex).ok()?, 16).ok()?;
                            out.push(char::from_u32(n).unwrap_or('\u{fffd}'));
                            *i += 4;
                        }
                        _ => return None,
                    }
                    *i += 1;
                }
                byte => {
                    // copy one UTF-8 sequence whole
                    let len = if byte < 0x80 { 1 } else if byte >> 5 == 0b110 { 2 } else if byte >> 4 == 0b1110 { 3 } else { 4 };
                    let s = std::str::from_utf8(b.get(*i..*i + len)?).ok()?;
                    out.push_str(s);
                    *i += len;
                }
            }
        }
        None
    }
    fn jnum(b: &[u8], i: &mut usize) -> Option<u64> {
        ws(b, i);
        let start = *i;
        while *i < b.len() && b[*i].is_ascii_digit() {
            *i += 1;
        }
        if *i == start {
            return None;
        }
        std::str::from_utf8(&b[start..*i]).ok()?.parse().ok()
    }
    fn skip_value(b: &[u8], i: &mut usize) -> Option<()> {
        ws(b, i);
        match b.get(*i)? {
            b'"' => {
                jstr(b, i)?;
            }
            b'{' | b'[' => {
                let (open, close) = if b[*i] == b'{' { (b'{', b'}') } else { (b'[', b']') };
                let mut depth = 0;
                loop {
                    ws(b, i);
                    match b.get(*i)? {
                        b'"' => {
                            jstr(b, i)?;
                        }
                        c if *c == open => {
                            depth += 1;
                            *i += 1;
                        }
                        c if *c == close => {
                            depth -= 1;
                            *i += 1;
                            if depth == 0 {
                                return Some(());
                            }
                        }
                        _ => *i += 1,
                    }
                }
            }
            _ => {
                jnum(b, i)?;
            }
        }
        Some(())
    }

    ws(b, &mut i);
    if b.get(i) != Some(&b'{') {
        return None;
    }
    i += 1;
    let mut active = 0usize;
    let mut tabs = Vec::new();
    loop {
        ws(b, &mut i);
        match b.get(i) {
            Some(b'}') => break,
            Some(b',') => {
                i += 1;
                continue;
            }
            Some(b'"') => {}
            _ => return None,
        }
        let key = jstr(b, &mut i)?;
        ws(b, &mut i);
        if b.get(i) != Some(&b':') {
            return None;
        }
        i += 1;
        match key.as_str() {
            "a" => active = jnum(b, &mut i)? as usize,
            "t" => {
                ws(b, &mut i);
                if b.get(i) != Some(&b'[') {
                    return None;
                }
                i += 1;
                loop {
                    ws(b, &mut i);
                    match b.get(i) {
                        Some(b']') => {
                            i += 1;
                            break;
                        }
                        Some(b'{') => {}
                        Some(b',') => {
                            i += 1;
                            continue;
                        }
                        _ => return None,
                    }
                    i += 1; // '{'
                    let mut url = String::new();
                    let mut title = String::new();
                    loop {
                        ws(b, &mut i);
                        match b.get(i) {
                            Some(b'}') => {
                                i += 1;
                                break;
                            }
                            Some(b',') => {
                                i += 1;
                                continue;
                            }
                            Some(b'"') => {}
                            _ => return None,
                        }
                        let k = jstr(b, &mut i)?;
                        ws(b, &mut i);
                        if b.get(i) != Some(&b':') {
                            return None;
                        }
                        i += 1;
                        let v = jstr(b, &mut i)?;
                        if k == "u" {
                            url = v;
                        } else if k == "n" {
                            title = v;
                        }
                    }
                    if tabs.len() >= SESSION_MAX_TABS
                        || url.len() > 4096
                        || url.chars().any(|c| c.is_control())
                        || title.len() > 1024
                        || title.chars().any(|c| c.is_control())
                    {
                        return None;
                    }
                    tabs.push((url, title));
                }
            }
            _ => skip_value(b, &mut i)?,
        }
    }
    if active >= tabs.len() && !tabs.is_empty() {
        active = tabs.len() - 1;
    }
    Some((active, tabs))
}

/// Keep a field on one line and free of tabs.
fn escape(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    for c in s.chars() {
        match c {
            '\\' => out.push_str("\\\\"),
            '\t' => out.push_str("\\t"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            c => out.push(c),
        }
    }
    out
}

fn unescape(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    let mut chars = s.chars();
    while let Some(c) = chars.next() {
        if c != '\\' {
            out.push(c);
            continue;
        }
        match chars.next() {
            Some('t') => out.push('\t'),
            Some('n') => out.push('\n'),
            Some('r') => out.push('\r'),
            Some(other) => out.push(other),
            None => out.push('\\'),
        }
    }
    out
}

/// A JSON string literal that is also safe inside an HTML `<script>` block.
pub fn json_string(s: &str) -> String {
    let mut out = String::with_capacity(s.len() + 2);
    out.push('"');
    for c in s.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            '<' | '>' | '&' | '\u{2028}' | '\u{2029}' => out.push_str(&format!("\\u{:04x}", c as u32)),
            c if (c as u32) < 0x20 => out.push_str(&format!("\\u{:04x}", c as u32)),
            c => out.push(c),
        }
    }
    out.push('"');
    out
}

// ---- the process-wide store the shells use ---------------------------------

static STORE: Mutex<Store> = Mutex::new(Store::in_memory());

fn store() -> MutexGuard<'static, Store> {
    STORE.lock().unwrap_or_else(|e| e.into_inner())
}

/// Settings the core itself acts on; everything else is only stored for the shell.
fn apply(key: &str, value: &str) {
    match key {
        "search_template" => {
            if !crate::omnibox::set_search_template(value) {
                crate::omnibox::reset_search_template(); // unset or unusable: the default engine
            }
        }
        "block_trackers" => crate::blocker::set_enabled(value != "0"),
        // These two are off unless the user turned them on, so only "1" opens them.
        "block_ads" => crate::blocker::set_ads_enabled(value == "1"),
        "block_external_apps" => crate::external::set_blocking(value == "1"),
        _ => {}
    }
}

pub fn open(dir: &str) {
    let loaded = Store::open(dir);
    for key in ["search_template", "block_trackers", "block_ads", "block_external_apps"] {
        apply(key, loaded.get(key)); // "" restores the default
    }
    *store() = loaded;
}

pub fn setting_get(key: &str) -> String {
    store().get(key).to_owned()
}

/// The profile dir the store was opened in, or "" when it is in memory.
pub fn profile_dir() -> String {
    store().dir.clone().map(|d| d.to_string_lossy().into_owned()).unwrap_or_default()
}

/// Every setting, in key order.
pub fn settings_all() -> Vec<(String, String)> {
    store().settings.iter().map(|(k, v)| (k.clone(), v.clone())).collect()
}

pub fn setting_set(key: &str, value: &str) {
    store().set(key, value);
    apply(key, value);
}

pub fn history_add(url: &str, title: &str, time_ms: u64) {
    store().history_add(url, title, time_ms);
}

pub fn history_json(query: &str, limit: usize) -> String {
    store().history_json(query, limit)
}

pub fn history_delete(url: &str, time_ms: u64) {
    store().history_delete(url, time_ms);
}

pub fn history_clear() -> bool {
    store().history_clear()
}

pub fn bookmark_add(url: &str, title: &str, parent: u64) -> u64 {
    store().bookmark_add(url, title, parent)
}

pub fn bookmark_folder(name: &str, parent: u64) -> u64 {
    store().bookmark_folder(name, parent)
}

pub fn bookmark_remove(id: u64) {
    store().bookmark_remove(id)
}

pub fn bookmark_move(id: u64, parent: u64, index: usize) {
    store().bookmark_move(id, parent, index)
}

pub fn bookmark_rename(id: u64, title: &str) {
    store().bookmark_rename(id, title)
}

pub fn bookmark_id(url: &str) -> u64 {
    store().bookmark_id(url)
}

pub fn bookmarks_json(query: &str) -> String {
    store().bookmarks_json(query)
}

pub fn bookmark_import(html: &str) -> usize {
    store().bookmark_import(html)
}

pub fn bookmark_export(format: &str) -> String {
    store().bookmark_export(format)
}

pub fn session_save(json: &str) -> bool {
    store().session_save(json)
}

pub fn session_json() -> String {
    store().session_json().to_owned()
}

pub fn session_clear() {
    store().session_clear()
}

pub fn session_count() -> usize {
    store().session_count()
}

pub fn session_tab(i: usize) -> Option<(String, String)> {
    store().session_tab(i)
}

pub fn session_active() -> usize {
    store().session_active()
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::{AtomicU32, Ordering};

    pub(super) fn temp_dir() -> PathBuf {
        static N: AtomicU32 = AtomicU32::new(0);
        let dir = std::env::temp_dir().join(format!("fable-store-{}-{}", std::process::id(), N.fetch_add(1, Ordering::Relaxed)));
        let _ = fs::remove_dir_all(&dir);
        dir
    }

    #[test]
    fn settings_round_trip_through_disk() {
        let dir = temp_dir();
        let mut s = Store::open(&dir);
        assert_eq!(s.get("ua_mode"), "");
        s.set("ua_mode", "desktop");
        s.set("shortcuts", "[{\"n\":\"a\\tb\",\"u\":\"https://x/\"}]\nsecond line\\");
        s.set("gone", "x");
        s.set("gone", "");
        s.set("", "ignored");

        let s = Store::open(&dir);
        assert_eq!(s.get("ua_mode"), "desktop");
        assert_eq!(s.get("shortcuts"), "[{\"n\":\"a\\tb\",\"u\":\"https://x/\"}]\nsecond line\\");
        assert_eq!(s.get("gone"), "");
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn history_records_updates_filters_and_persists() {
        let dir = temp_dir();
        let mut s = Store::open(&dir);
        s.history_add("https://a.example/", "", 1000);
        s.history_add("https://a.example/", "站点 A", 1500); // title arrives later: same visit
        s.history_add("https://b.example/x", "B <page> \"quoted\"", 2000);
        s.history_add("https://a.example/", "站点 A", 3000); // a new visit after going elsewhere
        s.history_add("   ", "blank", 4000);
        assert_eq!(s.history_len(), 3);

        assert_eq!(
            s.history_json("", 10),
            "[{\"t\":3000,\"u\":\"https://a.example/\",\"n\":\"站点 A\"},\
             {\"t\":2000,\"u\":\"https://b.example/x\",\"n\":\"B \\u003cpage\\u003e \\\"quoted\\\"\"},\
             {\"t\":1500,\"u\":\"https://a.example/\",\"n\":\"站点 A\"}]"
        );
        assert_eq!(s.history_json("B.EXAMPLE", 10).matches("\"t\":").count(), 1);
        assert_eq!(s.history_json("站点", 10).matches("\"t\":").count(), 2);
        assert_eq!(s.history_json("", 1).matches("\"t\":").count(), 1);
        assert_eq!(s.history_json("nothing", 10), "[]");

        // Reopening sees the same three visits (the log had four lines).
        let mut s = Store::open(&dir);
        assert_eq!(s.history_len(), 3);
        s.history_delete("https://a.example/", 1500);
        assert_eq!(s.history_len(), 2);
        s.history_delete("https://a.example/", 0);
        assert_eq!(s.history_len(), 1);
        assert_eq!(Store::open(&dir).history_len(), 1);
        s.history_clear();
        assert_eq!(Store::open(&dir).history_len(), 0);
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn deletion_preserves_distinct_visits_across_reopen() {
        let dir = temp_dir();
        fs::create_dir_all(&dir).unwrap();
        // Existing append-only files use consecutive rows to update a title.
        fs::write(dir.join("history.tsv"), "1\tA\t\n2\tA\tfirst\n3\tB\tmiddle\n4\tA\tlast\n").unwrap();
        let mut store = Store::open(&dir);
        store.history_delete("B", 3);
        let expected = store.history_json("", 10);
        assert_eq!(store.history_len(), 2);
        let mut store = Store::open(&dir);
        assert_eq!(store.history_json("", 10), expected);
        store.history_add("A", "updated", 5);
        let reopened = Store::open(&dir);
        assert_eq!(reopened.history_len(), 2);
        assert_eq!(reopened.history[0].title, "first");
        assert_eq!(reopened.history[1].title, "updated");
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn failed_clear_keeps_history_and_can_be_retried() {
        let dir = temp_dir();
        let mut store = Store::open(&dir);
        store.history_add("A", "visit", 1);
        let tmp = dir.join("history.tmp");
        fs::create_dir(&tmp).unwrap(); // prevent the temporary file from being written
        assert!(!store.history_clear());
        assert_eq!(store.history_len(), 1);
        assert_eq!(Store::open(&dir).history_len(), 1);
        fs::remove_dir(tmp).unwrap();
        assert!(store.history_clear());
        assert_eq!(store.history_len(), 0);
        assert_eq!(Store::open(&dir).history_len(), 0);
        fs::remove_dir_all(dir).unwrap();
    }

    #[test]
    fn history_is_capped() {
        let dir = temp_dir();
        let mut s = Store::open(&dir);
        for i in 0..(HISTORY_CAP + HISTORY_SLACK + 1) as u64 {
            s.history_add(&format!("https://example.com/{i}"), "t", i);
        }
        assert_eq!(s.history_len(), HISTORY_CAP);
        assert!(s.history_json("", 1).contains(&format!("/{}", HISTORY_CAP + HISTORY_SLACK)));
        assert_eq!(Store::open(&dir).history_len(), HISTORY_CAP);
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn works_without_a_directory() {
        let mut s = Store::in_memory();
        s.set("k", "v");
        s.history_add("https://a/", "A", 1);
        assert_eq!(s.get("k"), "v");
        assert_eq!(s.history_len(), 1);
        s.history_clear();
        assert_eq!(s.history_json("", 5), "[]");
    }

    #[test]
    fn bookmarks_add_dedupe_move_remove_and_persist() {
        let dir = temp_dir();
        let mut s = Store::open(&dir);
        let a = s.bookmark_add("https://a.example/", "", 0);
        assert!(a > 0);
        assert_eq!(s.bookmark_id("https://a.example/"), a);
        assert_eq!(s.bookmark_id("https://a.example/"), s.bookmark_add("https://a.example/", "A title", 0), "same URL: same entry");
        assert_eq!(s.bookmarks_json("").matches("\"i\":").count(), 1);
        let f = s.bookmark_folder("News", 0);
        assert!(f > a);
        let b = s.bookmark_add("https://b.example/", "B", f);
        assert!(b > f);
        let c = s.bookmark_add("https://c.example/", "C", 0);
        assert_eq!(s.bookmark_add("", "x", 0), 0);
        assert_eq!(s.bookmark_add("https://x/", "x", 999), s.bookmark_id("https://x/"), "an unknown folder means the root");
        s.bookmark_move(c, f, 0); // C first inside News
        let json = s.bookmarks_json("");
        let news = json.find("\"n\":\"News\"").unwrap();
        assert!(json[news..].find("\"n\":\"C\"").unwrap() < json[news..].find("\"n\":\"B\"").unwrap());
        s.bookmark_rename(c, "C2");
        assert!(s.bookmarks_json("").contains("\"n\":\"C2\""));
        s.bookmark_remove(f); // removes C and B with the folder
        assert_eq!(s.bookmark_id("https://b.example/"), 0);
        assert_eq!(s.bookmarks_json("").matches("\"i\":").count(), 2); // a and x
        // Persisted, and reloaded.
        let s = Store::open(&dir);
        assert_eq!(s.bookmark_id("https://a.example/"), a);
        assert!(s.bookmarks_json("").contains("\"n\":\"A title\""));
        assert_eq!(s.bookmarks_json("").matches("\"i\":").count(), 2);
        assert_eq!(s.session_count(), 0);
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn bookmarks_json_filters_by_query() {
        let mut s = Store::in_memory();
        let f = s.bookmark_folder("News", 0);
        s.bookmark_add("https://paper.example/", "Paper", f);
        s.bookmark_add("https://example.com/", "Example", 0);
        assert_eq!(s.bookmarks_json(""), "[{\"i\":1,\"f\":1,\"n\":\"News\",\"c\":[{\"i\":2,\"u\":\"https://paper.example/\",\"n\":\"Paper\"}]},{\"i\":3,\"u\":\"https://example.com/\",\"n\":\"Example\"}]");
        assert_eq!(s.bookmarks_json("PAPER"), "[{\"i\":1,\"f\":1,\"n\":\"News\",\"c\":[{\"i\":2,\"u\":\"https://paper.example/\",\"n\":\"Paper\"}]}]");
        assert_eq!(s.bookmarks_json("news"), "[{\"i\":1,\"f\":1,\"n\":\"News\",\"c\":[{\"i\":2,\"u\":\"https://paper.example/\",\"n\":\"Paper\"}]}]", "a folder name match keeps the subtree");
        assert_eq!(s.bookmarks_json("zzz"), "[]");
    }

    #[test]
    fn bookmark_import_reads_netscape_and_export_writes_it_back() {
        let dir = temp_dir();
        let mut s = Store::open(&dir);
        let html = r##"<!DOCTYPE NETSCAPE-Bookmark-file-1>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>Bookmarks</TITLE>
<H1>Bookmarks</H1>
<DL><p>
    <DT><A HREF="https://example.com/" ADD_DATE="1">Example &amp; Co</A>
    <DT><H3>News</H3>
    <DL><p>
        <DT><A HREF="https://paper.example/">Paper</A>
        <DT><A HREF="https://example.com/">dup</A>
    </DL><p>
</DL><p>
"##;
        assert_eq!(s.bookmark_import(html), 2, "the duplicate URL is skipped");
        assert_eq!(s.bookmark_id("https://example.com/"), 1);
        assert_eq!(s.bookmarks_json("").matches("\"f\":1").count(), 1);
        assert!(s.bookmarks_json("").contains("Example \\u0026 Co"), "& is \\u0026 in JSON");
        let exported = s.bookmark_export("html");
        assert!(exported.starts_with("<!DOCTYPE NETSCAPE-Bookmark-file-1>"));
        assert_eq!(Store::open(&dir).bookmark_import(&exported), 0, "re-importing an export adds nothing");
        assert_eq!(Store::open(&dir).bookmarks_json("").matches("\"i\":").count(), 3);
        assert_eq!(s.bookmark_import("not html at all"), 0);
        let _ = fs::remove_dir_all(dir);
    }

    /// Each fixture as a fresh profile would import it: (added, the panel's tree).
    fn imported(file: &str) -> (usize, String) {
        let dir = temp_dir();
        let mut s = Store::open(&dir);
        let n = s.bookmark_import(file);
        let tree = s.bookmarks_json("");
        let _ = fs::remove_dir_all(dir);
        (n, tree)
    }

    #[test]
    fn other_browsers_files_import_once_and_go_back_out() {
        let files = [
            ("chrome.html", include_str!("../../tests/bookmarks/chrome.html"), 5),
            ("chrome-Bookmarks.json", include_str!("../../tests/bookmarks/chrome-Bookmarks.json"), 5),
            ("firefox.html", include_str!("../../tests/bookmarks/firefox.html"), 6),
            ("firefox-backup.json", include_str!("../../tests/bookmarks/firefox-backup.json"), 6),
            ("safari.html", include_str!("../../tests/bookmarks/safari.html"), 3),
            ("opera-Bookmarks.json", include_str!("../../tests/bookmarks/opera-Bookmarks.json"), 2),
            ("ie.htm", include_str!("../../tests/bookmarks/ie.htm"), 2),
        ];
        for (name, file, web) in files {
            let dir = temp_dir();
            let mut s = Store::open(&dir);
            // Only web addresses come in: no bookmarklet, chrome:// or place: query.
            assert_eq!(s.bookmark_import(file), web, "{name}");
            let tree = s.bookmarks_json("");
            for scheme in ["javascript:", "chrome:", "place:"] {
                assert!(!tree.contains(scheme), "{name}: {scheme}");
            }
            // Again: nothing new, not even an empty copy of a folder.
            assert_eq!(s.bookmark_import(file), 0, "{name}");
            assert_eq!(s.bookmarks_json(""), tree, "{name} imported twice");
            assert_eq!(Store::open(&dir).bookmarks_json(""), tree, "{name} on disk");
            // Out as HTML (what every browser imports) and into a fresh profile: the same tree.
            let html = s.bookmark_export("html");
            assert_eq!(imported(&html), (web, tree.clone()), "{name} through Fable's HTML");
            // And Fable's HTML back into this profile adds nothing.
            assert_eq!(s.bookmark_import(&html), 0, "{name}");
            assert_eq!(s.bookmarks_json(""), tree, "{name} after its own export");
            let _ = fs::remove_dir_all(dir);
        }
        // The same profile imports alike whichever of its files was picked.
        assert_eq!(imported(include_str!("../../tests/bookmarks/chrome.html")), imported(include_str!("../../tests/bookmarks/chrome-Bookmarks.json")));
        let lang = crate::i18n::current();
        let (n, backup) = imported(include_str!("../../tests/bookmarks/firefox-backup.json"));
        let backup = backup
            .replace(&json_string(&crate::i18n::text(lang, "bookmarks_toolbar")), "\"Bookmarks Toolbar\"")
            .replace(&json_string(&crate::i18n::text(lang, "other_bookmarks")), "\"Other Bookmarks\"");
        assert_eq!((n, backup), imported(include_str!("../../tests/bookmarks/firefox.html")));
    }

    #[test]
    fn imported_titles_are_kept_and_folders_merged() {
        let dir = temp_dir();
        let mut s = Store::open(&dir);
        let long = "长".repeat(120); // 360 bytes
        let file = format!("<DL><p><DT><H3>Work</H3><DL><p><DT><A HREF=\"https://a.example/\">{long}</A><DT><A HREF=\"https://b.example/\">line\nbreak</A></DL><p></DL><p>");
        assert_eq!(s.bookmark_import(&file), 2);
        let tree = s.bookmarks_json("");
        // A long title is cut at a character boundary, not replaced by the host; a newline becomes a space.
        assert!(tree.contains(&format!("\"{}\"", "长".repeat(85))) && !tree.contains(&"长".repeat(86)), "{tree}");
        assert!(tree.contains("\"line break\""));
        // Another file with the same folder: one "Work", with the new bookmark in it.
        assert_eq!(s.bookmark_import("<DL><p><DT><H3>Work</H3><DL><p><DT><A HREF=\"https://c.example/\">C</A><DT><A HREF=\"https://a.example/\">A</A></DL><p></DL><p>"), 1);
        let tree = s.bookmarks_json("");
        assert_eq!(tree.matches("\"f\":1").count(), 1, "{tree}");
        assert_eq!(tree.matches("\"u\":").count(), 3);
        // A folder that would hold only bookmarks already here is not made.
        assert_eq!(s.bookmark_import("<DL><p><DT><H3>Copy</H3><DL><p><DT><A HREF=\"https://c.example/\">C</A></DL><p></DL><p>"), 0);
        assert!(!s.bookmarks_json("").contains("Copy"));
        // An empty folder in the file is made, and kept on disk.
        assert_eq!(s.bookmark_import("<DL><p><DT><H3>Later</H3><DL><p></DL><p></DL><p>"), 0);
        assert!(Store::open(&dir).bookmarks_json("").contains("\"Later\""));
        // Too big is refused whole.
        assert_eq!(s.bookmark_import(&" ".repeat(BOOKMARK_FILE_MAX + 1)), 0);
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn session_round_trip_and_refusal() {
        let dir = temp_dir();
        let mut s = Store::open(&dir);
        assert!(s.session_save(r#"{"a":1,"t":[{"u":"https://a.example/","n":"A \"quoted\""},{"u":"https://b.example/","n":"B"}]}"#));
        assert_eq!(s.session_count(), 2);
        assert_eq!(s.session_active(), 1);
        assert_eq!(s.session_tab(0), Some((r"https://a.example/".to_owned(), r#"A "quoted""#.to_owned())));
        assert_eq!(s.session_tab(5), None);
        let mut s = Store::open(&dir);
        assert_eq!(s.session_count(), 2);
        assert!(s.session_json().contains("\"a\":1"));
        // Refused: wrong shape, control characters, too big, bad active index is clamped.
        assert!(!s.session_save("[1,2]"));
        assert!(!s.session_save("{\"t\":\"x\"}"));
        assert!(!s.session_save("{\"a\":0,\"t\":[{\"u\":\"https://a/\n\"}]}"));
        assert!(!s.session_save(&format!("{{\"a\":0,\"t\":{}}}", "[]".repeat(300_000))));
        assert!(s.session_save(r#"{"a":9,"t":[{"u":"https://a/","n":""}]}"#), "an out-of-range active is clamped, not refused");
        assert_eq!(s.session_active(), 0);
        // An empty URL is Fable's own new-tab page: a tab of ours, not a web
        // page. It has to survive the round trip, or the tab is lost on the
        // next start.
        assert!(s.session_save(r#"{"a":0,"t":[{"u":"https://a/","n":"A"},{"u":"","n":""}]}"#));
        assert_eq!(s.session_count(), 2);
        assert_eq!(s.session_tab(1), Some((String::new(), String::new())));
        assert!(s.session_save(r#"{"a":0,"t":[{"u":"","n":""}]}"#), "a snapshot of only the new-tab page");
        assert_eq!(s.session_count(), 1);
        s.session_clear();
        assert_eq!(Store::open(&dir).session_count(), 0);
        // "Restore tabs on start" off: the snapshot goes, and no new one is kept.
        assert!(s.session_save(r#"{"a":0,"t":[{"u":"https://a/","n":""}]}"#));
        s.set("restore_tabs", "0");
        assert_eq!(Store::open(&dir).session_count(), 0, "switching it off deletes the saved tabs");
        assert!(!s.session_save(r#"{"a":0,"t":[{"u":"https://a/","n":""}]}"#));
        assert_eq!(s.session_count(), 0);
        s.set("restore_tabs", "1");
        assert!(s.session_save(r#"{"a":0,"t":[{"u":"https://a/","n":""}]}"#));
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn escaping_round_trips() {
        for s in ["", "plain", "tab\there", "line\nbreak\r", "back\\slash", "\\t literal", "混合\t\\\n"] {
            assert_eq!(unescape(&escape(s)), s);
            assert!(!escape(s).contains(['\t', '\n', '\r']));
        }
        assert_eq!(json_string("a\u{1}</script>&\u{2028}"), "\"a\\u0001\\u003c/script\\u003e\\u0026\\u2028\"");
    }
}
