/*
 * uint64_t fable_fnv1a_lower(const uint8_t *p, size_t n);
 *
 * FNV-1a (64-bit) over the bytes of p, folding ASCII 'A'..'Z' to lower case
 * on the fly, so host names hash case-insensitively without a copy.
 * This is the blocker's hot path: it runs once per label suffix of every
 * request host.
 *
 * x86-64, GNU assembler, Intel syntax. One source for both ABIs:
 *   System V (Linux, Android): p = rdi, n = rsi
 *   Win64    (Windows):        p = rcx, n = rdx
 * Only caller-saved registers are used (rax, r8-r11 and the argument regs).
 * macOS (Intel) is System V too; its Mach-O symbols carry a leading underscore.
 */
#if defined(_WIN32)
# define P rcx
# define N rdx
#else
# define P rdi
# define N rsi
#endif

#if defined(__APPLE__)
# define FNV _fable_fnv1a_lower
#else
# define FNV fable_fnv1a_lower
#endif

        .intel_syntax noprefix
        .text
        .globl  FNV
#if defined(__ELF__)
        .type   FNV, @function
#endif
        .p2align 4
FNV:
        movabs  rax, 0xcbf29ce484222325         /* FNV offset basis */
        movabs  r8,  0x00000100000001b3         /* FNV prime        */
        test    N, N
        jz      2f
        lea     r9, [P + N]                     /* r9 = end pointer */
1:
        movzx   r10d, byte ptr [P]              /* c = *p                    */
        lea     r11d, [r10 - 65]                /* c - 'A'                   */
        cmp     r11d, 25                        /* unsigned: is c in A..Z ?  */
        lea     r11d, [r10 + 32]                /* lower-case candidate (lea keeps flags) */
        cmovbe  r10d, r11d                      /* take it when c was upper  */
        xor     rax, r10                        /* h ^= c                    */
        imul    rax, r8                         /* h *= prime                */
        inc     P
        cmp     P, r9
        jne     1b
2:
        ret
#if defined(__ELF__)
        .size   FNV, . - FNV
        .section .note.GNU-stack, "", @progbits
#endif
