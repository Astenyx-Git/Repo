#!/bin/sh
# "Restore tabs on start" in the Linux shell, end to end with the real
# build/fable (make linux) and a local server that logs every page asked for:
#
# 1. Open a.html (from the command line) and b.html (Ctrl+T, typed), then end
#    the app the hard way (SIGTERM, as a crash would): the snapshot taken as
#    pages finished loading has both.
# 2. Start again with no address: both pages are asked for again.
# 3. Start with a link (c.html): the two come back and the link opens as well.
# 4. A tab left on the new-tab page (the skin is switched there) comes back as
#    well: the snapshot keeps it, with an empty URL.
#
# Needs xvfb-run, xdotool and python3; skips (exit 0) without them or without
# build/fable, unless FABLE_REQUIRE_UI=1.
set -u
cd "$(dirname "$0")/.."
skip() { echo "linux_restore_test: $1, skipped"; [ "${FABLE_REQUIRE_UI:-0}" = 1 ] && exit 1; exit 0; }
[ -x build/fable ] || skip "no build/fable (make linux)"
for tool in xvfb-run xdotool python3; do command -v $tool >/dev/null 2>&1 || skip "no $tool"; done

WORK=$(mktemp -d)
PORT=$(python3 -c 'import socket; s = socket.socket(); s.bind(("127.0.0.1", 0)); print(s.getsockname()[1])')
for page in a b c; do echo "<!doctype html><title>Page $page</title><p>$page" > "$WORK/$page.html"; done
# Pages are never cached, so each load reaches the log; the log is appended to,
# so the phase markers below stay in place.
cat > "$WORK/server.py" <<'PY'
import http.server, sys
class Handler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()
    def log_message(self, format, *args):
        with open("server.log", "a") as log:
            log.write(format % args + "\n")
http.server.ThreadingHTTPServer(("127.0.0.1", int(sys.argv[1])), Handler).serve_forever()
PY
cat > "$WORK/run.sh" <<SCRIPT
#!/bin/sh
cd "$WORK"
python3 -I server.py $PORT 2> server.err &
SERVER=\$!
export HOME="$WORK/home"; mkdir -p "\$HOME"
unset XDG_DATA_HOME XDG_CONFIG_HOME XDG_CACHE_HOME   # the profile goes under HOME, not the caller's
mkdir -p "$WORK/home/.local/share/fable"
printf 'accepted_eula\tV1.2\n' > "$WORK/home/.local/share/fable/settings.tsv"
"$PWD/build/fable" http://127.0.0.1:$PORT/a.html > fable1.log 2>&1 &
APP=\$!
sleep 6; xdotool key ctrl+t; sleep 1
xdotool type --delay 20 "http://127.0.0.1:$PORT/b.html"; xdotool key Return
sleep 4
# A third tab, left on the new-tab page: the skin is switched there, which is
# what the bug was about.
xdotool key ctrl+t; sleep 2
xdotool key ctrl+l; sleep 0.3; xdotool type --delay 20 "theme://Kimi"; xdotool key Return
sleep 3; kill \$APP; wait \$APP 2>/dev/null
cp "\$HOME/.local/share/fable/session.json" snapshot.json 2>/dev/null
echo "--- second start" >> server.log
"$PWD/build/fable" > fable2.log 2>&1 &
APP=\$!
sleep 7; kill \$APP; wait \$APP 2>/dev/null
echo "--- third start" >> server.log
"$PWD/build/fable" http://127.0.0.1:$PORT/c.html > fable3.log 2>&1 &
APP=\$!
sleep 7; kill \$APP \$SERVER; wait \$APP 2>/dev/null
SCRIPT
timeout 120 xvfb-run -a -s "-screen 0 1280x900x24" sh "$WORK/run.sh"
log="$WORK/server.log"
second=$(sed -n '/--- second start/,/--- third start/p' "$log")
third=$(sed -n '/--- third start/,$p' "$log")
fail=0
grep -q "GET /b.html" "$log" || { echo "FAIL linux_restore_test: the second tab never loaded, so nothing was tested"; fail=1; }
for page in a b; do
    echo "$second" | grep -q "GET /$page.html" || { echo "FAIL linux_restore_test: $page.html did not come back on the next start"; fail=1; }
    echo "$third" | grep -q "GET /$page.html" || { echo "FAIL linux_restore_test: started with a link, $page.html did not come back"; fail=1; }
done
echo "$third" | grep -q "GET /c.html" || { echo "FAIL linux_restore_test: the link handed over did not open"; fail=1; }
# The new-tab page is in the snapshot with an empty URL, and comes back with
# the others (0.18.29).
count_tabs() { python3 -c "import json,sys; print(len(json.load(open(sys.argv[1])).get('t',[])))" "$1" 2>/dev/null; }
count_ours() { python3 -c "import json,sys; print(sum(1 for t in json.load(open(sys.argv[1])).get('t',[]) if not t.get('u')))" "$1" 2>/dev/null; }
if [ -f "$WORK/snapshot.json" ]; then
    tabs=$(count_tabs "$WORK/snapshot.json")
    ours=$(count_ours "$WORK/snapshot.json")
    [ "$tabs" = "3" ] || { echo "FAIL linux_restore_test: the snapshot has $tabs tabs, not 3 (the new-tab page is missing)"; cat "$WORK/snapshot.json"; echo; fail=1; }
    [ "$ours" = "1" ] || { echo "FAIL linux_restore_test: the snapshot has no new-tab page (an empty URL)"; cat "$WORK/snapshot.json"; echo; fail=1; }
else
    echo "FAIL linux_restore_test: no snapshot to read"; fail=1
fi
[ $fail = 0 ] || { grep -E "GET|---" "$log"; find "$WORK/home" -name session.json -exec cat {} \; ; rm -rf "$WORK"; exit 1; }
rm -rf "$WORK"
echo "linux_restore_test: tabs come back after a hard stop, and with a link; the new-tab page comes back too"
