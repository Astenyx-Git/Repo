// The home screen over the system wallpaper (LAUNCHER.wallpaper 1 or 2; tests/launcher_wallpaper.json has 1):
// the page is see-through, its text light with a shadow (or dark on a light wallpaper), All apps keeps its sheet.
(function () {
  var log = [];
  function check(name, ok) { log.push((ok ? 'ok   ' : 'FAIL ') + name); }
  function css(el, p) { return getComputedStyle(el).getPropertyValue(p).trim(); }
  var html = document.documentElement, name = document.querySelector('.page a span.name'), h1 = document.querySelector('.page header h1');
  check('the page knows before it is drawn', html.classList.contains('wall') && html.classList.contains('wall-light'));
  check('nothing of the page covers the wallpaper', css(html, 'background-color') === 'rgba(0, 0, 0, 0)' && css(document.body, 'background-color') === 'rgba(0, 0, 0, 0)');
  check('names are white with a shadow', css(name.parentNode, 'color') === 'rgb(255, 255, 255)' && css(name.parentNode, 'text-shadow') !== 'none');
  check('the title too', css(h1, 'color') === 'rgb(255, 255, 255)');
  check('the tiles stay cards', css(document.querySelector('.page a span.tile'), 'background-color') === 'rgb(255, 255, 255)');
  check('All apps keeps its own background', css(document.getElementById('drawer'), 'background-color') === 'rgb(253, 247, 240)');
  html.classList.replace('wall-light', 'wall-dark');
  check('on a light wallpaper the text is dark', css(name.parentNode, 'color') === 'rgb(42, 26, 20)');
  html.classList.replace('wall-dark', 'wall-light');
  // For the picture only: something to stand in for a wallpaper behind the see-through page.
  html.style.background = 'linear-gradient(160deg, #1d3557, #457b9d 55%, #e9c46a)';
  return log.join('\n');
})();
