//! One runtime snapshot for request matching and WebKit rule generation.
use std::fs::File;
use std::io::Read;
use std::path::Path;
use std::sync::{RwLock, RwLockReadGuard};

/// A list file is at most 4 MiB: the community lists the updater extracts
/// (EasyList, EasyPrivacy) hold tens of thousands of domains, about 2 MB
/// serialised, so the old 1 MiB cap would reject every real update.
pub(crate) const MAX_BYTES: usize = 4 * 1024 * 1024;
/// At most this many domains in one list (the updater's estimate for the
/// community lists is well under half of this).
pub(crate) const MAX_DOMAINS: usize = 200_000;

/// A bare domain a list may hold: ASCII letters, digits and hyphens, at
/// least one dot, every label 1-63 chars and not starting or ending with '-'.
pub(crate) fn valid_domain(name: &str) -> bool {
    !name.is_empty()
        && name.len() <= 253
        && name.contains('.')
        && name.split('.').all(|label| {
            !label.is_empty()
                && label.len() <= 63
                && !label.starts_with('-')
                && !label.ends_with('-')
                && label.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'-')
        })
}

/// Whether the list keeps the domains as text besides their hashes. Requests
/// are matched by hash everywhere; the text is for the shells that need it:
/// iOS and macOS compile it into WebKit content rules, and the Linux shell
/// hands it to its web processes (`fable_ad_list_text`), which block there.
/// Android, Windows and HarmonyOS never read it, so they skip the ~2 MB a
/// community list's text takes (Mistral, 0.18.19).
pub(crate) const KEEP_TEXT: bool =
    cfg!(any(target_os = "ios", target_os = "macos", all(target_os = "linux", not(target_env = "ohos"))));

#[derive(Default)]
pub(crate) struct AdList {
    /// The domains, sorted; empty where `KEEP_TEXT` is false.
    pub domains: Vec<String>,
    hashes: Vec<u64>,
}

impl AdList {
    pub fn contains(&self, hash: u64) -> bool {
        self.hashes.binary_search(&hash).is_ok()
    }

    pub fn parse(bytes: &[u8]) -> Option<Self> {
        if bytes.len() > MAX_BYTES {
            return None;
        }
        let text = std::str::from_utf8(bytes).ok()?.trim_start_matches('\u{feff}');
        let mut domains = Vec::new();
        for line in text.lines() {
            let name = line.trim();
            if name.is_empty() || name.starts_with('#') {
                continue;
            }
            if domains.len() == MAX_DOMAINS || !valid_domain(name) {
                return None;
            }
            domains.push(name.to_ascii_lowercase());
        }
        if domains.is_empty() {
            return None;
        }
        domains.sort_unstable();
        domains.dedup();
        let mut hashes: Vec<_> = domains.iter().map(|d| crate::hash::fnv1a_lower(d.as_bytes())).collect();
        hashes.sort_unstable();
        if !KEEP_TEXT {
            domains = Vec::new();   // frees the text: only the hashes are used here
        }
        Some(Self { domains, hashes })
    }

    /// How many domains the list holds (one hash each, whether or not the text is kept).
    pub fn domain_count(&self) -> usize {
        self.hashes.len()
    }

    pub fn from_file(path: &Path) -> Option<Self> {
        let mut bytes = Vec::new();
        let metadata = path.metadata().ok()?;
        if !metadata.is_file() || metadata.len() > MAX_BYTES as u64 {
            return None;
        }
        File::open(path).ok()?.take(MAX_BYTES as u64 + 1).read_to_end(&mut bytes).ok()?;
        Self::parse(&bytes)
    }
}

static ACTIVE: RwLock<AdList> = RwLock::new(AdList { domains: Vec::new(), hashes: Vec::new() });

pub(crate) fn active() -> RwLockReadGuard<'static, AdList> {
    ACTIVE.read().unwrap_or_else(|e| e.into_inner())
}

/// Install the first valid source. A failed reload preserves the active rules.
pub(crate) fn load(profile: &str, packaged: impl FnOnce() -> Option<AdList>) -> bool {
    let override_list = if profile.is_empty() { None } else { AdList::from_file(&Path::new(profile).join("ads.txt")) };
    if let Some(list) = override_list.or_else(packaged) {
        *ACTIVE.write().unwrap_or_else(|e| e.into_inner()) = list;
        true
    } else {
        false
    }
}

#[cfg(test)]
pub(crate) fn load_test_defaults() {
    static INIT: std::sync::Once = std::sync::Once::new();
    INIT.call_once(|| {
        let path = Path::new(env!("CARGO_MANIFEST_DIR")).join("../rules/ads.txt");
        assert!(load("", || AdList::from_file(&path)));
    });
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn packaged_domains_match_the_request_table() {
        load_test_defaults();
        let list = active();
        for domain in &list.domains {
            assert!(list.contains(crate::hash::fnv1a_lower_portable(domain.as_bytes())), "{domain}");
        }
    }

    #[test]
    fn parses_and_bounds_runtime_input() {
        let list = AdList::parse("\u{feff}# ads\r\n ADS.Example \r\nads.example\n".as_bytes()).unwrap();
        assert_eq!(list.domain_count(), 1, "one domain, however often and however it is written");
        if KEEP_TEXT {
            assert_eq!(list.domains, ["ads.example"]);
        } else {
            assert!(list.domains.is_empty(), "Android, Windows and HarmonyOS keep only the hashes");
        }
        assert!(list.contains(crate::hash::fnv1a_lower(b"ads.example")));
        for bad in ["", "# only", "ok.example\n||bad.net^", "*.example", "local", "a..b", "-a.b", "a.b-", "a.b\0x"] {
            assert!(AdList::parse(bad.as_bytes()).is_none());
        }
        assert!(AdList::parse(&[0xff]).is_none());
        assert!(AdList::parse(&vec![b' '; MAX_BYTES + 1]).is_none());
        assert!(AdList::parse("a.b\n".repeat(MAX_DOMAINS + 1).as_bytes()).is_none());
    }
}
