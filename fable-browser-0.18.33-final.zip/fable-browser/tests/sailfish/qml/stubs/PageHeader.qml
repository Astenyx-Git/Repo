import QtQuick 2.0
Item {
    width: parent ? parent.width : 0; height: 80
    property string title
}
