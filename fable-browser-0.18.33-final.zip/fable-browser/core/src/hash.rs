//! FNV-1a (64-bit) with ASCII case folding. Host names are hashed with this,
//! so `Example.COM` and `example.com` land on the same table entry.

const OFFSET: u64 = 0xcbf2_9ce4_8422_2325;
const PRIME: u64 = 0x0000_0100_0000_01b3;

/// Reference implementation. Also the fallback on targets without assembly,
/// and what the blocklist table is built with (it is `const`, like Zig's).
pub const fn fnv1a_lower_portable(bytes: &[u8]) -> u64 {
    let mut h = OFFSET;
    let mut i = 0;
    while i < bytes.len() {
        let c = bytes[i];
        let c = if c.is_ascii_uppercase() { c | 0x20 } else { c };
        h ^= c as u64;
        h = h.wrapping_mul(PRIME);
        i += 1;
    }
    h
}

#[cfg(fable_native_hash)]
extern "C" {
    /// native/fnv1a_<arch>.S
    fn fable_fnv1a_lower(p: *const u8, n: usize) -> u64;
}

/// True when the assembly routine is linked in.
pub const NATIVE: bool = cfg!(fable_native_hash);

#[inline]
pub fn fnv1a_lower(bytes: &[u8]) -> u64 {
    #[cfg(fable_native_hash)]
    {
        // SAFETY: the routine reads exactly `n` bytes starting at `p`.
        unsafe { fable_fnv1a_lower(bytes.as_ptr(), bytes.len()) }
    }
    #[cfg(not(fable_native_hash))]
    {
        fnv1a_lower_portable(bytes)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn published_vectors() {
        for f in [fnv1a_lower as fn(&[u8]) -> u64, fnv1a_lower_portable] {
            assert_eq!(f(b""), 0xcbf2_9ce4_8422_2325);
            assert_eq!(f(b"a"), 0xaf63_dc4c_8601_ec8c);
            assert_eq!(f(b"foobar"), 0x8594_4171_f739_67e8);
            assert_eq!(f(b"FooBar"), f(b"foobar"));
            // Bytes just outside 'A'..='Z' must not be folded ('@'|0x20 == '`', '['|0x20 == '{').
            assert_ne!(f(b"@"), f(b"`"));
            assert_ne!(f(b"["), f(b"{"));
            assert_eq!(f(b"AZ"), f(b"az"));
        }
    }

    /// Values computed outside this crate (an independent Python FNV-1a with
    /// the same ASCII folding), so the reference itself is checked too: the
    /// comparison below would pass for any function equal to itself.
    #[test]
    fn independent_vectors() {
        let all: Vec<u8> = (0..=255u8).collect();
        let mixed: Vec<u8> = [0x80, 0xff, b'A', b'Z', b'@', b'[', b'`', b'{'].repeat(37);
        for f in [fnv1a_lower as fn(&[u8]) -> u64, fnv1a_lower_portable] {
            assert_eq!(f(&all), 0xfeb9_f659_1480_6ae5);
            assert_eq!(f(b"Stats.G.DoubleClick.NET"), 0xc914_8ff8_4b50_4947);
            assert_eq!(f(&mixed), 0x7fc2_5c07_0d63_453b);
        }
    }

    /// With the `asm` feature on an architecture that has a routine
    /// (native/fnv1a_<arch>.S), the routine must really be linked in: without
    /// it, `matches_reference_on_random_input` compares the portable hash with
    /// itself and proves nothing. CI runs the tests with `--features asm`.
    #[test]
    fn asm_feature_links_the_routine() {
        let wanted = cfg!(any(feature = "asm", feature = "zig-native"))
            && cfg!(any(target_arch = "x86_64", target_arch = "aarch64"));
        assert_eq!(NATIVE, wanted, "native hash linked: {NATIVE}, expected: {wanted}");
    }

    /// The linked routine (assembly when enabled) must agree with the
    /// reference on every byte value, every length and every alignment.
    /// Only meaningful when `NATIVE` is true; see `asm_feature_links_the_routine`.
    #[test]
    fn matches_reference_on_random_input() {
        let mut state = 0x9e37_79b9_7f4a_7c15u64;
        let mut next = || {
            state ^= state << 13;
            state ^= state >> 7;
            state ^= state << 17;
            state
        };
        let mut buf = vec![0u8; 512];
        for round in 0..2000 {
            for b in buf.iter_mut() {
                *b = next() as u8;
            }
            let start = (next() % 16) as usize;
            let len = (next() % 400) as usize;
            let slice = &buf[start..start + len];
            assert_eq!(fnv1a_lower(slice), fnv1a_lower_portable(slice), "round {round}");
        }
        let all: Vec<u8> = (0..=255u8).collect();
        assert_eq!(fnv1a_lower(&all), fnv1a_lower_portable(&all));
    }
}
