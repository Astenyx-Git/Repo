//! Tracker domains, stored as sorted 64-bit hashes.

#[cfg(feature = "zig-native")]
mod imp {
    extern "C" {
        fn fable_hostset_contains(hash: u64) -> bool;
        fn fable_hostset_len() -> usize;
    }
    pub fn contains(hash: u64) -> bool {
        unsafe { fable_hostset_contains(hash) }
    }
    pub fn len() -> usize {
        unsafe { fable_hostset_len() }
    }
}

#[cfg(not(feature = "zig-native"))]
mod imp {
    use std::sync::OnceLock;

    static LIST: &str = include_str!("../../native/trackers.txt");
    static TABLE: OnceLock<Vec<u64>> = OnceLock::new();

    fn table() -> &'static [u64] {
        TABLE.get_or_init(|| super::build_table(LIST))
    }
    pub fn contains(hash: u64) -> bool {
        table().binary_search(&hash).is_ok()
    }
    pub fn len() -> usize {
        table().len()
    }
}

/// A table the way Rust builds it: entries (the same characters the Zig build
/// trims, so both read the files the same way), hashed, sorted, without repeats.
/// Built here even with `zig-native`, where the tests compare the two.
#[cfg_attr(feature = "zig-native", allow(dead_code))]
fn build_table(list: &str) -> Vec<u64> {
    let mut t: Vec<u64> = list
        .lines()
        .map(|l| l.trim_matches(|c: char| c.is_ascii_whitespace()))
        .filter(|l| !l.is_empty() && !l.starts_with('#'))
        .map(|l| crate::hash::fnv1a_lower_portable(l.as_bytes()))
        .collect();
    t.sort_unstable();
    t.dedup();
    t
}

pub use imp::{contains, len};

/// The listed domains themselves, in file order, for shells whose engine
/// blocks by declarative rules instead of asking per request (macOS).
pub fn domains() -> impl Iterator<Item = &'static str> {
    static LIST: &str = include_str!("../../native/trackers.txt");
    LIST.lines().map(|l| l.trim_matches(|c: char| c.is_ascii_whitespace())).filter(|l| !l.is_empty() && !l.starts_with('#'))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn tracker_table_is_loaded() {
        assert!(len() >= 50, "trackers: {}", len());
    }

    #[test]
    fn a_domain_is_in_the_table_it_belongs_to() {
        use crate::hash::fnv1a_lower_portable;
        let h = fnv1a_lower_portable(b"doubleclick.net");
        assert!(contains(h));
        assert!(contains(fnv1a_lower_portable(b"hotjar.com")));
    }

    /// The tables in use (Zig's with `zig-native`) are the ones Rust builds from
    /// the same files: same length, every entry found, and nothing else found.
    #[test]
    fn tables_in_use_equal_the_rust_built_ones() {
        let table = build_table(include_str!("../../native/trackers.txt"));
        assert_eq!(len(), table.len());
        for h in &table {
            assert!(contains(*h));
            assert!(!contains(h ^ 1) || table.contains(&(h ^ 1)));
        }
        // Built from a list with a comment, blank lines, odd spacing and a repeat.
        assert_eq!(build_table("# x\n\n a.com\r\nA.COM\n\tb.com \n"), {
            let mut t = vec![crate::hash::fnv1a_lower_portable(b"a.com"), crate::hash::fnv1a_lower_portable(b"b.com")];
            t.sort_unstable();
            t
        });
    }

    #[test]
    fn the_files_hold_plain_unique_domains() {
        let list = domains().collect::<Vec<_>>();
        for d in &list {
            assert!(!d.is_empty(), "trackers: empty line");
            assert!(
                d.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'.' || b == b'-'),
                "trackers: {d} is not a plain domain"
            );
            assert!(d.contains('.'), "trackers: {d} has no dot");
        }
        let mut sorted = list.clone();
        sorted.sort_unstable();
        sorted.dedup();
        assert_eq!(sorted.len(), list.len(), "trackers: the list repeats a domain");
    }
}
