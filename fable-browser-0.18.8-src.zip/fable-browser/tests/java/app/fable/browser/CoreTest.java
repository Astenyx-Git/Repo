package app.fable.browser;

/** Runs the Android JNI bridge (Core.java + fable_jni.c) on a desktop JVM. */
public final class CoreTest {
    private static int failures;

    private static void check(boolean ok, String what) {
        if (!ok) { failures++; System.out.println("FAIL " + what); }
    }

    public static void main(String[] args) {
        check(Core.resolve("example.com").equals("https://example.com"), "resolve host");
        check(Core.resolve("").isEmpty(), "resolve blank");
        // Supplementary-plane characters must survive the JNI round trip.
        check(Core.resolve("😀 浏览器").equals("https://duckduckgo.com/?q=%F0%9F%98%80%20%E6%B5%8F%E8%A7%88%E5%99%A8"), "resolve emoji: " + Core.resolve("😀 浏览器"));
        check(Core.resolve("https://example.com/路径/😀").equals("https://example.com/路径/😀"), "url passthrough keeps non-BMP text");

        check(Core.shouldBlock("https://ad.doubleclick.net/x.gif", "https://news.example.com/"), "block third-party tracker");
        check(!Core.shouldBlock("https://news.example.com/a.js", "https://news.example.com/"), "allow first-party");
        check(!Core.shouldBlock("https://ad.doubleclick.net/x.gif", "https://www.doubleclick.net/"), "allow tracker on its own site");
        check(!Core.shouldBlock(null, null), "null urls");
        check(Core.blockedCount() == 1, "blocked count");

        // Languages: the system locale decides until the user picks one.
        Core.setSystemLocale("zh-TW");
        check(Core.language().equals("zh-Hant") && Core.tr("settings").equals("設定"), "system locale: " + Core.language());
        check(Core.newtabPage(1, "").contains("Here beginneth thy fable.") && Core.newtabPage(1, "").contains("無痕分頁"), "new-tab page text decodes as UTF-8");
        Core.settingSet("language", "ja");
        check(Core.tr("history").equals("履歴") && Core.tr("n_minutes", 5).equals("5 分"), "chosen language wins: " + Core.tr("history"));
        check(Core.readerScript().contains("data-fable-reader") && Core.readerScript().contains("\"exit\":\"終了\""), "reader script is localized");
        Core.settingSet("language", "");
        Core.setSystemLocale("fr-FR");
        check(Core.language().equals("fr") && Core.tr("settings").equals("Paramètres") && Core.tr("search_engine").equals("Moteur de recherche"), "French: " + Core.tr("settings"));
        Core.setSystemLocale("es-ES");
        check(Core.language().equals("es") && Core.tr("settings").equals("Configuración") && Core.tr("m_refresh_rate").equals("Frecuencia"), "Spanish: " + Core.tr("settings"));
        Core.setSystemLocale("ar-EG");
        check(Core.language().equals("ar") && Core.tr("settings").equals("الإعدادات") && Core.tr("m_refresh_rate").equals("التردد"), "Arabic: " + Core.tr("settings"));
        Core.setSystemLocale("de-DE");
        check(Core.tr("settings").equals("Settings"), "other languages fall back to English");
        Core.setSystemLocale("ko-KR");
        check(Core.language().equals("ko") && Core.tr("settings").equals("설정"), "Korean: " + Core.tr("settings"));
        Core.setSystemLocale("ru-RU");
        check(Core.language().equals("ru") && Core.tr("n_minutes", 5).equals("5 мин"), "Russian: " + Core.tr("n_minutes", 5));
        Core.setSystemLocale("zh-CN");

        long tabs = Core.tabsNew();
        int a = Core.tabsOpen(tabs, 0), b = Core.tabsOpen(tabs, 1_000);
        Core.tabsSetSleepAfterMs(tabs, 5_000);
        check(a == 1 && b == 2, "tab ids");
        check(Core.tabsCollectSleepers(tabs, 5_999).length == 0, "not yet idle");
        int[] sleepers = Core.tabsCollectSleepers(tabs, 6_000);
        check(sleepers.length == 1 && sleepers[0] == a, "idle background tab sleeps");
        check(Core.tabsActivate(tabs, a, 7_000) && !Core.tabsActivate(tabs, 99, 7_000), "activate");
        check(Core.tabsClose(tabs, b) && !Core.tabsClose(tabs, b), "close");
        Core.tabsFree(tabs);

        // Settings, history and generated pages, persisted in a scratch directory.
        String dir = System.getProperty("java.io.tmpdir") + "/fable-jni-test-" + System.nanoTime();
        Core.storeOpen(dir);
        check(Core.settingGet("ua_mode").isEmpty(), "unset setting");
        Core.settingSet("ua_mode", "desktop");
        Core.settingSet("ua_custom", "Mozilla/5.0 😀 测试");
        check(Core.settingGet("ua_custom").equals("Mozilla/5.0 😀 测试"), "setting round trip");
        Core.settingSet("search_template", "https://www.bing.com/search?q=%s");
        check(Core.resolve("rust 语言").equals("https://www.bing.com/search?q=rust%20%E8%AF%AD%E8%A8%80"), "search engine setting applies: " + Core.resolve("rust 语言"));
        Core.settingSet("block_trackers", "0");
        check(!Core.shouldBlock("https://ad.doubleclick.net/x.gif", "https://news.example.com/"), "blocking can be switched off");
        Core.settingSet("block_trackers", "1");
        check(Core.shouldBlock("https://ad.doubleclick.net/x.gif", "https://news.example.com/"), "and on again");

        Core.historyAdd("https://example.com/", "", 1000);
        Core.historyAdd("https://example.com/", "示例 <b>", 1200);
        Core.historyAdd("https://zh.wikipedia.org/wiki/土星", "土星", 2000);
        check(Core.historyJson("", 10).equals("[{\"t\":2000,\"u\":\"https://zh.wikipedia.org/wiki/土星\",\"n\":\"土星\"},{\"t\":1200,\"u\":\"https://example.com/\",\"n\":\"示例 \\u003cb\\u003e\"}]"), "history json: " + Core.historyJson("", 10));
        check(Core.historyJson("土星", 10).contains("\"t\":2000") && !Core.historyJson("土星", 10).contains("example.com"), "history search");
        Core.storeOpen(dir);   // reopen: everything comes back from disk
        check(Core.settingGet("ua_mode").equals("desktop"), "settings persist");
        check(Core.historyJson("", 10).contains("example.com"), "history persists");
        Core.historyDelete("https://example.com/", 1200);
        check(!Core.historyJson("", 10).contains("example.com"), "history delete");
        Core.historyClear();
        check(Core.historyJson("", 10).equals("[]"), "history clear");

        Core.settingSet("shortcuts", "[{\"n\":\"例子\",\"u\":\"https://example.com/\"}]");
        check(Core.newtabPage(0, "").contains("var SHORTCUTS = [{\"n\":\"例子\",\"u\":\"https://example.com/\"}];"), "shortcuts reach the new-tab page");
        check(Core.newtabPage(0, "{\"example.com\":[\"data:image/png;base64,AAAA\",64]}").contains("var ICONS = {\"example.com\":[\"data:image/png;base64,AAAA\",64]};"), "icons reach the new-tab page");
        check(Core.newtabPage(1, "").contains("var INCOGNITO = true;"), "private new-tab page");
        check(Core.newtabPage(2, "").contains("var INCOGNITO = \"shared\";"), "private new-tab page, cookies shared");
        check(Core.panelPage().contains("window.Fable") && Core.panelPage().contains("\"settings\":\"设置\""), "panel page is localized");
        check(Core.logoUri().startsWith("data:image/webp;base64,") && Core.newtabPage(0, "").contains(Core.logoUri()), "logo");
        check(Core.version().equals("0.18.8"), "version " + Core.version());

        // Resource sniffing through the bridge.
        check(Core.sniffNote(7, "https://cdn.example.com/电影.mp4", "range"), "sniff video");
        check(!Core.sniffNote(7, "https://cdn.example.com/电影.mp4", ""), "sniff de-duplicates");
        check(!Core.sniffNote(7, "https://cdn.example.com/app.js", ""), "sniff ignores scripts");
        check(Core.sniffNote(7, "https://img.example.com/p?id=1", "image"), "sniff image from the page");
        check(Core.sniffCount(7) == 2 && Core.sniffCount(8) == 0, "sniff count per tab");
        check(Core.sniffJson(7).equals("[{\"k\":\"video\",\"u\":\"https://cdn.example.com/电影.mp4\",\"e\":\"mp4\"},{\"k\":\"image\",\"u\":\"https://img.example.com/p?id=1\",\"e\":\"\"}]"), "sniff json: " + Core.sniffJson(7));
        Core.sniffClear(7);
        check(Core.sniffJson(7).equals("[]"), "sniff clear");
        check(Core.sniffJs().contains("document.images"), "sniff script");

        System.out.println(failures == 0 ? "jni_test: all checks passed" : failures + " check(s) failed");
        System.exit(failures == 0 ? 0 : 1);
    }
}
