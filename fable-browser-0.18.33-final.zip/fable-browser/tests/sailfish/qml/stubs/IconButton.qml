import QtQuick 2.0
MouseArea {
    width: 64; height: 64
    property alias icon: image
    property bool down: pressed
    IconSource { id: image }
}
