//! Compile-time blocklist tables.
//!
//! `trackers.txt` and `ads.txt` are embedded, parsed, hashed and sorted while
//! the compiler runs, so the shipped binary carries read-only sorted `[N]u64`
//! tables and pays no start-up cost. The Rust core calls the exported
//! functions when built with `--features zig-native`; without that feature
//! Rust builds the same tables at first use instead.
//!
//! The hash must stay identical to `fable_fnv1a_lower` (assembly) and
//! `fnv1a_lower_portable` (Rust): FNV-1a 64 with ASCII upper case folded.

const std = @import("std");

const list = @embedFile("trackers.txt");
const ads_list = @embedFile("ads.txt");

fn fnv1aLower(s: []const u8) u64 {
    var h: u64 = 0xcbf29ce484222325;
    for (s) |c| {
        const folded: u8 = if (c >= 'A' and c <= 'Z') c | 0x20 else c;
        h ^= folded;
        h *%= 0x100000001b3;
    }
    return h;
}

/// One entry of a list: the line without its ends, and not a comment.
fn entry(raw: []const u8) ?[]const u8 {
    // The same characters Rust's is_ascii_whitespace trims, so that both
    // builds read the files the same way.
    const line = std.mem.trim(u8, raw, " \t\r\n\x0c");
    if (line.len == 0 or line[0] == '#') return null;
    return line;
}

const table = blk: {
    @setEvalBranchQuota(2_000_000);
    var count: usize = 0;
    var counter = std.mem.tokenizeScalar(u8, list, '\n');
    while (counter.next()) |raw| {
        if (entry(raw) != null) count += 1;
    }
    var hashes: [count]u64 = undefined;
    var i: usize = 0;
    var lines = std.mem.tokenizeScalar(u8, list, '\n');
    while (lines.next()) |raw| {
        if (entry(raw)) |host| {
            hashes[i] = fnv1aLower(host);
            i += 1;
        }
    }
    std.mem.sort(u64, &hashes, {}, std.sort.asc(u64));
    // Repeats would make the table longer than the Rust one, so drop them.
    var distinct: usize = 0;
    var previous: u64 = 0;
    for (hashes) |h| {
        if (distinct == 0 or h != previous) distinct += 1;
        previous = h;
    }
    var unique: [distinct]u64 = undefined;
    var j: usize = 0;
    var last: u64 = 0;
    for (hashes) |h| {
        if (j == 0 or h != last) {
            unique[j] = h;
            j += 1;
        }
        last = h;
    }
    const frozen = unique;
    break :blk frozen;
};

/// The ad domains, the same way.
const ads_table = blk: {
    @setEvalBranchQuota(2_000_000);
    var count: usize = 0;
    var counter = std.mem.tokenizeScalar(u8, ads_list, '\n');
    while (counter.next()) |raw| {
        if (entry(raw) != null) count += 1;
    }
    var hashes: [count]u64 = undefined;
    var i: usize = 0;
    var lines = std.mem.tokenizeScalar(u8, ads_list, '\n');
    while (lines.next()) |raw| {
        if (entry(raw)) |host| {
            hashes[i] = fnv1aLower(host);
            i += 1;
        }
    }
    std.mem.sort(u64, &hashes, {}, std.sort.asc(u64));
    var distinct: usize = 0;
    var previous: u64 = 0;
    for (hashes) |h| {
        if (distinct == 0 or h != previous) distinct += 1;
        previous = h;
    }
    var unique: [distinct]u64 = undefined;
    var j: usize = 0;
    var last: u64 = 0;
    for (hashes) |h| {
        if (j == 0 or h != last) {
            unique[j] = h;
            j += 1;
        }
        last = h;
    }
    const frozen = unique;
    break :blk frozen;
};

/// True when `hash` is the hash of a listed domain. Binary search.
export fn fable_hostset_contains(hash: u64) bool {
    var lo: usize = 0;
    var hi: usize = table.len;
    while (lo < hi) {
        const mid = lo + (hi - lo) / 2;
        if (table[mid] < hash) lo = mid + 1 else hi = mid;
    }
    return lo < table.len and table[lo] == hash;
}

/// Number of listed domains.
export fn fable_hostset_len() usize {
    return table.len;
}

/// True when `hash` is the hash of a listed ad domain.
export fn fable_adhostset_contains(hash: u64) bool {
    var lo: usize = 0;
    var hi: usize = ads_table.len;
    while (lo < hi) {
        const mid = lo + (hi - lo) / 2;
        if (ads_table[mid] < hash) lo = mid + 1 else hi = mid;
    }
    return lo < ads_table.len and ads_table[lo] == hash;
}

/// Number of listed ad domains.
export fn fable_adhostset_len() usize {
    return ads_table.len;
}

test "hash matches the published FNV-1a vectors" {
    try std.testing.expectEqual(@as(u64, 0xcbf29ce484222325), fnv1aLower(""));
    try std.testing.expectEqual(@as(u64, 0xaf63dc4c8601ec8c), fnv1aLower("a"));
    try std.testing.expectEqual(@as(u64, 0x85944171f73967e8), fnv1aLower("foobar"));
    try std.testing.expectEqual(fnv1aLower("foobar"), fnv1aLower("FooBar"));
}

test "table lookup" {
    try std.testing.expect(table.len > 0);
    try std.testing.expect(fable_hostset_contains(fnv1aLower("doubleclick.net")));
    try std.testing.expect(fable_hostset_contains(fnv1aLower("DoubleClick.NET")));
    try std.testing.expect(!fable_hostset_contains(fnv1aLower("example.com")));
}

test "ad table lookup" {
    try std.testing.expect(ads_table.len > 0);
    try std.testing.expect(fable_adhostset_contains(fnv1aLower("doubleclick.net")));
    try std.testing.expect(fable_adhostset_contains(fnv1aLower("DoubleClick.NET")));
    try std.testing.expect(!fable_adhostset_contains(fnv1aLower("example.com")));
}
