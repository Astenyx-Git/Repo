import QtQuick 2.0
import Sailfish.Silica 1.0

// Made in harbour-fable.qml, which passes the title in and acts on the signals.
CoverBackground {
    id: cover
    property string title: ""
    signal newTab()
    signal reloadPage()

    Label {
        anchors.centerIn: parent
        width: parent.width - 2 * Theme.paddingLarge
        horizontalAlignment: Text.AlignHCenter
        wrapMode: Text.Wrap
        maximumLineCount: 4
        elide: Text.ElideRight
        text: cover.title || "Fable"
        color: Theme.highlightColor
        font.pixelSize: Theme.fontSizeLarge
    }

    CoverActionList {
        CoverAction {
            iconSource: "image://theme/icon-cover-new"
            onTriggered: cover.newTab()
        }
        CoverAction {
            iconSource: "image://theme/icon-cover-refresh"
            onTriggered: cover.reloadPage()
        }
    }
}
