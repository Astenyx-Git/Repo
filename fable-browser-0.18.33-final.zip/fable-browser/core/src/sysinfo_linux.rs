//! Linux: /proc, /sys, /etc and two libc calls (statvfs, getifaddrs).

use crate::sysinfo::{meaningful, Battery, Facts, Network, Volume};
use std::ffi::{CStr, CString};
use std::fs;
use std::os::raw::{c_char, c_int, c_uint, c_ulong, c_void};
use std::path::Path;

fn read(path: impl AsRef<Path>) -> String {
    fs::read_to_string(path).map(|s| s.trim().to_string()).unwrap_or_default()
}

fn os_release() -> String {
    let text = read("/etc/os-release");
    let text = if text.is_empty() { read("/usr/lib/os-release") } else { text };
    for line in text.lines() {
        if let Some(v) = line.strip_prefix("PRETTY_NAME=") {
            return v.trim_matches('"').to_string();
        }
    }
    "Linux".to_string()
}

#[repr(C)]
struct StatVfs {
    f_bsize: c_ulong,
    f_frsize: c_ulong,
    f_blocks: u64,
    f_bfree: u64,
    f_bavail: u64,
    f_files: u64,
    f_ffree: u64,
    f_favail: u64,
    f_fsid: c_ulong,
    f_flag: c_ulong,
    f_namemax: c_ulong,
    spare: [c_int; 6],
}

#[repr(C)]
struct IfAddrs {
    ifa_next: *mut IfAddrs,
    ifa_name: *mut c_char,
    ifa_flags: c_uint,
    ifa_addr: *mut SockAddr,
    ifa_netmask: *mut SockAddr,
    ifa_ifu: *mut SockAddr,
    ifa_data: *mut c_void,
}

#[repr(C)]
struct SockAddr {
    family: u16,
    data: [u8; 14],
}

extern "C" {
    fn statvfs(path: *const c_char, buf: *mut StatVfs) -> c_int;
    fn getifaddrs(out: *mut *mut IfAddrs) -> c_int;
    fn freeifaddrs(list: *mut IfAddrs);
}

const AF_INET: u16 = 2;
const AF_INET6: u16 = 10;
const IFF_LOOPBACK: c_uint = 0x8;

/// (total, available to the user) bytes of the file system holding `path`.
fn disk(path: &str) -> Option<(u64, u64)> {
    let c = CString::new(path).ok()?;
    let mut st: StatVfs = unsafe { std::mem::zeroed() };
    if unsafe { statvfs(c.as_ptr(), &mut st) } != 0 {
        return None;
    }
    let unit = if st.f_frsize > 0 { st.f_frsize as u64 } else { st.f_bsize as u64 };
    Some((st.f_blocks * unit, st.f_bavail * unit))
}

fn prefix_len(mask: &[u8]) -> u32 {
    mask.iter().map(|b| b.count_ones()).sum()
}

/// Addresses of one interface as "addr/prefix", IPv4 first.
fn addresses(iface: &str) -> Vec<String> {
    let mut v4 = Vec::new();
    let mut v6 = Vec::new();
    let mut list: *mut IfAddrs = std::ptr::null_mut();
    if unsafe { getifaddrs(&mut list) } != 0 {
        return v4;
    }
    let mut cur = list;
    while !cur.is_null() {
        let ifa = unsafe { &*cur };
        cur = ifa.ifa_next;
        if ifa.ifa_addr.is_null() || ifa.ifa_name.is_null() || ifa.ifa_flags & IFF_LOOPBACK != 0 {
            continue;
        }
        let name = unsafe { CStr::from_ptr(ifa.ifa_name) }.to_string_lossy();
        if name != iface {
            continue;
        }
        let family = unsafe { (*ifa.ifa_addr).family };
        let raw = ifa.ifa_addr as *const u8;
        let mask = ifa.ifa_netmask as *const u8;
        if family == AF_INET {
            let a = unsafe { std::slice::from_raw_parts(raw.add(4), 4) };
            let bits = if mask.is_null() { 32 } else { prefix_len(unsafe { std::slice::from_raw_parts(mask.add(4), 4) }) };
            v4.push(format!("{}.{}.{}.{}/{}", a[0], a[1], a[2], a[3], bits));
        } else if family == AF_INET6 {
            let a = unsafe { std::slice::from_raw_parts(raw.add(8), 16) };
            let bits = if mask.is_null() { 128 } else { prefix_len(unsafe { std::slice::from_raw_parts(mask.add(8), 16) }) };
            let mut seg = [0u16; 8];
            for i in 0..8 {
                seg[i] = u16::from_be_bytes([a[2 * i], a[2 * i + 1]]);
            }
            v6.push(format!("{}/{}", std::net::Ipv6Addr::from(seg), bits));
        }
    }
    unsafe { freeifaddrs(list) };
    v4.extend(v6);
    v4
}

/// The interface the default route leaves through.
fn default_iface() -> Option<String> {
    let routes = read("/proc/net/route");
    for line in routes.lines().skip(1) {
        let cols: Vec<&str> = line.split_whitespace().collect();
        if cols.len() > 2 && cols[1] == "00000000" {
            return Some(cols[0].to_string());
        }
    }
    let routes6 = read("/proc/net/ipv6_route");
    for line in routes6.lines() {
        let cols: Vec<&str> = line.split_whitespace().collect();
        if cols.len() == 10 && cols[0] == "00000000000000000000000000000000" && cols[1] == "00" && cols[9] != "lo" {
            return Some(cols[9].to_string());
        }
    }
    None
}

fn network() -> Network {
    let mut n = Network::default();
    let Some(iface) = default_iface() else {
        n.offline = true;
        return n;
    };
    let sys = Path::new("/sys/class/net").join(&iface);
    if sys.join("wireless").exists() || sys.join("phy80211").exists() {
        n.transports.push("wifi");
    } else if ["tun", "tap", "wg", "ppp", "utun", "ipsec"].iter().any(|p| iface.starts_with(p)) {
        n.transports.push("vpn");
    } else {
        n.transports.push("ethernet");
    }
    n.mtu = read(sys.join("mtu")).parse().ok();
    n.addresses = addresses(&iface);
    // systemd-resolved answers on 127.0.0.53; the servers it asks are listed here.
    let mut resolv = read("/run/systemd/resolve/resolv.conf");
    if resolv.is_empty() {
        resolv = read("/etc/resolv.conf");
    }
    for line in resolv.lines() {
        if let Some(server) = line.trim().strip_prefix("nameserver") {
            let server = server.trim().to_string();
            if !server.is_empty() && !n.dns.contains(&server) {
                n.dns.push(server);
            }
        }
    }
    if n.transports == ["wifi"] {
        // /proc/net/wireless: "wlan0: 0000   54.  -56.  -256 ..." (link, level in dBm)
        for line in read("/proc/net/wireless").lines().skip(2) {
            if let Some((name, rest)) = line.split_once(':') {
                if name.trim() == iface {
                    n.rssi = rest.split_whitespace().nth(2).and_then(|v| v.trim_end_matches('.').parse::<f64>().ok()).map(|v| v as i32);
                }
            }
        }
    }
    n.iface = iface;
    n
}

fn battery() -> Option<Battery> {
    let dir = fs::read_dir("/sys/class/power_supply").ok()?;
    let mut battery = None;
    let mut on_ac = None;
    for entry in dir.flatten() {
        let p = entry.path();
        match read(p.join("type")).as_str() {
            "Battery" if read(p.join("scope")) != "Device" && battery.is_none() => {
                let status = match read(p.join("status")).as_str() {
                    "Charging" => "charging",
                    "Discharging" => "discharging",
                    "Full" => "full",
                    "Not charging" => "not_charging",
                    _ => "",
                };
                let micro = |name: &str| read(p.join(name)).parse::<u64>().ok().filter(|v| *v > 0);
                battery = Some(Battery {
                    level: read(p.join("capacity")).parse().ok(),
                    status,
                    tech: read(p.join("technology")).replace("Unknown", ""),
                    cycles: read(p.join("cycle_count")).parse().ok().filter(|c| *c > 0),
                    voltage_mv: micro("voltage_now").map(|v| (v / 1000) as u32),
                    temp_c: read(p.join("temp")).parse::<f64>().ok().map(|t| t / 10.0),
                    ..Default::default()
                });
            }
            "Mains" | "USB" => {
                if read(p.join("online")) == "1" {
                    on_ac = Some(true);
                } else if on_ac.is_none() {
                    on_ac = Some(false);
                }
            }
            _ => {}
        }
    }
    let mut b = battery?;
    if let Some(ac) = on_ac {
        b.plugged = if ac { "ac" } else { "none" };
    }
    Some(b)
}

fn cpu(f: &mut Facts) {
    let info = read("/proc/cpuinfo");
    let mut flags = String::new();
    for line in info.lines() {
        let Some((key, value)) = line.split_once(':') else { continue };
        let (key, value) = (key.trim(), value.trim());
        match key {
            "model name" | "Model" | "Hardware" if f.cpu_name.is_empty() => f.cpu_name = value.to_string(),
            "flags" | "Features" if flags.is_empty() => flags = value.to_string(),
            _ => {}
        }
    }
    if f.cpu_name.is_empty() {
        f.cpu_name = read("/proc/device-tree/model").trim_end_matches('\0').to_string();
    }
    f.flags = flags;
    // Cores grouped by their top clock: one group on most PCs, two or three on
    // hybrid chips (performance and efficiency cores).
    let mut by_mhz: Vec<(u32, u32)> = Vec::new(); // (mhz, count)
    for i in 0..f.cores.max(1) {
        let khz: u32 = read(format!("/sys/devices/system/cpu/cpu{i}/cpufreq/cpuinfo_max_freq")).parse().unwrap_or(0);
        if khz == 0 {
            continue;
        }
        let mhz = khz / 1000;
        match by_mhz.iter_mut().find(|(m, _)| *m == mhz) {
            Some((_, n)) => *n += 1,
            None => by_mhz.push((mhz, 1)),
        }
    }
    by_mhz.sort();
    let single = by_mhz.len() == 1;
    f.clusters = by_mhz.into_iter().map(|(mhz, count)| (count, mhz, if single { f.cpu_name.clone() } else { String::new() })).collect();
}

fn volumes(f: &mut Facts) {
    let real = ["ext2", "ext3", "ext4", "btrfs", "xfs", "f2fs", "zfs", "vfat", "exfat", "ntfs", "ntfs3", "fuseblk", "hfsplus", "apfs", "bcachefs"];
    let mut seen = std::collections::HashSet::new();
    for line in read("/proc/self/mounts").lines() {
        let cols: Vec<&str> = line.split_whitespace().collect();
        if cols.len() < 3 || !real.contains(&cols[2]) || !seen.insert(cols[0].to_string()) {
            continue;
        }
        let point = cols[1].replace("\\040", " ");
        if point.starts_with("/snap/") || point.starts_with("/boot") || point.starts_with("/var/lib/") {
            continue;
        }
        f.volumes.push(Volume {
            primary: point == "/",
            removable: point.starts_with("/media/") || point.starts_with("/run/media/") || point.starts_with("/mnt/"),
            fs: cols[2].to_string(),
            name: point,
        });
    }
}

/// (vendor name, device name) for hex ids such as ("10de", "2684") in a pci.ids file.
fn pci_name(ids: &str, vendor: &str, device: &str) -> (String, String) {
    let (mut vname, mut dname) = (String::new(), String::new());
    let mut in_vendor = false;
    for line in ids.lines() {
        if line.starts_with('#') || line.is_empty() {
            continue;
        }
        if !line.starts_with('\t') {
            if in_vendor {
                break;
            }
            if line.len() > 6 && line.is_char_boundary(4) && line[..4].eq_ignore_ascii_case(vendor) {
                vname = line[4..].trim().to_string();
                in_vendor = true;
            }
        } else if in_vendor && !line.starts_with("\t\t") && line.len() > 7 && line.is_char_boundary(5) && line[1..5].eq_ignore_ascii_case(device) {
            dname = line[5..].trim().to_string();
        }
    }
    (vname, dname)
}

#[cfg(test)]
#[test]
fn pci_ids_are_read() {
    let ids = "# comment\n1002  Advanced Micro Devices, Inc. [AMD/ATI]\n\t15bf  Phoenix1\n10de  NVIDIA Corporation\n\t2684  AD102 [GeForce RTX 4090]\n\t\t1043 88e2  ROG Strix\n\t2704  AD103 [GeForce RTX 4080]\n8086  Intel Corporation\n";
    assert_eq!(pci_name(ids, "10de", "2684"), ("NVIDIA Corporation".into(), "AD102 [GeForce RTX 4090]".into()));
    assert_eq!(pci_name(ids, "1002", "15BF"), ("Advanced Micro Devices, Inc. [AMD/ATI]".into(), "Phoenix1".into()));
    assert_eq!(pci_name(ids, "10de", "9999"), ("NVIDIA Corporation".into(), String::new()));
    assert_eq!(pci_name(ids, "abcd", "0001"), (String::new(), String::new()));
}

/// Display controllers on the PCI bus, named from the pci.ids database when it
/// is installed; on boards without PCI graphics, the DRM driver's name.
fn gpu(f: &mut Facts) {
    let ids = ["/usr/share/hwdata/pci.ids", "/usr/share/misc/pci.ids", "/usr/share/pci.ids"].iter().map(read).find(|t| !t.is_empty()).unwrap_or_default();
    let lookup = |vendor: &str, device: &str| pci_name(&ids, vendor, device);
    let known = |v: &str| match v { "8086" => "Intel", "10de" => "NVIDIA", "1002" => "AMD", "1af4" => "Red Hat (virtio)", "15ad" => "VMware", "1234" => "QEMU", "1414" => "Microsoft", _ => "" };
    let mut names = Vec::new();
    let mut vendors = Vec::new();
    if let Ok(dir) = fs::read_dir("/sys/bus/pci/devices") {
        let mut devices: Vec<_> = dir.flatten().map(|e| e.path()).collect();
        devices.sort();
        for p in devices {
            if !read(p.join("class")).starts_with("0x03") {
                continue;
            }
            let vendor = read(p.join("vendor")).trim_start_matches("0x").to_lowercase();
            let device = read(p.join("device")).trim_start_matches("0x").to_lowercase();
            let (vname, dname) = lookup(&vendor, &device);
            let vname = if vname.is_empty() { known(&vendor).to_string() } else { vname };
            let short = vname.split(" Corporation").next().unwrap_or(&vname).replace(" [AMD/ATI]", "").replace("Advanced Micro Devices, Inc.", "AMD").trim().to_string();
            names.push(if dname.is_empty() { format!("{short} {vendor}:{device}").trim().to_string() } else { format!("{short} {dname}") });
            if !vendors.contains(&short) && !short.is_empty() {
                vendors.push(short);
            }
        }
    }
    if names.is_empty() {
        if let Ok(link) = fs::read_link("/sys/class/drm/card0/device/driver") {
            if let Some(name) = link.file_name() {
                names.push(name.to_string_lossy().to_string());
            }
        }
    }
    f.gpu = names.join(" + ");
    f.gpu_vendor = vendors.join(" + ");
}

pub fn fill(f: &mut Facts) {
    f.os = os_release();
    f.kernel = read("/proc/sys/kernel/osrelease");
    f.kernel_full = read("/proc/version");
    f.hostname = read("/proc/sys/kernel/hostname");
    let dmi = |name: &str| meaningful(&read(Path::new("/sys/class/dmi/id").join(name)));
    f.manufacturer = dmi("sys_vendor");
    f.model = {
        let name = dmi("product_name");
        let version = dmi("product_version");
        // Lenovo puts the marketing name in product_version ("ThinkPad X1 Carbon Gen 11").
        if f.manufacturer.eq_ignore_ascii_case("LENOVO") && !version.is_empty() { version } else { name }
    };
    if f.model.is_empty() {
        f.model = read("/proc/device-tree/model").trim_end_matches('\0').to_string();
    }
    f.board = dmi("board_name");
    let bios = [dmi("bios_vendor"), dmi("bios_version"), dmi("bios_date")].into_iter().filter(|s| !s.is_empty()).collect::<Vec<_>>();
    f.firmware = bios.join(" · ");
    cpu(f);
    gpu(f);
    let meminfo = read("/proc/meminfo");
    let kb = |key: &str| -> u64 {
        meminfo.lines().find_map(|l| l.strip_prefix(key)).and_then(|v| v.trim().trim_end_matches("kB").trim().parse::<u64>().ok()).unwrap_or(0) * 1024
    };
    f.mem_total = kb("MemTotal:");
    f.mem_avail = kb("MemAvailable:");
    if let Some((total, free)) = disk("/") {
        f.disk_total = total;
        f.disk_free = free;
    }
    volumes(f);
    f.battery = battery();
    f.network = Some(network());
    f.uptime_ms = read("/proc/uptime").split_whitespace().next().and_then(|s| s.parse::<f64>().ok()).map(|s| (s * 1000.0) as u64).unwrap_or(0);
    f.locales = std::env::var("LANGUAGE").ok().filter(|s| !s.is_empty()).or_else(|| std::env::var("LANG").ok()).unwrap_or_default().replace(':', ",");
}
