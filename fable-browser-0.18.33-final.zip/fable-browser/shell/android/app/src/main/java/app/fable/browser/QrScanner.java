package app.fable.browser;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.graphics.SurfaceTexture;
import android.graphics.drawable.GradientDrawable;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.util.Size;
import android.view.Gravity;
import android.view.View;
import android.view.Surface;
import android.view.TextureView;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * The camera screen behind the menu's "scan" tile.
 *
 * Android's WebView has no QR detector of its own, so the frames go to the
 * Rust core: the rear camera's Y plane is handed to {@link Core#decodeQr} off
 * the UI thread and the first payload it reads wins. One code, then the screen
 * closes itself and the shell decides what the text is (a web address opens,
 * anything else is shown first).
 *
 * Kept in a class of its own, like {@link FullscreenVideo}, so the wiring in
 * MainActivity stays a few lines. The viewfinder, the camera session and the
 * decode all live here; the shell only sees the three callbacks.
 */
final class QrScanner {
    interface Listener {
        /** A code was read; the screen has already closed. */
        void onQr(String text);

        /** The user closed the screen without a code. */
        void onCancel();

        /** There is no camera, or it could not be opened. */
        void onUnavailable();
    }

    private static final int SPARK = 0xFFD9512C;
    /** The core's pixel cap is 4,194,304; stay under it with room to spare. */
    private static final long MAX_AREA = 4_000_000L;

    private final Activity activity;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final AtomicBoolean closed = new AtomicBoolean(false);
    private final AtomicBoolean decoded = new AtomicBoolean(false);

    private HandlerThread thread;
    private Handler background;
    private FrameLayout overlay;
    private TextureView preview;
    private View frame;
    private Size previewSize;
    private String cameraId;
    private CameraDevice camera;
    private CameraCaptureSession session;
    private ImageReader reader;
    private byte[] frameBuffer;   // the Y plane is copied into this, so frames do not allocate

    QrScanner(Activity activity, Listener listener) {
        this.activity = activity;
        this.listener = listener;
    }

    boolean isShowing() {
        return overlay != null;
    }

    /** Show the screen and start the camera. Safe to call again while showing. */
    void show() {
        if (overlay != null) return;
        closed.set(false);
        decoded.set(false);
        build();
        ((ViewGroup) activity.getWindow().getDecorView()).addView(overlay,
                new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        thread = new HandlerThread("fable-qr");
        thread.start();
        background = new Handler(thread.getLooper());
        SurfaceTexture texture = preview.getSurfaceTexture();
        if (preview.isAvailable() && texture != null) open(texture);
    }

    /** Close the screen and release the camera. Safe to call from any thread. */
    void hide() {
        if (Looper.myLooper() != main.getLooper()) {
            main.post(this::hide);
            return;
        }
        if (!closed.compareAndSet(false, true)) return;
        try {
            if (session != null) session.stopRepeating();
        } catch (Exception ignored) {
            // already closed, or the camera went away
        }
        try {
            if (session != null) session.close();
        } catch (Exception ignored) {
        }
        session = null;
        if (reader != null) reader.close();
        reader = null;
        if (camera != null) camera.close();
        camera = null;
        if (overlay != null) {
            preview.setSurfaceTextureListener(null);
            if (overlay.getParent() != null) ((ViewGroup) overlay.getParent()).removeView(overlay);
        }
        overlay = null;
        preview = null;
        frame = null;
        if (thread != null) thread.quitSafely();
        thread = null;
        background = null;
    }

    /** The viewfinder, over a black preview, with the title, hint and a way out. */
    private void build() {
        final float dp = activity.getResources().getDisplayMetrics().density;
        overlay = new FrameLayout(activity);
        overlay.setBackgroundColor(Color.BLACK);

        preview = new TextureView(activity);
        preview.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override public void onSurfaceTextureAvailable(SurfaceTexture texture, int width, int height) {
                open(texture);
            }

            @Override public void onSurfaceTextureSizeChanged(SurfaceTexture texture, int width, int height) {
                configureTransform(width, height);
            }

            @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture texture) {
                return true;
            }

            @Override public void onSurfaceTextureUpdated(SurfaceTexture texture) {
            }
        });
        overlay.addView(preview, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // The title sits at the top, as on iOS; the frame and the hint are the centred group.
        TextView title = new TextView(activity);
        title.setText(Core.tr("scan_title"));
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams titleParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        titleParams.topMargin = Math.round(dp * 20);
        overlay.addView(title, titleParams);

        LinearLayout box = new LinearLayout(activity);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);

        // The frame is a stroke only: the preview shows through it, as on iOS.
        frame = new View(activity);
        GradientDrawable border = new GradientDrawable();
        border.setShape(GradientDrawable.RECTANGLE);
        border.setCornerRadius(dp * 16);
        border.setStroke(Math.round(dp * 2), SPARK);
        frame.setBackground(border);
        box.addView(frame, new LinearLayout.LayoutParams(Math.round(dp * 240), Math.round(dp * 240)));

        TextView hint = new TextView(activity);
        hint.setText(Core.tr("scan_hint"));
        hint.setTextColor(0xDDFFFFFF);
        hint.setTextSize(15);
        hint.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams hintParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        hintParams.topMargin = Math.round(dp * 16);
        box.addView(hint, hintParams);

        overlay.addView(box, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER));

        TextView cancel = new TextView(activity);
        cancel.setText(Core.tr("cancel"));
        cancel.setTextColor(Color.WHITE);
        cancel.setTextSize(17);
        cancel.setGravity(Gravity.CENTER);
        cancel.setPadding(Math.round(dp * 28), Math.round(dp * 12), Math.round(dp * 28), Math.round(dp * 12));
        GradientDrawable fill = new GradientDrawable();
        fill.setShape(GradientDrawable.RECTANGLE);
        fill.setCornerRadius(dp * 24);
        fill.setColor(0x33FFFFFF);
        cancel.setBackground(fill);
        cancel.setOnClickListener(v -> {
            hide();
            listener.onCancel();
        });
        FrameLayout.LayoutParams cancelParams = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        cancelParams.bottomMargin = Math.round(dp * 32);
        overlay.addView(cancel, cancelParams);

        final View frameView = frame;
        overlay.addOnLayoutChangeListener((v, left, top, right, bottom, oLeft, oTop, oRight, oBottom) -> {
            int side = Math.round(Math.min(right - left, bottom - top) * 0.7f);
            LinearLayout.LayoutParams p = (LinearLayout.LayoutParams) frameView.getLayoutParams();
            if (p.width != side) {
                p.width = side;
                p.height = side;
                frameView.setLayoutParams(p);
            }
            configureTransform(right - left, bottom - top);
        });
    }

    // ---- camera ----

    private void open(SurfaceTexture texture) {
        if (closed.get()) return;
        CameraManager manager = (CameraManager) activity.getSystemService(Context.CAMERA_SERVICE);
        if (manager == null) {
            unavailable();
            return;
        }
        try {
            cameraId = pickCamera(manager);
            if (cameraId == null) {
                unavailable();
                return;
            }
            manager.openCamera(cameraId, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice device) {
                    if (closed.get()) {
                        device.close();
                        return;
                    }
                    camera = device;
                    startSession(texture);
                }

                @Override public void onDisconnected(CameraDevice device) {
                    device.close();
                    unavailable();
                }

                @Override public void onError(CameraDevice device, int error) {
                    device.close();
                    unavailable();
                }
            }, background);
        } catch (CameraAccessException | RuntimeException noCamera) {   // the camera is in use, or went away
            unavailable();
        }
    }

    /** The first camera that is not front-facing, or any camera if that is all there is. */
    private static String pickCamera(CameraManager manager) {
        try {
            String any = null;
            for (String id : manager.getCameraIdList()) {
                CameraCharacteristics c = manager.getCameraCharacteristics(id);
                Integer facing = c.get(CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == CameraCharacteristics.LENS_FACING_FRONT) {
                    if (any == null) any = id;
                    continue;
                }
                return id;
            }
            return any;
        } catch (CameraAccessException | IllegalArgumentException unavailable) {
            return null;
        }
    }

    private void startSession(SurfaceTexture texture) {
        if (closed.get() || camera == null) return;
        try {
            CameraManager manager = (CameraManager) activity.getSystemService(Context.CAMERA_SERVICE);
            CameraCharacteristics c = manager.getCameraCharacteristics(cameraId);
            StreamConfigurationMap map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            if (map == null) {
                unavailable();
                return;
            }
            Size yuv = choose(map.getOutputSizes(ImageFormat.YUV_420_888), 1280, 720);
            Size shown = choose(map.getOutputSizes(SurfaceTexture.class), yuv == null ? 1280 : yuv.getWidth(), yuv == null ? 720 : yuv.getHeight());
            if (yuv == null || shown == null) {
                unavailable();
                return;
            }
            previewSize = shown;
            // The view's size and the camera's size arrive independently; apply the transform
            // once both are known (the layout listener covers the other order). The view is
            // captured: hide() may have cleared the field before this runs.
            TextureView view = preview;
            view.post(() -> configureTransform(view.getWidth(), view.getHeight()));
            texture.setDefaultBufferSize(shown.getWidth(), shown.getHeight());
            Surface previewSurface = new Surface(texture);
            reader = ImageReader.newInstance(yuv.getWidth(), yuv.getHeight(), ImageFormat.YUV_420_888, 2);
            reader.setOnImageAvailableListener(this::onImage, background);
            Surface readerSurface = reader.getSurface();
            camera.createCaptureSession(Arrays.asList(previewSurface, readerSurface), new CameraCaptureSession.StateCallback() {
                @Override public void onConfigured(CameraCaptureSession capture) {
                    if (closed.get() || camera == null) {
                        capture.close();
                        return;
                    }
                    session = capture;
                    try {
                        CaptureRequest.Builder b = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                        b.addTarget(previewSurface);
                        b.addTarget(readerSurface);
                        setFocus(b, c);
                        capture.setRepeatingRequest(b.build(), null, background);
                    } catch (CameraAccessException | RuntimeException failed) {
                        unavailable();
                    }
                }

                @Override public void onConfigureFailed(CameraCaptureSession capture) {
                    unavailable();
                }
            }, background);
        } catch (CameraAccessException | RuntimeException noCamera) {   // the camera is in use, or went away
            unavailable();
        }
    }

    /** Continuous focus where the camera has it, so a code comes in sharp. */
    private static void setFocus(CaptureRequest.Builder b, CameraCharacteristics c) {
        int[] modes = c.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES);
        if (modes == null) return;
        int[] wanted = {CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE,
                CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO,
                CaptureRequest.CONTROL_AF_MODE_AUTO};
        for (int mode : wanted) {
            for (int available : modes) {
                if (available == mode) {
                    b.set(CaptureRequest.CONTROL_AF_MODE, mode);
                    return;
                }
            }
        }
    }

    /** The supported size closest to the target area, never over the core's pixel cap. */
    private static Size choose(Size[] sizes, int targetWidth, int targetHeight) {
        if (sizes == null || sizes.length == 0) return null;
        long target = (long) targetWidth * targetHeight;
        Size best = null;
        long bestScore = Long.MAX_VALUE;
        for (Size s : sizes) {
            long area = (long) s.getWidth() * s.getHeight();
            if (area > MAX_AREA) continue;
            long score = Math.abs(area - target);
            if (score < bestScore) {
                bestScore = score;
                best = s;
            }
        }
        if (best == null) {   // every size is over the cap: the smallest of them
            for (Size s : sizes) {
                long area = (long) s.getWidth() * s.getHeight();
                if (best == null || area < (long) best.getWidth() * best.getHeight()) best = s;
            }
        }
        return best;
    }

    /** One frame: the Y plane to the core, off the UI thread. */
    private void onImage(ImageReader source) {
        Image image = null;
        try {
            image = source.acquireLatestImage();
            if (image == null || closed.get() || decoded.get()) return;
            Image.Plane[] planes = image.getPlanes();
            if (planes.length == 0) return;
            Image.Plane plane = planes[0];
            ByteBuffer buffer = plane.getBuffer();
            int length = buffer.remaining();
            if (frameBuffer == null || frameBuffer.length < length) frameBuffer = new byte[length];
            byte[] data = frameBuffer;
            buffer.get(data, 0, length);
            byte[] payload = Core.decodeQr(data, image.getWidth(), image.getHeight(),
                    plane.getRowStride(), plane.getPixelStride());
            if (payload != null && payload.length > 0 && decoded.compareAndSet(false, true)) {
                final String text = text(payload);
                main.post(() -> {
                    if (closed.get()) return;
                    hide();
                    listener.onQr(text);
                });
            }
        } catch (RuntimeException unreadable) {
            // A frame the core cannot read: the next one may still carry the code.
        } finally {
            if (image != null) image.close();
        }
    }

    /**
     * A payload as text. QR codes carry UTF-8 almost everywhere, but many made in
     * China use GBK, which GB18030 covers; the standard's own default, ISO-8859-1,
     * takes whatever is left (it maps every byte).
     */
    static String text(byte[] payload) {
        for (Charset charset : new Charset[] {StandardCharsets.UTF_8, Charset.forName("GB18030")}) {
            try {
                return charset.newDecoder()
                        .onMalformedInput(CodingErrorAction.REPORT)
                        .onUnmappableCharacter(CodingErrorAction.REPORT)
                        .decode(ByteBuffer.wrap(payload)).toString();
            } catch (CharacterCodingException notThisOne) {
                // try the next
            }
        }
        return new String(payload, StandardCharsets.ISO_8859_1);
    }

    /** Turn the camera's landscape buffer upright for the screen. */
    private void configureTransform(int viewWidth, int viewHeight) {
        if (preview == null || previewSize == null || viewWidth == 0 || viewHeight == 0) return;
        int rotation = activity.getWindowManager().getDefaultDisplay().getRotation();
        Matrix matrix = new Matrix();
        RectF viewRect = new RectF(0, 0, viewWidth, viewHeight);
        RectF bufferRect = new RectF(0, 0, previewSize.getHeight(), previewSize.getWidth());
        float centerX = viewRect.centerX();
        float centerY = viewRect.centerY();
        if (rotation == Surface.ROTATION_90 || rotation == Surface.ROTATION_270) {
            bufferRect.offset(centerX - bufferRect.centerX(), centerY - bufferRect.centerY());
            matrix.setRectToRect(viewRect, bufferRect, Matrix.ScaleToFit.FILL);
            float scale = Math.max((float) viewHeight / previewSize.getHeight(),
                    (float) viewWidth / previewSize.getWidth());
            matrix.postScale(scale, scale, centerX, centerY);
            matrix.postRotate(90 * (rotation - 2), centerX, centerY);
        } else if (rotation == Surface.ROTATION_180) {
            matrix.postRotate(180, centerX, centerY);
        }
        preview.setTransform(matrix);
    }

    private void unavailable() {
        main.post(() -> {
            if (closed.get()) return;
            hide();
            listener.onUnavailable();
        });
    }
}
