/*
 * BrowserPage - the browser: address bar, one WebView, toolbar, and the panel.
 *
 * One WebView for every tab: a Gecko view is heavy, so only the tab in front is
 * loaded, and switching tabs loads the other tab's address (its scroll position
 * and form state are not kept). The view is made again when the tab in front
 * changes between normal and private, since privateMode is fixed when a view
 * is made, and when the user agent changes. Gecko keeps a private session only
 * while a private view exists: leaving the private tabs for a normal one ends
 * their cookies and logins.
 *
 * Tabs are {id, url, title, incognito}; url "" is the new-tab page. QML
 * JavaScript here is ES5: Sailfish OS ships Qt 5.6.
 */
import QtQuick 2.0
import Sailfish.Silica 1.0
import Sailfish.WebView 1.0
import Sailfish.Pickers 1.0
import harbour.fable.Core 1.0

WebViewPage {
    id: page
    allowedOrientations: Orientation.All
    backNavigation: false

    property var tabs: []
    property int front: -1             // index of the tab in front
    property int tabCount: 0
    property int nextId: 1
    property int lastNormal: 0         // id of the normal tab to come back to when private tabs close
    property int lastPrivate: 0
    property bool incognito: false     // the WebView in place is a private one
    property bool expectHome: false    // the WebView was last told to show the new-tab page
    property bool homeShown: false     // ... and shows it now
    property bool homeButton: Fable.settingGet("home_button") === "1"
    property string coverTitle: Fable.tr("brand_name")
    property Item web: webLoader.item
    property var ipRequest: null

    // ---- tabs -----------------------------------------------------------------

    function current() { return front >= 0 && front < tabs.length ? tabs[front] : null; }
    function frontId() { var t = current(); return t ? t.id : 0; }

    function indexOf(id) {
        for (var i = 0; i < tabs.length; ++i) if (tabs[i].id === id) return i;
        return -1;
    }

    function titleOf(t) { return t.url ? (t.title || t.url) : Fable.tr("newtab"); }

    // A string of the language in use: bindings that call this follow a change of language.
    function tr(key) { return Fable.language !== undefined ? Fable.tr(key) : ""; }

    function anyPrivate() {
        for (var i = 0; i < tabs.length; ++i) if (tabs[i].incognito) return true;
        return false;
    }

    // Typed text or a link to the address to open: "" when there is none, or when it
    // would open another app and the user blocks that (block_external_apps).
    function addressFor(input) {
        var url = input ? Fable.resolve(input) : "";
        var skin = url ? Fable.themeApply(url) : -1;
        if (skin >= 0) {
            // theme://name: a skin, not a page, and nothing is said; a name that is no skin
            // changes nothing. Fable's own pages (the new-tab page, the panel, reader mode)
            // take its colours and logo; the bars are Silica's, which follow the ambience,
            // and Sailfish OS has no way for an app to change its own launcher icon.
            if (skin === 1) {
                if (homeShown) load();
                panel.reload();
                changed();
            }
            return "";
        }
        if (url && Fable.blockExternalApp(url)) {
            toast(Fable.tr("external_app_blocked"));
            return "";
        }
        return url;
    }

    function openTab(input, priv) {
        var url = "";
        if (input) {
            url = addressFor(input);
            if (!url) return null;
        }
        var t = { id: nextId++, url: url, title: "", incognito: !!priv };
        tabs.push(t);
        show(tabs.length - 1);
        saveSession();
        return t;
    }

    function show(i) {
        if (i < 0 || i >= tabs.length) return;
        front = i;
        var t = tabs[i];
        if (t.incognito) lastPrivate = t.id; else lastNormal = t.id;
        if (!webLoader.item || t.incognito !== incognito) rebuild();
        else load();
        changed();
    }

    function closeTab(id) {
        var i = indexOf(id);
        if (i < 0) return;
        var wasFront = i === front;
        Fable.sniffClear(id);
        tabs.splice(i, 1);
        if (i < front) front--;
        if (!tabs.length) {
            front = -1;
            openTab("", false);
            return;
        }
        if (wasFront) show(Math.min(i, tabs.length - 1));
        else changed();
        saveSession();
    }

    function enterPrivate() {
        var i = indexOf(lastPrivate);
        if (i < 0) for (var j = tabs.length - 1; j >= 0 && i < 0; --j) if (tabs[j].incognito) i = j;
        if (i >= 0) show(i); else openTab("", true);
    }

    // Close every private tab; the private view goes with them, and Gecko its data.
    function exitPrivate() {
        var wasPrivate = !!current() && current().incognito, keep = [];
        for (var i = 0; i < tabs.length; ++i) {
            if (tabs[i].incognito) Fable.sniffClear(tabs[i].id); else keep.push(tabs[i]);
        }
        var frontTab = current();
        tabs = keep;
        front = frontTab ? tabs.indexOf(frontTab) : -1;
        if (wasPrivate || front < 0) {
            var n = indexOf(lastNormal);
            if (n < 0) n = tabs.length - 1;
            if (n >= 0) show(n); else openTab("", false);
        } else {
            changed();
        }
        toast(Fable.tr("private_closed"));
    }

    // ---- the WebView ---------------------------------------------------------------

    function rebuild() {
        var t = current();
        incognito = t ? t.incognito : false;
        webLoader.active = false;
        webLoader.active = true;    // onLoaded: load()
    }

    // Show the tab in front: its page, or the new-tab page.
    function load() {
        var t = current(), view = webLoader.item;
        if (!t || !view) return;
        Fable.sniffClear(t.id);
        expectHome = !t.url;
        if (t.url) view.load(t.url);
        else view.loadHtml(Panel.homeHtml(t.incognito), Panel.homeUrl());
        syncAddress();
    }

    // In the tab in front.
    function navigate(input) {
        var t = current();
        if (!t) { openTab(input, false); return; }
        var url = addressFor(input);
        if (!url) return;
        t.url = url;
        t.title = "";
        load();
        changed();
    }

    function reloadPage() {
        var t = current();
        if (t && t.url && web) web.reload(); else load();
    }

    function pageMoved() {
        var t = current();
        if (!t || !web) return;
        var url = String(web.url || "");
        if (Panel.isWeb(url)) {
            expectHome = false;
            t.url = url;
        } else if (Panel.isHome(url)) {   // back to it, too
            expectHome = true;
            t.url = "";
            t.title = "";
        }
        // A web page is never the new-tab page, whatever it queued (see the drain below).
        homeShown = expectHome && !Panel.isWeb(url);
        syncAddress();
        changed();
    }

    function pageTitled() {
        var t = current();
        if (t && t.url && web) t.title = String(web.title || "");
        changed();
    }

    function pageStarted() {
        var t = current();
        if (t) Fable.sniffClear(t.id);
    }

    function pageFinished() {
        var t = current();
        if (!t || !t.url || !web || !Panel.isWeb(String(web.url || ""))) return;   // the new-tab page, or a failed load
        if (!t.incognito) Fable.historyAdd(t.url, t.title, Date.now());
        if (Fable.settingGet("block_ads") === "1") web.runJavaScript(Fable.adblockScript());
        scanMedia(false);
        saveSession();
        changed();
    }

    function scanMedia(tell) {
        var t = current();
        if (!t || !t.url || !web) return;
        var id = t.id;
        web.runJavaScript(Fable.sniffJs(), function (result) {
            if (result === undefined || result === null) return;
            var json = typeof result === "string" ? result : JSON.stringify(result);
            if (Fable.sniffNoteScan(id, json) > 0 && tell) panel.run("Fable.refresh('sniff')");
            else if (tell) panel.update();
        });
    }

    function syncAddress() {
        var t = current();
        if (!address.activeFocus) address.text = t ? t.url : "";
    }

    // Anything the tab strip, the cover or the panel show changed.
    function changed() {
        tabCount = tabs.length;
        var t = current();
        coverTitle = t ? titleOf(t) : Fable.tr("brand_name");
        panel.update();
    }

    // ---- restoring tabs ----------------------------------------------------------

    function saveSession() {
        if (Fable.settingGet("restore_tabs") === "0") return;
        Panel.saveSession(tabs, front);
    }

    function restore() {
        var s = Panel.restoreSession(), list = s.tabs || [];
        for (var i = 0; i < list.length; ++i)
            tabs.push({ id: nextId++, url: String(list[i].url), title: String(list[i].title || ""), incognito: false });
        if (tabs.length) show(Math.max(0, Math.min(s.active || 0, tabs.length - 1)));
        else openTab("", false);
    }

    // ---- the panel -------------------------------------------------------------------

    function wantsDesktop(mode) {
        return ["desktop", "ipad", "chrome_win", "chrome_mac", "safari_mac", "firefox", "edge"].indexOf(mode) >= 0;
    }

    function bookmarkIdOf(t) {
        return t && !t.incognito && Panel.isWeb(t.url) ? Fable.bookmarkId(t.url) : 0;
    }

    function panelState() {
        var t = current(), list = [], logo = Fable.logoUri();
        for (var i = 0; i < tabs.length; ++i) {
            var x = tabs[i];
            list.push({ id: x.id, title: titleOf(x), url: x.url, icon: x.url ? "" : logo, active: i === front,
                        "private": x.incognito, asleep: false });
        }
        var isWeb = !!t && !t.incognito && Panel.isWeb(t.url), settings = {};
        try { settings = JSON.parse(Fable.settingsJson() || "{}"); } catch (e) {}
        return JSON.stringify({
            tabs: list, incognito: !!t && t.incognito, active: t ? t.id : 0,
            url: t ? t.url : "", title: t ? titleOf(t) : "", web: isWeb,
            desktop: wantsDesktop(Fable.settingGet("ua_mode")), blocked: 0,
            sniffed: t ? Fable.sniffCount(t.id) : 0, bookmarked: isWeb ? bookmarkIdOf(t) : 0,
            version: Fable.version, platform: "sailfish", caps: JSON.parse(Panel.caps()), settings: settings
        });
    }

    function deviceExtras() {
        return JSON.stringify({ engine: "Gecko (Sailfish WebView)", screenW: Screen.width, screenH: Screen.height, cookies: true });
    }

    function systemExtras() {
        return JSON.stringify({ display: { w: Screen.width, h: Screen.height } });
    }

    function act(name, arg) {
        var t = current();
        if (name === "hidden") panel.hide();
        else if (name === "newTab") openTab("", false);
        else if (name === "newPrivate") openTab("", true);
        else if (name === "enterPrivate") enterPrivate();
        else if (name === "exitPrivate") exitPrivate();
        else if (name === "switchTab") show(indexOf(parseInt(arg, 10)));
        else if (name === "closeTab") closeTab(parseInt(arg, 10));
        else if (name === "open") navigate(arg);
        else if (name === "openNew") openTab(arg, !!t && t.incognito);
        else if (name === "reader") reader();
        else if (name === "desktop") {
            var on = wantsDesktop(Fable.settingGet("ua_mode"));
            Fable.settingSet("ua_mode", on ? "default" : "desktop");
            rebuild();
            toast(Fable.tr(on ? "mobile_on" : "desktop_on"));
        }
        else if (name === "bookmarkToggle") toggleBookmark();
        else if (name === "bookmarkImportPick") { panel.hide(); pageStack.push(importPicker); }
        else if (name === "bookmarkExport") exportBookmarks(arg);
        else if (name === "copy") { Clipboard.text = arg; toast(Fable.tr("link_copied")); }
        else if (name === "copyText") { Clipboard.text = arg; toast(Fable.tr("m_copied")); }
        else if (name === "toast") toast(arg);
        else if (name === "system") panel.run("Fable.system(" + Fable.systemInfo(systemExtras()) + ")");
        else if (name === "ip") lookupIp(0);
        else if (name === "clear") {
            var ok = arg.indexOf("history") < 0 || Fable.historyClear();   // cookies and the cache: not offered (caps.clearSiteData)
            toast(Fable.tr(ok ? "data_cleared" : "history_clear_failed"));
        }
        else if (name === "pageSource") {
            var token = JSON.stringify(arg);
            if (!web) panel.run("Fable.source(" + token + ",null)");
            else web.runJavaScript(Fable.panelQuery("sourceScript", "", 0), function (text) {
                panel.run("Fable.source(" + token + "," + JSON.stringify(typeof text === "string" ? text : null) + ")");
            });
        }
        else if (name === "sniffScan") scanMedia(true);
        else if (name === "download") { if (Panel.isWeb(arg)) Qt.openUrlExternally(arg); }   // the system browser downloads it
        // "find", "scan", "size", "downloadOpen", ...: the panel offers none of them here (caps)
    }

    function settingChanged(key) {
        if (key === "language") {
            panel.reload();
            panel.show("settings");
            if (homeShown) load();
        } else if (key === "ua_mode" || key === "ua_custom") {
            rebuild();
        } else if (key === "shortcuts" || key === "search_template" || key === "search_engine") {
            if (homeShown) load();
        } else if (key === "home_button") {
            homeButton = Fable.settingGet("home_button") === "1";
        } else if (key === "block_ads" || key === "data_saver" || key === "block_3p_cookies") {
            var t = current();
            if (t && t.url && web) web.reload();
        } else if (key === "restore_tabs") {
            saveSession();   // switched back on: what is open now is kept; off: the core dropped it
        }
    }

    function reader() {
        if (!web || !current() || !current().url) return;
        web.runJavaScript(Fable.readerScript(), function (r) {
            if (r === "off") return;   // back to the page: nothing to say
            toast(Fable.tr(r === "none" ? "no_article" : r === "on" ? "reader_on" : "reader_unsupported"));
        });
    }

    function toggleBookmark() {
        var t = current(), id = bookmarkIdOf(t);
        if (!t || t.incognito || !Panel.isWeb(t.url)) return;
        if (id) {
            Fable.bookmarkRemove(id);
            toast(Fable.tr("removed_bookmark"));
        } else {
            Fable.bookmarkAdd(t.url, t.title, 0);
            toast(Fable.tr("added_bookmark"));
        }
        panel.update();
    }

    function importBookmarks(path) {
        var text = path ? Panel.readText(path) : "";
        if (!text) { toast(Fable.tr("bookmark_import_failed")); return; }
        toast(Fable.tr("bookmark_imported").replace("{n}", Fable.bookmarkImport(text)));
    }

    // A QR code just read, from the camera or a picked image. A web address
    // opens in the tab in front; anything else is shown on its own page, so
    // nothing reaches a search engine unless the user asks (as on Android).
    function scanResult(text) {
        var found = text ? text.replace(/^\s+|\s+$/g, "") : "";
        if (!found) { toast(Fable.tr("scan_unknown")); return; }
        if (/^https?:\/\//i.test(found)) { navigate(found); return; }
        pageStack.push(scanResultPage, { resultText: found });
    }

    // A picked image file: the QR code in it, if it has one.
    function scanImageFile(path) {
        scanResult(path ? Fable.qrDecodeImage(path) : "");
    }

    // Into Downloads, as bookmarks.html (bookmarks-2.html, ... beside an older one).
    function exportBookmarks(fmt) {
        var f = fmt ? fmt : "html";
        var ok = Panel.writeText(Panel.downloadsPath("bookmarks." + f), Fable.bookmarkExportFmt(f));
        toast(Fable.tr(ok ? "exported_bookmark" : "bookmark_export_failed"));
    }

    // Public IP for the metadata sheet: Cloudflare's trace, then ipify; 10 s each.
    function lookupIp(attempt) {
        var xhr = new XMLHttpRequest(), source = attempt === 0 ? "cloudflare.com" : "ipify.org";
        ipRequest = xhr;
        xhr.onreadystatechange = function () {
            if (xhr.readyState !== XMLHttpRequest.DONE || ipRequest !== xhr) return;
            ipRequest = null;
            ipTimer.stop();
            var info = xhr.status === 200 ? Fable.parseIpReply(xhr.responseText, source) : "";
            if (!info && attempt === 0) { lookupIp(1); return; }
            panel.run("Fable.ip(" + (info || "{}") + ")");
        };
        xhr.open("GET", attempt === 0 ? "https://www.cloudflare.com/cdn-cgi/trace" : "https://api.ipify.org?format=json");
        xhr.send();
        ipTimer.attempt = attempt;
        ipTimer.restart();
    }

    Timer {
        id: ipTimer
        property int attempt: 0
        interval: 10000
        onTriggered: {
            var xhr = page.ipRequest;
            page.ipRequest = null;
            if (xhr) xhr.abort();
            if (attempt === 0) page.lookupIp(1); else panel.run("Fable.ip({})");
        }
    }

    function toast(text) { banner.show(text); }
    function showPanel(view) { panel.show(view); }
    property alias toastText: bannerText.text

    Component.onCompleted: restore()
    Component.onDestruction: saveSession()

    Connections {
        target: Panel
        onActionRequested: page.act(name, arg)
        onSettingChanged: page.settingChanged(key)
    }

    Connections {
        target: Qt.application
        onStateChanged: if (Qt.application.state !== Qt.ApplicationActive) page.saveSession()
    }

    // The new-tab page's search box: drained while that page is the one shown.
    Timer {
        interval: 100
        repeat: true
        running: page.homeShown && !panel.visible && !!page.web && page.web.active   // active: the app and page are in view
        onTriggered: {
            if (!page.web) return;
            page.web.runJavaScript(Panel.drainScript(), function (json) {
                if (!page.homeShown) return;   // a web page by now: what it queued is not ours
                var list;
                try { list = JSON.parse(json || "[]"); } catch (e) { return; }
                for (var i = 0; i < list.length; ++i) {
                    var q = Panel.homeQuery(String(list[i]));
                    if (q) { page.navigate(q); return; }
                }
            });
        }
    }

    // ---- the page ----------------------------------------------------------------------

    TextField {
        id: address
        objectName: "address"
        anchors { top: parent.top; left: parent.left; right: privateLabel.left }
        placeholderText: page.tr("addr_hint")
        inputMethodHints: Qt.ImhNoPredictiveText | Qt.ImhNoAutoUppercase | Qt.ImhUrlCharactersOnly
        EnterKey.iconSource: "image://theme/icon-m-enter-accept"
        EnterKey.onClicked: {
            var text = address.text.trim();
            address.focus = false;
            if (text) page.navigate(text); else page.syncAddress();
        }
        onActiveFocusChanged: {
            if (activeFocus) selectAll();
            else page.syncAddress();
        }
    }

    Label {
        id: privateLabel
        anchors { right: parent.right; rightMargin: visible ? Theme.horizontalPageMargin : 0; verticalCenter: address.verticalCenter }
        width: visible ? implicitWidth : 0
        visible: page.incognito
        text: page.tr("private_mode")
        color: Theme.highlightColor
        font.pixelSize: Theme.fontSizeExtraSmall
    }

    // QR scanning lives in the blank address bar (0.18.31): the QR button
    // (only where there is a camera) and the image button show only while the
    // field is empty, at its right end. Tapping one clears the field's focus
    // first, so the keyboard does not come up behind the scanner or picker.
    IconButton {
        id: scanImageButton
        objectName: "scanImage"
        anchors { right: address.right; rightMargin: Theme.paddingSmall; verticalCenter: address.verticalCenter }
        visible: address.text.trim() === ""
        icon.source: "image://theme/icon-m-image"
        onClicked: { address.focus = false; pageStack.push(imagePicker); }
    }
    IconButton {
        id: scanButton
        objectName: "scanCamera"
        anchors { right: scanImageButton.left; rightMargin: Theme.paddingSmall; verticalCenter: address.verticalCenter }
        visible: QrScanner.cameraAvailable && address.text.trim() === ""
        icon.source: "image://theme/icon-m-qr"
        onClicked: {
            address.focus = false;
            var scanner = pageStack.push(Qt.resolvedUrl("QrScannerPage.qml"));
            scanner.scanned.connect(function (text) { page.scanResult(text); });
            scanner.failed.connect(function () { toast(Fable.tr("scan_camera_unavailable")); });
        }
    }

    Rectangle {
        anchors { left: parent.left; bottom: webArea.top }
        height: Theme.paddingSmall / 2
        width: page.web && page.web.loading ? parent.width * Math.max(5, page.web.loadProgress) / 100 : 0
        color: Theme.highlightColor
        visible: width > 0
    }

    Item {
        id: webArea
        anchors { top: address.bottom; bottom: toolbar.top; left: parent.left; right: parent.right }
        clip: true

        Loader {
            id: webLoader
            anchors.fill: parent
            active: false
            sourceComponent: webComponent
            onLoaded: page.load()
        }
    }

    Row {
        id: toolbar
        anchors { bottom: parent.bottom; horizontalCenter: parent.horizontalCenter }
        height: Theme.itemSizeSmall

        IconButton {
            icon.source: "image://theme/icon-m-back"
            enabled: !!page.web && page.web.canGoBack
            onClicked: page.web.goBack()
        }
        IconButton {
            icon.source: "image://theme/icon-m-forward"
            enabled: !!page.web && page.web.canGoForward
            onClicked: page.web.goForward()
        }
        IconButton {
            visible: page.homeButton
            icon.source: "image://theme/icon-m-home"
            onClicked: {
                var t = page.current();
                if (!t) return;
                t.url = "";
                t.title = "";
                page.load();
                page.changed();
            }
        }
        IconButton {
            icon.source: "image://theme/icon-m-tabs"
            onClicked: page.showPanel("tabs")
            Label {
                anchors.centerIn: parent
                text: page.tabCount
                font.pixelSize: Theme.fontSizeTiny
                font.bold: true
                color: parent.down ? Theme.highlightColor : Theme.primaryColor
            }
        }
        IconButton {
            icon.source: "image://theme/icon-m-menu"
            onClicked: page.showPanel("menu")
        }
    }

    Rectangle {
        id: banner
        anchors { horizontalCenter: parent.horizontalCenter; bottom: toolbar.top; bottomMargin: Theme.paddingLarge }
        width: Math.min(parent.width - 2 * Theme.paddingLarge, bannerText.implicitWidth + 2 * Theme.paddingLarge)
        height: bannerText.implicitHeight + Theme.paddingMedium
        radius: Theme.paddingSmall
        color: Theme.highlightBackgroundColor
        opacity: 0
        visible: opacity > 0
        z: 20
        Behavior on opacity { FadeAnimation { duration: 200 } }
        function show(text) {
            bannerText.text = text || "";
            if (!bannerText.text) return;
            opacity = 1;
            bannerTimer.restart();
        }
        Label {
            id: bannerText
            anchors.centerIn: parent
            width: Math.min(implicitWidth, parent.parent.width - 4 * Theme.paddingLarge)
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.Wrap
            font.pixelSize: Theme.fontSizeSmall
            color: Theme.primaryColor
        }
        Timer { id: bannerTimer; interval: 2200; onTriggered: banner.opacity = 0 }
    }

    PanelView {
        id: panel
        anchors.fill: parent
        z: 10
        host: page
    }

    Component {
        id: webComponent
        WebView {
            privateMode: page.incognito
            Component.onCompleted: {
                var ua = Panel.userAgent(Fable.settingGet("ua_mode"), Fable.settingGet("ua_custom"));
                if (ua) httpUserAgent = ua;   // "": the WebView's own
            }
            onUrlChanged: page.pageMoved()
            onTitleChanged: page.pageTitled()
            onLoadingChanged: {
                if (loading) page.pageStarted();
                else page.pageFinished();
            }
        }
    }

    Component {
        id: importPicker
        FilePickerPage {
            nameFilters: ["*.html", "*.htm", "*.json", "*.csv"]
            onSelectedContentPropertiesChanged: page.importBookmarks(String(selectedContentProperties.filePath || ""))
        }
    }

    Component {
        id: imagePicker
        FilePickerPage {
            nameFilters: ["*.png", "*.jpg", "*.jpeg", "*.gif", "*.bmp", "*.webp"]
            onSelectedContentPropertiesChanged: page.scanImageFile(String(selectedContentProperties.filePath || ""))
        }
    }

    // A QR code that is not a web address: the text, with Search, Copy, Cancel.
    Component {
        id: scanResultPage
        Page {
            id: resultPage
            property string resultText: ""
            allowedOrientations: Orientation.All

            PageHeader {
                id: resultHeader
                title: Fable.tr("scan_text")
            }

            Label {
                anchors { left: parent.left; right: parent.right; top: resultHeader.bottom; bottom: resultButtons.top; leftMargin: Theme.horizontalPageMargin; rightMargin: Theme.horizontalPageMargin; topMargin: Theme.paddingMedium; bottomMargin: Theme.paddingMedium }
                text: resultText
                wrapMode: Text.Wrap
                color: Theme.primaryColor
            }

            Column {
                id: resultButtons
                anchors { left: parent.left; right: parent.right; bottom: parent.bottom; leftMargin: Theme.horizontalPageMargin; rightMargin: Theme.horizontalPageMargin; bottomMargin: Theme.paddingLarge }
                spacing: Theme.paddingMedium

                Button {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: Fable.tr("scan_search")
                    onClicked: { page.navigate(resultText); pageStack.pop(); }
                }
                Button {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: Fable.tr("copy")
                    onClicked: { Clipboard.text = resultText; page.toast(Fable.tr("m_copied")); pageStack.pop(); }
                }
                Button {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: Fable.tr("cancel")
                    onClicked: pageStack.pop()
                }
            }
        }
    }
}
