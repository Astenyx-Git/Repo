// The Rust core (core/include/fable_core.h, reached through the bridging
// header) as Swift. Foundation only, so tests/ios_test.sh can build and run it
// on Linux against the Linux libfable_core.a.
import Foundation

enum Core {
    /// A string the core allocated: copied into Swift, then given back to the core.
    static func take(_ s: UnsafeMutablePointer<CChar>?) -> String {
        guard let s = s else { return "" }
        defer { fable_string_free(s) }
        return String(cString: s)
    }

    static var version: String { String(cString: fable_version()) }
    static var nativeHash: Bool { fable_native_hash() != 0 }

    // ---- language ----
    static func setSystemLocale(_ tag: String) { fable_set_system_locale(tag) }
    static var language: String { take(fable_language()) }
    static func tr(_ key: String) -> String { take(fable_tr(key)) }
    static func tr(_ key: String, _ n: String) -> String { tr(key).replacingOccurrences(of: "{n}", with: n) }

    // ---- pages and scripts ----
    static var readerScript: String { take(fable_reader_script()) }
    /// Hides the ad boxes on a page (the "block ads" setting).
    static var adblockScript: String { take(fable_adblock_script()) }
    static var logoURI: String { take(fable_logo_uri()) }
    static var panelPage: String { take(fable_panel_page()) }
    static func newtabPage(private isPrivate: Bool) -> String { take(fable_newtab_page(isPrivate ? 1 : 0, nil)) }
    static var sniffScript: String { String(cString: fable_sniff_js()) }
    /// The tracker list as WebKit content-blocker JSON.
    static var contentRules: String { take(fable_content_rules()) }
    /// The ad list as WebKit content-blocker JSON.
    static var adsContentRules: String { take(fable_ads_content_rules()) }
    /// 1 when the ad list is due a fetch: blocking is on and a week has passed.
    static var adsUpdateDue: Bool { fable_ads_update_due() != 0 }
    /// The update sources, one URL per line (EasyList and EasyPrivacy).
    static var adsUpdateSources: String { take(fable_ads_update_sources()) }
    /// Validate the download as a list and install it; the new domain count, or -1.
    static func adsUpdateApply(_ data: Data) -> Int {
        data.withUnsafeBytes { raw in
            Int(fable_ads_update_apply(raw.baseAddress?.assumingMemoryBound(to: UInt8.self), data.count))
        }
    }
    /// True when following this URL would leave the browser for another app and
    /// the "block external apps" setting is on.
    static func blockExternalApp(_ url: String) -> Bool { fable_block_external_app(url) != 0 }

    // ---- address bar ----
    static func resolve(_ input: String) -> String { take(fable_resolve(input)) }

    // ---- the panel ----
    /// nil when the shell answers the request itself ("device", "icon").
    static func panelQuery(_ name: String, _ arg: String, tab: UInt32) -> String? {
        guard let answer = fable_panel_query(name, arg, tab) else { return nil }
        return take(answer)
    }
    static func panelReply(_ id: UInt32, _ answer: String) -> String { take(fable_panel_reply(id, answer)) }

    // Bookmarks: the core's table (bookmarks.tsv).
    static func bookmarkID(_ url: String) -> UInt64 { fable_bookmark_id(url) }
    @discardableResult static func bookmarkAdd(_ url: String, title: String) -> UInt64 { fable_bookmark_add(url, title, 0) }
    static func bookmarkRemove(_ id: UInt64) { fable_bookmark_remove(id) }
    static func bookmarkImport(_ html: String) -> Int { Int(fable_bookmark_import(html)) }
    static var bookmarkExport: String { take(fable_bookmark_export()) }

    // The session snapshot for "restore tabs on start".
    @discardableResult static func sessionSave(_ json: String) -> Bool { fable_session_save(json) != 0 }
    static var sessionCount: Int { Int(fable_session_count()) }
    static var sessionActive: Int { Int(fable_session_active()) }
    static func sessionURL(_ i: Int) -> String { take(fable_session_url(i)) }
    static func sessionTitle(_ i: Int) -> String { take(fable_session_title(i)) }
    static func json(_ s: String) -> String { take(fable_json_string(s)) }
    static var settingsJSON: String { take(fable_settings_json()) }
    static func parseIPReply(_ body: String, source: String) -> String { take(fable_parse_ip_reply(body, source)) }
    static func deviceInfo(_ extras: String) -> String { take(fable_device_info(extras)) }
    static func systemInfo(_ extras: String) -> String { take(fable_system_info(extras)) }
    static var blockedCount: UInt64 { fable_blocked_count() }

    // ---- settings and history ----
    static func openStore(_ dir: String) { fable_store_open(dir) }
    static func setting(_ key: String) -> String { take(fable_setting_get(key)) }
    static func set(_ key: String, _ value: String) { fable_setting_set(key, value) }
    static func historyAdd(_ url: String, title: String, timeMs: UInt64) { fable_history_add(url, title, timeMs) }
    static func historyClear() -> Bool { fable_history_clear() != 0 }

    // ---- resources found in a page ----
    static func sniffClear(_ tab: UInt32) { fable_sniff_clear(tab) }
    static func sniffCount(_ tab: UInt32) -> Int { Int(fable_sniff_count(tab)) }
    static func sniffNoteScan(_ tab: UInt32, _ json: String) -> Int { Int(fable_sniff_note_scan(tab, json)) }

    /// Wall-clock milliseconds, for the history.
    static var wallMs: UInt64 { UInt64(Date().timeIntervalSince1970 * 1000) }
    /// Milliseconds that never jump backwards, for the tab sleep policy.
    static var monotonicMs: UInt64 { UInt64(ProcessInfo.processInfo.systemUptime * 1000) }
}

/// The core's tab sleep policy: which background tabs may drop their web view.
final class TabPolicy {
    private let handle: OpaquePointer

    init() { handle = fable_tabs_new() }
    deinit { fable_tabs_free(handle) }

    func open(now: UInt64 = Core.monotonicMs) -> UInt32 { fable_tabs_open(handle, now) }
    @discardableResult func activate(_ id: UInt32, now: UInt64 = Core.monotonicMs) -> Bool { fable_tabs_activate(handle, id, now) != 0 }
    @discardableResult func touch(_ id: UInt32, now: UInt64 = Core.monotonicMs) -> Bool { fable_tabs_touch(handle, id, now) != 0 }
    @discardableResult func close(_ id: UInt32) -> Bool { fable_tabs_close(handle, id) != 0 }
    var count: Int { Int(fable_tabs_count(handle)) }
    func isAsleep(_ id: UInt32) -> Bool { fable_tabs_is_asleep(handle, id) != 0 }
    /// 0 never sleeps.
    func setSleepAfter(minutes: Int) { fable_tabs_set_sleep_after_ms(handle, UInt64(max(0, minutes)) * 60_000) }

    /// Tabs that have been in the background long enough to sleep now.
    func collectSleepers(now: UInt64 = Core.monotonicMs) -> [UInt32] {
        var out = [UInt32](repeating: 0, count: 64)
        let n = out.withUnsafeMutableBufferPointer { fable_tabs_collect_sleepers(handle, now, $0.baseAddress, $0.count) }
        return Array(out.prefix(min(Int(n), out.count)))
    }
}
