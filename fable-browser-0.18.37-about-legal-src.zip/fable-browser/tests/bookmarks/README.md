# Bookmark files from other browsers

Test fixtures for `core/src/bookmarks.rs` and `core/src/store.rs`, written the
way each browser's own exporter writes them (icons are random bytes):

| File | Written by |
|---|---|
| `chrome.html` | Chrome (zh-CN) › Bookmark manager › Export; Edge, Brave, Opera and Vivaldi write the same |
| `chrome-Bookmarks.json` | the same Chrome profile's own `Bookmarks` file |
| `opera-Bookmarks.json` | Opera's `Bookmarks` file: Chromium's, plus `custom_root` (speed dial, trash) |
| `firefox.html` | Firefox › Bookmarks › Manage › Export Bookmarks to HTML |
| `firefox-backup.json` | the same Firefox profile › Backup |
| `safari.html` | Safari › File › Export › Bookmarks: top folders outside any `<DL>` |
| `ie.htm` | Internet Explorer / Netscape: `FOLDED`, unquoted values, a folder's `<DD>` description |
