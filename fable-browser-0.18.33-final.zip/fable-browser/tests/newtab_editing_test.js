// Home screen editing, in either direction: Done at the top corner on the side text ends (top right; top left in
// Arabic), clear of every tile and remove badge on every page. Run with --lang zh-Hans and with --lang ar
// (tests/launcher_apps.json, tests/launcher_prelude.js).
(function () {
  var log = [];
  function check(name, ok) { log.push((ok ? 'ok   ' : 'FAIL ') + name); }
  function fire(el, type, x, y) { el.dispatchEvent(new PointerEvent(type, { bubbles: true, pointerId: 1, clientX: x, clientY: y, isPrimary: true })); }
  function apart(a, b) { return a.right <= b.left || b.right <= a.left || a.bottom <= b.top || b.bottom <= a.top; }
  var rtl = document.documentElement.dir === 'rtl', W = window.innerWidth, pages = document.getElementById('pages');
  var done = document.getElementById('done');
  check('Done is hidden until editing', getComputedStyle(done).display === 'none');
  var first = document.querySelector('.page a'), r = first.getBoundingClientRect();
  fire(first, 'pointerdown', r.left + 10, r.top + 10);
  setTimeout(function () {
    fire(document, 'pointerup', r.left + 10, r.top + 10);
    var d = done.getBoundingClientRect();
    check('a long press starts editing and shows Done', document.body.classList.contains('editing') && d.width > 0);
    check(rtl ? 'Done sits in the top-left corner (right to left)' : 'Done sits in the top-right corner',
          d.top <= 16 && (rtl ? d.left <= 20 && d.left >= 8 : W - d.right <= 20 && W - d.right >= 8));
    var tile = document.querySelector('.page a span.tile').getBoundingClientRect(), x = document.querySelector('.page a .x').getBoundingClientRect();
    check(rtl ? 'the remove badge sits on the tile\'s top-left corner' : 'the remove badge sits on the tile\'s top-right corner',
          Math.abs((x.left + x.width / 2) - (rtl ? tile.left : tile.right)) < 8 && Math.abs((x.top + x.height / 2) - tile.top) < 10);
    var n = pages.children.length, clear = true;
    (function next(i) {
      if (i === n) {
        check('Done covers no tile or remove badge on any of the ' + n + ' pages', clear && n >= 2);
        done.click();
        check('Done ends editing', !document.body.classList.contains('editing') && getComputedStyle(done).display === 'none');
        console.log(log.join('\n'));
        return;
      }
      pages.scrollLeft = (rtl ? -1 : 1) * i * pages.clientWidth;
      [].forEach.call(pages.children[i].querySelectorAll('a, a .x'), function (el) { if (!apart(el.getBoundingClientRect(), d)) clear = false; });
      next(i + 1);
    })(0);
  }, 700);
  return 'started';
})();
