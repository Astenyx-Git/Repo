#!/usr/bin/env python3
"""The HarmonyOS bar icons, as SVG, from the Android vector drawables (one
source for both). Each icon is written in the colours the bar uses: muted ink
on the cream bar, light ink on the dark private bar, white for the + pill.
Usage: harmony_icons.py   (no dependencies)"""
import pathlib, re

root = pathlib.Path(__file__).resolve().parent.parent
src = root / "shell/android/app/src/main/res/drawable"
out = root / "shell/harmony/entry/src/main/resources/base/media"
out.mkdir(parents=True, exist_ok=True)
COLOURS = {"": "#5E4A3F", "_dark": "#C9B5A6", "_white": "#FFFFFF"}
ATTR = re.compile(r'android:(\w+)="([^"]*)"')

for xml in sorted(src.glob("ic_*.xml")):
    text = xml.read_text(encoding="utf-8")
    vector = dict(ATTR.findall(text.split("<path")[0]))
    paths = [dict(ATTR.findall(p.split("/>")[0])) for p in text.split("<path")[1:]]
    for suffix, colour in COLOURS.items():
        if suffix == "_white" and xml.stem != "ic_plus":
            continue
        parts = []
        for p in paths:
            stroke = 'stroke="%s" stroke-width="%s" stroke-linecap="%s" stroke-linejoin="%s"' % (
                colour, p.get("strokeWidth", "2"), p.get("strokeLineCap", "round"), p.get("strokeLineJoin", "round")) if "strokeColor" in p else 'stroke="none"'
            fill = colour if "fillColor" in p else "none"
            parts.append('<path d="%s" fill="%s" %s/>' % (p["pathData"], fill, stroke))
        svg = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 %s %s">%s</svg>\n' % (
            vector.get("viewportWidth", "24"), vector.get("viewportHeight", "24"), "".join(parts))
        (out / f"{xml.stem}{suffix}.svg").write_text(svg, encoding="utf-8")
print("icons:", len(list(out.glob("ic_*.svg"))))
