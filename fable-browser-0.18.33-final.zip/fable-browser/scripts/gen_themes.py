#!/usr/bin/env python3
"""Icon packs (theme://name) from the artwork in assets/icon-variants/.

Usage: gen_themes.py   (needs Pillow; writes into the tree, prints the sizes)

For every theme but claude (the default, whose icons gen_assets.py makes):

* core/themes/<name>.webp       the logo on the new-tab page and the new-tab
                                tab's icon, 192 px, served by the core as a
                                data: URI (fable_logo_uri): like the default
                                Claude logo, only the planet, its ground cut
                                away (lossless, so the colours are exact)
* core/themes/grounds.rs        each theme's ground colour: the core's palette
                                paints the page in it (theme.rs), so the page
                                round the logo is the logo's own ground
* Android                       an adaptive launcher icon (artwork over the
                                theme's ground colour) and a legacy one for
                                Android 7, for the launcher alias of the theme
* iOS                           an alternate app icon, AppIcon-<Name>

The app icons keep the artwork's own ground: each is the artwork scaled into
a square of its ground colour, edges feathered into it.

The new-tab logo does not: wherever the artwork shows its ground, the logo is
see-through, so the page shows exactly its own colour there, and a wallpaper
behind the home screen shows through as round the default logo. The artwork's
ground is not flat (grain, a vignette a few units off), which is why it is cut
away and not kept. What counts as the drawing (outline() below): every pixel
further from the ground than the edge's own grain, and the pockets it encloses
unless they are ground too (the sky inside the ring is; the dark side of a
dark planet is not); the narrow gaps the artwork draws stay open. The planet
is round: where its edge fades into the ground (Grok's lower left, dark red
into black), the circle the rest of its edge lies on completes it
(planet_disc()). Each pixel kept gets the opacity and colour that, laid over
the ground, give the artwork's pixel back (cutout()): over its own ground the
logo is the artwork itself, but for the grain; over a wallpaper the drawing
is opaque with clean edges and no fringe of the ground's colour. Every pixel
is the artwork's own: nothing is taken from another skin's artwork.

The ground is measured once here and written for every user of it (the page's
palette, the adaptive icons' background), so they cannot drift apart.
tests/skin_ground_test.py checks it all on the rendered pages.
"""
import io, json, math, pathlib, random
from collections import deque
from PIL import Image, ImageChops, ImageDraw, ImageFilter

THEMES = {"chatgpt": "ChatGPT", "deepseek": "DeepSeek", "gemini": "Gemini", "grok": "Grok", "kimi": "Kimi"}
root = pathlib.Path(__file__).resolve().parent.parent


def ground_of(im):
    """The median colour of an 8 px ring round the edge."""
    w, h = im.size
    px = [im.getpixel((x, y)) for y in range(h) for x in range(w) if x < 8 or y < 8 or x >= w - 8 or y >= h - 8]
    return tuple(sorted(p[i] for p in px)[len(px) // 2] for i in range(3))


def feathered(art, size, fade):
    """The artwork at `size` with its outer `fade` of each side fading out."""
    a = art.convert("RGBA").resize((size, size), Image.LANCZOS)
    f = max(1, round(size * fade))
    mask = Image.new("L", (size, size), 0)
    ImageDraw.Draw(mask).rectangle([f, f, size - 1 - f, size - 1 - f], fill=255)
    a.putalpha(mask.filter(ImageFilter.GaussianBlur(f / 2)))
    return a


def tile(art, ground, n, fill, radius=0.0, transparent_ground=False):
    """An n x n square: the ground colour (or nothing), the artwork at `fill`
    of the side in the middle, corners rounded to `radius` of the side."""
    canvas = Image.new("RGBA", (n, n), (0, 0, 0, 0) if transparent_ground else (*ground, 255))
    a = feathered(art, round(n * fill), 0.05)
    canvas.alpha_composite(a, ((n - a.width) // 2, (n - a.height) // 2))
    if radius:
        big = 4 * n   # draw the rounded mask large and shrink it: smooth corners
        m = Image.new("L", (big, big), 0)
        ImageDraw.Draw(m).rounded_rectangle([0, 0, big - 1, big - 1], radius=round(big * radius), fill=255)
        canvas.putalpha(Image.composite(canvas.getchannel("A"), Image.new("L", (n, n), 0), m.resize((n, n), Image.LANCZOS)))
    return canvas


def _neighbours(w, h):
    def nb(i):
        x = i % w
        if x: yield i - 1
        if x < w - 1: yield i + 1
        if i >= w: yield i - w
        if i < w * (h - 1): yield i + w
    return nb


def _offness(art, ground):
    """Per pixel, how far it is from the ground (the largest channel difference)."""
    b = art.tobytes()
    return [max(abs(b[k] - ground[0]), abs(b[k + 1] - ground[1]), abs(b[k + 2] - ground[2])) for k in range(0, len(b), 3)]


def grain(art, ground, band=40):
    """How far the plain ground strays: nearly the most of the outer `band` px."""
    w, h = art.size
    d = _offness(art, ground)
    edge = sorted(d[y * w + x] for y in range(h) for x in range(w) if min(x, y, w - 1 - x, h - 1 - y) < band)
    return edge[int(len(edge) * 0.995)]


def outline(art, ground):
    """The drawing, as an L mask of the artwork's size (255 inside): every pixel a few units further
    from the ground than its grain, specks dropped, and the pockets it encloses unless they are ground
    too (the sky inside the ring). Hairline gaps in its edge are closed to find the pockets, and only
    for that: the narrow gaps the artwork draws (between a ring and its planet) stay open."""
    w, h = art.size
    n, nb, d, noise = w * h, _neighbours(w, h), _offness(art, ground), grain(art, ground)
    m = Image.frombytes("L", (w, h), bytes(255 if v > max(6, noise + 4) else 0 for v in d))
    raw = m.tobytes()
    core = bytearray(1 if v else 0 for v in m.filter(ImageFilter.MaxFilter(5)).filter(ImageFilter.MinFilter(5)).tobytes())

    def region(start, inside, mark):
        comp, k = [start], 0
        mark[start] = 1
        while k < len(comp):
            for j in nb(comp[k]):
                if inside(j) and not mark[j]:
                    mark[j] = 1
                    comp.append(j)
            k += 1
        return comp

    mark = bytearray(n)
    for s in range(n):
        if core[s] and not mark[s]:
            comp = region(s, lambda j: core[j], mark)
            if len(comp) < 40:   # a speck of grain
                for i in comp: core[i] = 0
    outside = bytearray(n)
    for s in [x for x in range(w)] + [n - w + x for x in range(w)] + [y * w for y in range(h)] + [y * w + w - 1 for y in range(h)]:
        if not core[s] and not outside[s]: region(s, lambda j: not core[j], outside)
    drawing = bytearray(1 if raw[i] and core[i] else 0 for i in range(n))   # as drawn, less the specks
    mark = bytearray(n)
    for s in range(n):
        if not core[s] and not outside[s] and not mark[s]:
            comp = region(s, lambda j: not core[j] and not outside[j], mark)
            if sorted(d[i] for i in comp)[len(comp) // 2] > noise + 1:   # not ground: part of the drawing
                for i in comp: drawing[i] = 1
    return Image.frombytes("L", (w, h), bytes(255 if v else 0 for v in drawing))


def planet_disc(shape, tol=1.5, tries=4000):
    """The circle most of the outline's edge lies on: the planet's (the rings are ellipses). Found by
    trying circles through three edge points (seeded, so the result is the same every run), then fitted
    to the points on the best one by least squares. Returns (cx, cy, r) in pixels."""
    w, h = shape.size
    m = shape.tobytes()
    edge = [(i % w, i // w) for i in range(w * h) if m[i] and any(not m[j] for j in _neighbours(w, h)(i))]
    rnd, best = random.Random(0), (0, None)
    for _ in range(tries):
        (x1, y1), (x2, y2), (x3, y3) = rnd.sample(edge, 3)
        dd = 2 * (x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2))
        if not dd:
            continue
        s1, s2, s3 = x1 * x1 + y1 * y1, x2 * x2 + y2 * y2, x3 * x3 + y3 * y3
        ux = (s1 * (y2 - y3) + s2 * (y3 - y1) + s3 * (y1 - y2)) / dd
        uy = (s1 * (x3 - x2) + s2 * (x1 - x3) + s3 * (x2 - x1)) / dd
        r = math.hypot(x1 - ux, y1 - uy)
        if w * 0.15 < r < w * 0.5:
            n = sum(1 for x, y in edge if abs(math.hypot(x - ux, y - uy) - r) <= tol)
            if n > best[0]:
                best = (n, (ux, uy, r))
    ux, uy, r = best[1]
    # Least squares on the points on it: x^2 + y^2 + D x + E y + F = 0.
    S, T = [[0.0] * 3 for _ in range(3)], [0.0] * 3
    for x, y in edge:
        if abs(math.hypot(x - ux, y - uy) - r) <= tol:
            v, z = (x, y, 1.0), -(x * x + y * y)
            for a in range(3):
                T[a] += v[a] * z
                for b in range(3):
                    S[a][b] += v[a] * v[b]
    det = lambda M: (M[0][0] * (M[1][1] * M[2][2] - M[1][2] * M[2][1]) - M[0][1] * (M[1][0] * M[2][2] - M[1][2] * M[2][0])
                     + M[0][2] * (M[1][0] * M[2][1] - M[1][1] * M[2][0]))
    D, E, F = (det([[T[a] if b == k else S[a][b] for b in range(3)] for a in range(3)]) / det(S) for k in range(3))
    cx, cy = -D / 2, -E / 2
    return cx, cy, math.sqrt(cx * cx + cy * cy - F)


def with_planet(shape):
    """The outline with the planet's whole disc in it. The disc is drawn 1.5 px inside the circle, so
    where the planet's own edge is clear it stays as drawn; the disc only fills where that edge is missing."""
    w, h = shape.size
    cx, cy, r = planet_disc(shape)
    r -= 1.5
    disc = Image.new("L", (w, h), 0)
    ImageDraw.Draw(disc).ellipse([cx - r, cy - r, cx + r, cy + r], fill=255)
    return ImageChops.lighter(shape, disc)


def cutout(art, ground, shape, n, fill, reach=14):
    """An n x n logo: the artwork at `fill` of the side, see-through but for the drawing (`shape`) and
    a glow within `reach` px of it.

    Over its own ground it is the artwork itself, but for the ground's grain, which is gone: every pixel
    kept is given an opacity and the colour that, laid over the ground at that opacity, is the artwork's
    pixel again. The opacity is how much of the pixel the outline covers (1 inside, a fraction on its
    edge, the outline softened by 0.7 px), but never less than the least that leaves the pixel's colour
    on top of the ground (a glow, the faint edge of a pale drawing). So over anything else (a wallpaper)
    the drawing is as drawn and opaque, its edges clean, the gaps between its parts open, and no fringe
    of the ground's colour round it. Outside the outline only pixels as far from the ground as the
    drawing's own threshold are kept: one just past the grain would come out as a near-black or
    near-white speck at a sliver of opacity, a sparkle on a wallpaper; over the ground they are the
    ground, off the artwork by no more than that threshold, as the grain everywhere else."""
    w, h = art.size
    N, nb, d, noise = w * h, _neighbours(w, h), _offness(art, ground), grain(art, ground)
    threshold = max(6, noise + 4)   # as outline()
    rgb = art.tobytes()
    inside = shape.tobytes()
    cover = shape.filter(ImageFilter.GaussianBlur(0.7)).tobytes()
    dist, q = [1 << 30] * N, deque()
    for i in range(N):
        if inside[i]:
            dist[i] = 0
            q.append(i)
    while q:
        i = q.popleft()
        for j in nb(i):
            if dist[j] > dist[i] + 1:
                dist[j] = dist[i] + 1
                q.append(j)
    out = bytearray(4 * N)
    for i in range(N):
        c = rgb[3 * i:3 * i + 3]
        least = 0.0
        if dist[i] <= reach and (inside[i] or d[i] > threshold):
            for k in range(3):
                if c[k] > ground[k]: least = max(least, (c[k] - ground[k]) / (255 - ground[k]))
                elif c[k] < ground[k]: least = max(least, (ground[k] - c[k]) / ground[k])
        a = max(least, cover[i] / 255)
        if a * 255 < 1:
            out[4 * i:4 * i + 4] = bytes((*ground, 0))
            continue
        fg = tuple(max(0, min(255, round(ground[k] + (c[k] - ground[k]) / a))) for k in range(3))
        out[4 * i:4 * i + 4] = bytes((*fg, round(a * 255)))
    big = Image.frombytes("RGBA", (w, h), bytes(out))
    side = round(n * fill)
    canvas = Image.new("RGBA", (n, n), (*ground, 0))
    canvas.alpha_composite(big.resize((side, side), Image.LANCZOS), ((n - side) // 2, (n - side) // 2))
    # What resampling leaves at the faintest (a unit or two of alpha) is nothing.
    px = canvas.load()
    for y in range(n):
        for x in range(n):
            if px[x, y][3] <= 2: px[x, y] = (*ground, 0)
    return canvas


def webp(im, path, quality):
    """quality None: lossless (exact colours, also under the alpha)."""
    b = io.BytesIO()
    if quality is None:
        im.save(b, "WEBP", lossless=True, quality=100, method=6, exact=True)
    else:
        im.save(b, "WEBP", quality=quality, method=6)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(b.getvalue())
    return len(b.getvalue())


res = root / "shell/android/app/src/main/res"
colors = ['<?xml version="1.0" encoding="utf-8"?>',
          "<!-- Generated by scripts/gen_themes.py: the ground of each icon pack (theme://name). -->",
          "<resources>"]
grounds = ["// Generated by scripts/gen_themes.py: the ground of each skin's artwork (the median",
           "// of its edge). The palette's ground (theme.rs), the logo and the app icons all use it."]
sizes = {}
for name, label in THEMES.items():
    art = Image.open(root / f"assets/icon-variants/fable-{name}.png").convert("RGB")
    ground = ground_of(art)
    hexcol = "#%02X%02X%02X" % ground

    # The new-tab page and the tab list: the planet alone, lossless (lossy coding moves colours a unit or two).
    shape = with_planet(outline(art, ground))
    sizes[f"core/themes/{name}.webp"] = webp(cutout(art, ground, shape, 192, 0.92), root / f"core/themes/{name}.webp", None)
    grounds.append(f'pub const GROUND_{name.upper()}: &str = "{hexcol}";')

    # Android 8+: adaptive icon, the artwork inside the 66/108 safe zone over the ground colour.
    sizes[f"android fg {name}"] = webp(tile(art, ground, 432, 0.62, transparent_ground=True),
                                       res / f"mipmap-xxxhdpi/ic_launcher_{name}_foreground.webp", 90)
    (res / f"mipmap-anydpi-v26/ic_launcher_{name}.xml").write_text(
        '<?xml version="1.0" encoding="utf-8"?>\n'
        "<!-- Generated by scripts/gen_themes.py -->\n"
        '<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n'
        f'    <background android:drawable="@color/ground_{name}" />\n'
        f'    <foreground android:drawable="@mipmap/ic_launcher_{name}_foreground" />\n'
        "</adaptive-icon>\n", encoding="utf-8")
    # Android 7: one bitmap, a rounded tile as legacy launcher icons are.
    sizes[f"android legacy {name}"] = webp(tile(art, ground, 192, 0.92, radius=0.18), res / f"mipmap-xxxhdpi/ic_launcher_{name}.webp", 88)
    colors.append(f'    <color name="ground_{name}">{hexcol}</color>')

    # iOS: an alternate app icon, opaque 1024 (the system rounds the corners).
    ios = root / f"shell/ios/Fable/Assets.xcassets/AppIcon-{label}.appiconset"
    ios.mkdir(parents=True, exist_ok=True)
    png = io.BytesIO()
    tile(art, ground, 1024, 0.92).convert("RGB").save(png, "PNG", optimize=True)
    (ios / "AppIcon.png").write_bytes(png.getvalue())
    sizes[f"ios {label}"] = len(png.getvalue())
    (ios / "Contents.json").write_text(json.dumps({
        "images": [{"filename": "AppIcon.png", "idiom": "universal", "platform": "ios", "size": "1024x1024"}],
        "info": {"author": "xcode", "version": 1}}, indent=2) + "\n", encoding="utf-8")

colors.append("</resources>")
(res / "values/theme_icons.xml").write_text("\n".join(colors) + "\n", encoding="utf-8")
(root / "core/themes/grounds.rs").write_text("\n".join(grounds) + "\n", encoding="utf-8")
for k, v in sizes.items():
    print(f"{v:8d}  {k}")
print(f"{sum(v for k, v in sizes.items() if not k.startswith('ios')):8d}  total outside iOS")
