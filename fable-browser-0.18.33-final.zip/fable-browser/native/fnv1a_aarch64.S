/*
 * uint64_t fable_fnv1a_lower(const uint8_t *p, size_t n);
 *
 * AArch64 (AAPCS64: p = x0, n = x1, result in x0). Used on arm64 Android,
 * arm64 Linux and Apple silicon Macs. Same contract as the x86-64 version:
 * FNV-1a 64 with ASCII upper case folded to lower case.
 * Mach-O (macOS) prefixes C symbols with an underscore and has no ELF
 * .type/.size/.note sections, hence the preprocessor switches.
 */
#if defined(__APPLE__)
# define FNV _fable_fnv1a_lower
#else
# define FNV fable_fnv1a_lower
#endif
        .text
        .globl  FNV
#if defined(__ELF__)
        .type   FNV, %function
#endif
        .p2align 2
FNV:
        mov     x8, x0                          // x8 = p
        mov     x0, #0x2325                     // x0 = 0xcbf29ce484222325 (offset basis)
        movk    x0, #0x8422, lsl #16
        movk    x0, #0x9ce4, lsl #32
        movk    x0, #0xcbf2, lsl #48
        mov     x9, #0x01b3                     // x9 = 0x00000100000001b3 (prime)
        movk    x9, #0x0100, lsl #32
        cbz     x1, 2f
        add     x10, x8, x1                     // x10 = end pointer
1:
        ldrb    w11, [x8], #1                   // c = *p++
        sub     w12, w11, #65                   // c - 'A'
        orr     w13, w11, #0x20                 // lower-case candidate
        cmp     w12, #25
        csel    w11, w13, w11, ls               // unsigned <= 25: c was upper case
        eor     x0, x0, x11                     // h ^= c
        mul     x0, x0, x9                      // h *= prime
        cmp     x8, x10
        b.ne    1b
2:
        ret
#if defined(__ELF__)
        .size   FNV, . - FNV
        .section .note.GNU-stack, "", %progbits
#endif
