import QtQuick 2.0
// Makes the initial page and the cover, as Silica's does; activate() is counted.
Item {
    id: win
    width: 540; height: 960
    property Component initialPage: null
    property var cover: null
    property int allowedOrientations: 0
    property int defaultAllowedOrientations: 15
    property Item pageItem: null
    property Item coverItem: null
    property int activations: 0
    function activate() { activations++; }
    Component.onCompleted: {
        if (initialPage) pageItem = initialPage.createObject(win, { width: 540, height: 960 });
        if (cover && cover.createObject) coverItem = cover.createObject(win);
    }
}
