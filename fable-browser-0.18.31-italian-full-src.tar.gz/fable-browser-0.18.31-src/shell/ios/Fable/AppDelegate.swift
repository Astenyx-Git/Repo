// App and scene lifecycle: one window holding the browser.
import UIKit

@main
final class AppDelegate: UIResponder, UIApplicationDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Settings and history live in Application Support (not in Documents,
        // which the Files app shows: that folder is for downloads).
        let fm = FileManager.default
        if let support = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask).first {
            let dir = support.appendingPathComponent("Fable", isDirectory: true)
            try? fm.createDirectory(at: dir, withIntermediateDirectories: true)
            fable_ad_list_file(dir.path, Bundle.main.path(forResource: "ads", ofType: "txt"))
            Core.openStore(dir.path)
        }
        Core.setSystemLocale(Locale.preferredLanguages.first ?? "en")
        Palette.load()   // the skin's colours (theme://name), before anything is drawn
        return true
    }
}

final class SceneDelegate: UIResponder, UIWindowSceneDelegate {
    var window: UIWindow?
    private var browser: BrowserViewController? { window?.rootViewController as? BrowserViewController }

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let scene = scene as? UIWindowScene else { return }
        let window = UIWindow(windowScene: scene)
        window.rootViewController = BrowserViewController()
        window.tintColor = Palette.spark
        self.window = window
        window.makeKeyAndVisible()
        for context in connectionOptions.urlContexts { browser?.openExternal(context.url) }
        if let url = connectionOptions.userActivities.first(where: { $0.activityType == NSUserActivityTypeBrowsingWeb })?.webpageURL {
            browser?.openExternal(url)
        }
    }

    /// http(s) links handed to Fable (Shortcuts, "Open in", a share).
    func scene(_ scene: UIScene, openURLContexts URLContexts: Set<UIOpenURLContext>) {
        for context in URLContexts { browser?.openExternal(context.url) }
    }

    func scene(_ scene: UIScene, continue userActivity: NSUserActivity) {
        if let url = userActivity.webpageURL { browser?.openExternal(url) }
    }

    // Private tabs stay out of the app switcher's snapshot.
    func sceneWillResignActive(_ scene: UIScene) { browser?.coverForAppSwitcher() }
    func sceneDidBecomeActive(_ scene: UIScene) { browser?.uncover() }
    // The app may be ended while in the background: the open tabs come back on the next start.
    func sceneDidEnterBackground(_ scene: UIScene) { browser?.saveSession() }
}
