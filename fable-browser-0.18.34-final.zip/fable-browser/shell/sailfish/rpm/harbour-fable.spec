Name:       harbour-fable
Summary:    Lightweight browser using the system WebView
Version:        0.18.34
Release:    1
Group:      Applications/Internet
# The project has not chosen a licence yet: set it here (an SPDX id) before publishing.
License:    LicenseRef-Unspecified
Source0:    %{name}-%{version}.tar.bz2

Requires:   sailfishsilica-qt5 >= 0.10.9
Requires:   qml(Sailfish.WebView)
Requires:   qml(Sailfish.WebEngine)
Requires:   qml(Sailfish.Pickers)
BuildRequires: pkgconfig(sailfishapp) >= 1.0.2
BuildRequires: pkgconfig(Qt5Core)
BuildRequires: pkgconfig(Qt5Qml)
BuildRequires: pkgconfig(Qt5Quick)
BuildRequires: pkgconfig(Qt5Multimedia)
BuildRequires: desktop-file-utils

%description
Fable Browser is a lightweight browser that does not ship its own rendering
engine. It uses the Sailfish OS system WebView (Gecko) and implements the UI
and core logic (address bar, tracker/ad rules, bookmarks, history, resource
sniffing, metadata) in a shared Rust core and a Sailfish Silica shell.

%prep
%autosetup -n %{name}-%{version}

%build
# The Rust core static library is cross-built for the target beforehand by
# scripts/build-sailfish-core.sh (see shell/sailfish/README.md). FABLE_CORE_TARGET
# is armv7hl or aarch64 and selects 3rdparty/<target>/libfable_core.a.
%qmake5 FABLE_CORE_TARGET=%{_arch}
%make_build

%install
%qmake5_install
desktop-file-install --delete-original \
    --dir %{buildroot}%{_datadir}/applications \
    %{buildroot}%{_datadir}/applications/%{name}.desktop

%files
%{_bindir}/%{name}
%{_datadir}/%{name}
%{_datadir}/applications/%{name}.desktop
%{_datadir}/icons/hicolor/*/apps/%{name}.png
