// harbour.fable.Core's QrScanner (shell/sailfish/src/qrscanner.h): no camera here.
pragma Singleton
import QtQuick 2.0
QtObject {
    property bool cameraAvailable: true
    property var camera: null
    property int starts: 0
    signal decoded(string text)
    signal failed()
    function start() { starts++; }
    function stop() {}
}
