/*
 * Fable for macOS: AppKit + WKWebView over the Rust core (core/include/fable_core.h).
 *
 * Objective-C with ARC, no Xcode project: scripts/build-macos.sh compiles this
 * one file against the universal libfable_core.a and wraps it in Fable.app.
 *
 * - Tabs are native macOS window tabs: each tab is a window in a tab group,
 *   so Cmd-T, the tab bar, Mission Control and "Merge All Windows" behave as
 *   in Safari. The core's tab model tracks them for the sleep policy.
 * - Private windows, as in Chrome: a separate dark window whose tabs share one
 *   non-persistent website data store, never written to disk and dropped when
 *   the last private tab closes. They keep no history.
 * - Tracker blocking: the core's list compiled into a WKContentRuleList.
 * - fable://newtab/ is the core's new-tab page; its search box posts here.
 * - Idle background tabs fall asleep (web view dropped, URL kept) unless they
 *   are playing sound, and wake when selected.
 * - Downloads (macOS 11.3+) go to ~/Downloads.
 * - The menu button opens the same panel as on Android and Linux (ui/panel.html:
 *   menu, settings, history, resource list, metadata) in a popover; it talks
 *   to this shell by messages, and the settings it changes take effect here.
 * - Menus and messages use the core's strings: the system language, or the
 *   one chosen in the panel.
 */
#import <Cocoa/Cocoa.h>
#import <WebKit/WebKit.h>
#import <Metal/Metal.h>
#import <IOKit/IOKitLib.h>
#import <IOKit/ps/IOPowerSources.h>
#import <IOKit/ps/IOPSKeys.h>
#import <objc/runtime.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "fable_core.h"

static NSString *const HOME = @"fable://newtab/";
static NSString *const NORMAL_GROUP = @"app.fable.browser.tabs";
static NSString *const PRIVATE_GROUP = @"app.fable.browser.private";
static NSString *const PANEL_BASE = @"fable://panel/";
static NSString *const ANDROID_UA = @"Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36";
static NSString *const IPHONE_UA = @"Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1";
static NSString *const IPAD_UA = @"Mozilla/5.0 (iPad; CPU OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1";
static NSString *const CHROME_WIN_UA = @"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";
static NSString *const CHROME_MAC_UA = @"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";
static NSString *const SAFARI_MAC_UA = @"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Safari/605.1.15";
static NSString *const FIREFOX_UA = @"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0";
static NSString *const EDGE_UA = @"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0";
static void *const KVO = (void *)&KVO;
static char DOWNLOAD_TARGET;   /* associated-object key: where a download is being saved */
static NSArray<NSString *> *observedKeys(void) { return @[@"URL", @"title", @"canGoBack", @"canGoForward", @"loading"]; }

/* ---- core helpers -------------------------------------------------------- */

static NSString *take(char *s) {   /* a core string, freed */
    if (!s) return @"";
    NSString *r = [NSString stringWithUTF8String:s] ?: @"";
    fable_string_free(s);
    return r;
}
static NSString *TR(const char *key) { return take(fable_tr(key)); }
static NSString *TRN(const char *key, NSString *n) { return [TR(key) stringByReplacingOccurrencesOfString:@"{n}" withString:n ?: @""]; }
static NSString *setting(const char *key) { return take(fable_setting_get(key)); }
/* The "text size" setting: on desktops the default zoom of every page (50–300%). */
static double defaultZoom(void) {
    double z = setting("text_size").doubleValue / 100.0;
    return z >= 0.5 && z <= 3.0 ? z : 1.0;
}
static NSString *J(NSString *s) { return take(fable_json_string((s ?: @"").UTF8String)); }   /* a JSON string literal */
static NSString *jsonText(id object) {   /* Foundation objects as JSON text */
    NSData *data = object ? [NSJSONSerialization dataWithJSONObject:object options:0 error:nil] : nil;
    return data ? [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] : @"{}";
}
static uint64_t now_ms(void) { return clock_gettime_nsec_np(CLOCK_UPTIME_RAW) / 1000000; }   /* monotonic, for the sleep policy */
static uint64_t wall_ms(void) { return (uint64_t)(NSDate.date.timeIntervalSince1970 * 1000.0); }

static NSImage *symbol(NSString *name, NSString *label) {
    return [NSImage imageWithSystemSymbolName:name accessibilityDescription:label];
}

@class Tab;

/* ---- the application ----------------------------------------------------- */

@interface FableApp : NSObject <NSApplicationDelegate, NSMenuItemValidation, NSPopoverDelegate, WKScriptMessageHandler, WKURLSchemeHandler, WKNavigationDelegate>
@property (nonatomic) FableTabs *tabs;
@property (nonatomic, weak) Tab *lastTab;                          /* the tab last in front: the panel acts on it */
@property (nonatomic, strong) WKContentRuleList *blockList;        /* the compiled tracker rules */
@property (nonatomic, strong) WKContentRuleList *adBlockList;       /* the compiled ad rules */
@property (nonatomic, strong) NSPopover *popover;                  /* the panel */
@property (nonatomic, strong) WKWebView *panelWeb;
@property (nonatomic) BOOL panelLoaded;
@property (nonatomic, strong) NSMutableArray<NSString *> *panelQueue; /* scripts waiting for the panel page */
@property (nonatomic, copy) NSString *panelView;                   /* the view it was opened on; nil when closed */
@property (nonatomic, strong) NSMutableArray<Tab *> *open;
@property (nonatomic, strong) WKUserContentController *content;   /* shared: the message handler and the blocklist */
@property (nonatomic, strong) WKWebsiteDataStore *privateStore;    /* nil when no private tab is open */
@property (nonatomic, strong) NSMutableSet *downloads;             /* WKDownload objects in flight */
@property (nonatomic, strong) NSTimer *sleepTimer;
@property (nonatomic) NSPoint cascade;
- (WKWebViewConfiguration *)configurationPrivate:(BOOL)priv;
- (Tab *)openTab:(NSString *)input private:(BOOL)priv nextTo:(Tab *)sibling configuration:(WKWebViewConfiguration *)config background:(BOOL)background;
- (Tab *)tabForWebView:(WKWebView *)web;
- (Tab *)frontTab;
- (void)tabClosed:(Tab *)tab;
- (NSString *)userAgent;
- (void)buildMenus;
@end

/* The panel: ui/panel.html in a popover (implemented near the end). */
@interface FableApp (Panel)
- (void)showPanel:(NSString *)view from:(Tab *)tab;
- (void)panelRun:(NSString *)script;
- (void)panelMessage:(NSString *)message;
- (void)panelAct:(NSString *)name arg:(NSString *)arg;
- (void)compileBlockList;
@end

static FableApp *app;

API_AVAILABLE(macos(11.3))
@interface FableApp (Downloads) <WKDownloadDelegate>
@end

/* ---- a tab: one window of a tab group ------------------------------------ */

@interface Tab : NSWindowController <NSWindowDelegate, NSToolbarDelegate, NSToolbarItemValidation, NSMenuItemValidation, NSTextFieldDelegate, WKNavigationDelegate, WKUIDelegate>
@property (nonatomic) uint32_t tabId;
@property (nonatomic) BOOL isPrivate;
@property (nonatomic, strong) WKWebView *web;     /* nil while asleep */
@property (nonatomic, copy) NSString *url;        /* what to load on waking; HOME for the new-tab page */
@property (nonatomic, strong) NSTextField *address;
@property (nonatomic, strong) NSTextField *toast;
@property (nonatomic, strong) NSButton *menuButton;   /* the panel opens under it */
@property (nonatomic) NSInteger toastSerial;
- (void)applyHomeButton;
@end

/* FABLE_SNAPSHOT_DIR=<folder> (for CI, where screencapture has no display):
   each finished page load writes a PNG of its window there: the window frame
   (toolbar included) with the page's own snapshot drawn into its place. */
static void snapshot_window(NSWindow *window, WKWebView *web) {
    const char *dir = getenv("FABLE_SNAPSHOT_DIR");
    if (!dir || !*dir || !window || !web) return;
    static int serial = 0;
    NSString *path = [NSString stringWithFormat:@"%s/macos-%02d-%@.png", dir, ++serial, web.URL.host.length ? web.URL.host : @"home"];
    NSView *frame = window.contentView.superview ?: window.contentView;
    NSRect bounds = frame.bounds;
    NSBitmapImageRep *chrome = [frame bitmapImageRepForCachingDisplayInRect:bounds];
    [frame cacheDisplayInRect:bounds toBitmapImageRep:chrome];
    NSRect place = [web convertRect:web.bounds toView:frame];
    if (frame.isFlipped) place.origin.y = NSHeight(bounds) - NSMaxY(place);
    [web takeSnapshotWithConfiguration:nil completionHandler:^(NSImage *page, NSError *error) {
        NSBitmapImageRep *out = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:(NSInteger)NSWidth(bounds) * 2
            pixelsHigh:(NSInteger)NSHeight(bounds) * 2 bitsPerSample:8 samplesPerPixel:4 hasAlpha:YES isPlanar:NO
            colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:0 bitsPerPixel:0];
        out.size = bounds.size;
        [NSGraphicsContext saveGraphicsState];
        NSGraphicsContext.currentContext = [NSGraphicsContext graphicsContextWithBitmapImageRep:out];
        [chrome drawInRect:bounds];
        if (page) [page drawInRect:place];
        [NSGraphicsContext restoreGraphicsState];
        NSData *png = [out representationUsingType:NSBitmapImageFileTypePNG properties:@{}];
        [png writeToFile:path atomically:YES];
        NSLog(@"Fable: snapshot %@%@", path, error ? [@" (page: " stringByAppendingFormat:@"%@)", error] : @"");
    }];
}

@implementation Tab

- (instancetype)initPrivate:(BOOL)priv configuration:(WKWebViewConfiguration *)config {
    NSWindow *w = [[NSWindow alloc] initWithContentRect:NSMakeRect(0, 0, 1180, 800)
                                              styleMask:NSWindowStyleMaskTitled | NSWindowStyleMaskClosable | NSWindowStyleMaskMiniaturizable | NSWindowStyleMaskResizable
                                                backing:NSBackingStoreBuffered
                                                  defer:NO];
    if (!(self = [super initWithWindow:w])) return nil;
    _isPrivate = priv;
    _url = HOME;
    w.releasedWhenClosed = NO;
    w.minSize = NSMakeSize(480, 320);
    w.delegate = self;
    w.tabbingIdentifier = priv ? PRIVATE_GROUP : NORMAL_GROUP;   /* private tabs never join normal windows */
    w.tabbingMode = NSWindowTabbingModeAutomatic;
    w.titleVisibility = NSWindowTitleHidden;                      /* the address field says where you are; tabs show titles */
    w.toolbarStyle = NSWindowToolbarStyleUnified;
    w.title = TR("newtab");
    if (priv) {
        w.appearance = [NSAppearance appearanceNamed:NSAppearanceNameDarkAqua];
        /* kept out of screenshots, screen recordings and sharing, as on Android, unless allowed */
        w.sharingType = [setting("private_screenshots") isEqualToString:@"1"] ? NSWindowSharingReadOnly : NSWindowSharingNone;
    }

    NSToolbar *bar = [[NSToolbar alloc] initWithIdentifier:priv ? @"fable.toolbar.private" : @"fable.toolbar"];
    bar.delegate = self;
    bar.displayMode = NSToolbarDisplayModeIconOnly;
    bar.allowsUserCustomization = YES;
    bar.autosavesConfiguration = YES;
    w.toolbar = bar;
    [self applyHomeButton];

    NSTextField *toast = [NSTextField labelWithString:@""];
    toast.wantsLayer = YES;
    toast.layer.cornerRadius = 9;
    toast.layer.masksToBounds = YES;
    toast.drawsBackground = YES;
    toast.backgroundColor = [NSColor colorWithSRGBRed:0.165 green:0.102 blue:0.078 alpha:0.92];   /* #2A1A14 */
    toast.textColor = [NSColor colorWithSRGBRed:0.984 green:0.937 blue:0.894 alpha:1];           /* #FBEFE4 */
    toast.alignment = NSTextAlignmentCenter;
    toast.font = [NSFont systemFontOfSize:13];
    toast.hidden = YES;
    toast.translatesAutoresizingMaskIntoConstraints = NO;
    [w.contentView addSubview:toast];
    [NSLayoutConstraint activateConstraints:@[
        [toast.centerXAnchor constraintEqualToAnchor:w.contentView.centerXAnchor],
        [toast.bottomAnchor constraintEqualToAnchor:w.contentView.bottomAnchor constant:-28],
        [toast.widthAnchor constraintLessThanOrEqualToAnchor:w.contentView.widthAnchor constant:-80],
        [toast.heightAnchor constraintGreaterThanOrEqualToConstant:30],
    ]];
    _toast = toast;

    [self attachWeb:config ?: [app configurationPrivate:priv]];
    return self;
}

/* ---- the web view ---- */

- (void)attachWeb:(WKWebViewConfiguration *)config {
    WKWebView *web = [[WKWebView alloc] initWithFrame:self.window.contentView.bounds configuration:config];
    web.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    web.navigationDelegate = self;
    web.UIDelegate = self;
    web.allowsBackForwardNavigationGestures = YES;
    web.allowsMagnification = YES;
    if (@available(macOS 13.3, *)) web.inspectable = YES;   /* Safari's Develop menu can inspect Fable's pages */
    web.customUserAgent = [app userAgent];   /* nil: WebKit's own */
    web.pageZoom = defaultZoom();
    for (NSString *key in observedKeys()) [web addObserver:self forKeyPath:key options:0 context:KVO];
    [self.window.contentView addSubview:web positioned:NSWindowBelow relativeTo:self.toast];
    self.web = web;
}

- (void)detachWeb {
    WKWebView *web = self.web;
    if (!web) return;
    self.web = nil;
    if (web.URL.absoluteString.length) self.url = web.URL.absoluteString;
    for (NSString *key in observedKeys()) [web removeObserver:self forKeyPath:key context:KVO];
    [web stopLoading];
    web.navigationDelegate = nil;
    web.UIDelegate = nil;
    [web removeFromSuperview];
}

- (void)loadURLString:(NSString *)url {
    self.url = url.length ? url : HOME;
    if (!self.web) { [self wake]; return; }
    NSURL *u = [NSURL URLWithString:self.url];
    if (u) [self.web loadRequest:[NSURLRequest requestWithURL:u]];
}

/* Address-bar input: a URL, a host or search words, resolved by the core. */
- (void)navigate:(NSString *)input {
    NSString *url = take(fable_resolve(input.UTF8String));
    if (url.length) [self loadURLString:url];
    [self.window makeFirstResponder:self.web];
}

- (void)showHome {
    [self loadURLString:HOME];
    [self.window makeFirstResponder:self.address];
}

- (BOOL)atHome {
    NSString *u = self.web ? (self.web.URL.absoluteString ?: self.url) : self.url;
    return u.length == 0 || [u hasPrefix:HOME];
}

/* ---- sleep ---- */

- (void)sleep {
    if (!self.web) return;
    [self detachWeb];   /* the page's memory goes with it; the URL and title stay */
}

- (void)wake {
    if (self.web) return;
    [self attachWeb:[app configurationPrivate:self.isPrivate]];
    NSURL *u = [NSURL URLWithString:self.url ?: HOME];
    if (u) [self.web loadRequest:[NSURLRequest requestWithURL:u]];
    [self refreshChrome];
}

/* Asks the page whether anything is audibly playing before it is put to sleep. */
- (void)sleepUnlessPlaying {
    if (!self.web) return;
    NSString *js = @"Array.prototype.some.call(document.querySelectorAll('video,audio'),function(m){return !m.paused&&!m.muted&&m.volume>0})";
    __weak Tab *weak = self;
    [self.web evaluateJavaScript:js completionHandler:^(id result, NSError *error) {
        Tab *t = weak;
        if (!t) return;
        if ([result isKindOfClass:NSNumber.class] && [result boolValue]) fable_tabs_touch(app.tabs, t.tabId, now_ms());
        else if (!t.window.isVisible) [t sleep];
    }];
}

/* ---- chrome ---- */

- (void)refreshChrome {
    NSString *u = self.web ? (self.web.URL.absoluteString ?: self.url) : self.url;
    if (self.web.URL.absoluteString.length) self.url = self.web.URL.absoluteString;
    BOOL home = [self atHome];
    if (!self.address.currentEditor) self.address.stringValue = home ? @"" : (u ?: @"");   /* never under the user's typing */
    NSString *title = self.web.title;
    self.window.title = title.length ? title : (home ? TR("newtab") : (u ?: @""));
    [self.window.toolbar validateVisibleItems];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
    if (context != KVO) { [super observeValueForKeyPath:keyPath ofObject:object change:change context:context]; return; }
    [self refreshChrome];
}

- (void)say:(NSString *)message {
    NSTextField *toast = self.toast;
    toast.stringValue = [NSString stringWithFormat:@"   %@   ", message];
    toast.hidden = NO;
    toast.alphaValue = 1;
    NSInteger serial = ++self.toastSerial;
    __weak Tab *weak = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.4 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        Tab *t = weak;
        if (!t || t.toastSerial != serial) return;   /* a newer message is showing */
        [NSAnimationContext runAnimationGroup:^(NSAnimationContext *ctx) {
            ctx.duration = 0.25;
            t.toast.animator.alphaValue = 0;
        } completionHandler:^{
            if (t.toastSerial == serial) t.toast.hidden = YES;
        }];
    });
}

/* ---- toolbar ---- */

static NSString *const ITEM_BACK = @"back", *const ITEM_FORWARD = @"forward", *const ITEM_RELOAD = @"reload",
                *const ITEM_ADDRESS = @"address", *const ITEM_READER = @"reader", *const ITEM_NEW = @"new",
                *const ITEM_PRIVATE = @"private", *const ITEM_MENU = @"menu", *const ITEM_HOME = @"home";

/* The optional Home button (Settings › Display), after Forward; off unless switched on. Windows
 * of one kind share their toolbar's items, so this checks before adding or removing. */
- (void)applyHomeButton {
    NSToolbar *bar = self.window.toolbar;
    BOOL want = [setting("home_button") isEqualToString:@"1"];
    NSUInteger at = NSNotFound, forward = NSNotFound;
    for (NSUInteger i = 0; i < bar.items.count; i++) {
        NSString *ident = bar.items[i].itemIdentifier;
        if ([ident isEqualToString:ITEM_HOME]) at = i;
        if ([ident isEqualToString:ITEM_FORWARD]) forward = i;
    }
    if (want && at == NSNotFound) [bar insertItemWithItemIdentifier:ITEM_HOME atIndex:forward == NSNotFound ? 0 : forward + 1];
    else if (!want && at != NSNotFound) [bar removeItemAtIndex:at];
}

- (NSArray<NSToolbarItemIdentifier> *)toolbarDefaultItemIdentifiers:(NSToolbar *)toolbar {
    NSMutableArray *items = [@[ITEM_BACK, ITEM_FORWARD, ITEM_RELOAD, NSToolbarFlexibleSpaceItemIdentifier, ITEM_ADDRESS,
                               NSToolbarFlexibleSpaceItemIdentifier, ITEM_NEW, ITEM_MENU] mutableCopy];
    if (self.isPrivate) [items insertObject:ITEM_PRIVATE atIndex:0];
    return items;
}

- (NSArray<NSToolbarItemIdentifier> *)toolbarAllowedItemIdentifiers:(NSToolbar *)toolbar {
    return [[self toolbarDefaultItemIdentifiers:toolbar] arrayByAddingObjectsFromArray:@[ITEM_HOME, ITEM_READER, NSToolbarSpaceItemIdentifier]];
}

- (NSToolbarItem *)button:(NSToolbarItemIdentifier)ident symbol:(NSString *)name label:(NSString *)label action:(SEL)action {
    NSToolbarItem *item = [[NSToolbarItem alloc] initWithItemIdentifier:ident];
    item.image = symbol(name, label);
    item.label = label;
    item.paletteLabel = label;
    item.toolTip = label;
    item.target = self;
    item.action = action;
    item.bordered = YES;
    return item;
}

- (NSToolbarItem *)toolbar:(NSToolbar *)toolbar itemForItemIdentifier:(NSToolbarItemIdentifier)ident willBeInsertedIntoToolbar:(BOOL)flag {
    if ([ident isEqualToString:ITEM_BACK]) return [self button:ident symbol:@"chevron.left" label:TR("go_back") action:@selector(fableBack:)];
    if ([ident isEqualToString:ITEM_FORWARD]) return [self button:ident symbol:@"chevron.right" label:TR("go_forward") action:@selector(fableForward:)];
    if ([ident isEqualToString:ITEM_HOME]) return [self button:ident symbol:@"house" label:TR("go_home") action:@selector(fableHome:)];
    if ([ident isEqualToString:ITEM_RELOAD]) return [self button:ident symbol:@"arrow.clockwise" label:TR("reload") action:@selector(fableReload:)];
    if ([ident isEqualToString:ITEM_READER]) return [self button:ident symbol:@"doc.plaintext" label:TR("reader_mode") action:@selector(toggleReader:)];
    if ([ident isEqualToString:ITEM_NEW]) return [self button:ident symbol:@"plus" label:TR(self.isPrivate ? "new_private" : "new_tab_btn") action:@selector(newTab:)];
    if ([ident isEqualToString:ITEM_MENU]) {   /* a real button, so the popover has something to point at */
        NSToolbarItem *item = [[NSToolbarItem alloc] initWithItemIdentifier:ident];
        NSButton *button = [NSButton buttonWithImage:symbol(@"line.3.horizontal", TR("menu")) target:self action:@selector(showMenuPanel:)];
        button.bezelStyle = NSBezelStyleTexturedRounded;
        button.toolTip = TR("menu");
        item.view = button;
        item.label = TR("menu");
        item.paletteLabel = item.label;
        item.visibilityPriority = NSToolbarItemVisibilityPriorityHigh;
        self.menuButton = button;
        return item;
    }
    if ([ident isEqualToString:ITEM_PRIVATE]) {
        NSToolbarItem *item = [[NSToolbarItem alloc] initWithItemIdentifier:ident];
        NSButton *badge = [NSButton buttonWithTitle:TR("private_mode") image:symbol(@"eye.slash", TR("private_mode")) target:nil action:NULL];
        badge.bordered = NO;
        badge.imagePosition = NSImageLeading;
        badge.contentTintColor = [NSColor colorWithSRGBRed:0.961 green:0.643 blue:0.514 alpha:1];   /* #F5A483, as on the private new-tab page */
        item.view = badge;
        item.label = TR("private_mode");
        item.paletteLabel = item.label;
        return item;
    }
    if ([ident isEqualToString:ITEM_ADDRESS]) {
        NSToolbarItem *item = [[NSToolbarItem alloc] initWithItemIdentifier:ident];
        NSTextField *field = [NSTextField textFieldWithString:@""];
        field.placeholderString = TR("addr_hint");
        field.bezelStyle = NSTextFieldRoundedBezel;
        field.delegate = self;
        field.target = self;
        field.action = @selector(addressEntered:);
        field.cell.scrollable = YES;
        field.cell.wraps = NO;
        field.translatesAutoresizingMaskIntoConstraints = NO;
        NSLayoutConstraint *wide = [field.widthAnchor constraintEqualToConstant:640];
        wide.priority = NSLayoutPriorityDefaultLow;   /* as wide as the toolbar allows, up to 640 */
        [NSLayoutConstraint activateConstraints:@[wide, [field.widthAnchor constraintGreaterThanOrEqualToConstant:220],
                                                  [field.widthAnchor constraintLessThanOrEqualToConstant:860]]];
        item.view = field;
        item.label = TR("url");
        item.paletteLabel = item.label;
        item.visibilityPriority = NSToolbarItemVisibilityPriorityHigh;
        self.address = field;
        return item;
    }
    return nil;
}

- (BOOL)validateToolbarItem:(NSToolbarItem *)item {
    if ([item.itemIdentifier isEqualToString:ITEM_BACK]) return self.web.canGoBack;
    if ([item.itemIdentifier isEqualToString:ITEM_FORWARD]) return self.web.canGoForward;
    if ([item.itemIdentifier isEqualToString:ITEM_READER]) return self.web != nil && ![self atHome];
    return YES;
}

/* ---- actions (toolbar, menus via the responder chain) ---- */

- (void)addressEntered:(NSTextField *)field {
    NSString *text = [field.stringValue stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    if (text.length) [self navigate:text];
}

/* Esc in the address field puts the page's address back. */
- (BOOL)control:(NSControl *)control textView:(NSTextView *)textView doCommandBySelector:(SEL)command {
    if (control == self.address && command == @selector(cancelOperation:)) {
        self.address.stringValue = [self atHome] ? @"" : (self.url ?: @"");
        [self.window makeFirstResponder:self.web];
        return YES;
    }
    return NO;
}

- (IBAction)fableBack:(id)sender { [self.web goBack]; }
- (IBAction)fableForward:(id)sender { [self.web goForward]; }
- (IBAction)fableHome:(id)sender { [self loadURLString:HOME]; }   /* the new-tab page, in this window */
- (IBAction)fableReload:(id)sender { if (self.web) [self.web reload]; else [self wake]; }
- (IBAction)openLocation:(id)sender { [self.window makeFirstResponder:self.address]; [self.address selectText:nil]; }
- (IBAction)newTab:(id)sender { [app openTab:nil private:self.isPrivate nextTo:self configuration:nil background:NO]; }
- (IBAction)newWindowForTab:(id)sender { [self newTab:sender]; }   /* the "+" of the native tab bar */
- (IBAction)showMenuPanel:(id)sender { [app showPanel:@"menu" from:self]; }
- (IBAction)showSettings:(id)sender { [app showPanel:@"settings" from:self]; }
- (IBAction)showHistory:(id)sender { [app showPanel:@"history" from:self]; }
- (IBAction)showSniffer:(id)sender { [app showPanel:@"sniff" from:self]; [app panelAct:@"sniffScan" arg:@""]; }

/* After a language change: every label this window shows. */
- (void)relabel {
    NSDictionary *labels = @{ITEM_BACK: TR("go_back"), ITEM_FORWARD: TR("go_forward"), ITEM_HOME: TR("go_home"), ITEM_RELOAD: TR("reload"), ITEM_READER: TR("reader_mode"),
                             ITEM_NEW: TR(self.isPrivate ? "new_private" : "new_tab_btn"), ITEM_MENU: TR("menu"), ITEM_PRIVATE: TR("private_mode"), ITEM_ADDRESS: TR("url")};
    for (NSToolbarItem *item in self.window.toolbar.items) {
        NSString *label = labels[item.itemIdentifier];
        if (!label) continue;
        item.label = label;
        item.paletteLabel = label;
        item.toolTip = label;
        if ([item.itemIdentifier isEqualToString:ITEM_PRIVATE]) ((NSButton *)item.view).title = label;
    }
    self.address.placeholderString = TR("addr_hint");
    if ([self atHome] && self.web) [self.web reload];   /* the new-tab page in the new language */
    [self refreshChrome];
}

- (IBAction)closeWindowGroup:(id)sender {
    for (NSWindow *w in [self.window.tabbedWindows ?: @[self.window] copy]) [w performClose:sender];
}

- (IBAction)toggleReader:(id)sender {
    if (!self.web) return;
    NSString *script = take(fable_reader_script());
    __weak Tab *weak = self;
    [self.web evaluateJavaScript:script completionHandler:^(id result, NSError *error) {
        if ([result isEqual:@"none"]) [weak say:TR("no_article")];
        else if ([result isEqual:@"on"]) [weak say:TR("reader_on")];
    }];
}

- (void)zoomBy:(double)step {
    if (!self.web) return;
    double z = step == 0 ? defaultZoom() : MIN(3.0, MAX(0.5, self.web.pageZoom + step));
    self.web.pageZoom = z;
}
- (IBAction)fableZoomIn:(id)sender { [self zoomBy:0.1]; }
- (IBAction)fableZoomOut:(id)sender { [self zoomBy:-0.1]; }
- (IBAction)fableActualSize:(id)sender { [self zoomBy:0]; }

- (BOOL)validateMenuItem:(NSMenuItem *)item {
    SEL a = item.action;
    if (a == @selector(fableBack:)) return self.web.canGoBack;
    if (a == @selector(fableForward:)) return self.web.canGoForward;
    if (a == @selector(toggleReader:)) return self.web != nil && ![self atHome];
    if (a == @selector(fableZoomIn:) || a == @selector(fableZoomOut:) || a == @selector(fableActualSize:)) return self.web != nil;
    return YES;
}

/* ---- window ---- */

- (void)windowDidBecomeKey:(NSNotification *)note {
    app.lastTab = self;
    fable_tabs_activate(app.tabs, self.tabId, now_ms());
    if (!self.web) [self wake];
}
- (void)windowDidDeminiaturize:(NSNotification *)note { if (!self.web) [self wake]; }

- (void)windowWillClose:(NSNotification *)note {
    [self detachWeb];
    fable_tabs_close(app.tabs, self.tabId);
    fable_sniff_clear(self.tabId);
    [app tabClosed:self];
}

/* ---- navigation ---- */

/* The preferences variant: the JavaScript setting applies from the next page on, in every tab. */
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)action preferences:(WKWebpagePreferences *)preferences
    decisionHandler:(void (^)(WKNavigationActionPolicy, WKWebpagePreferences *))decideWith {
    preferences.allowsContentJavaScript = ![setting("javascript") isEqualToString:@"0"];
    void (^decide)(WKNavigationActionPolicy) = ^(WKNavigationActionPolicy policy) { decideWith(policy, preferences); };
    NSURL *url = action.request.URL;
    NSString *scheme = url.scheme.lowercaseString ?: @"";
    if (@available(macOS 11.3, *)) {
        if (action.shouldPerformDownload) { decide(WKNavigationActionPolicyDownload); return; }
    }
    /* The page tried to leave the browser for another app. */
    if (fable_block_external_app(url.absoluteString.UTF8String)) {
        decide(WKNavigationActionPolicyCancel);
        [self say:TR("external_app_blocked")];
        return;
    }
    /* mailto:, tel:, app links and the like belong to other apps. */
    if ([scheme isEqualToString:@"fable"] && ![url.absoluteString hasPrefix:HOME]) { decide(WKNavigationActionPolicyCancel); return; }   /* only the new-tab page */
    NSSet *ours = [NSSet setWithArray:@[@"http", @"https", @"fable", @"about", @"data", @"blob", @"file", @"javascript"]];
    if (![ours containsObject:scheme]) {
        if (action.navigationType == WKNavigationTypeLinkActivated) [NSWorkspace.sharedWorkspace openURL:url];
        decide(WKNavigationActionPolicyCancel);
        return;
    }
    /* Cmd-click and middle-click open a background tab, as in Safari and Chrome. */
    BOOL newTab = (action.modifierFlags & NSEventModifierFlagCommand) || action.buttonNumber == 2;
    if (newTab && action.navigationType == WKNavigationTypeLinkActivated && action.targetFrame.isMainFrame) {
        [app openTab:url.absoluteString private:self.isPrivate nextTo:self configuration:nil
          background:!(action.modifierFlags & NSEventModifierFlagShift)];
        decide(WKNavigationActionPolicyCancel);
        return;
    }
    decide(WKNavigationActionPolicyAllow);
}

- (void)webView:(WKWebView *)webView decidePolicyForNavigationResponse:(WKNavigationResponse *)response decisionHandler:(void (^)(WKNavigationResponsePolicy))decide {
    if (@available(macOS 11.3, *)) {
        NSString *disposition = nil;
        if ([response.response isKindOfClass:NSHTTPURLResponse.class])
            disposition = [(NSHTTPURLResponse *)response.response valueForHTTPHeaderField:@"Content-Disposition"];
        if (!response.canShowMIMEType || (response.isForMainFrame && [disposition.lowercaseString hasPrefix:@"attachment"])) {
            decide(WKNavigationResponsePolicyDownload);
            return;
        }
    }
    decide(WKNavigationResponsePolicyAllow);
}

- (void)webView:(WKWebView *)webView navigationAction:(WKNavigationAction *)action didBecomeDownload:(WKDownload *)download API_AVAILABLE(macos(11.3)) {
    [app.downloads addObject:download];
    download.delegate = app;
}

- (void)webView:(WKWebView *)webView navigationResponse:(WKNavigationResponse *)response didBecomeDownload:(WKDownload *)download API_AVAILABLE(macos(11.3)) {
    [app.downloads addObject:download];
    download.delegate = app;
}

- (void)webView:(WKWebView *)webView didCommitNavigation:(WKNavigation *)navigation {
    fable_sniff_clear(self.tabId);
    [self refreshChrome];
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation {
    [self refreshChrome];
    if (getenv("FABLE_SNAPSHOT_DIR")) {
        __weak Tab *weakSelf = self;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            Tab *tab = weakSelf;
            if (tab && tab.web == webView) snapshot_window(tab.window, webView);
        });
    }
    if ([setting("block_ads") isEqualToString:@"1"]) {
        /* Hide the ad boxes the page shows itself; the rule list already
         * stops the third-party ones. */
        NSString *script = take(fable_adblock_script());
        [webView evaluateJavaScript:script completionHandler:nil];
    }
    NSString *scheme = webView.URL.scheme.lowercaseString;
    if (!self.isPrivate && ([scheme isEqualToString:@"http"] || [scheme isEqualToString:@"https"]))
        fable_history_add(webView.URL.absoluteString.UTF8String, (webView.title ?: @"").UTF8String, wall_ms());   /* private tabs keep no history */
}

- (void)webViewWebContentProcessDidTerminate:(WKWebView *)webView {
    [webView reload];   /* a crashed page comes back instead of staying blank */
}

/* ---- UI delegate ---- */

/* target=_blank and window.open: a new tab in the same mode, keeping the opener link (sign-in pop-ups need it). */
- (WKWebView *)webView:(WKWebView *)webView createWebViewWithConfiguration:(WKWebViewConfiguration *)configuration
   forNavigationAction:(WKNavigationAction *)action windowFeatures:(WKWindowFeatures *)features {
    Tab *t = [app openTab:nil private:self.isPrivate nextTo:self configuration:configuration background:NO];
    return t.web;
}

- (void)webViewDidClose:(WKWebView *)webView { [self.window performClose:nil]; }

- (NSAlert *)alertFrom:(WKFrameInfo *)frame message:(NSString *)message {
    NSAlert *alert = [NSAlert new];
    alert.messageText = frame.request.URL.host ?: @"";
    alert.informativeText = message ?: @"";
    return alert;
}

- (void)webView:(WKWebView *)webView runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(void))done {
    NSAlert *alert = [self alertFrom:frame message:message];
    [alert addButtonWithTitle:TR("mac_ok")];
    [alert beginSheetModalForWindow:self.window completionHandler:^(NSModalResponse r) { done(); }];
}

- (void)webView:(WKWebView *)webView runJavaScriptConfirmPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(BOOL))done {
    NSAlert *alert = [self alertFrom:frame message:message];
    [alert addButtonWithTitle:TR("mac_ok")];
    [alert addButtonWithTitle:TR("mac_cancel")];
    [alert beginSheetModalForWindow:self.window completionHandler:^(NSModalResponse r) { done(r == NSAlertFirstButtonReturn); }];
}

- (void)webView:(WKWebView *)webView runJavaScriptTextInputPanelWithPrompt:(NSString *)prompt defaultText:(NSString *)text initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(NSString *))done {
    NSAlert *alert = [self alertFrom:frame message:prompt];
    NSTextField *field = [NSTextField textFieldWithString:text ?: @""];
    field.frame = NSMakeRect(0, 0, 280, 24);
    alert.accessoryView = field;
    [alert addButtonWithTitle:TR("mac_ok")];
    [alert addButtonWithTitle:TR("mac_cancel")];
    alert.window.initialFirstResponder = field;
    [alert beginSheetModalForWindow:self.window completionHandler:^(NSModalResponse r) {
        done(r == NSAlertFirstButtonReturn ? field.stringValue : nil);
    }];
}

- (void)webView:(WKWebView *)webView runOpenPanelWithParameters:(WKOpenPanelParameters *)parameters initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(NSArray<NSURL *> *))done {
    NSOpenPanel *panel = [NSOpenPanel openPanel];
    panel.allowsMultipleSelection = parameters.allowsMultipleSelection;
    panel.canChooseDirectories = parameters.allowsDirectories;
    panel.canChooseFiles = YES;
    [panel beginSheetModalForWindow:self.window completionHandler:^(NSModalResponse r) {
        done(r == NSModalResponseOK ? panel.URLs : nil);
    }];
}

@end

/* ---- application ----------------------------------------------------------- */

@implementation FableApp

- (WKWebViewConfiguration *)configurationPrivate:(BOOL)priv {
    WKWebViewConfiguration *config = [WKWebViewConfiguration new];
    config.userContentController = self.content;
    [config setURLSchemeHandler:self forURLScheme:@"fable"];
    if (priv) {
        if (!self.privateStore) self.privateStore = [WKWebsiteDataStore nonPersistentDataStore];   /* memory only */
        config.websiteDataStore = self.privateStore;
    } else {
        config.websiteDataStore = [WKWebsiteDataStore defaultDataStore];
    }
    config.preferences.javaScriptCanOpenWindowsAutomatically = NO;   /* pop-ups only from a click */
    return config;
}

- (Tab *)tabForWebView:(WKWebView *)web {
    for (Tab *t in self.open) if (t.web == web) return t;
    return nil;
}

/* The key window's tab; while the panel (a popover window) is key, the tab it was opened from. */
- (Tab *)frontTab {
    NSWindowController *c = NSApp.keyWindow.windowController ?: NSApp.mainWindow.windowController;
    if ([c isKindOfClass:Tab.class]) return (Tab *)c;
    Tab *last = self.lastTab;
    return last && [self.open containsObject:last] ? last : self.open.lastObject;
}

- (NSString *)userAgent {
    NSString *mode = setting("ua_mode"), *custom = setting("ua_custom");
    if ([mode isEqualToString:@"android"]) return ANDROID_UA;
    if ([mode isEqualToString:@"iphone"]) return IPHONE_UA;
    if ([mode isEqualToString:@"ipad"]) return IPAD_UA;
    if ([mode isEqualToString:@"chrome_win"]) return CHROME_WIN_UA;
    if ([mode isEqualToString:@"chrome_mac"]) return CHROME_MAC_UA;
    if ([mode isEqualToString:@"safari_mac"]) return SAFARI_MAC_UA;
    if ([mode isEqualToString:@"firefox"]) return FIREFOX_UA;
    if ([mode isEqualToString:@"edge"]) return EDGE_UA;
    if ([mode isEqualToString:@"custom"] && custom.length) return custom;
    return nil;
}

- (Tab *)openTab:(NSString *)input private:(BOOL)priv nextTo:(Tab *)sibling configuration:(WKWebViewConfiguration *)config background:(BOOL)background {
    Tab *t = [[Tab alloc] initPrivate:priv configuration:config];
    t.tabId = fable_tabs_open(self.tabs, now_ms());
    [self.open addObject:t];
    if (sibling.window && sibling.isPrivate == priv) {
        [sibling.window addTabbedWindow:t.window ordered:NSWindowAbove];
    } else {
        [t.window center];
        self.cascade = [t.window cascadeTopLeftFromPoint:self.cascade];
    }
    if (background && sibling) {
        fable_tabs_activate(self.tabs, sibling.tabId, now_ms());   /* the core's front tab stays the one in front */
        [sibling.window makeKeyAndOrderFront:nil];
    } else {
        [t.window makeKeyAndOrderFront:nil];
    }
    if (!config) {   /* a page-opened window loads its own request */
        if (input.length) [t navigate:input];
        else [t showHome];
    }
    [t refreshChrome];
    return t;
}

- (void)tabClosed:(Tab *)tab {
    [self.open removeObject:tab];
    if (self.popover.shown && self.lastTab == tab) [self.popover close];   /* the panel was pointing into this window */
    if (!tab.isPrivate) return;
    for (Tab *t in self.open) if (t.isPrivate) return;
    self.privateStore = nil;   /* the last private tab: its cookies, cache and storage go with the store */
}

/* ---- menu actions without a window ---- */

- (IBAction)newTab:(id)sender {   /* reached only when no tab window is key */
    [self openTab:nil private:NO nextTo:nil configuration:nil background:NO];
}
- (IBAction)newWindow:(id)sender { [self openTab:nil private:NO nextTo:nil configuration:nil background:NO]; }
- (IBAction)newPrivateWindow:(id)sender { [self openTab:nil private:YES nextTo:nil configuration:nil background:NO]; }

- (IBAction)makeDefaultBrowser:(id)sender {
    NSURL *bundle = NSBundle.mainBundle.bundleURL;
    if (@available(macOS 12.0, *)) {
        for (NSString *scheme in @[@"http", @"https"])
            [NSWorkspace.sharedWorkspace setDefaultApplicationAtURL:bundle toOpenURLsWithScheme:scheme completionHandler:^(NSError *error) {}];
    } else {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
        CFStringRef ident = (__bridge CFStringRef)NSBundle.mainBundle.bundleIdentifier;
        LSSetDefaultHandlerForURLScheme(CFSTR("http"), ident);
        LSSetDefaultHandlerForURLScheme(CFSTR("https"), ident);
#pragma clang diagnostic pop
    }
}

- (BOOL)validateMenuItem:(NSMenuItem *)item { return YES; }

/* ---- the new-tab page and its search box ---- */

- (void)webView:(WKWebView *)webView startURLSchemeTask:(id<WKURLSchemeTask>)task {
    NSURL *url = task.request.URL;
    if (![url.host isEqualToString:@"newtab"]) {
        [task didFailWithError:[NSError errorWithDomain:NSURLErrorDomain code:NSURLErrorFileDoesNotExist userInfo:nil]];
        return;
    }
    BOOL priv = !webView.configuration.websiteDataStore.isPersistent;
    char *html = fable_newtab_page(priv ? 1 : 0, NULL);   /* 1: private, and on macOS truly kept apart */
    NSData *data = [NSData dataWithBytes:html length:strlen(html)];
    fable_string_free(html);
    NSURLResponse *response = [[NSURLResponse alloc] initWithURL:url MIMEType:@"text/html" expectedContentLength:(NSInteger)data.length textEncodingName:@"utf-8"];
    [task didReceiveResponse:response];
    [task didReceiveData:data];
    [task didFinish];
}

- (void)webView:(WKWebView *)webView stopURLSchemeTask:(id<WKURLSchemeTask>)task {}

/* Only the new-tab page may post, and all it can ask is to navigate its own tab.
 * The panel has a handler of its own ("fableui"), on its own web view. */
- (void)userContentController:(WKUserContentController *)controller didReceiveScriptMessage:(WKScriptMessage *)message {
    if ([message.name isEqualToString:@"fableui"]) {
        if (message.webView == self.panelWeb && [message.body isKindOfClass:NSString.class]) [self panelMessage:message.body];
        return;
    }
    if (!message.frameInfo.isMainFrame || ![message.frameInfo.request.URL.scheme isEqualToString:@"fable"]) return;
    if (![message.body isKindOfClass:NSString.class]) return;
    [[self tabForWebView:message.webView] navigate:message.body];
}

/* ---- sleep policy ---- */

- (void)sleepTick:(NSTimer *)timer {
    uint32_t ids[64];
    size_t count = fable_tabs_collect_sleepers(self.tabs, now_ms(), ids, 64);
    for (size_t i = 0; i < count; i++) {
        for (Tab *t in [self.open copy]) {
            if (t.tabId != ids[i] || !t.web) continue;
            if (t.window.isVisible || t.window.isKeyWindow) fable_tabs_touch(self.tabs, t.tabId, now_ms());   /* on screen */
            else [t sleepUnlessPlaying];
        }
    }
}

/* ---- menus ---- */

static NSMenuItem *item(NSString *title, SEL action, NSString *key, NSEventModifierFlags mods) {
    NSMenuItem *m = [[NSMenuItem alloc] initWithTitle:title action:action keyEquivalent:key ?: @""];
    if (key.length) m.keyEquivalentModifierMask = mods ? mods : NSEventModifierFlagCommand;
    return m;
}

static NSMenu *submenu(NSMenu *bar, NSString *title) {
    NSMenuItem *top = [[NSMenuItem alloc] initWithTitle:title action:nil keyEquivalent:@""];
    NSMenu *menu = [[NSMenu alloc] initWithTitle:title];
    top.submenu = menu;
    [bar addItem:top];
    return menu;
}

- (void)buildMenus {
    NSString *name = @"Fable";
    NSEventModifierFlags cmd = NSEventModifierFlagCommand, shift = NSEventModifierFlagCommand | NSEventModifierFlagShift,
                         opt = NSEventModifierFlagCommand | NSEventModifierFlagOption;
    NSMenu *bar = [NSMenu new];

    NSMenu *appMenu = submenu(bar, name);
    [appMenu addItem:item(TRN("mac_about", name), @selector(orderFrontStandardAboutPanel:), nil, 0)];
    [appMenu addItem:NSMenuItem.separatorItem];
    [appMenu addItem:item([TR("settings") stringByAppendingString:@"…"], @selector(showSettings:), @",", cmd)];
    NSMenuItem *dflt = item(TR("mac_set_default"), @selector(makeDefaultBrowser:), nil, 0);
    dflt.target = self;
    [appMenu addItem:dflt];
    [appMenu addItem:NSMenuItem.separatorItem];
    [appMenu addItem:item(TRN("mac_hide", name), @selector(hide:), @"h", cmd)];
    [appMenu addItem:item(TR("mac_hide_others"), @selector(hideOtherApplications:), @"h", opt)];
    [appMenu addItem:item(TR("mac_show_all"), @selector(unhideAllApplications:), nil, 0)];
    [appMenu addItem:NSMenuItem.separatorItem];
    [appMenu addItem:item(TRN("mac_quit", name), @selector(terminate:), @"q", cmd)];

    NSMenu *file = submenu(bar, TR("mac_file"));
    [file addItem:item(TR("new_tab_btn"), @selector(newTab:), @"t", cmd)];
    NSMenuItem *window = item(TR("mac_new_window"), @selector(newWindow:), @"n", cmd);
    window.target = self;
    [file addItem:window];
    NSMenuItem *priv = item(TR("mac_new_private_window"), @selector(newPrivateWindow:), @"n", shift);
    priv.target = self;
    [file addItem:priv];
    [file addItem:item(TR("mac_open_location"), @selector(openLocation:), @"l", cmd)];
    [file addItem:NSMenuItem.separatorItem];
    [file addItem:item(TR("close_tab"), @selector(performClose:), @"w", cmd)];
    [file addItem:item(TR("mac_close_window"), @selector(closeWindowGroup:), @"w", shift)];

    NSMenu *edit = submenu(bar, TR("mac_edit"));
    [edit addItem:item(TR("mac_undo"), @selector(undo:), @"z", cmd)];
    [edit addItem:item(TR("mac_redo"), @selector(redo:), @"z", shift)];
    [edit addItem:NSMenuItem.separatorItem];
    [edit addItem:item(TR("mac_cut"), @selector(cut:), @"x", cmd)];
    [edit addItem:item(TR("copy"), @selector(copy:), @"c", cmd)];
    [edit addItem:item(TR("mac_paste"), @selector(paste:), @"v", cmd)];
    [edit addItem:item(TR("mac_select_all"), @selector(selectAll:), @"a", cmd)];

    NSMenu *view = submenu(bar, TR("mac_view"));
    [view addItem:item(TR("reload"), @selector(fableReload:), @"r", cmd)];
    [view addItem:item(TR("reader_mode"), @selector(toggleReader:), @"r", shift)];
    [view addItem:NSMenuItem.separatorItem];
    [view addItem:item(TR("mac_actual_size"), @selector(fableActualSize:), @"0", cmd)];
    [view addItem:item(TR("mac_zoom_in"), @selector(fableZoomIn:), @"+", cmd)];
    [view addItem:item(TR("mac_zoom_out"), @selector(fableZoomOut:), @"-", cmd)];
    [view addItem:NSMenuItem.separatorItem];
    [view addItem:item(TR("mac_show_tab_bar"), @selector(toggleTabBar:), nil, 0)];
    [view addItem:item(TR("mac_show_all_tabs"), @selector(toggleTabOverview:), @"\\", shift)];

    NSMenu *history = submenu(bar, TR("history"));
    [history addItem:item(TR("go_back"), @selector(fableBack:), @"[", cmd)];
    [history addItem:item(TR("go_forward"), @selector(fableForward:), @"]", cmd)];
    [history addItem:item(TR("go_home"), @selector(fableHome:), @"h", shift)];   /* ⇧⌘H, as in Safari */
    [history addItem:NSMenuItem.separatorItem];
    [history addItem:item(TR("history"), @selector(showHistory:), @"y", cmd)];
    [view addItem:NSMenuItem.separatorItem];
    [view addItem:item(TR("sniff"), @selector(showSniffer:), @"m", opt)];

    NSMenu *windows = submenu(bar, TR("mac_window"));
    [windows addItem:item(TR("mac_minimize"), @selector(performMiniaturize:), @"m", cmd)];
    [windows addItem:item(TR("mac_zoom"), @selector(performZoom:), nil, 0)];
    [windows addItem:NSMenuItem.separatorItem];
    [windows addItem:item(TR("mac_front"), @selector(arrangeInFront:), nil, 0)];

    NSApp.mainMenu = bar;
    NSApp.windowsMenu = windows;   /* AppKit adds the window list and the tab commands */
}

/* ---- lifecycle ---- */

- (void)applicationWillFinishLaunching:(NSNotification *)note {
    NSFileManager *fm = NSFileManager.defaultManager;
    NSURL *support = [[fm URLsForDirectory:NSApplicationSupportDirectory inDomains:NSUserDomainMask].firstObject URLByAppendingPathComponent:@"Fable"];
    [fm createDirectoryAtURL:support withIntermediateDirectories:YES attributes:nil error:nil];
    fable_store_open(support.path.fileSystemRepresentation);                 /* settings and history */
    fable_set_system_locale((NSLocale.preferredLanguages.firstObject ?: @"en").UTF8String);   /* e.g. zh-Hans-CN, fr-CA */

    self.tabs = fable_tabs_new();
    self.open = [NSMutableArray array];
    self.downloads = [NSMutableSet set];
    self.content = [WKUserContentController new];
    [self.content addScriptMessageHandler:self name:@"fable"];
    NSWindow.allowsAutomaticWindowTabbing = YES;
    [self buildMenus];

    [self compileBlockList];

    /* Idle background tabs sleep after "sleep_minutes" (default 10) or FABLE_SLEEP_AFTER_SECONDS. */
    NSTimeInterval tick = 30;
    NSString *minutes = setting("sleep_minutes");
    if (minutes.length) fable_tabs_set_sleep_after_ms(self.tabs, (uint64_t)minutes.longLongValue * 60000);
    const char *seconds = getenv("FABLE_SLEEP_AFTER_SECONDS");
    if (seconds) {
        long long s = atoll(seconds);
        fable_tabs_set_sleep_after_ms(self.tabs, (uint64_t)s * 1000);
        if (s > 0 && s < tick) tick = (NSTimeInterval)s;
    }
    self.sleepTimer = [NSTimer scheduledTimerWithTimeInterval:tick target:self selector:@selector(sleepTick:) userInfo:nil repeats:YES];
}

- (void)applicationDidFinishLaunching:(NSNotification *)note {
    if (self.open.count == 0) {   /* not launched to open a link */
        NSArray<NSString *> *args = NSProcessInfo.processInfo.arguments;
        NSString *input = args.count > 1 && ![args[1] hasPrefix:@"-"] ? args[1] : nil;
        [self openTab:input private:NO nextTo:nil configuration:nil background:NO];
    }
    [NSApp activateIgnoringOtherApps:YES];
}

/* Links from other apps when Fable is the default browser. */
- (void)application:(NSApplication *)application openURLs:(NSArray<NSURL *> *)urls {
    Tab *front = [self frontTab];
    if (front.isPrivate) front = nil;   /* never into a private window */
    for (Tab *t in self.open) if (!front && !t.isPrivate) front = t;
    for (NSURL *url in urls) front = [self openTab:url.absoluteString private:NO nextTo:front configuration:nil background:NO];
}

- (BOOL)applicationShouldHandleReopen:(NSApplication *)sender hasVisibleWindows:(BOOL)visible {
    if (!visible) [self openTab:nil private:NO nextTo:nil configuration:nil background:NO];
    return YES;
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)sender { return NO; }
- (BOOL)applicationSupportsSecureRestorableState:(NSApplication *)sender { return YES; }

@end

/* ---- downloads (macOS 11.3+) ---- */

API_AVAILABLE(macos(11.3))
@implementation FableApp (Downloads)

- (void)download:(WKDownload *)download decideDestinationUsingResponse:(NSURLResponse *)response suggestedFilename:(NSString *)name
    completionHandler:(void (^)(NSURL *))done {
    NSFileManager *fm = NSFileManager.defaultManager;
    NSURL *dir = [fm URLsForDirectory:NSDownloadsDirectory inDomains:NSUserDomainMask].firstObject;
    NSString *file = name.lastPathComponent.length ? name.lastPathComponent : @"download";
    NSURL *target = [dir URLByAppendingPathComponent:file];
    for (int i = 2; [fm fileExistsAtPath:target.path] && i < 1000; i++) {   /* name (2).ext, name (3).ext … */
        NSString *ext = file.pathExtension;
        NSString *stem = [NSString stringWithFormat:@"%@ (%d)", file.stringByDeletingPathExtension, i];
        target = [dir URLByAppendingPathComponent:ext.length ? [stem stringByAppendingPathExtension:ext] : stem];
    }
    objc_setAssociatedObject(download, &DOWNLOAD_TARGET, target, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [[self frontTab] say:TRN("dl_start", target.lastPathComponent)];
    done(target);
}

- (void)downloadDidFinish:(WKDownload *)download {
    NSURL *target = objc_getAssociatedObject(download, &DOWNLOAD_TARGET);
    [self.downloads removeObject:download];
    [[self frontTab] say:TRN("mac_downloaded", target.lastPathComponent)];
    if (target.path)   /* the Downloads stack in the Dock bounces, as for Safari */
        [NSDistributedNotificationCenter.defaultCenter postNotificationName:@"com.apple.DownloadFileFinished" object:target.path];
}

- (void)download:(WKDownload *)download didFailWithError:(NSError *)error resumeData:(NSData *)resumeData {
    [self.downloads removeObject:download];
    [[self frontTab] say:TR("dl_fail")];
}

@end

/* ---- the panel (ui/panel.html in a popover) --------------------------------- */

@implementation FableApp (Panel)

- (void)compileBlockList {
    /* The trackers (on by default) and the ads (off by default) are two rule
     * lists: WebKit applies both to every tab. */
    BOOL trackers = ![setting("block_trackers") isEqualToString:@"0"];
    BOOL ads = [setting("block_ads") isEqualToString:@"1"];
    if (trackers) {
        if (self.blockList) {
            [self.content addContentRuleList:self.blockList];
        } else {
            NSString *rules = take(fable_content_rules());
            __weak FableApp *weak = self;
            [WKContentRuleListStore.defaultStore compileContentRuleListForIdentifier:@"fable-trackers" encodedContentRuleList:rules
                                                               completionHandler:^(WKContentRuleList *list, NSError *error) {
                FableApp *me = weak;
                if (!list) { NSLog(@"Fable: tracker rules did not compile: %@", error); return; }
                me.blockList = list;
                if (![setting("block_trackers") isEqualToString:@"0"]) [me.content addContentRuleList:list];   /* every tab, open or not */
            }];
        }
    }
    if (ads) {
        if (self.adBlockList) {
            [self.content addContentRuleList:self.adBlockList];
        } else {
            NSString *rules = take(fable_ads_content_rules());
            __weak FableApp *weak = self;
            [WKContentRuleListStore.defaultStore compileContentRuleListForIdentifier:@"fable-ads" encodedContentRuleList:rules
                                                               completionHandler:^(WKContentRuleList *list, NSError *error) {
                FableApp *me = weak;
                if (!list) { NSLog(@"Fable: ad rules did not compile: %@", error); return; }
                me.adBlockList = list;
                if ([setting("block_ads") isEqualToString:@"1"]) [me.content addContentRuleList:list];
            }];
        }
    }
}

- (void)panelCreate {
    WKWebViewConfiguration *config = [WKWebViewConfiguration new];
    WKUserContentController *ui = [WKUserContentController new];
    [ui addScriptMessageHandler:self name:@"fableui"];
    config.userContentController = ui;
    [config setURLSchemeHandler:self forURLScheme:@"fable"];
    config.websiteDataStore = [WKWebsiteDataStore nonPersistentDataStore];   /* the panel keeps nothing */
    self.panelWeb = [[WKWebView alloc] initWithFrame:NSMakeRect(0, 0, 400, 640) configuration:config];
    self.panelWeb.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    self.panelWeb.navigationDelegate = self;
    NSViewController *vc = [NSViewController new];
    NSView *box = [[NSView alloc] initWithFrame:NSMakeRect(0, 0, 400, 640)];
    [box addSubview:self.panelWeb];
    vc.view = box;
    self.popover = [NSPopover new];
    self.popover.behavior = NSPopoverBehaviorTransient;   /* a click elsewhere closes it */
    self.popover.contentViewController = vc;
    self.popover.contentSize = NSMakeSize(400, 640);
    self.popover.delegate = self;
    self.panelQueue = [NSMutableArray array];
    [self panelLoad];
}

- (void)panelLoad {
    self.panelLoaded = NO;
    [self.panelWeb loadHTMLString:take(fable_panel_page()) baseURL:[NSURL URLWithString:PANEL_BASE]];
}

/* The panel page itself: once in, run what waited. Nothing else may load there. */
- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation {
    if (webView != self.panelWeb) return;
    self.panelLoaded = YES;
    for (NSString *script in self.panelQueue) [self.panelWeb evaluateJavaScript:script completionHandler:nil];
    [self.panelQueue removeAllObjects];
}

- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)action decisionHandler:(void (^)(WKNavigationActionPolicy))decide {
    NSString *url = action.request.URL.absoluteString ?: @"";
    decide([url hasPrefix:PANEL_BASE] || [url hasPrefix:@"about:"] ? WKNavigationActionPolicyAllow : WKNavigationActionPolicyCancel);
}

- (void)panelRun:(NSString *)script {
    if (!self.panelWeb) return;
    if (!self.panelLoaded) { [self.panelQueue addObject:script]; return; }
    [self.panelWeb evaluateJavaScript:script completionHandler:nil];
}

- (void)popoverDidClose:(NSNotification *)note { self.panelView = nil; }

/* What the panel shows: every tab (for the private-tab count), the front tab,
 * the settings snapshot and what this shell can do. */
- (NSString *)panelState {
    Tab *front = [self frontTab];
    NSMutableString *s = [NSMutableString stringWithString:@"{\"tabs\":["];
    BOOL first = YES;
    for (Tab *t in self.open) {
        NSString *url = [t.url hasPrefix:HOME] ? @"" : (t.url ?: @"");
        NSString *title = t.web.title.length ? t.web.title : ([t atHome] ? @"" : t.window.title);
        [s appendFormat:@"%@{\"id\":%u,\"title\":%@,\"url\":%@,\"active\":%@,\"private\":%@,\"asleep\":%@}", first ? @"" : @",", t.tabId, J(title), J(url),
                        t == front ? @"true" : @"false", t.isPrivate ? @"true" : @"false", t.web ? @"false" : @"true"];
        first = NO;
    }
    NSString *url = front && ![front atHome] ? (front.url ?: @"") : @"";
    BOOL web = !front.isPrivate && ([url hasPrefix:@"http://"] || [url hasPrefix:@"https://"]);
    [s appendFormat:@"],\"active\":%u,\"url\":%@,\"title\":%@,\"web\":%@,\"incognito\":%@,\"desktop\":false,\"blocked\":0,\"sniffed\":%zu,\"version\":%@,"
                     "\"platform\":\"macos\",\"caps\":{\"thirdPartyCookies\":false,\"images\":false},\"settings\":%@}",
                    front.tabId, J(url), J(front.web.title ?: @""), web ? @"true" : @"false", front.isPrivate ? @"true" : @"false",
                    front ? fable_sniff_count(front.tabId) : (size_t)0, J([NSString stringWithUTF8String:fable_version()]), take(fable_settings_json())];
    return s;
}

- (void)showPanel:(NSString *)view from:(Tab *)tab {
    if (!tab) return;
    if (!self.panelWeb) [self panelCreate];
    self.lastTab = tab;
    self.panelView = view;
    [self panelRun:[NSString stringWithFormat:@"Fable.show('%@',%@)", view, [self panelState]]];
    self.popover.appearance = tab.window.appearance;   /* dark beside a private window */
    NSView *anchor = tab.menuButton.window == tab.window ? tab.menuButton : tab.window.contentView;
    NSRect rect = anchor == tab.menuButton ? anchor.bounds : NSMakeRect(NSWidth(anchor.bounds) - 40, NSHeight(anchor.bounds) - 2, 1, 1);
    [self.popover showRelativeToRect:rect ofView:anchor preferredEdge:NSRectEdgeMaxY];
}

- (void)panelUpdate {
    if (self.panelView) [self panelRun:[NSString stringWithFormat:@"Fable.update(%@)", [self panelState]]];
}

/* "q\tid\tname\targ" (a request) or "a\tname\targ" (an action). */
- (void)panelMessage:(NSString *)message {
    NSArray<NSString *> *f = [message componentsSeparatedByString:@"\t"];
    if (f.count >= 3 && [f[0] isEqualToString:@"q"]) {
        uint32_t ident = (uint32_t)f[1].longLongValue;
        NSString *name = f[2];
        NSString *arg = f.count > 3 ? [[f subarrayWithRange:NSMakeRange(3, f.count - 3)] componentsJoinedByString:@"\t"] : @"";
        Tab *front = [self frontTab];
        char *answer = fable_panel_query(name.UTF8String, arg.UTF8String, front ? front.tabId : 0);
        NSString *reply = answer ? take(answer) : [name isEqualToString:@"device"] ? take(fable_device_info([self deviceExtras].UTF8String)) : @"";   /* "icon": none kept */
        [self panelRun:take(fable_panel_reply(ident, reply.UTF8String))];
        if ([name isEqualToString:@"set"]) [self settingChanged:[arg componentsSeparatedByString:@"\n"].firstObject];
    } else if (f.count >= 2 && [f[0] isEqualToString:@"a"]) {
        NSString *arg = f.count > 2 ? [[f subarrayWithRange:NSMakeRange(2, f.count - 2)] componentsJoinedByString:@"\t"] : @"";
        [self panelAct:f[1] arg:arg];
    }
}

- (Tab *)frontOf:(BOOL)priv {   /* the tab of that kind most recently in front */
    Tab *front = [self frontTab];
    if (front && front.isPrivate == priv) return front;
    for (Tab *t in self.open.reverseObjectEnumerator) if (t.isPrivate == priv && t.window.isVisible) return t;
    for (Tab *t in self.open.reverseObjectEnumerator) if (t.isPrivate == priv) return t;
    return nil;
}

- (void)panelAct:(NSString *)name arg:(NSString *)arg {
    Tab *front = [self frontTab];
    if ([name isEqualToString:@"hidden"]) {
        [self.popover close];
    } else if ([name isEqualToString:@"size"]) {   /* the panel's content height */
        CGFloat h = arg.doubleValue;
        if (h >= 200 && h <= 800) self.popover.contentSize = NSMakeSize(400, h);
    } else if ([name isEqualToString:@"switchTab"] || [name isEqualToString:@"closeTab"]) {
        for (Tab *t in [self.open copy]) {
            if (t.tabId != (uint32_t)arg.longLongValue) continue;
            if ([name isEqualToString:@"closeTab"]) { [t.window performClose:nil]; [self panelUpdate]; }
            else [t.window makeKeyAndOrderFront:nil];
        }
    } else if ([name isEqualToString:@"newTab"]) {
        [self openTab:nil private:NO nextTo:[self frontOf:NO] configuration:nil background:NO];
    } else if ([name isEqualToString:@"newPrivate"]) {
        [self openTab:nil private:YES nextTo:front.isPrivate ? front : nil configuration:nil background:NO];
    } else if ([name isEqualToString:@"enterPrivate"]) {   /* back to a private window, or a new one */
        Tab *p = [self frontOf:YES];
        if (p) [p.window makeKeyAndOrderFront:nil];
        else [self openTab:nil private:YES nextTo:nil configuration:nil background:NO];
    } else if ([name isEqualToString:@"exitPrivate"]) {    /* every private window closes */
        NSArray *privates = [self.open filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"isPrivate == YES"]];
        if (!privates.count) return;
        for (Tab *t in privates) [t.window close];
        Tab *stay = [self frontOf:NO] ?: [self openTab:nil private:NO nextTo:nil configuration:nil background:NO];
        [stay.window makeKeyAndOrderFront:nil];
        [stay say:TR("private_closed")];
    } else if ([name isEqualToString:@"open"]) {
        [front navigate:arg];
    } else if ([name isEqualToString:@"openNew"]) {
        [self openTab:arg private:front.isPrivate nextTo:front configuration:nil background:NO];
    } else if ([name isEqualToString:@"reader"]) {
        [front toggleReader:nil];
    } else if ([name isEqualToString:@"clear"]) {
        [self clearData:arg];
    } else if ([name isEqualToString:@"sniffScan"]) {
        if (!front.web) return;
        uint32_t ident = front.tabId;
        __weak FableApp *weak = self;
        [front.web evaluateJavaScript:[NSString stringWithUTF8String:fable_sniff_js()] completionHandler:^(id result, NSError *error) {
            if (![result isKindOfClass:NSArray.class]) return;   /* the page blocked the script */
            if (fable_sniff_note_scan(ident, jsonText(result).UTF8String) > 0) [weak panelRun:@"Fable.refresh('sniff')"];
        }];
    } else if ([name isEqualToString:@"download"]) {
        NSURL *url = [NSURL URLWithString:arg];
        if (!url || !front.web) return;
        if (@available(macOS 11.3, *)) {
            __weak FableApp *weak = self;
            [front.web startDownloadUsingRequest:[NSURLRequest requestWithURL:url] completionHandler:^(WKDownload *download) {
                [weak.downloads addObject:download];
                download.delegate = weak;
            }];
        } else {
            [NSWorkspace.sharedWorkspace openURL:url];
        }
    } else if ([name isEqualToString:@"copy"] || [name isEqualToString:@"copyText"]) {
        [NSPasteboard.generalPasteboard clearContents];
        [NSPasteboard.generalPasteboard setString:arg forType:NSPasteboardTypeString];
        [front say:TR([name isEqualToString:@"copy"] ? "link_copied" : "m_copied")];
    } else if ([name isEqualToString:@"toast"]) {
        [front say:arg];
    } else if ([name isEqualToString:@"ip"]) {
        [self lookupIP:0];
    } else if ([name isEqualToString:@"system"]) {
        NSString *info = take(fable_system_info([self systemExtras].UTF8String));
        [self panelRun:[NSString stringWithFormat:@"Fable.system(%@)", info]];
    }
}

/* A setting the panel just changed: make it so here. */
- (void)settingChanged:(NSString *)key {
    if ([key isEqualToString:@"language"]) {
        [self buildMenus];
        for (Tab *t in self.open) [t relabel];
        NSString *view = self.panelView;
        [self panelLoad];   /* the panel page carries its strings */
        if (view) [self panelRun:[NSString stringWithFormat:@"Fable.show('%@',%@)", view, [self panelState]]];
    } else if ([key isEqualToString:@"block_trackers"] || [key isEqualToString:@"block_ads"]) {
        [self.content removeAllContentRuleLists];   /* start from nothing ... */
        [self compileBlockList];                     /* ... and put back what is on */
    } else if ([key isEqualToString:@"ua_mode"] || [key isEqualToString:@"ua_custom"]) {
        for (Tab *t in self.open) t.web.customUserAgent = [self userAgent];
    } else if ([key isEqualToString:@"private_screenshots"]) {
        BOOL allow = [setting("private_screenshots") isEqualToString:@"1"];
        for (Tab *t in self.open) if (t.isPrivate) t.window.sharingType = allow ? NSWindowSharingReadOnly : NSWindowSharingNone;
    } else if ([key isEqualToString:@"text_size"]) {
        for (Tab *t in self.open) t.web.pageZoom = defaultZoom();
    } else if ([key isEqualToString:@"home_button"]) {
        for (Tab *t in self.open) [t applyHomeButton];
    } else if ([key isEqualToString:@"sleep_minutes"]) {
        NSString *minutes = setting("sleep_minutes");
        fable_tabs_set_sleep_after_ms(self.tabs, minutes.length ? (uint64_t)minutes.longLongValue * 60000 : 600000);
    }
}

- (void)clearData:(NSString *)what {
    if ([what containsString:@"history"]) fable_history_clear();
    NSMutableSet *types = [NSMutableSet set];
    if ([what containsString:@"cookies"])
        [types addObjectsFromArray:@[WKWebsiteDataTypeCookies, WKWebsiteDataTypeLocalStorage, WKWebsiteDataTypeSessionStorage,
                                     WKWebsiteDataTypeIndexedDBDatabases, WKWebsiteDataTypeWebSQLDatabases, WKWebsiteDataTypeServiceWorkerRegistrations]];
    if ([what containsString:@"cache"])
        [types addObjectsFromArray:@[WKWebsiteDataTypeDiskCache, WKWebsiteDataTypeMemoryCache, WKWebsiteDataTypeOfflineWebApplicationCache]];
    if (types.count)
        [WKWebsiteDataStore.defaultDataStore removeDataOfTypes:types modifiedSince:[NSDate dateWithTimeIntervalSince1970:0] completionHandler:^{}];
    [[self frontTab] say:TR("data_cleared")];
}

/* ---- metadata: what only the shell can see ---- */

static NSString *webkitVersion(void) {
    NSString *v = [[NSBundle bundleForClass:WKWebView.class] objectForInfoDictionaryKey:@"CFBundleShortVersionString"] ?: @"";
    NSRange dot = [v rangeOfString:@"."];
    if (dot.location != NSNotFound && dot.location >= 5) v = [v substringFromIndex:2];   /* 20620.1.16 → 620.1.16 (the leading digits name the macOS release) */
    return v;
}

static NSDictionary *batteryFacts(void) {
    NSMutableDictionary *b = [NSMutableDictionary dictionary];
    CFTypeRef info = IOPSCopyPowerSourcesInfo();
    CFArrayRef list = info ? IOPSCopyPowerSourcesList(info) : NULL;
    for (CFIndex i = 0; list && i < CFArrayGetCount(list); i++) {
        NSDictionary *d = (__bridge NSDictionary *)IOPSGetPowerSourceDescription(info, CFArrayGetValueAtIndex(list, i));
        if (![d[@kIOPSTypeKey] isEqual:@kIOPSInternalBatteryType]) continue;
        NSInteger cur = [d[@kIOPSCurrentCapacityKey] integerValue], max = [d[@kIOPSMaxCapacityKey] integerValue];
        if (max > 0) b[@"level"] = @(cur * 100 / max);
        BOOL ac = [d[@kIOPSPowerSourceStateKey] isEqual:@kIOPSACPowerValue];
        b[@"status"] = [d[@kIOPSIsChargingKey] boolValue] ? @"charging" : [d[@kIOPSIsChargedKey] boolValue] ? @"full" : ac ? @"not_charging" : @"discharging";
        b[@"plugged"] = ac ? @"ac" : @"none";
        b[@"tech"] = @"Li-ion";
    }
    if (list) CFRelease(list);
    if (info) CFRelease(info);
    if (!b.count) return nil;
    io_service_t service = IOServiceGetMatchingService(0, IOServiceMatching("AppleSmartBattery"));   /* 0: the default main port */
    if (service) {
        NSNumber *(^prop)(NSString *) = ^NSNumber *(NSString *key) {
            CFTypeRef v = IORegistryEntryCreateCFProperty(service, (__bridge CFStringRef)key, kCFAllocatorDefault, 0);
            return v ? (NSNumber *)CFBridgingRelease(v) : nil;
        };
        NSNumber *cycles = prop(@"CycleCount"), *temp = prop(@"Temperature"), *volts = prop(@"Voltage");
        if ([cycles isKindOfClass:NSNumber.class]) b[@"cycles"] = cycles;
        if ([temp isKindOfClass:NSNumber.class] && temp.integerValue > 0) b[@"temp"] = @(round(temp.doubleValue / 10.0) / 10.0);   /* hundredths of °C */
        if ([volts isKindOfClass:NSNumber.class]) b[@"voltage"] = volts;
        IOObjectRelease(service);
    }
    return b;
}

static NSDictionary *storageFacts(void) {
    NSMutableDictionary *s = [NSMutableDictionary dictionary];
    NSDictionary *root = [[NSURL fileURLWithPath:@"/"] resourceValuesForKeys:@[NSURLVolumeTotalCapacityKey, NSURLVolumeAvailableCapacityForImportantUsageKey] error:nil];
    if (root[NSURLVolumeTotalCapacityKey]) s[@"total"] = root[NSURLVolumeTotalCapacityKey];
    if (root[NSURLVolumeAvailableCapacityForImportantUsageKey]) s[@"free"] = root[NSURLVolumeAvailableCapacityForImportantUsageKey];
    NSArray *keys = @[NSURLVolumeLocalizedNameKey, NSURLVolumeIsRemovableKey, NSURLVolumeLocalizedFormatDescriptionKey, NSURLVolumeIsRootFileSystemKey];
    NSMutableArray *volumes = [NSMutableArray array];
    for (NSURL *url in [NSFileManager.defaultManager mountedVolumeURLsIncludingResourceValuesForKeys:keys options:NSVolumeEnumerationSkipHiddenVolumes] ?: @[]) {
        NSDictionary *v = [url resourceValuesForKeys:keys error:nil];
        [volumes addObject:@{@"name": v[NSURLVolumeLocalizedNameKey] ?: url.lastPathComponent ?: @"", @"state": v[NSURLVolumeLocalizedFormatDescriptionKey] ?: @"",
                             @"primary": v[NSURLVolumeIsRootFileSystemKey] ?: @NO, @"removable": v[NSURLVolumeIsRemovableKey] ?: @NO}];
    }
    if (volumes.count) s[@"volumes"] = volumes;
    return s;
}

/* The screen the front window is on. */
static NSDictionary *screenFacts(NSWindow *window) {
    NSScreen *screen = window.screen ?: NSScreen.mainScreen;
    if (!screen) return @{};
    CGFloat scale = screen.backingScaleFactor;
    NSMutableDictionary *d = [NSMutableDictionary dictionary];
    d[@"w"] = @((NSInteger)round(screen.frame.size.width * scale));
    d[@"h"] = @((NSInteger)round(screen.frame.size.height * scale));
    if (@available(macOS 12.0, *)) d[@"refresh"] = @(screen.maximumFramesPerSecond);
    d[@"name"] = screen.localizedName ?: @"";
    CGDirectDisplayID display = [screen.deviceDescription[@"NSScreenNumber"] unsignedIntValue];
    CGSize mm = CGDisplayScreenSize(display);
    if (mm.width > 0 && mm.height > 0) {
        d[@"inches"] = @(round(sqrt(mm.width * mm.width + mm.height * mm.height) / 25.4 * 10) / 10);
        d[@"dpi"] = @((NSInteger)round([d[@"w"] doubleValue] / (mm.width / 25.4)));
    }
    d[@"wideGamut"] = @([screen canRepresentDisplayGamut:NSDisplayGamutP3]);
    if (screen.maximumPotentialExtendedDynamicRangeColorComponentValue > 1.0) d[@"hdr"] = @[@"EDR"];
    return d;
}

- (NSString *)deviceExtras {
    NSMutableDictionary *d = [NSMutableDictionary dictionary];
    d[@"engine"] = [@"WebKit " stringByAppendingString:webkitVersion()];
    d[@"cookies"] = @YES;
    NSString *gpu = MTLCreateSystemDefaultDevice().name;
    if (gpu.length) { d[@"gpu"] = gpu; d[@"gpuVendor"] = @"Apple"; }
    NSDictionary *screen = screenFacts([self frontTab].window);
    if (screen[@"w"]) { d[@"screenW"] = screen[@"w"]; d[@"screenH"] = screen[@"h"]; }
    if (screen[@"refresh"]) d[@"refresh"] = screen[@"refresh"];
    if (screen[@"dpi"]) d[@"dpi"] = screen[@"dpi"];
    NSDictionary *battery = batteryFacts();
    if (battery[@"level"]) { d[@"battery"] = battery[@"level"]; d[@"charging"] = @([battery[@"status"] isEqual:@"charging"]); }
    NSDictionary *storage = storageFacts();
    if (storage[@"total"]) { d[@"storageTotal"] = storage[@"total"]; d[@"storageFree"] = storage[@"free"] ?: @0; }
    return jsonText(d);
}

/* Appended after the core's facts; for the same key the last one counts. */
- (NSString *)systemExtras {
    NSMutableDictionary *d = [NSMutableDictionary dictionary];
    d[@"display"] = screenFacts([self frontTab].window);
    d[@"storage"] = storageFacts();
    NSDictionary *battery = batteryFacts();
    if (battery) d[@"battery"] = battery;
    return jsonText(d);
}

/* Public IP for the metadata sheet: Cloudflare's trace, then ipify. No cookies, no cache. */
- (void)lookupIP:(int)attempt {
    NSURLSessionConfiguration *config = NSURLSessionConfiguration.ephemeralSessionConfiguration;
    config.timeoutIntervalForRequest = 10;
    NSURLSession *session = [NSURLSession sessionWithConfiguration:config];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:attempt == 0 ? @"https://www.cloudflare.com/cdn-cgi/trace" : @"https://api.ipify.org?format=json"]];
    NSString *ua = [self userAgent];
    if (ua) [request setValue:ua forHTTPHeaderField:@"User-Agent"];
    __weak FableApp *weak = self;
    [[session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSString *body = data ? [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] : @"";
        NSString *info = take(fable_parse_ip_reply((body ?: @"").UTF8String, attempt == 0 ? "cloudflare.com" : "ipify.org"));
        dispatch_async(dispatch_get_main_queue(), ^{
            if (!info.length && attempt == 0) { [weak lookupIP:1]; return; }
            [weak panelRun:[NSString stringWithFormat:@"Fable.ip(%@)", info.length ? info : @"{}"]];
        });
    }] resume];
    [session finishTasksAndInvalidate];
}

@end

int main(int argc, const char *argv[]) {
    @autoreleasepool {
        NSApplication *application = NSApplication.sharedApplication;
        application.activationPolicy = NSApplicationActivationPolicyRegular;
        app = [FableApp new];
        application.delegate = app;
        [application run];
    }
    return 0;
}
