# Fable Browser for Sailfish OS - qmake project file.
# Target and package name follow the Harbour rule: "harbour-" prefix, lowercase.

TARGET = harbour-fable

CONFIG += sailfishapp
CONFIG += c++11
CONFIG += link_pkgconfig

# Qt modules used by the shell. Sailfish.WebView, .WebEngine and .Pickers are QML
# imports only (their C++ APIs are not used), so nothing more is linked;
# QtMultimedia is linked for the camera QR scanner (QCamera, QVideoProbe).
QT += qml quick multimedia

SOURCES += \
    src/main.cpp \
    src/fablecore.cpp \
    src/panelbridge.cpp \
    src/qrscanner.cpp

HEADERS += \
    src/fablecore.h \
    src/panelbridge.h \
    src/qrscanner.h

# The Rust core C ABI and its static library, built for the target by
# scripts/build-sailfish-core.sh and placed in 3rdparty/<target>/; the Rust
# standard library inside it needs pthread, dl and libm.
INCLUDEPATH += 3rdparty/include
LIBS += -L$$PWD/3rdparty/$$FABLE_CORE_TARGET -lfable_core -lpthread -ldl -lm

DISTFILES += \
    qml/harbour-fable.qml \
    qml/pages/BrowserPage.qml \
    qml/pages/PanelView.qml \
    qml/pages/QrScannerPage.qml \
    qml/cover/CoverPage.qml \
    harbour-fable.desktop \
    harbour-fable.png \
    harbour-fable-108x108.png \
    harbour-fable-128x128.png \
    harbour-fable-172x172.png \
    rpm/harbour-fable.spec \
    rpm/harbour-fable.changes.in

# Sailfish SDK deploys <TARGET>.png (86x86) and <TARGET>-<size>.png for the
# remaining sizes into hicolor when SAILFISHAPP_ICONS lists them.
SAILFISHAPP_ICONS = 86x86 108x108 128x128 172x172

# No Qt translations: every string comes from the core (ui/strings.tsv, ten languages).
