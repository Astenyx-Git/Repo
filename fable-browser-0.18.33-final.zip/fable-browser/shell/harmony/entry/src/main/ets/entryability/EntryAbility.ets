// Fable for HarmonyOS: the ability. Opens the core's store, tells it the
// system language, and hands links from other apps to the browser.
import fable from 'libfable.so';
import { AbilityConstant, ConfigurationConstant, UIAbility, Want } from '@kit.AbilityKit';
import { window } from '@kit.ArkUI';
import { BusinessError } from '@kit.BasicServicesKit';
import { FableApp, FableColors } from '../common/Model';
import { FableBrowser } from '../common/Browser';

export default class EntryAbility extends UIAbility {
  onCreate(want: Want, launchParam: AbilityConstant.LaunchParam): void {
    try {   // private mode has its own dark look; the rest follows Fable's colours, not the system theme
      this.context.getApplicationContext().setColorMode(ConfigurationConstant.ColorMode.COLOR_MODE_LIGHT);
    } catch (e) {
      // the system theme then
    }
    FableApp.context = this.context;
    let adDomains = new Uint8Array(0);
    try {
      adDomains = this.context.resourceManager.getRawFileContentSync('ads.txt');
    } catch (e) {
      console.warn('Fable could not read the bundled ad domains');
    }
    fable.storeOpen(this.context.filesDir + '/fable', adDomains);
    fable.setSystemLocale(this.context.config.language ?? '');   // pages follow the system language unless the "language" setting says otherwise
    FableApp.launchUrl = FableApp.linkOf(want);
  }

  onNewWant(want: Want, launchParam: AbilityConstant.LaunchParam): void {
    const url: string = FableApp.linkOf(want);
    if (url.length > 0) {
      FableApp.onLink(url);
    }
  }

  onWindowStageCreate(windowStage: window.WindowStage): void {
    windowStage.getMainWindow().then((win: window.Window): void => {
      FableApp.mainWindow = win;
      const bars: window.SystemBarProperties = {   // the cream of the page and the bar; private mode turns them dark
        statusBarColor: FableColors.GROUND,
        navigationBarColor: FableColors.BAR,
        statusBarContentColor: '#000000',
        navigationBarContentColor: '#000000'
      };
      win.setWindowSystemBarProperties(bars).catch((e: BusinessError): void => {});
      FableBrowser.applyWindowSettings(win);
    }).catch((e: BusinessError): void => {});
    windowStage.loadContent('pages/Index', (err: BusinessError): void => {});
  }
}
