#!/usr/bin/env python3
"""Every skin's logo stands on the page as the default Claude logo does: no box.

theme://name puts on an artwork and a palette. The new-tab page is painted in
the palette's ground and shows the skin's logo; the launcher shows the app
icon on its ground. The default logo is only the planet, see-through all
round, so the page shows exactly its own colour wherever the planet is not;
every skin's logo must do the same. This checks, for every skin, the default
included:

* statically: the palette's ground (from the core, build/skin_pages) is the
  ground scripts/gen_themes.py measures from the artwork (the median of its
  edge), the Android adaptive icons' background (theme_icons.xml), and the
  edge of the iOS alternate icon;
* the logo itself (tests/skin_ground_test.js): see-through all round its
  edge and over at least half of it, and nothing visible but the drawing;
  and a skin's logo, laid over the page's ground, is its artwork again (bar
  the ground's grain), so no part of the drawing is lost or ground kept;
* rendered, in headless Chrome (tests/chrome_harness.py, phone size, 2x): the
  new-tab page exactly as the core serves it in that skin, with the logo shown
  and hidden, on the page's ground and over a wallpaper (launcher mode):
  wherever the logo is see-through, and round it, the two screenshots are the
  same to the last unit; with it hidden, its place is the page's ground.

Without Chrome the rendered part is skipped (exit 0) unless FABLE_REQUIRE_UI=1.
usage: python3 tests/skin_ground_test.py [build/skin_pages]"""
import base64, json, os, re, shutil, struct, subprocess, sys, tempfile, zlib

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
LABELS = {"chatgpt": "ChatGPT", "deepseek": "DeepSeek", "gemini": "Gemini", "grok": "Grok", "kimi": "Kimi"}
failures = []


def check(name, ok, detail=""):
    print(("ok   " if ok else "FAIL ") + name + ("" if ok or not detail else ": " + detail), flush=True)
    if not ok: failures.append(name)


def png_pixels(data):
    """(width, height, rows of (r, g, b)) of an 8-bit, non-interlaced RGB(A) or palette PNG."""
    assert data[:8] == b"\x89PNG\r\n\x1a\n", "not a PNG"
    pos, idat, palette = 8, b"", None
    while pos < len(data):
        n, kind = struct.unpack(">I4s", data[pos:pos + 8]); body = data[pos + 8:pos + 8 + n]; pos += 12 + n
        if kind == b"IHDR": w, h, depth, ctype, _, _, interlace = struct.unpack(">IIBBBBB", body)
        elif kind == b"PLTE": palette = [tuple(body[i:i + 3]) for i in range(0, len(body), 3)]
        elif kind == b"IDAT": idat += body
    assert depth == 8 and interlace == 0 and ctype in (2, 3, 6), "PNG kind %d/%d" % (depth, ctype)
    bpp = {2: 3, 3: 1, 6: 4}[ctype]
    raw, stride, prev, rows, at = zlib.decompress(idat), w * bpp, bytearray(w * bpp), [], 0
    for _ in range(h):
        f, line = raw[at], bytearray(raw[at + 1:at + 1 + stride]); at += 1 + stride
        for i in range(stride):
            a = line[i - bpp] if i >= bpp else 0; b = prev[i]; c = prev[i - bpp] if i >= bpp else 0
            if f == 1: line[i] = (line[i] + a) & 255
            elif f == 2: line[i] = (line[i] + b) & 255
            elif f == 3: line[i] = (line[i] + (a + b) // 2) & 255
            elif f == 4:
                p = a + b - c; pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
                line[i] = (line[i] + (a if pa <= pb and pa <= pc else b if pb <= pc else c)) & 255
        prev = line
        rows.append([palette[v] for v in line] if ctype == 3 else [tuple(line[i:i + 3]) for i in range(0, stride, bpp)])
    return w, h, rows


def hexof(c): return "#%02X%02X%02X" % tuple(c[:3])


def artwork_ground(path):
    """The median of an 8 px ring round the artwork's edge, as gen_themes.py measures it."""
    w, h, rows = png_pixels(open(path, "rb").read())
    px = [rows[y][x] for y in range(h) for x in range(w) if x < 8 or y < 8 or x >= w - 8 or y >= h - 8]
    return hexof([sorted(p[i] for p in px)[len(px) // 2] for i in range(3)])


def main():
    tool = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, "build", "skin_pages")
    work = tempfile.mkdtemp(prefix="fable-skins-")
    try:
        out = subprocess.run([tool, work], capture_output=True, text=True, check=True).stdout
    except (OSError, subprocess.CalledProcessError) as e:
        print("FAIL skin_ground_test: %s does not run (make test builds it): %s" % (tool, e)); return 1
    grounds = dict(line.split() for line in out.splitlines())
    check("every skin has a page", sorted(grounds) == sorted(["claude"] + list(LABELS)), " ".join(grounds))

    # Statically: the app icons' grounds are the page's.
    res = os.path.join(ROOT, "shell/android/app/src/main/res")
    xml = open(os.path.join(res, "values/theme_icons.xml"), encoding="utf-8").read()
    colors = open(os.path.join(res, "values/colors.xml"), encoding="utf-8").read()
    cream = re.search(r'<color name="ground">(#[0-9A-Fa-f]{6})</color>', colors).group(1).upper()
    check("claude: the default icon's ground (colors.xml) is the page's", cream == grounds["claude"], cream + " vs " + grounds["claude"])
    for name, label in LABELS.items():
        m = re.search(r'<color name="ground_%s">(#[0-9A-Fa-f]{6})</color>' % name, xml)
        android = m.group(1).upper() if m else "none"
        check("%s: Android icon ground %s is the page's %s" % (name, android, grounds[name]), android == grounds[name])
        measured = artwork_ground(os.path.join(ROOT, "assets/icon-variants/fable-%s.png" % name))
        if measured: check("%s: the page's ground is the artwork's own %s" % (name, measured), measured == grounds[name], grounds[name])
        fg = open(os.path.join(res, "mipmap-anydpi-v26/ic_launcher_%s.xml" % name), encoding="utf-8").read()
        check("%s: the adaptive icon stands on it" % name, '<background android:drawable="@color/ground_%s" />' % name in fg)
        w, h, rows = png_pixels(open(os.path.join(ROOT, "shell/ios/Fable/Assets.xcassets/AppIcon-%s.appiconset/AppIcon.png" % label), "rb").read())
        edge = {hexof(rows[y][x]) for y in range(h) for x in range(w) if min(x, y, w - 1 - x, h - 1 - y) < 24 and (x + y) % 7 == 0}
        check("%s: the iOS icon's edge is the page's ground" % name, edge == {grounds[name]}, " ".join(sorted(edge)[:6]))

    # Rendered.
    have_chrome = bool(os.environ.get("CHROME") or shutil.which("google-chrome") or shutil.which("chromium") or shutil.which("chromium-browser"))
    if not have_chrome:
        shutil.rmtree(work, ignore_errors=True)
        if os.environ.get("FABLE_REQUIRE_UI") == "1":
            print("FAIL skin_ground_test: no Chrome and FABLE_REQUIRE_UI=1"); return 1
        print("skin_ground_test: no Chrome, the rendered pages are not checked")
        return 1 if failures else 0
    main_js = open(os.path.join(HERE, "skin_ground_test.js"), encoding="utf-8").read()
    # A skin's artwork goes into its page, hidden, for the script to lay its logo against (a data: URI
    # keeps the canvas readable; a file:// image would taint it).
    for name in LABELS:
        page = os.path.join(work, name + ".html")
        with open(os.path.join(ROOT, "assets/icon-variants/fable-%s.png" % name), "rb") as f:
            uri = "data:image/png;base64," + base64.b64encode(f.read()).decode()
        html = open(page, encoding="utf-8").read()
        assert html.count("</body>") == 1, name
        open(page, "w", encoding="utf-8").write(html.replace("</body>", '<img id="skin-art" hidden alt="" src="%s"></body>' % uri))

    def render(name, mode, hide):
        js = os.path.join(work, "%s-%s-%d.js" % (name, mode, hide))
        with open(js, "w", encoding="utf-8") as f:
            f.write("window.SKIN_MODE = %s; window.SKIN_HIDE = %s;\n" % (json.dumps(mode), "true" if hide else "false") + main_js)
        shot = os.path.join(work, "%s-%s-%d.png" % (name, mode, hide))
        r = subprocess.run([sys.executable, os.path.join(HERE, "chrome_harness.py"), os.path.join(work, name + ".html"), shot,
                            "--js", js, "--wait", "0.3"], capture_output=True, text=True, timeout=180)
        lines = r.stdout.replace("js result: ", "").splitlines()
        pixels = png_pixels(open(shot, "rb").read()) if os.path.exists(shot) else None
        return lines, pixels, r

    for name in grounds:
        lines, shown, r = render(name, "page", False)
        oks = [l for l in lines if l.startswith("ok ")]
        for l in lines:
            if l.startswith(("ok ", "FAIL")): check(name + ": " + l[5:].split(": ")[0], l.startswith("ok"), l[5:].partition(": ")[2])
        rect = next((json.loads(l[5:]) for l in lines if l.startswith("rect ")), None)
        mask = next((base64.b64decode(l[5:]) for l in lines if l.startswith("mask ")), None)
        if not rect or not mask or not shown or not any("the logo has loaded" in l for l in oks):
            check(name + ": the page ran", False, (r.stdout + r.stderr)[-400:]); continue
        check(name + ": the page is painted in the palette's ground", rect["ground"] == grounds[name], rect["ground"] + " vs " + grounds[name])
        s_ = rect["dpr"]; nw, nh = rect["nw"], rect["nh"]
        x0, y0 = round(rect["x"] * s_), round(rect["y"] * s_)
        bw, bh = round(rect["w"] * s_), round(rect["h"] * s_)
        ground = tuple(int(grounds[name][i:i + 2], 16) for i in (1, 3, 5))
        for mode in ("page", "wall"):
            a = shown if mode == "page" else render(name, mode, False)[1]
            b = render(name, mode, True)[1]
            if not a or not b:
                check("%s: %s: the screenshots were taken" % (name, mode), False); continue
            rows_a, rows_b = a[2], b[2]
            same = differ = 0; worst = ""
            for Y in range(y0 - 12, y0 + bh + 12):
                for X in range(x0 - 12, x0 + bw + 12):
                    inside = x0 <= X < x0 + bw and y0 <= Y < y0 + bh
                    if inside:
                        ix, iy = (X - x0) * nw // bw, (Y - y0) * nh // bh
                        bit = iy * nw + ix
                        if not mask[bit >> 3] >> (bit & 7) & 1: continue
                    if rows_a[Y][X] == rows_b[Y][X]: same += 1
                    else:
                        differ += 1
                        if not worst: worst = "%d,%d %s with the logo, %s without" % (X, Y, hexof(rows_a[Y][X]), hexof(rows_b[Y][X]))
            check("%s: %s: where the logo is see-through and round it, nothing of it shows (%d px)" % (name, "on the page" if mode == "page" else "over a wallpaper", same),
                  differ == 0 and same > 0, "%d px differ, first %s" % (differ, worst))
            if mode == "page":
                off = [(X, Y) for Y in range(y0, y0 + bh) for X in range(x0, x0 + bw) if rows_b[Y][X] != ground]
                check("%s: without the logo its place is the page's ground %s" % (name, grounds[name]), not off,
                      "%d px are not, first %s %s" % (len(off), off[0] if off else "", hexof(rows_b[off[0][1]][off[0][0]]) if off else ""))
    shutil.rmtree(work, ignore_errors=True)
    if failures:
        print("skin_ground_test: %d check(s) failed" % len(failures)); return 1
    print("skin_ground_test: every skin's page ground is its artwork's and its icons' ground, and its logo shows nothing but the planet, as the default's")
    return 0


if __name__ == "__main__":
    sys.exit(main())
