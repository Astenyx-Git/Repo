import QtQuick 2.0
import Fake 1.0
// Sailfish.WebView's WebView as far as Fable uses it. A load "finishes" at once.
Item {
    id: view
    property url url: ""
    property string title: ""
    property bool loading: false
    property bool loaded: false
    property int loadProgress: 0
    property bool canGoBack: false
    property bool canGoForward: false
    property string httpUserAgent: ""
    property bool privateMode: false
    property bool active: true
    property string html: ""
    property var calls: []
    property var scripts: []
    function finish(u, t) { loading = true; url = u; title = t || ""; loading = false; loaded = true; }
    function load(u) { calls.push("load " + u); finish(u, ""); }
    function loadHtml(h, base) { html = h; calls.push("loadHtml " + base); finish(base, ""); }
    function reload() { calls.push("reload"); loading = true; loading = false; }
    function goBack() { calls.push("goBack"); }
    function goForward() { calls.push("goForward"); }
    function runJavaScript(script, callback) {
        scripts.push(script);
        var result = FakeWeb.answer ? FakeWeb.answer(view, script) : undefined;
        if (callback) Qt.callLater(function () { callback(result); });
    }
    Component.onCompleted: FakeWeb.made(view)
}
