#!/bin/sh
# "Restore tabs on start" in the Linux shell, end to end with the real
# build/fable (make linux) and a local server that logs every page asked for:
#
# 1. Open a.html (from the command line) and b.html (Ctrl+T, typed), then end
#    the app the hard way (SIGTERM, as a crash would): the snapshot taken as
#    pages finished loading has both.
# 2. Start again with no address: both pages are asked for again.
# 3. Start with a link (c.html): the two come back and the link opens as well.
#
# Needs xvfb-run, xdotool and python3; skips (exit 0) without them or without
# build/fable, unless FABLE_REQUIRE_UI=1.
set -u
cd "$(dirname "$0")/.."
skip() { echo "linux_restore_test: $1, skipped"; [ "${FABLE_REQUIRE_UI:-0}" = 1 ] && exit 1; exit 0; }
[ -x build/fable ] || skip "no build/fable (make linux)"
for tool in xvfb-run xdotool python3; do command -v $tool >/dev/null 2>&1 || skip "no $tool"; done

WORK=$(mktemp -d)
PORT=$(python3 -c 'import socket; s = socket.socket(); s.bind(("127.0.0.1", 0)); print(s.getsockname()[1])')
for page in a b c; do echo "<!doctype html><title>Page $page</title><p>$page" > "$WORK/$page.html"; done
# Pages are never cached, so each load reaches the log; the log is appended to,
# so the phase markers below stay in place.
cat > "$WORK/server.py" <<'PY'
import http.server, sys
class Handler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()
    def log_message(self, format, *args):
        with open("server.log", "a") as log:
            log.write(format % args + "\n")
http.server.ThreadingHTTPServer(("127.0.0.1", int(sys.argv[1])), Handler).serve_forever()
PY
cat > "$WORK/run.sh" <<SCRIPT
#!/bin/sh
cd "$WORK"
python3 -I server.py $PORT 2> server.err &
SERVER=\$!
export HOME="$WORK/home"; mkdir -p "\$HOME"
"$PWD/build/fable" http://127.0.0.1:$PORT/a.html > fable1.log 2>&1 &
APP=\$!
sleep 6; xdotool key ctrl+t; sleep 1
xdotool type --delay 20 "http://127.0.0.1:$PORT/b.html"; xdotool key Return
sleep 4; kill \$APP; wait \$APP 2>/dev/null
echo "--- second start" >> server.log
"$PWD/build/fable" > fable2.log 2>&1 &
APP=\$!
sleep 7; kill \$APP; wait \$APP 2>/dev/null
echo "--- third start" >> server.log
"$PWD/build/fable" http://127.0.0.1:$PORT/c.html > fable3.log 2>&1 &
APP=\$!
sleep 7; kill \$APP \$SERVER; wait \$APP 2>/dev/null
SCRIPT
timeout 120 xvfb-run -a -s "-screen 0 1280x900x24" sh "$WORK/run.sh"
log="$WORK/server.log"
second=$(sed -n '/--- second start/,/--- third start/p' "$log")
third=$(sed -n '/--- third start/,$p' "$log")
fail=0
grep -q "GET /b.html" "$log" || { echo "FAIL linux_restore_test: the second tab never loaded, so nothing was tested"; fail=1; }
for page in a b; do
    echo "$second" | grep -q "GET /$page.html" || { echo "FAIL linux_restore_test: $page.html did not come back on the next start"; fail=1; }
    echo "$third" | grep -q "GET /$page.html" || { echo "FAIL linux_restore_test: started with a link, $page.html did not come back"; fail=1; }
done
echo "$third" | grep -q "GET /c.html" || { echo "FAIL linux_restore_test: the link handed over did not open"; fail=1; }
[ $fail = 0 ] || { grep -E "GET|---" "$log"; find "$WORK/home" -name session.json -exec cat {} \; ; rm -rf "$WORK"; exit 1; }
rm -rf "$WORK"
echo "linux_restore_test: tabs come back after a hard stop, and with a link"
