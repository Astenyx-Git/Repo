// The Rust core through fable_napi.c. Strings are UTF-8; JSON results are strings.
export const version: () => string;
export const setSystemLocale: (tag: string) => void;
export const language: () => string;
export const tr: (key: string) => string;
export const readerScript: () => string;
export const panelPage: () => string;
export const logoUri: () => string;
/** kind: 0 normal, 1 private (its own storage). iconsJson: {"host": [dataUri, width]} or "". */
export const newtabPage: (kind: number, iconsJson: string) => string;
export const sniffJs: () => string;
export const resolve: (input: string) => string;
export const shouldBlock: (url: string, page: string) => boolean;
/** The script that hides the ad boxes on a page. */
export const adblockScript: () => string;
/** True when following this URL would leave the browser for another app and the setting is on. */
export const blockExternalApp: (url: string) => boolean;
export const blockedCount: () => number;
export const storeOpen: (dir: string) => void;
export const settingGet: (key: string) => string;
export const settingSet: (key: string, value: string) => void;
export const settingsJson: () => string;
export const historyAdd: (url: string, title: string, wallClockMs: number) => void;
export const historyJson: (query: string, limit: number) => string;
export const historyClear: () => void;
/** null: the request is the shell's to answer. */
export const panelQuery: (name: string, arg: string, tab: number) => string | null;
export const parseIpReply: (body: string, source: string) => string;
export const deviceInfo: (extras: string) => string;
export const systemInfo: (extras: string) => string;
export const jsonString: (text: string) => string;
export const sniffNote: (tab: number, url: string, hint: string) => boolean;
export const sniffNoteScan: (tab: number, json: string) => number;
export const sniffCount: (tab: number) => number;
export const sniffJson: (tab: number) => string;
export const sniffClear: (tab: number) => void;
export const tabsOpen: (nowMs: number) => number;
export const tabsActivate: (id: number, nowMs: number) => boolean;
export const tabsClose: (id: number) => boolean;
export const tabsSetSleepAfterMs: (ms: number) => void;
export const tabsCollectSleepers: (nowMs: number) => number[];
