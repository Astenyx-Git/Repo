/*
 * Fable Browser for Sailfish OS - application entry point.
 *
 * Uses libsailfishapp (the standard Sailfish SDK template) so the application
 * inherits the platform window/lifecycle behaviour, then registers the Fable
 * core bridge as QML singletons before loading the main QML file.
 */
#include <sailfishapp.h>

#include <QGuiApplication>
#include <QQmlEngine>
#include <QQuickView>
#include <QLocale>
#include <QStandardPaths>
#include <QtQml>

#include "fablecore.h"
#include "panelbridge.h"
#include "qrscanner.h"

namespace {

PanelBridge *s_bridge = nullptr;
QrScanner *s_scanner = nullptr;

// Plain functions, not capturing lambdas: Qt 5.6's qmlRegisterSingletonType
// takes a function pointer. All three objects live as long as the app, owned by C++
// (the QML engine must not delete them).
QObject *coreSingleton(QQmlEngine *, QJSEngine *)
{
    QObject *core = FableCore::instance();
    QQmlEngine::setObjectOwnership(core, QQmlEngine::CppOwnership);
    return core;
}

QObject *bridgeSingleton(QQmlEngine *, QJSEngine *)
{
    QQmlEngine::setObjectOwnership(s_bridge, QQmlEngine::CppOwnership);
    return s_bridge;
}

QObject *scannerSingleton(QQmlEngine *, QJSEngine *)
{
    QQmlEngine::setObjectOwnership(s_scanner, QQmlEngine::CppOwnership);
    return s_scanner;
}

} // namespace

int main(int argc, char *argv[])
{
    QScopedPointer<QGuiApplication> app(SailfishApp::application(argc, argv));

    FableCore *core = FableCore::instance();
    s_bridge = new PanelBridge(core, core);
    s_scanner = new QrScanner(core);
    qmlRegisterSingletonType<FableCore>("harbour.fable.Core", 1, 0, "Fable", coreSingleton);
    qmlRegisterSingletonType<PanelBridge>("harbour.fable.Core", 1, 0, "Panel", bridgeSingleton);
    qmlRegisterSingletonType<QrScanner>("harbour.fable.Core", 1, 0, "QrScanner", scannerSingleton);

    // User data lives under the app's own XDG directory (Sailjail sandbox).
    const QString dataDir = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    core->storeOpen(dataDir);
    core->setSystemLocale(QLocale::system().name());

    QScopedPointer<QQuickView> view(SailfishApp::createView());
    view->setSource(SailfishApp::pathTo("qml/harbour-fable.qml"));
    view->show();
    return app->exec();
}
