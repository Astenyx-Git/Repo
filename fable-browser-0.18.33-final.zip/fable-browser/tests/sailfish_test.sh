#!/bin/sh
# The Sailfish OS shell, as far as it can be checked without the Sailfish SDK:
#
# 1. shell/sailfish/src compiled as C++11 (harbour-fable.pro) against desktop Qt 5
#    with the real core, and the bridge run: tests/sailfish/bridge_test.cpp.
# 2. The panel and new-tab pages that bridge builds, in headless Chrome, driven
#    with the scripts QML runs: tests/sailfish/panel_test.js, home_test.js.
# 3. shell/sailfish/qml by Qt Quick Test, with stand-ins for Silica, the WebView,
#    WebEngineSettings and the file picker: tests/sailfish/qml.
# 4. ES5 only (Qt 5.6 on the device), and qmllint.
#
# What stays for a device: the real Silica and Sailfish WebView (how they draw,
# how runJavaScript behaves), and cross-building (scripts/build-sailfish-core.sh, sfdk). Skips (exit 0) without
# Qt 5 (moc, pkg-config Qt5Core), unless FABLE_REQUIRE_SAILFISH=1.
set -eu
cd "$(dirname "$0")/.."
skip() { echo "sailfish_test: $1, skipped"; [ "${FABLE_REQUIRE_SAILFISH:-0}" = 1 ] && exit 1; exit 0; }
MOC=$( [ -x /usr/lib/qt5/bin/moc ] && echo /usr/lib/qt5/bin/moc || command -v moc || true)
[ -n "$MOC" ] || skip "no moc (Qt 5)"
pkg-config --exists Qt5Core 2>/dev/null || skip "no Qt5Core development package"
CXX=${CXX:-g++}
[ -f core/target/release/libfable_core.a ] || (cd core && cargo build -q --release)

W=$(mktemp -d)
trap 'rm -rf "$W"' EXIT
"$MOC" shell/sailfish/src/fablecore.h -o "$W/moc_fablecore.cpp"
"$MOC" shell/sailfish/src/panelbridge.h -o "$W/moc_panelbridge.cpp"
# FableCore reads QR codes from pictures (QImage), so it needs QtGui, as the app
# has it through QtQuick.
QTGUI=Qt5Core
pkg-config --exists Qt5Gui 2>/dev/null && QTGUI=Qt5Gui
# shellcheck disable=SC2046
$CXX -std=c++11 -fPIC -Wall -Wextra -Werror -Icore/include -Ishell/sailfish/src $(pkg-config --cflags $QTGUI) \
    shell/sailfish/src/fablecore.cpp shell/sailfish/src/panelbridge.cpp "$W/moc_fablecore.cpp" "$W/moc_panelbridge.cpp" \
    tests/sailfish/bridge_test.cpp core/target/release/libfable_core.a $(pkg-config --libs $QTGUI) -lpthread -ldl -lm \
    -o "$W/bridge_test"
# The camera scanner (QtMultimedia) and main.cpp, which needs libsailfishapp: main.cpp
# against a stand-in for its header only, both compiled but not run.
QTMM=
if pkg-config --exists Qt5Multimedia 2>/dev/null; then
    QTMM=Qt5Multimedia
    "$MOC" shell/sailfish/src/qrscanner.h -o "$W/moc_qrscanner.cpp"
    # shellcheck disable=SC2046
    $CXX -std=c++11 -c -fPIC -Wall -Wextra -Werror -Icore/include -Ishell/sailfish/src $(pkg-config --cflags Qt5Multimedia) \
        shell/sailfish/src/qrscanner.cpp -o "$W/qrscanner.o"
    # shellcheck disable=SC2046
    $CXX -std=c++11 -c -fPIC -Wall -Wextra -Werror -Icore/include -Ishell/sailfish/src $(pkg-config --cflags Qt5Multimedia) \
        "$W/moc_qrscanner.cpp" -o "$W/moc_qrscanner.o"
else
    echo "sailfish_test: no Qt5Multimedia development package: the camera scanner is not compiled"
fi
if [ -n "$QTMM" ] || ! grep -q qrscanner.h shell/sailfish/src/main.cpp; then
    # shellcheck disable=SC2046
    $CXX -std=c++11 -fsyntax-only -fPIC -Wall -Wextra -Werror -Icore/include -Ishell/sailfish/src -Itests/sailfish/stub \
        $(pkg-config --cflags Qt5Quick $QTMM 2>/dev/null || pkg-config --cflags Qt5Core) shell/sailfish/src/main.cpp
fi
mkdir -p "$W/home"
HOME="$W/home" XDG_CONFIG_HOME="$W/home/.config" QT_QPA_PLATFORM=offscreen "$W/bridge_test" "$W"

if python3 -c 'import shutil, os, sys; sys.exit(0 if (os.environ.get("CHROME") or shutil.which("google-chrome") or shutil.which("chromium") or shutil.which("chromium-browser")) else 1)'; then
    for page in panel:5 home:2; do
        name=${page%:*} want=${page#*:}
        cat "$W/generated.js" "tests/sailfish/${name}_test.js" > "$W/check.js"
        out=$(python3 tests/chrome_harness.py "$W/$name.html" "$W/$name.png" --js "$W/check.js" --wait 1) || { echo "$out"; exit 1; }
        echo "$out"
        [ "$(echo "$out" | grep -cE '(^|: )ok ')" -ge "$want" ] || { echo "FAIL sailfish_test: the $name page checks did not all run"; exit 1; }
    done
else
    echo "sailfish_test: no Chrome, the panel page was not run"
fi

# 3. The QML, by Qt Quick Test, with stand-ins for the Sailfish modules (tests/sailfish/qml).
if pkg-config --exists Qt5QuickTest Qt5Quick 2>/dev/null && [ -d "$(pkg-config --variable=libdir Qt5Core)/qt5/qml/QtTest" ]; then
    "$MOC" tests/sailfish/qml/qml_test.cpp -o "$W/qml_test.moc"
    # shellcheck disable=SC2046
    $CXX -std=c++11 -fPIC -Wall -Wextra -Werror -Icore/include -Ishell/sailfish/src -I"$W" $(pkg-config --cflags Qt5QuickTest Qt5Quick) \
        -DFABLE_TEST_DIR="\"$PWD/tests/sailfish/qml\"" -DFABLE_SHELL_QML="\"$PWD/shell/sailfish/qml\"" \
        shell/sailfish/src/fablecore.cpp shell/sailfish/src/panelbridge.cpp "$W/moc_fablecore.cpp" "$W/moc_panelbridge.cpp" \
        tests/sailfish/qml/qml_test.cpp core/target/release/libfable_core.a $(pkg-config --libs Qt5QuickTest Qt5Quick) -lpthread -ldl -lm \
        -o "$W/qml_test"
    rm -rf "$W/home" && mkdir -p "$W/home"
    HOME="$W/home" XDG_CONFIG_HOME="$W/home/.config" XDG_DATA_HOME="$W/home/.local/share" XDG_DOWNLOAD_DIR="$W/home/Downloads" \
        QT_LOGGING_RULES="qt.qml.connections=false" QT_QPA_PLATFORM=offscreen "$W/qml_test" -input tests/sailfish/qml
else
    echo "sailfish_test: no Qt Quick Test (qtdeclarative5-dev, qml-module-qttest, qml-module-qtquick2), the QML was not run"
    [ "${FABLE_REQUIRE_SAILFISH:-0}" = 1 ] && exit 1
fi

# 4. ES5 only (Sailfish OS ships Qt 5.6), and qmllint for syntax.
if grep -nE '=>|`|\b(let|const|class)\s' shell/sailfish/qml -r; then
    echo "FAIL sailfish_test: Sailfish OS's Qt 5.6 runs ES5 QML JavaScript only"; exit 1
fi
if command -v qmllint >/dev/null 2>&1; then
    find shell/sailfish/qml -name '*.qml' -exec qmllint {} +
    echo "sailfish_test: qmllint passed on $(find shell/sailfish/qml -name '*.qml' | wc -l) QML files"
fi
echo "sailfish_test: bridge, pages and QML pass"
