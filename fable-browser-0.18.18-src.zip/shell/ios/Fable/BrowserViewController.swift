// The browser: tabs in a stage, Android's bottom bar (or the address at the
// top), and ui/panel.html as a bottom sheet for the menu, tabs and settings.
import UIKit
import UniformTypeIdentifiers
import WebKit

enum Browser {
    static let scheme = "fable"
    static let home = "fable://newtab/"
}

enum Palette {
    static func rgb(_ v: UInt32) -> UIColor {
        UIColor(red: CGFloat((v >> 16) & 0xFF) / 255, green: CGFloat((v >> 8) & 0xFF) / 255, blue: CGFloat(v & 0xFF) / 255, alpha: 1)
    }
    // The same colours as the Android shell.
    static let ground = rgb(0xFDF7F0), bar = rgb(0xFBF2E8), ink = rgb(0x2A1A14), muted = rgb(0x5E4A3F),
               hint = rgb(0x8A766A), line = rgb(0xEBDDD0), spark = rgb(0xD9512C)
    static let darkBar = rgb(0x211611), darkPill = rgb(0x33241D), darkLine = rgb(0x4A372D),
               darkInk = rgb(0xFBEFE4), darkMuted = rgb(0xC9B5A6)
}

/// Passes script messages on without the content controller keeping the browser alive.
final class WeakScriptHandler: NSObject, WKScriptMessageHandler {
    weak var target: WKScriptMessageHandler?
    init(_ target: WKScriptMessageHandler) { self.target = target }
    func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
        target?.userContentController(controller, didReceive: message)
    }
}

/// A label with room around its text (the toast).
final class InsetLabel: UILabel {
    var insets = UIEdgeInsets(top: 10, left: 16, bottom: 10, right: 16)
    override func drawText(in rect: CGRect) { super.drawText(in: rect.inset(by: insets)) }
    override var intrinsicContentSize: CGSize {
        let s = super.intrinsicContentSize
        return CGSize(width: s.width + insets.left + insets.right, height: s.height + insets.top + insets.bottom)
    }
    override func textRect(forBounds bounds: CGRect, limitedToNumberOfLines n: Int) -> CGRect {
        let r = super.textRect(forBounds: bounds.inset(by: insets), limitedToNumberOfLines: n)
        return r.inset(by: UIEdgeInsets(top: -insets.top, left: -insets.left, bottom: -insets.bottom, right: -insets.right))
    }
}

final class BrowserViewController: UIViewController {
    private let policy = TabPolicy()
    private(set) var tabs: [Tab] = []
    private(set) var active: Tab?
    private weak var lastNormal: Tab?
    private weak var lastPrivate: Tab?
    /// Shared by every tab: the new-tab page's "fable" handler and the content blockers.
    private let content = WKUserContentController()
    /// Private tabs share one store that lives until the last private tab closes.
    private var privateStore: WKWebsiteDataStore?
    private var trackerRules: WKContentRuleList?
    private var adRules: WKContentRuleList?
    private var imageRules: WKContentRuleList?
    private var adsUpdating = false   // one ad-list fetch at a time
    private lazy var logo = Core.logoURI
    /// Downloads under way (kept alive here) and where each one is going.
    private var downloadRecords: [WKDownload: UInt32] = [:]
    private var downloads: [WKDownload: URL?] = [:]

    // ---- views ----
    private let stage = UIView()
    private let topBar = UIView()
    private let topStack = UIStackView()
    private let bottomBar = UIView()
    private let bottomStack = UIStackView()
    private let pillRow = UIView()
    private let pill = UIView()
    private let siteIcon = UIImageView()
    private let address = UITextField()
    private let reloadButton = UIButton(type: .system)
    private let progress = UIProgressView(progressViewStyle: .bar)
    private let navRow = UIStackView()
    private let backButton = UIButton(type: .system)
    private let forwardButton = UIButton(type: .system)
    private let homeButton = UIButton(type: .system)
    private let newTabButton = UIButton(type: .system)
    private let tabsButton = UIButton(type: .system)
    private let tabCount = UILabel()
    private let menuButton = UIButton(type: .system)
    private let toastLabel = InsetLabel()
    private var stageUnderTopBar: NSLayoutConstraint!
    private var stageUnderSafeArea: NSLayoutConstraint!
    private var toastSerial = 0
    private var sleepTimer: Timer?
    private var privacyCover: UIView?

    // ---- the panel ----
    private var panel: WKWebView?
    private var panelReady = false
    private var panelQueue: [String] = []
    private var panelOpen = false
    private var exportingBookmarks = false   // which document picker is up: export, or import

    var inPrivate: Bool { active?.isPrivate ?? false }
    private var addressAtTop: Bool { Core.setting("address_top") == "1" }

    deinit { sleepTimer?.invalidate() }

    // MARK: - set up

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = Palette.ground
        content.add(WeakScriptHandler(self), name: "fable")
        buildViews()
        applyLanguage(reload: false)
        applyAddressBarPosition()
        applyRuleLists()
        if Core.adsUpdateDue { fetchAdList() }   // a week since the last fetch, while ad blocking is on
        policy.setSleepAfter(minutes: Prefs.sleepMinutes(Core.setting("sleep_minutes")))
        UIApplication.shared.isIdleTimerDisabled = Core.setting("keep_screen_on") == "1"
        // As on macOS, an address given at launch opens in the first tab
        // (xcrun simctl launch <device> app.fable.browser https://example.com).
        let args = ProcessInfo.processInfo.arguments
        let address = args.count > 1 && !args[1].hasPrefix("-") ? args[1] : nil
        // The tabs of the last run come back unless that is switched off; an address
        // given at launch, or a link handed over (SceneDelegate), opens on top of them.
        if !restoreSession() || address != nil { openTab(address, isPrivate: false) }
        sleepTimer = Timer.scheduledTimer(withTimeInterval: 30, repeats: true) { [weak self] _ in self?.sleepIdleTabs() }
    }

    private func buildViews() {
        for v in [stage, topBar, bottomBar, topStack, bottomStack, pill, siteIcon, address, reloadButton, tabCount, toastLabel] {
            v.translatesAutoresizingMaskIntoConstraints = false
        }
        stage.backgroundColor = Palette.ground
        view.addSubview(stage)
        view.addSubview(topBar)
        view.addSubview(bottomBar)
        topBar.addSubview(topStack)
        bottomBar.addSubview(bottomStack)
        topStack.axis = .vertical
        bottomStack.axis = .vertical

        // The address pill: site icon, the field, reload/stop.
        pillRow.addSubview(pill)
        pill.layer.cornerRadius = 22
        pill.layer.borderWidth = 1
        pill.addSubview(siteIcon)
        pill.addSubview(address)
        pill.addSubview(reloadButton)
        siteIcon.contentMode = .scaleAspectFit
        siteIcon.preferredSymbolConfiguration = UIImage.SymbolConfiguration(pointSize: 14, weight: .semibold)
        address.borderStyle = .none
        address.font = .systemFont(ofSize: 16)
        address.keyboardType = .webSearch
        address.returnKeyType = .go
        address.autocapitalizationType = .none
        address.autocorrectionType = .no
        address.spellCheckingType = .no
        address.smartDashesType = .no
        address.smartQuotesType = .no
        address.textContentType = .URL
        address.clearButtonMode = .whileEditing
        address.semanticContentAttribute = .forceLeftToRight   // addresses read left to right in every language
        address.delegate = self
        reloadButton.addTarget(self, action: #selector(reloadOrStop), for: .touchUpInside)
        NSLayoutConstraint.activate([
            pill.topAnchor.constraint(equalTo: pillRow.topAnchor, constant: 6),
            pill.bottomAnchor.constraint(equalTo: pillRow.bottomAnchor, constant: -6),
            pill.leadingAnchor.constraint(equalTo: pillRow.leadingAnchor, constant: 12),
            pill.trailingAnchor.constraint(equalTo: pillRow.trailingAnchor, constant: -12),
            pill.heightAnchor.constraint(equalToConstant: 44),
            siteIcon.leadingAnchor.constraint(equalTo: pill.leadingAnchor, constant: 14),
            siteIcon.centerYAnchor.constraint(equalTo: pill.centerYAnchor),
            siteIcon.widthAnchor.constraint(equalToConstant: 18),
            siteIcon.heightAnchor.constraint(equalToConstant: 18),
            address.leadingAnchor.constraint(equalTo: siteIcon.trailingAnchor, constant: 10),
            address.topAnchor.constraint(equalTo: pill.topAnchor),
            address.bottomAnchor.constraint(equalTo: pill.bottomAnchor),
            reloadButton.leadingAnchor.constraint(equalTo: address.trailingAnchor, constant: 4),
            reloadButton.trailingAnchor.constraint(equalTo: pill.trailingAnchor, constant: -4),
            reloadButton.centerYAnchor.constraint(equalTo: pill.centerYAnchor),
            reloadButton.widthAnchor.constraint(equalToConstant: 36),
            reloadButton.heightAnchor.constraint(equalToConstant: 36),
        ])
        progress.progressTintColor = Palette.spark
        progress.trackTintColor = .clear
        progress.alpha = 0
        progress.heightAnchor.constraint(equalToConstant: 2).isActive = true

        // The nav row, as on Android: back, forward, (home), new tab, tabs, menu.
        navRow.axis = .horizontal
        navRow.distribution = .fillEqually
        navRow.heightAnchor.constraint(equalToConstant: 48).isActive = true
        setUp(backButton, symbol: "chevron.backward", action: #selector(goBack))
        setUp(forwardButton, symbol: "chevron.forward", action: #selector(goForward))
        setUp(homeButton, symbol: "house", action: #selector(goHome))
        setUp(newTabButton, symbol: "plus", action: #selector(newTabTapped))
        setUp(tabsButton, symbol: nil, action: #selector(tabsTapped))
        setUp(menuButton, symbol: "line.3.horizontal", action: #selector(menuTapped))
        tabsButton.addSubview(tabCount)
        tabCount.isUserInteractionEnabled = false
        tabCount.textAlignment = .center
        tabCount.font = .systemFont(ofSize: 12, weight: .bold)
        tabCount.adjustsFontSizeToFitWidth = true
        tabCount.minimumScaleFactor = 0.6
        tabCount.layer.borderWidth = 2
        tabCount.layer.cornerRadius = 6
        NSLayoutConstraint.activate([
            tabCount.centerXAnchor.constraint(equalTo: tabsButton.centerXAnchor),
            tabCount.centerYAnchor.constraint(equalTo: tabsButton.centerYAnchor),
            tabCount.widthAnchor.constraint(equalToConstant: 22),
            tabCount.heightAnchor.constraint(equalToConstant: 22),
        ])
        bottomStack.addArrangedSubview(navRow)

        let safe = view.safeAreaLayoutGuide
        stageUnderTopBar = stage.topAnchor.constraint(equalTo: topBar.bottomAnchor)
        stageUnderSafeArea = stage.topAnchor.constraint(equalTo: safe.topAnchor)
        NSLayoutConstraint.activate([
            topBar.topAnchor.constraint(equalTo: view.topAnchor),
            topBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            topBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            topStack.topAnchor.constraint(equalTo: safe.topAnchor),
            topStack.leadingAnchor.constraint(equalTo: safe.leadingAnchor),
            topStack.trailingAnchor.constraint(equalTo: safe.trailingAnchor),
            topStack.bottomAnchor.constraint(equalTo: topBar.bottomAnchor),
            bottomBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bottomBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            bottomBar.bottomAnchor.constraint(equalTo: view.bottomAnchor),   // the bar's colour runs under the home indicator
            bottomStack.topAnchor.constraint(equalTo: bottomBar.topAnchor),
            bottomStack.leadingAnchor.constraint(equalTo: safe.leadingAnchor),
            bottomStack.trailingAnchor.constraint(equalTo: safe.trailingAnchor),
            bottomStack.bottomAnchor.constraint(equalTo: view.keyboardLayoutGuide.topAnchor),   // rides on the keyboard
            stage.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            stage.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            stage.bottomAnchor.constraint(equalTo: bottomBar.topAnchor),
        ])

        toastLabel.numberOfLines = 0
        toastLabel.textAlignment = .center
        toastLabel.font = .systemFont(ofSize: 14, weight: .medium)
        toastLabel.textColor = .white
        toastLabel.backgroundColor = Palette.ink.withAlphaComponent(0.92)
        toastLabel.layer.cornerRadius = 18
        toastLabel.layer.masksToBounds = true
        toastLabel.alpha = 0
        toastLabel.isUserInteractionEnabled = false
        view.addSubview(toastLabel)
        NSLayoutConstraint.activate([
            toastLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            toastLabel.bottomAnchor.constraint(equalTo: bottomBar.topAnchor, constant: -16),
            toastLabel.widthAnchor.constraint(lessThanOrEqualTo: safe.widthAnchor, constant: -48),
        ])
    }

    private func setUp(_ button: UIButton, symbol: String?, action: Selector) {
        if let symbol = symbol {
            button.setImage(UIImage(systemName: symbol, withConfiguration: UIImage.SymbolConfiguration(pointSize: 19, weight: .regular)), for: .normal)
        }
        button.addTarget(self, action: action, for: .touchUpInside)
        navRow.addArrangedSubview(button)
    }

    // MARK: - status bar, orientation

    override var preferredStatusBarStyle: UIStatusBarStyle {
        // Private mode darkens the status bar wherever the address bar is (as in Chrome): light text on it.
        inPrivate ? .lightContent : .darkContent
    }

    override var prefersStatusBarHidden: Bool { Core.setting("hide_status_bar") == "1" }

    /// Locking the orientation works where iOS lets an app choose: iPhone, and
    /// iPad apps that opt out of multitasking (Fable does not; caps say so).
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        switch Prefs.orientation(Core.setting("orientation")) {
        case .portrait: return .portrait
        case .landscape: return .landscape
        case .any: return traitCollection.userInterfaceIdiom == .pad ? .all : .allButUpsideDown
        }
    }

    private var canLockOrientation: Bool { traitCollection.userInterfaceIdiom != .pad }

    private func applyOrientation() {
        if #available(iOS 16.0, *) {
            setNeedsUpdateOfSupportedInterfaceOrientations()
            view.window?.windowScene?.requestGeometryUpdate(.iOS(interfaceOrientations: supportedInterfaceOrientations)) { _ in }
        } else {
            UIViewController.attemptRotationToDeviceOrientation()
        }
    }

    // MARK: - chrome

    /// Android's "address bar at the top" (address_top): the pill moves into a top bar.
    private func applyAddressBarPosition() {
        let top = addressAtTop
        pillRow.removeFromSuperview()
        progress.removeFromSuperview()
        if top {
            topStack.addArrangedSubview(pillRow)
            topStack.addArrangedSubview(progress)
        } else {
            bottomStack.insertArrangedSubview(progress, at: 0)
            bottomStack.insertArrangedSubview(pillRow, at: 1)
        }
        topBar.isHidden = !top
        stageUnderTopBar.isActive = false
        stageUnderSafeArea.isActive = false
        (top ? stageUnderTopBar : stageUnderSafeArea).isActive = true
        styleChrome()
    }

    private func styleChrome() {
        let dark = inPrivate
        let ink = dark ? Palette.darkInk : Palette.ink, muted = dark ? Palette.darkMuted : Palette.muted
        let barColor = dark ? Palette.darkBar : Palette.bar
        view.backgroundColor = dark ? Palette.darkBar : Palette.ground   // what shows behind the status bar when the address is at the bottom
        topBar.backgroundColor = barColor
        bottomBar.backgroundColor = barColor
        stage.backgroundColor = dark ? Palette.darkBar : Palette.ground
        pill.backgroundColor = dark ? Palette.darkPill : .white
        pill.layer.borderColor = (dark ? Palette.darkLine : Palette.line).cgColor
        address.textColor = ink
        address.tintColor = Palette.spark
        address.keyboardAppearance = dark ? .dark : .light
        for b in [reloadButton, backButton, forwardButton, homeButton, newTabButton, tabsButton, menuButton] { b.tintColor = muted }
        siteIcon.tintColor = muted
        tabCount.textColor = muted
        tabCount.layer.borderColor = muted.cgColor
        setPlaceholder(dark ? Palette.darkMuted : Palette.hint)
        // The bars keep Fable's palette in light and dark mode alike; pages follow
        // the system's appearance (prefers-color-scheme), as in Safari.
        setNeedsStatusBarAppearanceUpdate()
    }

    private func setPlaceholder(_ color: UIColor) {
        let style = NSMutableParagraphStyle()
        style.alignment = isRTL ? .right : .left
        address.attributedPlaceholder = NSAttributedString(string: Core.tr("addr_hint"),
                                                           attributes: [.foregroundColor: color, .paragraphStyle: style])
    }

    private var isRTL: Bool { Core.language.hasPrefix("ar") }

    /// Labels in the chosen language, and the bars mirrored for Arabic.
    private func applyLanguage(reload: Bool) {
        let direction: UISemanticContentAttribute = isRTL ? .forceRightToLeft : .forceLeftToRight
        for v in [view, topBar, topStack, bottomBar, bottomStack, pillRow, pill, navRow, toastLabel] as [UIView] {
            v.semanticContentAttribute = direction
        }
        for b in [backButton, forwardButton, homeButton, newTabButton, tabsButton, menuButton, reloadButton] { b.semanticContentAttribute = direction }
        backButton.accessibilityLabel = Core.tr("go_back")
        forwardButton.accessibilityLabel = Core.tr("go_forward")
        homeButton.accessibilityLabel = Core.tr("go_home")
        newTabButton.accessibilityLabel = Core.tr("new_tab_btn")
        tabsButton.accessibilityLabel = Core.tr("tabs")
        menuButton.accessibilityLabel = Core.tr("menu")
        styleChrome()
        guard reload else { return }
        for t in tabs where t.isHome {
            if t.url.isEmpty { t.title = Core.tr("newtab") }
            t.web?.reload()
        }
        reloadPanel()
        refreshChrome()
    }

    private func refreshChrome() {
        guard let t = active else { return }
        if !address.isFirstResponder { address.text = t.url }
        let symbol = t.isPrivate ? "eye.slash" : t.url.hasPrefix("https://") ? "lock.fill" : t.url.isEmpty ? "magnifyingglass" : "globe"
        siteIcon.image = UIImage(systemName: symbol)
        let loading = t.web?.isLoading ?? false
        reloadButton.setImage(UIImage(systemName: loading ? "xmark" : "arrow.clockwise"), for: .normal)
        reloadButton.accessibilityLabel = Core.tr(loading ? "stop" : "reload")
        reloadButton.isHidden = t.url.isEmpty && !loading
        backButton.isEnabled = t.web?.canGoBack ?? false
        forwardButton.isEnabled = t.web?.canGoForward ?? false
        homeButton.isHidden = Core.setting("home_button") != "1"
        let count = tabs.filter { $0.isPrivate == t.isPrivate }.count
        tabCount.text = count > 99 ? ":D" : String(count)
        if loading {
            progress.alpha = 1
            progress.setProgress(max(0.05, Float(t.web?.estimatedProgress ?? 0)), animated: true)
        } else if progress.alpha > 0 {
            progress.setProgress(1, animated: true)
            UIView.animate(withDuration: 0.25, delay: 0.1, options: [], animations: { self.progress.alpha = 0 }) { _ in
                self.progress.setProgress(0, animated: false)
            }
        }
    }

    /// A tab's address, title or loading state changed.
    func tabChanged(_ tab: Tab) {
        if tab === active { refreshChrome() }
    }

    func toast(_ text: String) {
        guard !text.isEmpty else { return }
        toastSerial += 1
        let serial = toastSerial
        toastLabel.text = text
        view.bringSubviewToFront(toastLabel)
        UIView.animate(withDuration: 0.2) { self.toastLabel.alpha = 1 }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.4) { [weak self] in
            guard let self = self, self.toastSerial == serial else { return }
            UIView.animate(withDuration: 0.3) { self.toastLabel.alpha = 0 }
        }
    }

    /// One dialog at a time; a page asking while another shows gets "no".
    func presentDialog(_ alert: UIAlertController, otherwise: @escaping () -> Void) {
        guard presentedViewController == nil, view.window != nil else { otherwise(); return }
        if inPrivate { alert.overrideUserInterfaceStyle = .dark }
        present(alert, animated: true)
    }

    // MARK: - nav row

    @objc private func goBack() { active?.web?.goBack() }
    @objc private func goForward() { active?.web?.goForward() }
    @objc private func goHome() { if let t = active { navigate(t, Browser.home) } }
    @objc private func newTabTapped() { openTab(nil, isPrivate: inPrivate) }
    @objc private func tabsTapped() { showPanel("tabs") }
    @objc private func menuTapped() { showPanel("menu") }
    @objc private func reloadOrStop() {
        guard let web = active?.web else { return }
        if web.isLoading { web.stopLoading() } else { web.reload() }
    }

    // MARK: - tabs

    private func makeConfiguration(private isPrivate: Bool) -> WKWebViewConfiguration {
        let c = WKWebViewConfiguration()
        c.userContentController = content
        c.setURLSchemeHandler(self, forURLScheme: Browser.scheme)
        if isPrivate {
            if privateStore == nil { privateStore = .nonPersistent() }
            c.websiteDataStore = privateStore!
        } else {
            c.websiteDataStore = .default()
        }
        c.allowsInlineMediaPlayback = true
        c.allowsPictureInPictureMediaPlayback = true
        c.preferences.isFraudulentWebsiteWarningEnabled = true
        c.preferences.javaScriptCanOpenWindowsAutomatically = false
        c.defaultWebpagePreferences.preferredContentMode = Prefs.wantsDesktop(mode: Core.setting("ua_mode")) ? .desktop : .mobile
        // Without "Version/… Safari/…" some sites take WKWebView for an in-app browser.
        let parts = UIDevice.current.systemVersion.split(separator: ".")
        let version = parts.prefix(2).joined(separator: ".")
        c.applicationNameForUserAgent = "Version/\(parts.count > 1 ? version : version + ".0") Mobile/15E148 Safari/604.1"
        return c
    }

    private func attach(_ tab: Tab, configuration: WKWebViewConfiguration? = nil) {
        let web = tab.wake(configuration: configuration ?? makeConfiguration(private: tab.isPrivate))
        web.customUserAgent = Prefs.userAgent(mode: Core.setting("ua_mode"), custom: Core.setting("ua_custom"))
        web.pageZoom = CGFloat(Prefs.pageZoom(Core.setting("text_size")))
        web.translatesAutoresizingMaskIntoConstraints = false
        web.isHidden = tab !== active
        stage.addSubview(web)
        NSLayoutConstraint.activate([
            web.topAnchor.constraint(equalTo: stage.topAnchor),
            web.bottomAnchor.constraint(equalTo: stage.bottomAnchor),
            web.leadingAnchor.constraint(equalTo: stage.leadingAnchor),
            web.trailingAnchor.constraint(equalTo: stage.trailingAnchor),
        ])
    }

    /// A new tab next to the one in front. With a configuration (a page opened
    /// a window) WebKit loads the page itself.
    @discardableResult
    func openTab(_ input: String?, isPrivate: Bool, configuration: WKWebViewConfiguration? = nil, background: Bool = false) -> Tab {
        let tab = Tab(id: policy.open(), isPrivate: isPrivate, browser: self)
        if let a = active, let i = tabs.firstIndex(where: { $0 === a }) { tabs.insert(tab, at: i + 1) } else { tabs.append(tab) }
        attach(tab, configuration: configuration)
        if configuration == nil {
            let target = input.map { Core.resolve($0) } ?? ""
            tab.load(target.isEmpty ? Browser.home : target)
        }
        if background, let current = active {
            policy.activate(current.id)   // the core's front tab stays the one in front
            refreshChrome()
        } else {
            activate(tab)
        }
        if panelOpen { panelUpdate() }
        return tab
    }

    func activate(_ tab: Tab) {
        let modeChanged = active?.isPrivate != tab.isPrivate
        active = tab
        if tab.isPrivate { lastPrivate = tab } else { lastNormal = tab }
        policy.activate(tab.id)
        if tab.web == nil {   // asleep: wake it where it was
            attach(tab)
            tab.load(tab.pageURL)
        }
        for t in tabs { t.web?.isHidden = t !== tab }
        if modeChanged { styleChrome() }
        refreshChrome()
    }

    func navigate(_ tab: Tab, _ input: String) {
        let target = input == Browser.home ? input : Core.resolve(input)
        guard !target.isEmpty else { return }
        if tab.web == nil { attach(tab) }
        tab.load(target)
        if tab === active { refreshChrome() }
    }

    func close(_ tab: Tab?) {
        guard let tab = tab, let i = tabs.firstIndex(where: { $0 === tab }) else { return }
        let wasActive = tab === active
        tabs.remove(at: i)
        drop(tab)
        if !tab.isPrivate { saveSession() }
        if wasActive {
            // The neighbour of the same kind; private mode ends with its last tab; normal mode always keeps one.
            let next = tabs[i...].first { $0.isPrivate == tab.isPrivate } ?? tabs[..<i].last { $0.isPrivate == tab.isPrivate }
            active = nil
            if let next = next {
                activate(next)
            } else if tab.isPrivate, let normal = alive(lastNormal) ?? tabs.last(where: { !$0.isPrivate }) {
                activate(normal)
            } else {
                openTab(nil, isPrivate: false)
            }
        } else {
            refreshChrome()
        }
        if !tabs.contains(where: { $0.isPrivate }) { privateStore = nil }
    }

    // MARK: - restoring tabs

    /// Snapshot the normal tabs for "restore tabs on start" (the core keeps
    /// nothing while it is off). Private tabs never enter it.
    func saveSession() {
        let front = active.flatMap { a in a.isPrivate ? alive(lastNormal) : a }
        let list = tabs.map { (url: $0.url, title: $0.title, isPrivate: $0.isPrivate) }
        Core.sessionSave(Panel.session(list, front: front.flatMap { f in tabs.firstIndex { $0 === f } } ?? -1))
    }

    /// Reopen the normal tabs of the last run. They come back asleep (an
    /// address and a title) except the one that was in front. False when
    /// there was nothing to restore.
    private func restoreSession() -> Bool {
        guard Core.setting("restore_tabs") != "0" else { return false }
        let wanted = Core.sessionActive
        var front: Tab?
        for i in 0..<Core.sessionCount {
            let url = Core.sessionURL(i)
            guard url.hasPrefix("http://") || url.hasPrefix("https://"), URL(string: url) != nil else { continue }   // web pages only
            let tab = Tab(id: policy.open(), isPrivate: false, browser: self)
            tab.pageURL = url
            tab.url = url
            let title = Core.sessionTitle(i)
            tab.title = title.isEmpty ? url : title
            tabs.append(tab)
            if front == nil || i == wanted { front = tab }
        }
        guard let tab = front else { return false }
        activate(tab)   // wakes it: the view is built and the page loads
        return true
    }

    // MARK: - bookmarks

    /// The bookmark id of the tab's page: 0 for private tabs and pages not on the web.
    private func bookmarkID(_ tab: Tab?) -> UInt64 {
        guard let t = tab, !t.isPrivate, t.isWebPage else { return 0 }
        return Core.bookmarkID(t.url)
    }

    private func toggleBookmark() {
        guard let t = active, !t.isPrivate, t.isWebPage else { return }
        let id = bookmarkID(t)
        if id != 0 {
            Core.bookmarkRemove(id)
            toast(Core.tr("removed_bookmark"))
        } else {
            Core.bookmarkAdd(t.url, title: t.title)
            toast(Core.tr("added_bookmark"))
        }
        if panelOpen { panelUpdate() }
    }

    /// Import a Chrome/Firefox bookmark file (HTML) picked in Files.
    private func pickBookmarkFile() {
        hidePanel()
        exportingBookmarks = false
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.html], asCopy: true)
        picker.delegate = self
        present(picker, animated: true)
    }

    /// Export the bookmarks as an HTML file Chrome and Firefox can import, saved where the user picks in Files.
    private func saveBookmarkFile() {
        hidePanel()
        let file = FileManager.default.temporaryDirectory.appendingPathComponent("bookmarks.html")
        do {
            try Data(Core.bookmarkExport.utf8).write(to: file, options: .atomic)
        } catch {
            toast(Core.tr("bookmark_export_failed"))
            return
        }
        exportingBookmarks = true
        let picker = UIDocumentPickerViewController(forExporting: [file], asCopy: true)
        picker.delegate = self
        present(picker, animated: true)
    }

    /// A remembered tab, if it is still open.
    private func alive(_ tab: Tab?) -> Tab? {
        guard let tab = tab, tabs.contains(where: { $0 === tab }) else { return nil }
        return tab
    }

    private func drop(_ tab: Tab) {
        policy.close(tab.id)
        Core.sniffClear(tab.id)
        tab.sleep()
    }

    private func enterPrivate() {
        if let t = alive(lastPrivate) ?? tabs.last(where: { $0.isPrivate }) { activate(t) } else { openTab(nil, isPrivate: true) }
    }

    /// Close every private tab and forget their data.
    private func exitPrivate() {
        let gone = tabs.filter { $0.isPrivate }
        tabs.removeAll { $0.isPrivate }
        gone.forEach(drop)
        privateStore = nil
        if inPrivate {
            active = nil
            if let normal = alive(lastNormal) ?? tabs.last { activate(normal) } else { openTab(nil, isPrivate: false) }
        }
        refreshChrome()
        toast(Core.tr("private_closed"))
    }

    /// Opened from another app (a link, a share, "Open in").
    func openExternal(_ url: URL) {
        guard ["http", "https"].contains(url.scheme?.lowercased() ?? "") else { return }
        if let t = active, !t.isPrivate, t.isHome, !(t.web?.canGoBack ?? false) { navigate(t, url.absoluteString) }
        else { openTab(url.absoluteString, isPrivate: false) }
    }

    private func reloadActiveWebPage() {
        if let t = active, t.isWebPage { t.web?.reload() }
    }

    // MARK: - sleep

    /// Background tabs idle for sleep_minutes give up their web view, unless they play media.
    private func sleepIdleTabs() {
        for id in policy.collectSleepers() {
            guard let tab = tabs.first(where: { $0.id == id }), tab !== active, let web = tab.web else { continue }
            web.evaluateJavaScript("Array.prototype.some.call(document.querySelectorAll('video,audio'), function (m) { return !m.paused; })") { [weak self, weak tab] result, _ in
                guard let self = self, let tab = tab, tab !== self.active else { return }
                if (result as? Bool) == true { self.policy.touch(tab.id) } else { tab.sleep() }
                if self.panelOpen { self.panelUpdate() }
            }
        }
    }

    /// iOS is short of memory: every background tab sleeps now.
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        for t in tabs where t !== active && t.web != nil { t.sleep() }
        if panelOpen { panelUpdate() }
    }

    // MARK: - private tabs in the app switcher

    /// iOS cannot keep a window out of screenshots, but the app-switcher
    /// snapshot can be covered while a private tab is in front.
    func coverForAppSwitcher() {
        guard inPrivate, privacyCover == nil, let window = view.window else { return }
        let cover = UIView(frame: window.bounds)
        cover.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        cover.backgroundColor = Palette.darkBar
        let mark = UIImageView(image: UIImage(systemName: "eye.slash", withConfiguration: UIImage.SymbolConfiguration(pointSize: 44, weight: .light)))
        mark.tintColor = Palette.darkMuted
        mark.center = CGPoint(x: cover.bounds.midX, y: cover.bounds.midY)
        mark.autoresizingMask = [.flexibleTopMargin, .flexibleBottomMargin, .flexibleLeftMargin, .flexibleRightMargin]
        cover.addSubview(mark)
        window.addSubview(cover)
        privacyCover = cover
    }

    func uncover() {
        privacyCover?.removeFromSuperview()
        privacyCover = nil
    }

    // MARK: - content blockers

    /// Trackers (block_trackers, on by default) and images (data_saver), as compiled WebKit rule lists.
    private func applyRuleLists() {
        let store = WKContentRuleListStore.default()
        if Core.setting("block_trackers") != "0" {
            if let list = trackerRules { content.add(list) } else {
                store?.compileContentRuleList(forIdentifier: "fable-trackers-\(Core.version)", encodedContentRuleList: Core.contentRules) { [weak self] list, error in
                    guard let self = self, let list = list else { if let error = error { NSLog("Fable: tracker list: %@", "\(error)") }; return }
                    self.trackerRules = list
                    if Core.setting("block_trackers") != "0" { self.content.add(list) }
                }
            }
        } else if let list = trackerRules {
            content.remove(list)
        }
        if Core.setting("block_ads") == "1" {
            if let list = adRules { content.add(list) } else {
                store?.compileContentRuleList(forIdentifier: "fable-ads-\(Core.version)", encodedContentRuleList: Core.adsContentRules) { [weak self] list, error in
                    guard let self = self, let list = list else { if let error = error { NSLog("Fable: ad list: %@", "\(error)") }; return }
                    self.adRules = list
                    if Core.setting("block_ads") == "1" { self.content.add(list) }
                }
            }
        } else if let list = adRules {
            content.remove(list)
        }
        if Core.setting("data_saver") == "1" {
            if let list = imageRules { content.add(list) } else {
                store?.compileContentRuleList(forIdentifier: "fable-no-images", encodedContentRuleList: Rules.noImages) { [weak self] list, _ in
                    guard let self = self, let list = list else { return }
                    self.imageRules = list
                    if Core.setting("data_saver") == "1" { self.content.add(list) }
                }
            }
        } else if let list = imageRules {
            content.remove(list)
        }
    }

    /// The list was replaced: drop the compiled ad rules and build them again.
    private func refreshAdRules() {
        if let list = adRules { content.remove(list); adRules = nil }
        applyRuleLists()
    }

    // MARK: - settings

    /// A setting the panel just changed: make it so here.
    private func settingChanged(_ key: String) {
        switch key {
        case "language":
            applyLanguage(reload: true)
        case "block_trackers", "block_ads", "data_saver":
            applyRuleLists()
            reloadActiveWebPage()
        case "ua_mode", "ua_custom":
            let ua = Prefs.userAgent(mode: Core.setting("ua_mode"), custom: Core.setting("ua_custom"))
            for t in tabs { t.web?.customUserAgent = ua }
            reloadActiveWebPage()
        case "javascript":
            reloadActiveWebPage()
        case "text_size":
            let zoom = CGFloat(Prefs.pageZoom(Core.setting("text_size")))
            for t in tabs { t.web?.pageZoom = zoom }
        case "home_button":
            refreshChrome()
        case "address_top":
            applyAddressBarPosition()
        case "orientation":
            applyOrientation()
        case "keep_screen_on":
            UIApplication.shared.isIdleTimerDisabled = Core.setting("keep_screen_on") == "1"
        case "hide_status_bar":
            UIView.animate(withDuration: 0.2) { self.setNeedsStatusBarAppearanceUpdate() }
        case "sleep_minutes":
            policy.setSleepAfter(minutes: Prefs.sleepMinutes(Core.setting("sleep_minutes")))
        case "shortcuts", "search_engine":
            for t in tabs where t.isHome { t.web?.reload() }
        default:
            break
        }
    }

    // MARK: - the panel

    private func ensurePanel() -> WKWebView {
        if let p = panel { return p }
        let controller = WKUserContentController()
        controller.addUserScript(WKUserScript(source: Panel.sheetScript, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        controller.add(WeakScriptHandler(self), name: "fableui")
        WKContentRuleListStore.default()?.compileContentRuleList(forIdentifier: "fable-panel-offline", encodedContentRuleList: Rules.offline) { list, _ in
            if let list = list { controller.add(list) }
        }
        let c = WKWebViewConfiguration()
        c.userContentController = controller
        c.websiteDataStore = .nonPersistent()
        let p = WKWebView(frame: view.bounds, configuration: c)
        p.isOpaque = false
        p.backgroundColor = .clear
        p.scrollView.backgroundColor = .clear
        p.scrollView.isScrollEnabled = false      // the sheet scrolls inside the page
        p.scrollView.contentInsetAdjustmentBehavior = .never
        p.navigationDelegate = self
        p.isHidden = true
        p.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(p)
        NSLayoutConstraint.activate([
            p.topAnchor.constraint(equalTo: view.topAnchor),
            p.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            p.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            p.trailingAnchor.constraint(equalTo: view.trailingAnchor),
        ])
        panel = p
        panelReady = false
        p.loadHTMLString(Core.panelPage, baseURL: nil)
        return p
    }

    /// The panel page carries its strings: a new language needs a new load.
    private func reloadPanel() {
        guard let p = panel else { return }
        panelReady = false
        panelQueue.removeAll()
        p.loadHTMLString(Core.panelPage, baseURL: nil)
        if panelOpen { panelRun(Panel.call("Fable.show", "settings", panelState())) }
    }

    func showPanel(_ name: String) {
        address.resignFirstResponder()
        let p = ensurePanel()
        panelOpen = true
        p.isHidden = false
        view.bringSubviewToFront(p)
        panelRun(Panel.call("Fable.show", name, panelState()))
    }

    private func hidePanel() {
        panelOpen = false
        panel?.isHidden = true
    }

    private func panelRun(_ script: String) {
        guard let p = panel else { return }
        if panelReady { p.evaluateJavaScript(script, completionHandler: nil) } else { panelQueue.append(script) }
    }

    private func panelUpdate() {
        panelRun("Fable.update(\(panelState()))")
    }

    private func panelState() -> String {
        let list = tabs.map { t -> PanelTab in
            let icon = t.isHome ? logo : ""
            return PanelTab(id: t.id, title: t.title, url: t.url, icon: icon, active: t === active, isPrivate: t.isPrivate, asleep: t.web == nil)
        }
        return Panel.state(tabs: list, incognito: inPrivate, desktop: Prefs.wantsDesktop(mode: Core.setting("ua_mode")),
                           sniffed: active.map { Core.sniffCount($0.id) } ?? 0, blocked: Core.blockedCount,
                           orientation: canLockOrientation, bookmarked: bookmarkID(active))
    }

    private func panelMessage(_ message: PanelMessage) {
        switch message {
        case let .query(id, name, arg):
            let answer = Core.panelQuery(name, arg, tab: active?.id ?? 0)
                ?? (name == "device" ? Core.deviceInfo(DeviceFacts.deviceExtras(window: view.window)) : "")   // "icon": none kept
            panelRun(Core.panelReply(id, answer))
            if name == "set" { settingChanged(PanelMessage.settingKey(ofSet: arg)) }
        case let .action(name, arg):
            panelAct(name, arg)
        }
    }

    private func panelAct(_ name: String, _ arg: String) {
        let front = active
        switch name {
        case "hidden":
            hidePanel()
        case "newTab":
            openTab(nil, isPrivate: false)
        case "newPrivate":
            openTab(nil, isPrivate: true)
        case "enterPrivate":
            enterPrivate()
        case "exitPrivate":
            exitPrivate()
            if panelOpen { panelUpdate() }
        case "switchTab":
            if let id = UInt32(arg), let t = tabs.first(where: { $0.id == id }) { activate(t) }
        case "closeTab":
            if let id = UInt32(arg) { close(tabs.first { $0.id == id }) }
            if panelOpen { panelUpdate() }
        case "open":
            if let t = front { navigate(t, arg) } else { openTab(arg, isPrivate: false) }
        case "openNew":
            openTab(arg, isPrivate: front?.isPrivate ?? false)
        case "reader":
            front?.web?.evaluateJavaScript(Core.readerScript) { [weak self] result, _ in
                let r = result as? String
                if r == "off" { return }   // back to the page: nothing to say
                self?.toast(Core.tr(r == "none" ? "no_article" : r == "on" ? "reader_on" : "reader_unsupported"))
            }
        case "desktop":
            let on = Prefs.wantsDesktop(mode: Core.setting("ua_mode"))
            Core.set("ua_mode", on ? "default" : "desktop")
            settingChanged("ua_mode")
            toast(Core.tr(on ? "mobile_on" : "desktop_on"))
        case "clear":
            clearData(arg)
        case "sniffScan":
            guard let t = front, let web = t.web else { return }
            let id = t.id
            web.evaluateJavaScript(Core.sniffScript) { [weak self] result, _ in
                guard let list = result as? [Any], JSONSerialization.isValidJSONObject(list),
                      let data = try? JSONSerialization.data(withJSONObject: list), let json = String(data: data, encoding: .utf8) else { return }
                if Core.sniffNoteScan(id, json) > 0 { self?.panelRun("Fable.refresh('sniff')") }
            }
        case "download":
            guard let url = URL(string: arg), let web = front?.web else { return }
            web.startDownload(using: URLRequest(url: url)) { [weak self] download in self?.track(download) }
        case "copy":
            UIPasteboard.general.string = arg
            toast(Core.tr("link_copied"))
        case "copyText":
            UIPasteboard.general.string = arg
            toast(Core.tr("m_copied"))
        case "toast":
            toast(arg)
        case "system":
            let extras = DeviceFacts.systemExtras(window: view.window)
            DispatchQueue.global(qos: .userInitiated).async { [weak self] in   // off the main thread, as on the other platforms
                let info = Core.systemInfo(extras)
                DispatchQueue.main.async { self?.panelRun("Fable.system(\(info))") }
            }
        case "ip":
            lookupIP(attempt: 0)
        case "bookmarkToggle":   // the star in the menu: the page in front
            toggleBookmark()
        case "bookmarkImportPick":
            pickBookmarkFile()
        case "bookmarkExport":
            saveBookmarkFile()
        default:
            break   // "size" is for the desktops' panel windows
        }
    }

    private func clearData(_ what: String) {
        let historyCleared = !what.contains("history") || Core.historyClear()
        var types = Set<String>()
        if what.contains("cookies") {
            types.formUnion([WKWebsiteDataTypeCookies, WKWebsiteDataTypeLocalStorage, WKWebsiteDataTypeSessionStorage,
                             WKWebsiteDataTypeIndexedDBDatabases, WKWebsiteDataTypeWebSQLDatabases, WKWebsiteDataTypeServiceWorkerRegistrations])
        }
        if what.contains("cache") {
            types.formUnion([WKWebsiteDataTypeDiskCache, WKWebsiteDataTypeMemoryCache, WKWebsiteDataTypeOfflineWebApplicationCache])
        }
        if !types.isEmpty {
            WKWebsiteDataStore.default().removeData(ofTypes: types, modifiedSince: Date(timeIntervalSince1970: 0)) {}
        }
        toast(Core.tr(historyCleared ? "data_cleared" : "history_clear_failed"))
    }

    /// Fetch the ad list the user set (at most 1 MiB + 1) and hand it to the core.
    /// The shell fetches because the core builds offline and has no HTTP client.
    /// Fetch the built-in community ad lists (at most 8 MiB each) and hand
    /// them to the core, concatenated. A source that fails is skipped.
    private func fetchAdList() {
        if adsUpdating { return }
        adsUpdating = true
        fetchAdListSource(0, into: Data())
    }

    private func fetchAdListSource(_ index: Int, into all: Data) {
        let sources = Core.adsUpdateSources.split(separator: "\n", omittingEmptySubsequences: false)
        guard index < sources.count else {
            adsUpdating = false
            if !all.isEmpty && Core.adsUpdateApply(all) >= 0 { refreshAdRules() }
            return
        }
        guard let target = URL(string: String(sources[index])) else {
            fetchAdListSource(index + 1, into: all)
            return
        }
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 10
        let session = URLSession(configuration: config)
        session.dataTask(with: URLRequest(url: target)) { [weak self] data, response, _ in
            let http = response as? HTTPURLResponse
            var all = all
            if let data = data, http?.statusCode == 200, data.count <= 8 * 1024 * 1024 + 1 {
                all.append(data)
                all.append(contentsOf: "\n".utf8)
            }
            DispatchQueue.main.async {
                guard let self = self else { return }
                self.fetchAdListSource(index + 1, into: all)
            }
        }.resume()
        session.finishTasksAndInvalidate()
    }

    /// Public IP for the metadata sheet: Cloudflare's trace, then ipify. No cookies, no cache.
    private func lookupIP(attempt: Int) {
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 10
        let session = URLSession(configuration: config)
        let source = attempt == 0 ? "cloudflare.com" : "ipify.org"
        var request = URLRequest(url: URL(string: attempt == 0 ? "https://www.cloudflare.com/cdn-cgi/trace" : "https://api.ipify.org?format=json")!)
        if let ua = Prefs.userAgent(mode: Core.setting("ua_mode"), custom: Core.setting("ua_custom")) { request.setValue(ua, forHTTPHeaderField: "User-Agent") }
        session.dataTask(with: request) { [weak self] data, _, _ in
            let body = data.flatMap { String(data: $0, encoding: .utf8) } ?? ""
            let info = Core.parseIPReply(body, source: source)
            DispatchQueue.main.async {
                if info.isEmpty && attempt == 0 { self?.lookupIP(attempt: 1); return }
                self?.panelRun("Fable.ip(\(info.isEmpty ? "{}" : info))")
            }
        }.resume()
        session.finishTasksAndInvalidate()
    }

    // MARK: - downloads

    func track(_ download: WKDownload) {
        download.delegate = self
        downloads[download] = .some(nil)
    }
}

// MARK: - address field

extension BrowserViewController: UIDocumentPickerDelegate {
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        if exportingBookmarks {
            toast(Core.tr("exported_bookmark"))
            return
        }
        // A copy in the app's own sandbox (asCopy); at most 4 MiB, as on the other platforms.
        guard let url = urls.first,
              let size = (try? url.resourceValues(forKeys: [.fileSizeKey]))?.fileSize, size <= 4 * 1024 * 1024,
              let data = try? Data(contentsOf: url),
              let html = String(data: data, encoding: .utf8) ?? String(data: data, encoding: .isoLatin1) else {
            toast(Core.tr("bookmark_import_failed"))
            return
        }
        toast(Core.tr("bookmark_imported", String(Core.bookmarkImport(html))))
    }
}

extension BrowserViewController: UITextFieldDelegate {
    func textFieldDidBeginEditing(_ textField: UITextField) {
        navRow.isHidden = true   // as on Android: the keyboard needs the room
        DispatchQueue.main.async { textField.selectAll(nil) }
    }

    func textFieldDidEndEditing(_ textField: UITextField) {
        navRow.isHidden = false
        refreshChrome()
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        let text = textField.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        textField.resignFirstResponder()
        if !text.isEmpty, let t = active { navigate(t, text) }
        return false
    }
}

// MARK: - fable://newtab/

extension BrowserViewController: WKURLSchemeHandler {
    func webView(_ webView: WKWebView, start task: WKURLSchemeTask) {
        guard let url = task.request.url, url.host == "newtab" else {
            task.didFailWithError(NSError(domain: NSURLErrorDomain, code: NSURLErrorFileDoesNotExist))
            return
        }
        let data = Data(Core.newtabPage(private: !webView.configuration.websiteDataStore.isPersistent).utf8)
        let response = HTTPURLResponse(url: url, statusCode: 200, httpVersion: "HTTP/1.1",
                                       headerFields: ["Content-Type": "text/html; charset=utf-8", "Content-Length": String(data.count)])!
        task.didReceive(response)
        task.didReceive(data)
        task.didFinish()
    }

    func webView(_ webView: WKWebView, stop task: WKURLSchemeTask) {}
}

// MARK: - script messages

extension BrowserViewController: WKScriptMessageHandler {
    /// "fableui" comes from the panel only (its own content controller).
    /// "fable": the new-tab page's search box, which can only navigate its own tab.
    func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
        if message.name == "fableui" {
            guard let p = panel, message.webView === p, let body = message.body as? String, let m = PanelMessage.parse(body) else { return }
            panelMessage(m)
            return
        }
        guard message.name == "fable", message.frameInfo.isMainFrame, message.frameInfo.request.url?.scheme == Browser.scheme,
              let text = message.body as? String, let tab = tabs.first(where: { $0.web != nil && $0.web === message.webView }) else { return }
        navigate(tab, text)
    }
}

// MARK: - the panel's own navigation: the bundled page and nothing else

extension BrowserViewController: WKNavigationDelegate {
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        let scheme = navigationAction.request.url?.scheme ?? "about"
        decisionHandler(scheme == "about" ? .allow : .cancel)
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        guard webView === panel else { return }
        panelReady = true
        let queued = panelQueue
        panelQueue.removeAll()
        for script in queued { webView.evaluateJavaScript(script, completionHandler: nil) }
    }

    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        guard webView === panel else { return }
        panelReady = false
        webView.loadHTMLString(Core.panelPage, baseURL: nil)
        if panelOpen { hidePanel() }
    }
}

// MARK: - downloads into the app's Documents folder (Files ▸ On My iPhone ▸ Fable)

extension BrowserViewController: WKDownloadDelegate {
    func download(_ download: WKDownload, decideDestinationUsing response: URLResponse, suggestedFilename: String,
                  completionHandler: @escaping (URL?) -> Void) {
        guard let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else { completionHandler(nil); return }
        let target = Downloads.uniqueFile(in: dir, suggested: suggestedFilename)
        if download.webView?.configuration.websiteDataStore.isPersistent == true {
            downloadRecords[download] = fable_download_begin(target.lastPathComponent)
        }
        downloads[download] = .some(target)
        toast(Core.tr("dl_start", target.lastPathComponent))
        completionHandler(target)
    }

    func downloadDidFinish(_ download: WKDownload) {
        if let id = downloadRecords.removeValue(forKey: download) { fable_download_finish(id, 1) }
        let name = downloads.removeValue(forKey: download)??.lastPathComponent ?? ""
        toast(Core.tr("ios_downloaded", name))
    }

    func download(_ download: WKDownload, didFailWithError error: Error, resumeData: Data?) {
        if let id = downloadRecords.removeValue(forKey: download) { fable_download_finish(id, 0) }
        downloads.removeValue(forKey: download)
        toast(Core.tr("dl_fail"))
    }
}
