/* Writes the new-tab page as the core serves it in every skin, for
 * tests/skin_ground_test.py: <dir>/<skin>.html, and prints "<skin> <ground>"
 * per line (the palette's ground, the colour the shells paint behind the page).
 * usage: skin_pages <dir> */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fable_core.h"

static const char *SKINS[] = {"claude", "chatgpt", "deepseek", "gemini", "grok", "kimi"};

int main(int argc, char **argv) {
    if (argc != 2) { fprintf(stderr, "usage: skin_pages <dir>\n"); return 2; }
    for (size_t i = 0; i < sizeof SKINS / sizeof *SKINS; i++) {
        char url[64], path[4096];
        snprintf(url, sizeof url, "theme://%s", SKINS[i]);
        if (fable_theme_apply(url) != 1) { fprintf(stderr, "skin_pages: %s is no skin\n", SKINS[i]); return 1; }
        char *page = fable_newtab_page(0, ""), *ground = fable_theme_colour("ground");
        snprintf(path, sizeof path, "%s/%s.html", argv[1], SKINS[i]);
        FILE *f = fopen(path, "wb");
        if (!f || !page || fputs(page, f) < 0 || fclose(f) != 0) { fprintf(stderr, "skin_pages: cannot write %s\n", path); return 1; }
        printf("%s %s\n", SKINS[i], ground);
        fable_string_free(page); fable_string_free(ground);
    }
    fable_theme_apply("theme://claude");
    return 0;
}
