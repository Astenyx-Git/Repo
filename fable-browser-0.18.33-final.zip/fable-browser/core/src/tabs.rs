//! Tab bookkeeping and the sleep policy.
//!
//! The shells own the web views; this decides *which* tabs have been idle long
//! enough to be put to sleep (web view discarded or suspended, URL kept).
//! Time is supplied by the caller as monotonic milliseconds, which keeps the
//! policy deterministic and testable.

pub const DEFAULT_SLEEP_AFTER_MS: u64 = 10 * 60 * 1000;

struct Tab {
    id: u32,
    last_active_ms: u64,
    asleep: bool,
}

pub struct Tabs {
    tabs: Vec<Tab>,
    active: Option<u32>,
    next_id: u32,
    sleep_after_ms: u64,
}

impl Default for Tabs {
    fn default() -> Self {
        Self::new()
    }
}

impl Tabs {
    pub fn new() -> Self {
        Tabs { tabs: Vec::new(), active: None, next_id: 1, sleep_after_ms: DEFAULT_SLEEP_AFTER_MS }
    }

    /// 0 disables sleeping.
    pub fn set_sleep_after_ms(&mut self, ms: u64) {
        self.sleep_after_ms = ms;
    }

    /// Open a tab and make it the active one. Ids start at 1 and are never reused.
    pub fn open(&mut self, now_ms: u64) -> u32 {
        let id = self.next_id;
        self.next_id += 1;
        self.tabs.push(Tab { id, last_active_ms: now_ms, asleep: false });
        self.activate(id, now_ms);
        id
    }

    /// Switch to a tab. The tab being left starts its idle clock now; the tab
    /// being entered is awake again.
    pub fn activate(&mut self, id: u32, now_ms: u64) -> bool {
        if !self.tabs.iter().any(|t| t.id == id) {
            return false;
        }
        if let Some(prev) = self.active {
            self.touch(prev, now_ms);
        }
        self.active = Some(id);
        self.touch(id, now_ms)
    }

    /// Mark a tab as used now and awake, without switching to it
    /// (e.g. a background tab that is playing audio).
    pub fn touch(&mut self, id: u32, now_ms: u64) -> bool {
        match self.tabs.iter_mut().find(|t| t.id == id) {
            Some(t) => {
                t.last_active_ms = now_ms;
                t.asleep = false;
                true
            }
            None => false,
        }
    }

    pub fn close(&mut self, id: u32) -> bool {
        let before = self.tabs.len();
        self.tabs.retain(|t| t.id != id);
        if self.active == Some(id) {
            self.active = None;
        }
        self.tabs.len() != before
    }

    pub fn len(&self) -> usize {
        self.tabs.len()
    }

    pub fn is_empty(&self) -> bool {
        self.tabs.is_empty()
    }

    pub fn is_asleep(&self, id: u32) -> bool {
        self.tabs.iter().any(|t| t.id == id && t.asleep)
    }

    /// Write the ids of background tabs idle for at least the threshold into
    /// `out` and mark exactly those as asleep. Returns how many were written;
    /// tabs that did not fit are reported on a later call.
    pub fn collect_sleepers(&mut self, now_ms: u64, out: &mut [u32]) -> usize {
        if self.sleep_after_ms == 0 {
            return 0;
        }
        let mut n = 0;
        for t in self.tabs.iter_mut() {
            if n == out.len() {
                break;
            }
            let idle = now_ms.saturating_sub(t.last_active_ms);
            if Some(t.id) != self.active && !t.asleep && idle >= self.sleep_after_ms {
                t.asleep = true;
                out[n] = t.id;
                n += 1;
            }
        }
        n
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    const MIN: u64 = 60_000;

    #[test]
    fn idle_background_tabs_sleep_and_wake() {
        let mut tabs = Tabs::new();
        let a = tabs.open(0);
        let b = tabs.open(MIN); // a goes to the background at 1 min
        let mut out = [0u32; 8];

        assert_eq!(tabs.collect_sleepers(10 * MIN, &mut out), 0); // a idle 9 min
        assert_eq!(tabs.collect_sleepers(11 * MIN, &mut out), 1); // a idle 10 min
        assert_eq!(out[0], a);
        assert!(tabs.is_asleep(a));
        assert_eq!(tabs.collect_sleepers(60 * MIN, &mut out), 0); // not reported twice; active b never sleeps

        assert!(tabs.activate(a, 61 * MIN));
        assert!(!tabs.is_asleep(a));
        assert_eq!(tabs.collect_sleepers(70 * MIN, &mut out), 0); // b idle 9 min
        assert_eq!(tabs.collect_sleepers(71 * MIN, &mut out), 1);
        assert_eq!(out[0], b);
    }

    #[test]
    fn respects_output_capacity_touch_close_and_disable() {
        let mut tabs = Tabs::new();
        let ids: Vec<u32> = (0..5).map(|_| tabs.open(0)).collect();
        assert_eq!(ids, vec![1, 2, 3, 4, 5]);

        let mut two = [0u32; 2];
        assert_eq!(tabs.collect_sleepers(20 * MIN, &mut two), 2);
        assert_eq!(two, [1, 2]);
        assert!(tabs.touch(3, 20 * MIN)); // e.g. playing audio
        assert!(tabs.close(4));
        assert!(!tabs.close(4));
        assert!(!tabs.activate(99, 0));

        let mut out = [0u32; 8];
        assert_eq!(tabs.collect_sleepers(21 * MIN, &mut out), 0); // 3 was touched, 4 closed, 5 active
        assert_eq!(tabs.len(), 4);

        tabs.set_sleep_after_ms(0);
        assert_eq!(tabs.collect_sleepers(999 * MIN, &mut out), 0);
        tabs.set_sleep_after_ms(MIN);
        assert_eq!(tabs.collect_sleepers(999 * MIN, &mut out), 1);
        assert_eq!(out[0], 3);
    }

    #[test]
    fn clock_going_backwards_is_harmless() {
        let mut tabs = Tabs::new();
        tabs.open(50 * MIN);
        tabs.open(50 * MIN);
        let mut out = [0u32; 4];
        assert_eq!(tabs.collect_sleepers(0, &mut out), 0);
    }
}
