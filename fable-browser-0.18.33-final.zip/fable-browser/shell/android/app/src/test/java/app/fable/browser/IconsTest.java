package app.fable.browser;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.GraphicsMode;

import java.io.ByteArrayOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The icon store with real bitmaps (Android's own codecs, running on the JVM)
 * and a local web server standing in for a site.
 */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class IconsTest {
    private Icons icons;
    private ServerSocket server;
    private final Map<String, Object[]> routes = new ConcurrentHashMap<>();   // path -> {status, type, body}
    private final List<String> hits = Collections.synchronizedList(new ArrayList<String>());

    private static Bitmap square(int edge, int color) {
        Bitmap b = Bitmap.createBitmap(edge, edge, Bitmap.Config.ARGB_8888);
        b.eraseColor(color);
        return b;
    }

    private static byte[] png(Bitmap b) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        b.compress(Bitmap.CompressFormat.PNG, 100, out);
        return out.toByteArray();
    }

    /** A one-image .ico file wrapping a PNG, as most sites serve today. */
    private static byte[] ico(Bitmap b) {
        byte[] image = png(b);
        ByteBuffer out = ByteBuffer.allocate(22 + image.length).order(ByteOrder.LITTLE_ENDIAN);
        out.putShort((short) 0).putShort((short) 1).putShort((short) 1);                    // ICONDIR
        out.put((byte) b.getWidth()).put((byte) b.getHeight()).put((byte) 0).put((byte) 0); // ICONDIRENTRY
        out.putShort((short) 1).putShort((short) 32).putInt(image.length).putInt(22);
        out.put(image);
        return out.array();
    }

    private void serve(String path, int status, String type, byte[] body) {
        routes.put(path, new Object[] {status, type, body});
    }

    /** Just enough HTTP for one GET per connection. */
    private void answer(Socket socket) {
        try (Socket s = socket) {
            BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), "ISO-8859-1"));
            String[] request = in.readLine().split(" ");
            for (String line; (line = in.readLine()) != null && !line.isEmpty(); ) { }
            hits.add(request[1]);
            Object[] route = routes.get(request[1]);
            int status = route == null ? 404 : (Integer) route[0];
            byte[] body = route == null ? new byte[0] : (byte[]) route[2];
            OutputStream out = s.getOutputStream();
            out.write(("HTTP/1.1 " + status + " X\r\nContent-Type: " + (route == null ? "text/plain" : route[1])
                    + "\r\nContent-Length: " + body.length + "\r\nConnection: close\r\n\r\n").getBytes("ISO-8859-1"));
            out.write(body);
            out.flush();
        } catch (Exception ignored) { }
    }

    private String origin(String host) {
        return "http://" + host + ":" + server.getLocalPort();
    }

    private static int width(byte[] png) {
        return BitmapFactory.decodeByteArray(png, 0, png.length).getWidth();
    }

    @Before public void start() throws Exception {
        icons = new Icons(new File(RuntimeEnvironment.getApplication().getFilesDir(), "icons"), "FableTest/1.0");
        server = new ServerSocket(0, 16, InetAddress.getByName("127.0.0.1"));
        Thread loop = new Thread(() -> {
            while (!server.isClosed()) {
                try { answer(server.accept()); } catch (Exception closed) { return; }
            }
        });
        loop.setDaemon(true);
        loop.start();
    }

    @After public void stop() throws Exception {
        server.close();
        icons.shutdown();
    }

    @Test public void keepsTheLargestIconPerHost() {
        assertNull(icons.get("example.com"));
        assertEquals("", icons.dataUri("example.com"));

        icons.offer("example.com", square(16, Color.RED));
        assertEquals(16, width(icons.get("example.com")));
        icons.offer("example.com", square(64, Color.BLUE));
        assertEquals(64, width(icons.get("example.com")));
        icons.offer("example.com", square(32, Color.GREEN));
        assertEquals("a smaller icon does not replace a larger one", 64, width(icons.get("example.com")));
        icons.offer("example.com", square(600, Color.BLACK));
        assertEquals("oversized icons are scaled down", 192, width(icons.get("example.com")));

        assertTrue(icons.dataUri("example.com").startsWith("data:image/png;base64,iVBOR"));
        assertNull("hosts are separate", icons.get("other.example.com"));
        icons.offer("example.com", square(4, Color.RED));   // junk sizes and empty hosts are ignored
        icons.offer("", square(32, Color.RED));
        icons.offer("../../etc/passwd", square(32, Color.RED));
        assertEquals("a hostile host name cannot leave the icon directory", 2,
                new File(RuntimeEnvironment.getApplication().getFilesDir(), "icons").listFiles().length);

        icons.clear();
        assertNull(icons.get("example.com"));
        assertEquals("", icons.dataUri("example.com"));
    }

    @Test public void readsHostsFromWebAddressesOnly() {
        assertEquals("zh.wikipedia.org", Icons.hostOf("https://ZH.Wikipedia.org/wiki/土星"));
        assertEquals("localhost", Icons.hostOf("http://localhost:8080/x"));
        assertEquals("", Icons.hostOf("about:blank"));
        assertEquals("", Icons.hostOf("file:///sdcard/a.html"));
        assertEquals("", Icons.hostOf("javascript:alert(1)"));
        assertEquals("", Icons.hostOf(null));
    }

    @Test public void fetchesTheHomeScreenIconFirst() {
        serve("/apple-touch-icon.png", 200, "image/png", png(square(180, Color.RED)));
        serve("/favicon.ico", 200, "image/x-icon", ico(square(32, Color.BLUE)));
        byte[] icon = icons.fetch(origin("127.0.0.1"));
        assertNotNull(icon);
        assertEquals(180, width(icon));
        assertEquals("the favicon was not needed", Collections.singletonList("/apple-touch-icon.png"), hits);

        assertArrayEquals("second time comes from disk", icon, icons.fetch(origin("127.0.0.1")));
        assertEquals(1, hits.size());
    }

    @Test public void findsIconsThePageDeclares() throws Exception {
        // Nothing at the usual addresses; the home page names its icons, relative and with odd quoting.
        serve("/", 200, "text/html; charset=utf-8", ("<!doctype html><html><head><title>x</title>"
                + "<link rel=stylesheet href=/a.css><LINK REL='shortcut icon' HREF='static/small.png?v=1&amp;x=2'>"
                + "<link href=\"/static/big.png\" sizes=\"180x180\" rel=\"apple-touch-icon\"></head><body></body></html>").getBytes("UTF-8"));
        serve("/static/small.png?v=1&x=2", 200, "image/png", png(square(16, Color.BLUE)));
        serve("/static/big.png", 200, "image/png", png(square(120, Color.RED)));
        byte[] icon = icons.fetch(origin("127.0.0.1"));
        assertNotNull(icon);
        assertEquals("the home-screen icon is preferred over the small favicon", 120, width(icon));
        assertEquals(java.util.Arrays.asList("/apple-touch-icon.png", "/favicon.ico", "/", "/static/big.png"), hits);
    }

    @Test public void aTinyFaviconIsUpgradedFromThePage() throws Exception {
        serve("/favicon.ico", 200, "image/x-icon", ico(square(16, Color.BLUE)));
        serve("/", 200, "text/html", "<link rel=\"icon\" sizes=\"192x192\" href=\"/icons/192.png\">".getBytes("UTF-8"));
        serve("/icons/192.png", 200, "image/png", png(square(192, Color.RED)));
        assertEquals(192, width(icons.fetch(origin("127.0.0.1"))));
    }

    @Test public void backgroundRequestsFillTheStore() throws Exception {
        serve("/favicon.ico", 200, "image/x-icon", ico(square(32, Color.BLUE)));
        assertNull(icons.get("127.0.0.1"));
        icons.request(origin("127.0.0.1"));
        icons.request(origin("127.0.0.1"));   // a second ask while the first is running is dropped
        for (int i = 0; i < 100 && hits.size() < 3; i++) Thread.sleep(50);
        assertNotNull(icons.get("127.0.0.1"));
        assertEquals("one pass: both usual addresses, then the home page because the favicon was small",
                java.util.Arrays.asList("/apple-touch-icon.png", "/favicon.ico", "/"), hits);
    }

    @Test public void fallsBackToTheFaviconAndRemembersFailures() {
        serve("/apple-touch-icon.png", 200, "text/html", "<html>not found, but with status 200</html>".getBytes());
        serve("/favicon.ico", 200, "image/x-icon", ico(square(32, Color.BLUE)));
        byte[] icon = icons.fetch(origin("127.0.0.1"));
        assertNotNull("an .ico file is decoded", icon);
        assertEquals(32, width(icon));

        icons.clear();
        routes.remove("/favicon.ico");
        hits.clear();
        assertNull(icons.fetch(origin("127.0.0.1")));
        assertNull(icons.fetch(origin("127.0.0.1")));
        assertEquals("a site without icons is asked once per run (two usual addresses and its home page), not on every new tab",
                java.util.Arrays.asList("/apple-touch-icon.png", "/favicon.ico", "/"), hits);

        assertNull("only web origins are fetched", icons.fetch("file:///etc/passwd"));
        assertNull(icons.fetch(null));
        assertNull(icons.fetch("not a url"));
    }
}
