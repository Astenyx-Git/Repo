# Fable Browser 第三者声明（日本語完全版）
Fable Browser 第三者コンポーネントおよび素材に関する声明

バージョン：V1.2
発効日：2026年11月25日

許諾者：Fable browser team（連絡先メールアドレス：[fable-browser-team@astermail.org](mailto:fable-browser-team@astermail.org)）


1. 説明
2. 本声明は、Fable Browserが使用または依存する第三者の素材、コンポーネント、およびリストの出所、ライセンス、および権利の帰属を明記するものです。本声明は「エンドユーザーライセンス契約」の不可分の一部を構成します。

3. アイコン素材
4. 以下のインターフェースアイコンは、Google Material Symbolsプロジェクトのものであり、Apache License 2.0に基づいて使用されています。
- ホームボタンアイコン「home」（outlined）：Android、HarmonyOSなどのプラットフォームのインターフェースで使用。
- スキャンボタンアイコン「qr_code_scanner」（outlined）：各プラットフォームのスキャン機能の入り口で使用。
- 出所：[https://github.com/google/material-design-icons](https://github.com/google/material-design-icons) （Apache License 2.0、ライセンス全文は [https://www.apache.org/licenses/LICENSE-2.0](https://www.apache.org/licenses/LICENSE-2.0) を参照）

3. ブロックリスト
4. 3.1 内蔵デフォルトリスト（アプリにオフラインで同梱）：本ソフトウェアには、プロジェクトが独自に維持管理する広告ドメインリスト（ads.txt）およびトラッキングドメインリスト（trackers.txt）が同梱されており、インストールパッケージと共にオフラインで配布されます。これら2つのリストは、本プロジェクトの独自コンテンツです。
5. 3.2 リストの更新元（EasyListおよびEasyPrivacy）：広告ブロックスイッチがオンの場合、アプリ起動時に週に1回の頻度でチェックを行い、easylist.toからEasyListおよびEasyPrivacyの2つのコミュニティリストを自動的に取得します（スイッチがオフの場合、このトラフィックは発生しません）。EasyListの公式ライセンスページ（[https://easylist.to/pages/licence.html）に基づきます。](https://easylist.to/pages/licence.html%EF%BC%89%E3%81%AB%E5%9F%BA%E3%81%A5%E3%81%8D%E3%81%BE%E3%81%99%E3%80%82)
6. 本ソフトウェアは、ブロックのために上記リストをローカルで取得および解析するものであり、リストファイルを外部に再配布することはありません。今後のバージョンでリストファイルをインストールパッケージに直接同梱して再配布する場合は、その時点で選択したライセンスに従って、対応する義務（クレジット表記、同一ライセンスでの提供など）を履行するものとします。

7. システムWebエンジン（各プラットフォームに標準搭載、本ソフトウェアの構成要素ではありません）
8. 本ソフトウェアはWebレンダリングエンジンを内蔵しておらず、Webコンテンツはお使いのプラットフォームシステムが提供するWebエンジンによって読み込まれます。各エンジンはそれぞれの権利者に帰属します。
- Android：システムWebView（Chromiumコア、Google / Chromiumプロジェクト）
- HarmonyOS：ArkWeb（Huawei）
- iOS / iPadOS / macOS：WKWebView（Apple WebKit）
- Windows：WebView2（Microsoft Edge）
- Linux：WebKitGTK（GNOMEプロジェクト）
- Sailfish OS：Sailfish WebView（Gecko / embedlite）
- 上記エンジンの名称および商標はそれぞれの権利者に帰属します。本ソフトウェアと各プラットフォームベンダーとの間には、システムエンジンの使用に起因する提携関係や推奨関係は一切存在しません。

5. インターフェーススキンにおける第三者の名称およびロゴ
6. 本ソフトウェアに内蔵されているスキンは、一部の第三者ブランドの名称、ロゴ、または様式化された図案を切り替えて表示することができます。これらの名称、ロゴ、および図案の権利はそれぞれの権利者に帰属します。本ソフトウェアはそれらの権利を主張するものではなく、それらの表示は提携、承認、または推奨を構成するものではありません。関連する権利者から異議がある場合は、「エンドユーザーライセンス契約」第13.3条に記載されている連絡先までフィードバックをお寄せください。

7. その他のリンクおよび構成要素
- 新しいタブページのWikipediaショートカットは、wikipedia.orgの対応する言語バージョンへの外部リンクであり、そのコンテンツの埋め込みや転載を構成するものではありません。
- 本ソフトウェアのバイナリファイルにコンパイルツールチェーンと共に導入される第三者のコードコンポーネント（Rust標準ライブラリ、MIT / Apache-2.0デュアルライセンス、quircs QRデコードライブラリ、ISCライセンスなど）の完全な声明リストは、最終的なビルド成果物において自動生成され、本文書の末尾に添付されます。
