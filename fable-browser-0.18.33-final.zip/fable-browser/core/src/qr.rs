//! Decode one QR symbol from a camera luminance plane.

use std::borrow::Cow;

// The decoder uses two bytes of scratch space per pixel for region labels.
const MAX_PIXELS: usize = 4 * 1024 * 1024;
const MAX_EDGE: usize = 4096;

/// Return the first successfully decoded payload. The bytes can contain NUL or
/// non-UTF-8 data. Invalid layouts and frames with no decodable QR return None.
///
/// `data[0]` is the first pixel of the image (or crop). Both strides are in
/// bytes. Padding after the last pixel is optional, as on Android Image.Plane.
pub fn decode_luma_plane(
    data: &[u8],
    width: usize,
    height: usize,
    row_stride: usize,
    pixel_stride: usize,
) -> Option<Vec<u8>> {
    if !(1..=MAX_EDGE).contains(&width) || !(1..=MAX_EDGE).contains(&height)
        || width * height > MAX_PIXELS || pixel_stride == 0
    {
        return None;
    }
    let row_bytes = (width - 1).checked_mul(pixel_stride)?.checked_add(1)?;
    if row_stride < row_bytes {
        return None;
    }
    let required = (height - 1).checked_mul(row_stride)?.checked_add(row_bytes)?;
    let plane = data.get(..required)?;
    let pixels = if pixel_stride == 1 && row_stride == width {
        Cow::Borrowed(plane)
    } else {
        let mut packed = Vec::with_capacity(width * height);
        for row in plane.chunks(row_stride) {
            let samples = &row[..row_bytes];
            if pixel_stride == 1 {
                packed.extend_from_slice(samples);
            } else {
                packed.extend(samples.iter().step_by(pixel_stride).copied());
            }
        }
        Cow::Owned(packed)
    };

    let mut decoder = quircs::Quirc::new();
    let mut symbols = decoder.identify(width, height, &pixels);
    symbols.find_map(|candidate| candidate.ok()?.decode().ok().map(|data| data.payload))
}
