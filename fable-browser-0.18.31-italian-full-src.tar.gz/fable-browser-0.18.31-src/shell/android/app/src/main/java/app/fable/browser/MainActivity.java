package app.fable.browser;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityOptions;
import android.app.AlertDialog;
import android.app.WallpaperColors;
import android.app.WallpaperManager;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.BroadcastReceiver;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.text.InputType;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.webkit.ProfileStore;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Fable for Android.
 *
 * The page is a system WebView. Everything around it is drawn by Fable itself
 * so it looks like one app: the bottom bar is built here from plain views with
 * our own shapes and vector icons, and the sheets (menu, tabs, settings,
 * history) are one HTML page from the core, shown in a separate "panel"
 * WebView. Only that panel gets the privileged bridge; web pages never do.
 *
 * Logic (address resolution, tracker blocking, tab sleep policy, settings and
 * history storage) lives in the Rust core, reached through {@link Core}.
 */
public final class MainActivity extends Activity {
    static final int PICK_BOOKMARKS = 41, SAVE_BOOKMARKS = 42;   // the system file pickers for bookmark import / export
    private static final int SCAN_QR = 43;                        // the camera permission behind the "scan" tile
    private static final int BOOKMARK_FILE_MAX = 4 * 1024 * 1024;
    /** Fable's cream: the system wallpaper Fable can set (the skins leave that alone). */
    private static final int CREAM = 0xFFFDF7F0;
    /** Private mode's colours, the same in every skin. */
    private static final int DARK_BAR = 0xFF211611, DARK_PILL = 0xFF33241D, DARK_LINE = 0xFF4A372D, DARK_INK = 0xFFFBEFE4, DARK_MUTED = 0xFFC9B5A6;
    /** The skin's colours (theme://name; core/src/theme.rs), read by loadPalette(). Until then, the default skin's. */
    int ground = CREAM, barColour = 0xFFFBF2E8, ink = 0xFF2A1A14, iconColour = 0xFF5E4A3F, hint = 0xFF8A766A,
            line = 0xFFEBDDD0, spark = 0xFFD9512C, pillColour = 0xFFFFFFFF, onSpark = 0xFFFFFFFF;
    boolean darkSkin;   // light status-bar and navigation-bar icons, as in private mode
    private static final long SLEEP_CHECK_MS = 30_000;
    /** Hosts of the built-in shortcuts (ui/newtab.html), for sending their icons along with the page. */
    private static final String[] DEFAULT_SHORTCUT_HOSTS = {"claude.ai", "chatgpt.com", "chat.deepseek.com", "gemini.google.com",
            "zh.wikipedia.org", "ja.wikipedia.org", "en.wikipedia.org", "ko.wikipedia.org", "ru.wikipedia.org", "fr.wikipedia.org", "es.wikipedia.org", "ar.wikipedia.org", "github.com", "www.bilibili.com", "www.youtube.com"};
    /** The new-tab page is served from this address by {@code shouldInterceptRequest}; .invalid never resolves. */
    static final String HOME = "https://newtab.fable.invalid/";
    /** Open once the ad list loaded at start-up is in place (see {@link #awaitAds}). */
    private final java.util.concurrent.CountDownLatch adsLoaded = new java.util.concurrent.CountDownLatch(1);
    static final String ICON_ENDPOINT = HOME + "icon?";
    /** The home screen's own requests (when Fable is the default home app): app icons, starting apps, saving its layout. */
    static final String APP_ICON_ENDPOINT = HOME + "app-icon?";
    static final String HOME_LAUNCH = HOME + "home/launch?";
    static final String HOME_SET = HOME + "home/set?";
    static final String HOME_INFO = HOME + "home/info?";
    private static final String PRIVATE_PROFILE = "fable-private";
    private static final String ANDROID_UA = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 "
            + "(KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36";
    private static final String IPHONE_UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 "
            + "(KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1";
    private static final String IPAD_UA = "Mozilla/5.0 (iPad; CPU OS 17_5 like Mac OS X) AppleWebKit/605.1.15 "
            + "(KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1";
    private static final String CHROME_WIN_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            + "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";
    private static final String CHROME_MAC_UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
            + "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";
    private static final String SAFARI_MAC_UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 "
            + "(KHTML, like Gecko) Version/18.1 Safari/605.1.15";
    private static final String FIREFOX_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0";
    private static final String EDGE_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            + "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0";

    static final class Tab {   // package-visible members below are read by the JVM tests
        int id;                          // id in the core's tab table
        boolean incognito;
        WebView web;                     // null while the tab is asleep
        String url = "";                 // shown in the address field; "" for the new-tab page
        String title = "";
        boolean loading;
        int progress;
        Bitmap icon;                     // favicon of the page in the tab, as reported by WebView
        String iconUri = "";             // the same as a data: URI, for the tab list
        volatile String pageUrl = "";    // read by the blocker on WebView's network thread
        String document;                 // a content:// document another app shared: the one content URI this tab may load
    }

    final ArrayList<Tab> tabs = new ArrayList<>();
    private final Handler ui = new Handler(Looper.getMainLooper());
    Tab active;                          // its kind is the mode: normal, or private with a tab set of its own
    Tab addressHeld;                     // the bar is keeping what was typed for this tab, until its load reports the URL
    private Tab lastNormal, lastPrivate; // where each mode picks up again
    private volatile int activeId;       // for the panel bridge, which runs on another thread
    private long core;
    private boolean privateIsolated;     // this WebView can keep private tabs in a separate profile
    private boolean privateScreenshots;  // the user allowed screenshots of private tabs
    private String defaultUa = "";
    private Downloads downloads;
    private FullscreenVideo fullscreen;   // the view a page shows when it goes fullscreen (a video, say)
    QrScanner scanner;                    // the camera screen behind the "scan" tile; null until first use
    boolean cameraAvailable;              // the "scan" tile is offered only where there is a camera
    Icons icons;
    private final java.util.concurrent.ExecutorService metaLookups = java.util.concurrent.Executors.newSingleThreadExecutor();

    private FrameLayout root, stage;
    LinearLayout bar, pill, navRow;
    LinearLayout topBar;                 // holds the address pill when it is at the top (Settings › Display)
    View progress;   // package-private for the tests
    EditText address;
    private ImageView siteIcon, scanButton, reloadButton, backButton, forwardButton, menuButton;
    ImageView homeButton;
    ImageView plusButton;
    private FrameLayout tabsCell;
    private String homeIcons = "", homeIconsFor = "";   // icon bundle for the new-tab page, and what it was built from
    TextView tabCount, toast;
    private FrameLayout.LayoutParams toastParams;
    WebView panel;
    private boolean panelReady, panelOpen;
    private boolean adListUpdating;   // one ad-list fetch at a time
    private boolean backAsked;   // the home page is still answering the last Back: a second question would act twice
    /** How the last home page was built: 0 its own background, 1 the wallpaper through it (light text), 2 the same with dark text. */
    volatile int homeWallpaper;
    private boolean wallpaperShown;   // the window currently lets the wallpaper through
    private Object wallpaperColorsListener;   // WallpaperManager.OnColorsChangedListener, Android 8.1+
    private String pendingPanelScript;

    private final Runnable sleeper = new Runnable() {
        @Override public void run() {
            for (int id : Core.tabsCollectSleepers(core, now())) {
                Tab t = find(id);
                if (t == null || t.web == null) continue;
                stage.removeView(t.web);   // drop the page and its memory; the URL stays
                t.web.destroy();
                t.web = null;
            }
            ui.postDelayed(this, SLEEP_CHECK_MS);
        }
    };
    private final Runnable hideToast = () -> toast.animate().alpha(0f).setDuration(180).withEndAction(() -> toast.setVisibility(View.GONE));

    // ---- lifecycle ---------------------------------------------------------

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        String profile = new File(getFilesDir(), "fable").getAbsolutePath();
        byte[] adDefaults = null;
        try (java.io.InputStream input = getAssets().open("ads.txt")) {
            java.io.ByteArrayOutputStream bytes = new java.io.ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int n;
            while ((n = input.read(buffer)) != -1) bytes.write(buffer, 0, n);
            adDefaults = bytes.toByteArray();
        } catch (java.io.IOException e) {
            android.util.Log.w("Fable", "Could not read the bundled ad domains", e);
        }
        // The ad list is parsed off the main thread (a community list is tens of
        // thousands of domains); requests wait for it, so none slips through first.
        final byte[] packagedAds = adDefaults;
        new Thread(() -> {
            try {
                Core.loadAdList(profile, packagedAds);
            } finally {
                adsLoaded.countDown();
            }
        }, "fable-ads").start();
        Core.storeOpen(profile);
        loadPalette();
        getWindow().setBackgroundDrawable(new ColorDrawable(ground));
        syncLauncherIcon();   // e.g. after the app's data was cleared: back to the default icon
        if (Core.adsUpdateDue()) fetchAdList();   // a week since the last fetch, while ad blocking is on
        Core.setSystemLocale(Locale.getDefault().toLanguageTag());
        core = Core.tabsNew();
        applySleepSetting();
        defaultUa = WebSettings.getDefaultUserAgent(this).replace("; wv)", ")").replace("Version/4.0 ", "");
        icons = new Icons(new File(getFilesDir(), "icons"), defaultUa);
        launcher = new Launcher(this);
        launcher.dropOldWallpaperCopy();
        IntentFilter packages = new IntentFilter();   // apps installed, removed or updated: the home screen lists them again
        packages.addAction(Intent.ACTION_PACKAGE_ADDED);
        packages.addAction(Intent.ACTION_PACKAGE_REMOVED);
        packages.addAction(Intent.ACTION_PACKAGE_CHANGED);
        packages.addAction(Intent.ACTION_PACKAGE_REPLACED);
        packages.addDataScheme("package");
        registerReceiver(packageWatcher, packages);
        watchWallpaperColors();
        downloads = new Downloads(this);
        cameraAvailable = getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY);
        privateIsolated = WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE);
        privateScreenshots = "1".equals(Core.settingGet("private_screenshots"));
        deletePrivateProfile();   // left over if the app was killed with private tabs open

        setContentView(buildUi());
        applyDisplaySettings();
        fullscreen = new FullscreenVideo(this, this::applyStatusBar);   // a video going fullscreen shows its view through this
        boolean restored = restoreSession();   // the normal tabs of the last run, unless that is switched off
        Intent start = getIntent();
        if (restored && start != null && Intent.ACTION_MAIN.equals(start.getAction()) && start.hasCategory(Intent.CATEGORY_HOME)) {
            goHome();   // started as the home app: the home screen comes first, the restored tabs wait behind it
        } else {
            openIntent(start, !restored);   // a link handed over still opens, in a tab of its own
        }
        ui.postDelayed(sleeper, SLEEP_CHECK_MS);
        ui.postDelayed(this::ensurePanel, 1500);   // load the sheet page ahead of its first use
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (Intent.ACTION_MAIN.equals(intent.getAction()) && intent.hasCategory(Intent.CATEGORY_HOME)) {
            goHome();   // the Home key, with Fable as the home app
            return;
        }
        openIntent(intent, false);
    }

    /**
     * What another app handed over: a web link, shared text, or a shared text
     * document. The activity is exported, so an explicit intent can carry any
     * data URI whatever the manifest's filters say: only http(s) links are
     * opened, and shared text goes through the address bar's rules (Core.resolve).
     */
    void openIntent(Intent intent, boolean always) {
        Uri document = sharedDocument(intent);
        if (document != null) {
            openDocument(document);
            return;
        }
        String input = intentInput(intent);
        if (always || !input.isEmpty()) newTab(input, false);
        if (input.isEmpty() && intent != null && intent.getData() != null) toast(Core.tr("link_not_opened"));   // say so, rather than nothing happening
    }

    /** A shared document (ACTION_SEND with a content:// stream), the only content URI Fable loads. */
    static Uri sharedDocument(Intent intent) {
        if (intent == null || !Intent.ACTION_SEND.equals(intent.getAction()) || intent.getStringExtra(Intent.EXTRA_TEXT) != null) return null;
        Uri stream = intent.getParcelableExtra(Intent.EXTRA_STREAM);
        return stream != null && "content".equals(stream.getScheme()) ? stream : null;
    }

    /** A tab for a shared document: content access is turned on for that tab, and that URI, only. */
    void openDocument(Uri document) {
        Tab t = addTab(false, document.toString());
        activate(t);
        t.web.loadUrl(t.document);
    }

    static boolean isWebUrl(String url) {
        Uri uri = Uri.parse(url);
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(java.util.Locale.ROOT);
        return ("http".equals(scheme) || "https".equals(scheme)) && uri.getHost() != null && !uri.getHost().isEmpty();
    }

    /**
     * Icon packs (theme://name). Each has a launcher entry of its own, an
     * activity-alias of MainActivity in AndroidManifest.xml (.Icon_<pack>);
     * only the chosen pack's is enabled, so the launcher shows its icon.
     */
    static final String[] ICON_PACKS = {"claude", "chatgpt", "deepseek", "gemini", "grok", "kimi"};

    static ComponentName iconAlias(Context context, String pack) {
        return new ComponentName(context.getPackageName(), "app.fable.browser.Icon_" + pack);
    }

    /**
     * The launcher shows the chosen pack's icon. The new entry is enabled before
     * the old one goes, so Fable is never without one; nothing is touched when
     * the launcher already shows the right icon (also on every start).
     */
    void syncLauncherIcon() {
        String want = Core.themeCurrent();
        PackageManager pm = getPackageManager();
        setIconAlias(pm, want, true);
        for (String pack : ICON_PACKS) if (!pack.equals(want)) setIconAlias(pm, pack, false);
    }

    private void setIconAlias(PackageManager pm, String pack, boolean on) {
        ComponentName alias = iconAlias(this, pack);
        try {
            int state = pm.getComponentEnabledSetting(alias);
            boolean enabled = state == PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                    || (state == PackageManager.COMPONENT_ENABLED_STATE_DEFAULT && "claude".equals(pack));   // the manifest's
            if (enabled == on) return;
            pm.setComponentEnabledSetting(alias, on ? PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                    : PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
        } catch (RuntimeException unknown) {
            // Not in this build's manifest: nothing to switch.
        }
    }

    private Launcher launcher;
    private final BroadcastReceiver packageWatcher = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            launcher.invalidate();
            reloadHomeTabs();
        }
    };

    /** Normal tabs showing the home page draw it again (new apps, a changed layout). */
    void reloadHomeTabs() {
        for (Tab t : tabs) if (!t.incognito && t.web != null && t.pageUrl.startsWith(HOME)) t.web.reload();
    }

    /**
     * The Home key: back to the home screen's first page. A normal tab already on
     * the home page is reused, so pressing Home does not pile up tabs.
     */
    void goHome() {
        if (panelOpen) onPanelAction("hidden", "");
        leaveAddress();
        Tab home = null;
        for (Tab t : tabs) if (!t.incognito && t.web != null && t.pageUrl.startsWith(HOME)) home = t;
        if (home == null) {
            newTab("", false);
            return;
        }
        activate(home);
        home.web.evaluateJavascript("window.fableHome && fableHome()", null);
    }

    static String intentInput(Intent intent) {
        if (intent == null) return "";
        if (intent.getData() != null) {
            String url = intent.getData().toString();
            return isWebUrl(url) ? url : "";   // javascript:, file:, content:, intent: ... are not opened
        }
        if (Intent.ACTION_SEND.equals(intent.getAction())) {
            String text = intent.getStringExtra(Intent.EXTRA_TEXT);
            if (text != null) return text.trim();
        }
        return "";
    }

    @Override protected void onPause() {
        if (scanner != null) scanner.hide();   // the scanner does not outlive the app going off screen
        fullscreen.hide();   // a fullscreen video does not outlive the page going off screen
        saveSession();       // the process may be ended in the background: the tabs come back on the next start
        if (active != null && active.web != null) active.web.onPause();
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        applyStatusBar();   // the system may have shown it again while away
        if (active != null && active.web != null) active.web.onResume();
        refreshChrome();   // the home app may have been changed meanwhile: the wallpaper shows through only while it is Fable
    }

    @Override protected void onDestroy() {
        if (scanner != null) scanner.hide();
        ui.removeCallbacksAndMessages(null);
        for (Tab t : tabs) if (t.web != null) t.web.destroy();
        tabs.clear();
        if (panel != null) panel.destroy();
        icons.shutdown();
        try { unregisterReceiver(packageWatcher); } catch (IllegalArgumentException ignored) { }
        if (Build.VERSION.SDK_INT >= 27 && wallpaperColorsListener != null) {
            try {
                WallpaperManager.getInstance(this).removeOnColorsChangedListener((WallpaperManager.OnColorsChangedListener) wallpaperColorsListener);
            } catch (RuntimeException ignored) { }
        }
        metaLookups.shutdownNow();
        deletePrivateProfile();
        Core.tabsFree(core);
        core = 0;
        super.onDestroy();
    }

    /**
     * Requests of the home screen: answered only for a normal tab whose page is
     * the home page, and only while Fable is the home app. Any other page asking
     * (an iframe, a script on some site) gets 404, so no site can list the apps,
     * start one, or rewrite the home screen.
     */
    private WebResourceResponse homeRequest(Tab t, Uri request) {
        String url = request.toString();
        boolean allowed = !t.incognito && t.pageUrl.startsWith(HOME) && launcher.isDefaultHome();
        if (allowed && url.startsWith(APP_ICON_ENDPOINT)) {
            byte[] png = launcher.icon(request.getQueryParameter("c"));
            if (png != null) return new WebResourceResponse("image/png", null, new ByteArrayInputStream(png));
        } else if (allowed && url.startsWith(HOME_LAUNCH)) {
            Intent start = launcher.launchIntent(request.getQueryParameter("c"));
            if (start != null) {
                final WebView from = t.web;
                final Rect icon = iconRect(request.getQueryParameter("r"), getResources().getDisplayMetrics().density);
                ui.post(() -> { try { startActivity(start, launchOptions(start, from, icon)); } catch (RuntimeException ignored) { } });
                return noContent();
            }
        } else if (allowed && url.startsWith(HOME_INFO)) {
            Intent info = launcher.infoIntent(request.getQueryParameter("c"));
            if (info != null) {
                ui.post(() -> { try { startActivity(info); } catch (RuntimeException ignored) { } });
                return noContent();
            }
        } else if (allowed && url.startsWith(HOME_SET)) {
            String key = request.getQueryParameter("k"), value = request.getQueryParameter("v");
            boolean known = "home_order".equals(key) || "home_hidden".equals(key) || "shortcuts".equals(key);
            if (known && value != null && value.startsWith("[") && value.length() < 256 * 1024) {
                Core.settingSet(key, value);
                return noContent();
            }
        }
        return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", Collections.<String, String>emptyMap(), new ByteArrayInputStream(new byte[0]));
    }

    private static WebResourceResponse noContent() {
        return new WebResourceResponse("text/plain", "utf-8", 204, "No Content", Collections.<String, String>emptyMap(), new ByteArrayInputStream(new byte[0]));
    }

    @Override public void onBackPressed() {
        if (scanner != null && scanner.isShowing()) { scanner.hide(); return; }   // Back first leaves the scanner
        if (fullscreen.showing()) { fullscreen.hide(); return; }   // Back first leaves a fullscreen video
        if (panelOpen) panel.evaluateJavascript("Fable.back()", null);
        else if (address.hasFocus()) leaveAddress();
        else if (onHomeScreen(active)) {
            if (backAsked) return;   // the last Back is still being answered: one question at a time
            // The home screen first closes what it has open (an app's menu, All apps, editing); it says whether it did.
            backAsked = true;
            final Tab t = active;
            t.web.evaluateJavascript("window.fableBack ? fableBack() : false", value -> {
                backAsked = false;
                if (!"true".equals(value) && t == active) backBeyondPage();
            });
        } else backBeyondPage();
    }

    /**
     * Where the tapped icon is, in the web view's pixels: the page sends it in CSS pixels
     * ("left,top,width,height" in the viewport, which is the web view's own area). Null when
     * missing or not a sensible box.
     */
    static Rect iconRect(String box, float density) {
        if (box == null) return null;
        String[] parts = box.split(",");
        if (parts.length != 4) return null;
        try {
            float x = Float.parseFloat(parts[0]), y = Float.parseFloat(parts[1]), w = Float.parseFloat(parts[2]), h = Float.parseFloat(parts[3]);
            if (!(w > 0 && h > 0 && w < 4096 && h < 4096 && Math.abs(x) < 16384 && Math.abs(y) < 16384)) return null;
            return new Rect(Math.round(x * density), Math.round(y * density), Math.round((x + w) * density), Math.round((y + h) * density));
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /**
     * An app started from the home screen opens growing out of its icon (the clip-reveal
     * animation launchers use; a third-party home app cannot run the system's own
     * icon-to-window animation, which needs a privileged permission), and is told where it
     * was started from (source bounds, on screen), as from any home screen.
     */
    private static Bundle launchOptions(Intent start, View from, Rect icon) {
        if (icon == null || from == null || !from.isAttachedToWindow()) return null;
        int[] at = new int[2];
        from.getLocationOnScreen(at);
        Rect onScreen = new Rect(icon);
        onScreen.offset(at[0], at[1]);
        start.setSourceBounds(onScreen);
        return ActivityOptions.makeClipRevealAnimation(from, icon.left, icon.top, icon.width(), icon.height()).toBundle();
    }

    /** The home page of a normal tab while Fable is the home app: the phone's home screen. */
    private boolean onHomeScreen(Tab t) {
        return t != null && !t.incognito && t.web != null && t.pageUrl.startsWith(HOME) && launcher.isDefaultHome();
    }

    private void backBeyondPage() {
        if (active != null && active.web != null && active.web.canGoBack()) active.web.goBack();
        else if (active != null && (active.incognito || tabsIn(false).size() > 1)) close(active);   // the last private tab hands back to normal mode
        else if (!launcher.isDefaultHome()) super.onBackPressed();   // a home screen stays where it is
    }

    // ---- chrome ------------------------------------------------------------

    private int dp(float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()));
    }

    private static GradientDrawable shape(int fill, float radius, int strokeWidth, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(radius);
        if (strokeWidth > 0) d.setStroke(strokeWidth, strokeColor);
        return d;
    }

    /** The accent at 20% for ripples. */
    private int sparkRipple() {
        return (spark & 0x00FFFFFF) | 0x33000000;
    }

    /** The skin's colours from the core. */
    void loadPalette() {
        try {
            JSONObject p = new JSONObject(Core.themePalette());
            ground = colour(p, "ground"); barColour = colour(p, "bar"); ink = colour(p, "ink"); iconColour = colour(p, "icon");
            hint = colour(p, "hint"); line = colour(p, "line"); spark = colour(p, "spark"); pillColour = colour(p, "card");
            onSpark = colour(p, "on_spark"); darkSkin = p.optBoolean("dark_ui");
        } catch (JSONException | IllegalArgumentException unreadable) {
            // keep the colours we have
        }
    }

    private static int colour(JSONObject p, String key) throws JSONException {
        return Color.parseColor(p.getString(key));
    }

    /**
     * theme://name was typed: everything Fable draws itself takes the skin's colours
     * (the bars here, the panel, the new-tab pages), and the launcher its icon.
     */
    private void applySkin() {
        loadPalette();
        logo = null;
        syncLauncherIcon();
        getWindow().setBackgroundDrawable(new ColorDrawable(ground));
        root.setBackgroundColor(ground);
        progress.setBackgroundColor(spark);
        tabsCell.setBackground(new RippleDrawable(ColorStateList.valueOf(sparkRipple()), null, null));
        for (ImageView v : new ImageView[] {siteIcon, scanButton, reloadButton, backButton, forwardButton, homeButton, menuButton})
            v.setBackground(new RippleDrawable(ColorStateList.valueOf(sparkRipple()), null, null));
        for (Tab t : tabs) {
            if (t.web != null && !t.incognito) t.web.setBackgroundColor(ground);
            if (t.web != null && t.pageUrl.startsWith(HOME)) t.web.reload();   // the new-tab page in the new colours and logo
        }
        if (panel != null) {   // the sheet is a page in the old colours: load it again
            panelReady = false;
            pendingPanelScript = null;
            panel.loadDataWithBaseURL(null, Core.panelPage(), "text/html", "utf-8", null);
        }
        applyHomeButton();   // + on the accent, and refreshChrome
        if (active == null) styleChrome(false);
    }

    /** An icon button: our vector, our ripple, a 48dp touch target. */
    private ImageView iconButton(int drawable, String description, View.OnClickListener onClick) {
        ImageView v = new ImageView(this);
        v.setImageResource(drawable);
        v.setScaleType(ImageView.ScaleType.CENTER);
        v.setContentDescription(description);
        v.setBackground(new RippleDrawable(ColorStateList.valueOf(sparkRipple()), null, null));
        v.setClickable(true);
        v.setFocusable(true);
        v.setOnClickListener(onClick);
        return v;
    }

    private View buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(ground);
        root.setFitsSystemWindows(true);
        root.setFocusableInTouchMode(true);   // somewhere for focus to rest other than the address field

        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        root.addView(column, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // Above the page: the address pill, when the user put it at the top (as in Chrome). Empty and gone otherwise.
        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.VERTICAL);
        topBar.setVisibility(View.GONE);
        column.addView(topBar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        stage = new FrameLayout(this);
        column.addView(stage, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.VERTICAL);
        column.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // Loading progress: a thin line along the edge of the bar that faces the page.
        progress = new View(this);
        progress.setBackgroundColor(spark);
        progress.setPivotX(0f);
        progress.setScaleX(0f);

        // Address pill: site icon, text, reload/stop.
        pill = new LinearLayout(this);
        pill.setGravity(Gravity.CENTER_VERTICAL);
        siteIcon = new ImageView(this);
        siteIcon.setScaleType(ImageView.ScaleType.CENTER);
        pill.addView(siteIcon, new LinearLayout.LayoutParams(dp(44), dp(48)));

        address = new EditText(this);
        address.setBackground(null);
        address.setPadding(0, 0, 0, 0);
        address.setSingleLine(true);
        address.setTextSize(15);
        address.setSelectAllOnFocus(true);
        address.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        address.setImeOptions(EditorInfo.IME_ACTION_GO | EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        address.setOnEditorActionListener((view, action, event) -> {
            String typed = view.getText().toString();
            leaveAddress();
            if (active != null && !typed.trim().isEmpty()) navigate(active, typed);
            return true;
        });
        address.setOnFocusChangeListener((view, focused) -> {
            navRow.setVisibility(focused ? View.GONE : View.VISIBLE);   // typing: give the keyboard the room
            if (focused) return;
            if (active != null && addressHeld != active) address.setText(active.url);
            ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(view.getWindowToken(), 0);
        });
        pill.addView(address, new LinearLayout.LayoutParams(0, dp(48), 1f));

        // QR scanning lives in the blank address bar (0.18.31): the camera button shows only while it is empty.
        scanButton = iconButton(R.drawable.ic_camera, "", v -> startScan());
        address.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { updateScanButton(); }
            @Override public void afterTextChanged(android.text.Editable s) { }
        });
        pill.addView(scanButton, new LinearLayout.LayoutParams(dp(40), dp(48)));

        reloadButton = iconButton(R.drawable.ic_reload, "", v -> {
            if (active == null || active.web == null) return;
            if (active.loading) active.web.stopLoading(); else active.web.reload();
        });
        pill.addView(reloadButton, new LinearLayout.LayoutParams(dp(48), dp(48)));

        // Navigation row: back, forward, (home), new tab, tabs, menu.
        navRow = new LinearLayout(this);
        navRow.setGravity(Gravity.CENTER_VERTICAL);
        backButton = iconButton(R.drawable.ic_back, "", v -> { if (active != null && active.web != null && active.web.canGoBack()) active.web.goBack(); });
        forwardButton = iconButton(R.drawable.ic_forward, "", v -> { if (active != null && active.web != null && active.web.canGoForward()) active.web.goForward(); });
        navRow.addView(backButton, cell());
        navRow.addView(forwardButton, cell());
        homeButton = iconButton(R.drawable.ic_home, "", v -> { if (active != null) { leaveAddress(); navigate(active, ""); } });   // the new-tab page, in this tab
        navRow.addView(homeButton, cell());

        FrameLayout plusCell = new FrameLayout(this);
        plusButton = iconButton(R.drawable.ic_plus, "", v -> newTab("", active != null && active.incognito));
        plusButton.setColorFilter(onSpark);
        plusButton.setBackground(new RippleDrawable(ColorStateList.valueOf(0x40FFFFFF), shape(spark, dp(20), 0, 0), null));
        plusCell.addView(plusButton, new FrameLayout.LayoutParams(dp(52), dp(40), Gravity.CENTER));
        navRow.addView(plusCell, cell());
        applyHomeButton();

        tabsCell = new FrameLayout(this);
        tabsCell.setBackground(new RippleDrawable(ColorStateList.valueOf(sparkRipple()), null, null));
        tabsCell.setOnClickListener(v -> showPanel("tabs"));
        tabCount = new TextView(this);
        tabCount.setGravity(Gravity.CENTER);
        tabCount.setTextSize(12);
        tabCount.setTypeface(Typeface.DEFAULT_BOLD);
        tabCount.setIncludeFontPadding(false);
        tabsCell.addView(tabCount, new FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER));
        navRow.addView(tabsCell, cell());

        menuButton = iconButton(R.drawable.ic_menu, "", v -> showPanel("menu"));
        navRow.addView(menuButton, cell());
        LinearLayout.LayoutParams navParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        navParams.setMargins(dp(4), 0, dp(4), dp(2));
        bar.addView(navRow, navParams);

        // Our own message pill instead of a system toast.
        toast = new TextView(this);
        toast.setTextColor(DARK_INK);
        toast.setTextSize(14);
        toast.setBackground(shape(0xF22A1A14, dp(22), 0, 0));
        toast.setPadding(dp(18), dp(11), dp(18), dp(11));
        toast.setVisibility(View.GONE);
        toastParams = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        toastParams.setMargins(dp(24), 0, dp(24), dp(132));
        root.addView(toast, toastParams);

        applyAddressBarPosition();
        styleChrome(false);
        applyLanguage();
        return root;
    }

    /**
     * Where the address pill sits (Settings › Display, Android only): at the bottom with the buttons, under the
     * thumb (the default), or at the top above the page, as in Chrome. The buttons stay at the bottom either way,
     * and the loading line runs along whichever edge faces the page.
     */
    void applyAddressBarPosition() {
        boolean top = "1".equals(Core.settingGet("address_top"));
        if (pill.getParent() == (top ? topBar : bar)) return;
        if (pill.getParent() != null) ((ViewGroup) pill.getParent()).removeView(pill);
        if (progress.getParent() != null) ((ViewGroup) progress.getParent()).removeView(progress);
        LinearLayout.LayoutParams pillParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        LinearLayout.LayoutParams line = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(2));
        if (top) {
            pillParams.setMargins(dp(12), dp(6), dp(12), dp(6));
            topBar.addView(pill, pillParams);
            topBar.addView(progress, line);
        } else {
            pillParams.setMargins(dp(12), dp(8), dp(12), dp(2));
            bar.addView(progress, 0, line);
            bar.addView(pill, 1, pillParams);
        }
        topBar.setVisibility(top ? View.VISIBLE : View.GONE);
        toastParams.bottomMargin = dp(top ? 76 : 132);   // just above the bar, whichever height it has
        toast.setLayoutParams(toastParams);
    }

    /** The Home button is optional (Settings › Display), off unless switched on, as in Chrome. */
    private void applyHomeButton() {
        boolean on = "1".equals(Core.settingGet("home_button"));
        homeButton.setVisibility(on ? View.VISIBLE : View.GONE);
        // Six buttons in the row: + becomes one of them (plain, tinted like the rest, as on iOS) rather than
        // the orange pill, which crowds the row once Home is there. Five: the pill, as before.
        plusButton.setLayoutParams(on ? new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
                : new FrameLayout.LayoutParams(dp(52), dp(40), Gravity.CENTER));
        plusButton.setBackground(on ? new RippleDrawable(ColorStateList.valueOf(sparkRipple()), null, null)
                : new RippleDrawable(ColorStateList.valueOf(0x40FFFFFF), shape(spark, dp(20), 0, 0), null));
        if (active != null) refreshChrome();   // the tint of +
        else plusButton.setColorFilter(on ? iconColour : onSpark);
    }

    private LinearLayout.LayoutParams cell() {
        return new LinearLayout.LayoutParams(0, dp(48), 1f);
    }

    /** Put the current language's text on everything the bar shows or announces. */
    private void applyLanguage() {
        address.setHint(Core.tr("addr_hint"));
        backButton.setContentDescription(Core.tr("go_back"));
        forwardButton.setContentDescription(Core.tr("go_forward"));
        homeButton.setContentDescription(Core.tr("go_home"));
        plusButton.setContentDescription(Core.tr(inPrivate() ? "new_private" : "new_tab_btn"));
        tabsCell.setContentDescription(Core.tr("tabs"));
        menuButton.setContentDescription(Core.tr("menu"));
        scanButton.setContentDescription(Core.tr("scan"));
        reloadButton.setContentDescription(Core.tr(active != null && active.loading ? "stop" : "reload"));
        for (Tab t : tabs) if (t.url.isEmpty()) t.title = Core.tr("newtab");
    }

    /**
     * Icons of the home-page shortcuts that are already stored, as JSON for the
     * new-tab page. Rebuilt only when the shortcuts or the icon store change, so
     * opening or refreshing the page costs no disk reads and shows no empty tiles.
     */
    private synchronized String homeIconsJson() {
        String shortcuts = Core.settingGet("shortcuts");
        String key = icons.version() + "|" + shortcuts;
        if (key.equals(homeIconsFor)) return homeIcons;
        ArrayList<String> hosts = new ArrayList<>();
        try {
            JSONArray list = new JSONArray(shortcuts);
            for (int i = 0; i < list.length(); i++) hosts.add(Icons.hostOf(list.getJSONObject(i).optString("u")));
        } catch (org.json.JSONException unset) {
            Collections.addAll(hosts, DEFAULT_SHORTCUT_HOSTS);
        }
        homeIcons = icons.bundle(hosts);
        homeIconsFor = key;
        return homeIcons;
    }

    /** Colours of the bar (and of the top bar, when the address is up there): the skin's normally, dark in private mode. */
    private void styleChrome(boolean incognito) {
        applySecure(incognito);
        int ink = incognito ? DARK_INK : this.ink, muted = incognito ? DARK_MUTED : iconColour, barColor = incognito ? DARK_BAR : barColour;
        boolean lightIcons = incognito || darkSkin;   // light system icons on a dark bar
        bar.setBackgroundColor(barColor);
        topBar.setBackgroundColor(barColor);
        pill.setBackground(shape(incognito ? DARK_PILL : pillColour, dp(24), dp(1), incognito ? DARK_LINE : line));
        address.setTextColor(ink);
        address.setHintTextColor(incognito ? DARK_MUTED : hint);
        address.setHighlightColor((spark & 0x00FFFFFF) | 0x55000000);
        for (ImageView v : new ImageView[] {siteIcon, scanButton, reloadButton, backButton, forwardButton, homeButton, menuButton}) v.setColorFilter(muted);
        plusButton.setColorFilter(homeButton.getVisibility() == View.VISIBLE ? muted : onSpark);   // on the accent pill, else like the rest
        tabCount.setTextColor(muted);
        tabCount.setBackground(shape(0x00000000, dp(7), dp(2), muted));
        // The status bar: dark in private mode wherever the address bar is (as in Chrome), with light icons;
        // otherwise the top bar's colour when the address is up there, else the page's cream.
        boolean top = topBar.getVisibility() == View.VISIBLE;
        getWindow().setStatusBarColor(incognito ? DARK_BAR : top ? barColor : ground);
        View decorView = getWindow().getDecorView();
        int uiFlags = decorView.getSystemUiVisibility();
        decorView.setSystemUiVisibility(lightIcons ? uiFlags & ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR : uiFlags | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        if (Build.VERSION.SDK_INT >= 27) {
            getWindow().setNavigationBarColor(barColor);
            View decor = getWindow().getDecorView();   // dark system buttons on a light bar, light ones on a dark bar
            int flags = decor.getSystemUiVisibility();
            decor.setSystemUiVisibility(lightIcons ? flags & ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR : flags | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
        applyHomeWallpaper();
    }

    /**
     * The home screen shows the user's own wallpaper, as any launcher does: the window
     * lets the system draw the wallpaper behind it (Fable never reads or changes the
     * wallpaper, so no permission is involved), and the window, the root and the home
     * page's web view are see-through; the status bar sits on the wallpaper with icons
     * to suit it. Because the home window shows the wallpaper, the system also opens
     * apps from it with its open-from-home transition. Only the home page of a normal
     * tab while Fable is the home app, and only with the setting on (home_wallpaper).
     */
    private void applyHomeWallpaper() {
        Tab t = active;
        boolean wall = homeWallpaper != 0 && onHomeScreen(t);
        if (wall) {
            getWindow().setStatusBarColor(Color.TRANSPARENT);
            View decor = getWindow().getDecorView();
            int flags = decor.getSystemUiVisibility();
            decor.setSystemUiVisibility(homeWallpaper == 2 ? flags | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR : flags & ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
        if (t != null && t.web != null && !t.incognito) t.web.setBackgroundColor(wall ? Color.TRANSPARENT : ground);
        if (wall == wallpaperShown) return;
        wallpaperShown = wall;
        if (wall) getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER);
        getWindow().setBackgroundDrawable(new ColorDrawable(wall ? Color.TRANSPARENT : ground));
        root.setBackgroundColor(wall ? Color.TRANSPARENT : ground);
    }

    /** 0: the home page draws its own background (setting off); 1 or 2: the wallpaper, with light or dark text. */
    int wallpaperMode() {
        if ("0".equals(Core.settingGet("home_wallpaper"))) return 0;
        return wallpaperWantsDarkText() ? 2 : 1;
    }

    /** Whether the home wallpaper is light enough for dark text (the system works this out; no pixels are read). */
    private boolean wallpaperWantsDarkText() {
        if (Build.VERSION.SDK_INT < 27) return false;   // light text with a shadow reads on most wallpapers
        try {
            WallpaperColors colors = WallpaperManager.getInstance(this).getWallpaperColors(WallpaperManager.FLAG_SYSTEM);
            if (colors == null) return false;
            if (Build.VERSION.SDK_INT >= 31) return (colors.getColorHints() & WallpaperColors.HINT_SUPPORTS_DARK_TEXT) != 0;
            return colors.getPrimaryColor().luminance() > 0.6f;
        } catch (RuntimeException unavailable) {
            return false;
        }
    }

    // ---- the system wallpaper itself: Fable's cream, or the user's back (Settings › Search and home › System wallpaper) ----

    private File keptWallpaper() { return new File(getFilesDir(), "wallpaper-kept.png"); }

    private boolean wallpaperChangeable() {
        try {
            WallpaperManager wm = WallpaperManager.getInstance(this);
            return wm.isWallpaperSupported() && wm.isSetWallpaperAllowed();
        } catch (RuntimeException none) {
            return false;
        }
    }

    /**
     * Whether the wallpaper about to be replaced can be kept for later. Only where Android
     * lets an app read it without a storage permission: before 8.1. From 8.1 to 12 reading
     * it needs the storage permission, 13 hands out the stock wallpaper instead, and 14 refuses
     * (short of All files access); there the user picks theirs again to restore it. A live
     * wallpaper cannot be kept as a picture either.
     */
    private boolean canKeepWallpaper() {
        try {
            return Build.VERSION.SDK_INT < 27 && WallpaperManager.getInstance(this).getWallpaperInfo() == null;
        } catch (RuntimeException none) {
            return false;
        }
    }

    /**
     * Whether the home wallpaper is Fable's cream: from the colours the system reports (8.1+, no
     * pixels read), or before 8.1, where an app may read it, from the picture itself.
     */
    boolean groundWallpaperUp() {
        if (Build.VERSION.SDK_INT < 27) {
            try {
                Drawable now = WallpaperManager.getInstance(this).getDrawable();
                return now instanceof BitmapDrawable && ((BitmapDrawable) now).getBitmap().getPixel(0, 0) == CREAM;
            } catch (RuntimeException unreadable) {
                return false;
            }
        }
        try {
            WallpaperColors colors = WallpaperManager.getInstance(this).getWallpaperColors(WallpaperManager.FLAG_SYSTEM);
            if (colors == null) return false;
            int c = colors.getPrimaryColor().toArgb();
            return Math.abs(Color.red(c) - Color.red(CREAM)) < 10 && Math.abs(Color.green(c) - Color.green(CREAM)) < 10 && Math.abs(Color.blue(c) - Color.blue(CREAM)) < 10;
        } catch (RuntimeException unavailable) {
            return false;
        }
    }

    /**
     * The home wallpaper (not the lock screen's: Android keeps the old picture there when
     * only the home one is set) becomes Fable's cream: one pixel, stretched by the system.
     * The old one is kept first where it can be (canKeepWallpaper). Off the UI thread.
     */
    private void setGroundWallpaper() {
        final File kept = keptWallpaper();
        new Thread(() -> {
            boolean ok = false;
            try {
                WallpaperManager wm = WallpaperManager.getInstance(this);
                if (!kept.exists() && canKeepWallpaper() && !groundWallpaperUp()) {
                    Drawable now = wm.getDrawable();
                    Bitmap picture = now instanceof BitmapDrawable ? ((BitmapDrawable) now).getBitmap() : null;
                    if (picture != null) {
                        try (java.io.FileOutputStream out = new java.io.FileOutputStream(kept)) {
                            picture.compress(Bitmap.CompressFormat.PNG, 100, out);
                        } catch (java.io.IOException failed) {
                            kept.delete();
                        }
                    }
                }
                Bitmap cream = Bitmap.createBitmap(new int[] {CREAM}, 1, 1, Bitmap.Config.ARGB_8888);
                wm.setBitmap(cream, null, true, WallpaperManager.FLAG_SYSTEM);
                ok = true;
            } catch (java.io.IOException | RuntimeException failed) { }
            final boolean done = ok;
            ui.post(() -> toast(Core.tr(done ? "wallpaper_done_ground" : "wallpaper_fail")));
        }, "fable-wallpaper").start();
    }

    /** The system's own wallpaper picker. */
    private void pickWallpaper() {
        try {
            startActivity(Intent.createChooser(new Intent(Intent.ACTION_SET_WALLPAPER), Core.tr("wallpaper_sys")));
        } catch (RuntimeException noPicker) {
            toast(Core.tr("wallpaper_fail"));
        }
    }

    /** The kept wallpaper back, or, with none kept, the system's own wallpaper picker to choose it again. */
    private void restoreWallpaper() {
        final File kept = keptWallpaper();
        if (!kept.exists()) {
            pickWallpaper();
            return;
        }
        new Thread(() -> {
            boolean ok = false;
            Bitmap picture = android.graphics.BitmapFactory.decodeFile(kept.getAbsolutePath());
            if (picture != null) {
                try {
                    WallpaperManager.getInstance(this).setBitmap(picture, null, true, WallpaperManager.FLAG_SYSTEM);
                    ok = true;
                } catch (java.io.IOException | RuntimeException failed) { }
            }
            if (ok || picture == null) kept.delete();   // back, or unreadable for good
            final boolean done = ok;
            ui.post(() -> toast(Core.tr(done ? "wallpaper_done_restore" : "wallpaper_fail")));
        }, "fable-wallpaper").start();
    }

    /** A new wallpaper may want the other text colour: the home page is built again. */
    private void watchWallpaperColors() {
        if (Build.VERSION.SDK_INT < 27) return;
        try {
            WallpaperManager.OnColorsChangedListener listener = (colors, which) -> {
                if ((which & WallpaperManager.FLAG_SYSTEM) != 0) reloadHomeTabs();
            };
            WallpaperManager.getInstance(this).addOnColorsChangedListener(listener, ui);
            wallpaperColorsListener = listener;
        } catch (RuntimeException unavailable) { }
    }

    /**
     * Private mode keeps its pages out of screenshots, screen recordings and the
     * recent-apps preview, as Chrome does, unless the user allowed screenshots.
     */
    private void applySecure(boolean incognito) {
        boolean secure = incognito && !privateScreenshots;
        boolean now = (getWindow().getAttributes().flags & WindowManager.LayoutParams.FLAG_SECURE) != 0;
        if (secure == now) return;
        if (secure) getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
    }

    /** Bring the bar in line with the tab in front. */
    private void refreshChrome() {
        Tab t = active;
        if (t == null) return;
        styleChrome(t.incognito);
        if (!address.hasFocus() && addressHeld != t) address.setText(t.url);
        siteIcon.setImageResource(t.incognito ? R.drawable.ic_mask : t.url.startsWith("https://") ? R.drawable.ic_lock : R.drawable.ic_search);
        updateScanButton();
        reloadButton.setImageResource(t.loading ? R.drawable.ic_stop : R.drawable.ic_reload);
        reloadButton.setContentDescription(Core.tr(t.loading ? "stop" : "reload"));
        backButton.setAlpha(t.web != null && t.web.canGoBack() ? 1f : 0.35f);
        forwardButton.setAlpha(t.web != null && t.web.canGoForward() ? 1f : 0.35f);
        tabCount.setText(String.valueOf(Math.min(tabsIn(t.incognito).size(), 99)));   // the tabs of this mode only
        plusButton.setContentDescription(Core.tr(t.incognito ? "new_private" : "new_tab_btn"));
        progress.animate().cancel();
        if (t.loading) {
            progress.setAlpha(1f);
            progress.setScaleX(Math.max(0.08f, t.progress / 100f));
        } else {
            progress.animate().alpha(0f).setDuration(250).withEndAction(() -> progress.setScaleX(0f));
        }
    }

    private void leaveAddress() {
        if (address.hasFocus()) root.requestFocus();   // the focus listener puts the URL back and hides the keyboard
    }

    /** The camera button is the QR entry: shown only where there is a camera and the address bar is blank. */
    private void updateScanButton() {
        scanButton.setVisibility(cameraAvailable && address.getText().toString().trim().isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void toast(String message) {
        ui.removeCallbacks(hideToast);
        toast.setText(message);
        toast.setAlpha(0f);
        toast.setVisibility(View.VISIBLE);
        toast.animate().alpha(1f).setDuration(150);
        ui.postDelayed(hideToast, 2600);
    }

    // ---- tabs --------------------------------------------------------------

    private long now() {
        return SystemClock.elapsedRealtime();
    }

    private Tab find(int id) {
        for (Tab t : tabs) if (t.id == id) return t;
        return null;
    }

    private Tab addTab(boolean incognito) {
        return addTab(incognito, null);
    }

    private Tab addTab(boolean incognito, String document) {
        Tab t = new Tab();
        t.id = Core.tabsOpen(core, now());
        t.incognito = incognito;
        t.document = document;
        t.title = Core.tr("newtab");
        tabs.add(t);
        createWeb(t);
        return t;
    }

    void newTab(String input, boolean incognito) {
        if (incognito && !privateIsolated && !hasPrivateTabs()) {
            toast(Core.tr("old_webview"));
        }
        Tab t = addTab(incognito);
        activate(t);
        navigate(t, input);
    }

    private boolean hasPrivateTabs() {
        for (Tab t : tabs) if (t.incognito) return true;
        return false;
    }

    /** The tabs of one mode, in order. */
    ArrayList<Tab> tabsIn(boolean incognito) {
        ArrayList<Tab> list = new ArrayList<>();
        for (Tab t : tabs) if (t.incognito == incognito) list.add(t);
        return list;
    }

    boolean inPrivate() {
        return active != null && active.incognito;
    }

    /** Enter private mode: back to the private tab last in front, or a new one if there is none. */
    void enterPrivate() {
        Tab t = tabs.contains(lastPrivate) ? lastPrivate : null;
        if (t == null) {
            ArrayList<Tab> open = tabsIn(true);
            if (!open.isEmpty()) t = open.get(open.size() - 1);
        }
        if (t != null) activate(t); else newTab("", true);
    }

    /** Leave private mode: close every private tab (which wipes their data) and go back to the normal tabs. */
    int exitPrivate() {
        Tab front = inPrivate() ? active : null;
        int closed = 0;
        for (Tab t : tabsIn(true)) if (t != front) { close(t); closed++; }
        if (front != null) { close(front); closed++; }   // last, so normal mode resumes only once
        if (closed > 0) toast(Core.tr("private_closed"));
        return closed;
    }

    private void activate(Tab t) {
        backAsked = false;   // a question left over to another view (or one now rebuilt) will never be answered
        if (active != null && active != t && active.web != null) {
            active.web.setVisibility(View.GONE);
            active.web.onPause();
        }
        active = t;
        activeId = t.id;
        if (t.incognito) lastPrivate = t; else lastNormal = t;
        Core.tabsActivate(core, t.id, now());
        if (t.web == null) {   // wake: rebuild the view and reload where the tab was
            createWeb(t);
            t.web.loadUrl(t.url.isEmpty() ? HOME : t.url);
        }
        t.web.setVisibility(View.VISIBLE);
        t.web.onResume();
        refreshChrome();
    }

    void close(Tab t) {
        if (t == null) return;
        int index = tabs.indexOf(t);
        if (index < 0) return;
        Tab next = null;   // for the tab in front: its neighbour of the same mode, right first, then left
        if (t == active) {
            ArrayList<Tab> same = tabsIn(t.incognito);
            int at = same.indexOf(t);
            if (same.size() > 1) next = same.get(at + 1 < same.size() ? at + 1 : at - 1);
        }
        Core.tabsClose(core, t.id);
        Core.sniffClear(t.id);
        tabs.remove(index);
        if (!t.incognito) saveSession();
        if (t.web != null) {
            stage.removeView(t.web);
            t.web.destroy();
            t.web = null;
        }
        if (t == lastNormal) lastNormal = null;
        if (t == lastPrivate) lastPrivate = null;
        if (t == addressHeld) addressHeld = null;
        if (t.incognito && !hasPrivateTabs()) ui.postDelayed(this::deletePrivateProfile, 500);
        if (t != active) {
            refreshChrome();
        } else {
            active = null;
            if (next != null) {
                activate(next);
            } else if (t.incognito && !tabsIn(false).isEmpty()) {   // the last private tab: back to normal mode where it was left
                ArrayList<Tab> normal = tabsIn(false);
                activate(tabs.contains(lastNormal) ? lastNormal : normal.get(normal.size() - 1));
            } else {
                newTab("", false);   // normal mode always has a tab
            }
        }
    }

    /**
     * Snapshot the normal tabs for "restore tabs on start". Private tabs never
     * enter it, nor a document another app shared (its access ends with the
     * tab), nor the home and new-tab pages. The core keeps nothing while the
     * setting is off.
     */
    void saveSession() {
        try {
            JSONArray list = new JSONArray();
            Tab front = active != null && !active.incognito ? active : lastNormal;
            int at = 0;
            for (Tab t : tabs) {
                if (t.incognito || t.document != null || !isWebUrl(t.url)) continue;
                if (list.length() >= SESSION_TABS_MAX) break;
                if (t == front) at = list.length();
                list.put(new JSONObject().put("u", t.url).put("n", t.title == null ? "" : t.title));
            }
            Core.panelQuery("sessionSave", new JSONObject().put("a", at).put("t", list).toString(), 0);
        } catch (org.json.JSONException impossible) {
            // only strings and numbers go in
        }
    }

    private static final int SESSION_TABS_MAX = 500;   // what the core accepts

    /**
     * Reopen the normal tabs of the last run. They come back asleep (a URL and
     * a title, no view) except the one that was in front, so a long list costs
     * nothing until a tab is chosen. False when there was nothing to restore.
     */
    boolean restoreSession() {
        if ("0".equals(Core.settingGet("restore_tabs"))) return false;
        String json = Core.panelQuery("session", "", 0);
        if (json == null || json.isEmpty()) return false;
        try {
            JSONObject o = new JSONObject(json);
            JSONArray list = o.optJSONArray("t");
            if (list == null) return false;
            int wanted = o.optInt("a", 0);
            Tab front = null;
            for (int i = 0; i < list.length(); i++) {
                JSONObject e = list.optJSONObject(i);
                String url = e == null ? "" : e.optString("u", "");
                if (!isWebUrl(url)) continue;   // only web pages, whatever the file says
                Tab t = new Tab();
                t.id = Core.tabsOpen(core, now());
                t.url = url;
                t.pageUrl = url;
                String title = e.optString("n", "");
                t.title = title.isEmpty() ? url : title;
                tabs.add(t);
                if (front == null || i == wanted) front = t;
            }
            if (front == null) return false;
            activate(front);   // wakes it: the view is built and the page loads
            return true;
        } catch (org.json.JSONException broken) {
            return false;
        }
    }

    /** Wipe what private tabs stored. Only possible once none of their views is alive. */
    private void deletePrivateProfile() {
        if (!privateIsolated || hasPrivateTabs()) return;
        try {
            ProfileStore.getInstance().deleteProfile(PRIVATE_PROFILE);
        } catch (RuntimeException stillInUse) {
            // A view is still being torn down; onCreate tries again on the next start.
        }
    }

    /**
     * Load what was typed or handed over. WebView.loadUrl does not pass through
     * shouldOverrideUrlLoading, so the scheme is checked here: only web pages
     * and about:blank (Core.resolve turns dangerous schemes into a search;
     * file: is off on Android).
     */
    private void navigate(Tab t, String input) {
        if (addressHeld == t) {   // new words: whatever the bar kept before is past
            addressHeld = null;
            if (t == active && !address.hasFocus()) address.setText(t.url);
        }
        String url = Core.resolve(input);
        int skin = Core.themeApply(url);
        if (skin >= 0) {
            // theme://name: a skin, not a page, and nothing is said. A name that is no skin
            // changes nothing. The tab stays where it is; pages never get here
            // (shouldOverrideUrlLoading follows http(s) links only).
            if (skin == 1) applySkin();
            if (t.web.getUrl() == null) t.web.loadUrl(HOME);   // a new tab still needs a page
            refreshChrome();
            return;
        }
        if (!url.isEmpty() && !(isWebUrl(url) || "about:blank".equalsIgnoreCase(url))) {
            // The address bar passes other schemes through (ftp://, myapp://); Android opens web pages only.
            // Say so and stay, rather than showing the home page instead.
            toast(Core.tr("link_not_opened"));
            if (t.web.getUrl() == null) t.web.loadUrl(HOME);   // a new tab still needs a page
            return;
        }
        // The words the user typed stay in the bar until the load's own URL arrives:
        // the callbacks come back later, and a blank bar in between reads as a failure.
        if (t == active) {
            addressHeld = t;
            if (!address.hasFocus()) address.setText(input.trim());
        }
        t.web.loadUrl(url.isEmpty() ? HOME : url);
    }

    /** What the address field shows for a page URL: nothing for our own pages. */
    private static String shown(String url) {
        return url == null || url.startsWith(HOME) || url.startsWith("about:") || url.startsWith("data:") ? "" : url;
    }

    // ---- settings that shape the web views ---------------------------------

    private String userAgent() {
        String mode = Core.settingGet("ua_mode");
        if ("desktop".equals(mode)) {
            Matcher m = Pattern.compile("Chrome/(\\d+)").matcher(defaultUa);
            String major = m.find() ? m.group(1) : "130";
            return "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + major + ".0.0.0 Safari/537.36";
        }
        if ("android".equals(mode)) return ANDROID_UA;
        if ("iphone".equals(mode)) return IPHONE_UA;
        if ("ipad".equals(mode)) return IPAD_UA;
        if ("chrome_win".equals(mode)) return CHROME_WIN_UA;
        if ("chrome_mac".equals(mode)) return CHROME_MAC_UA;
        if ("safari_mac".equals(mode)) return SAFARI_MAC_UA;
        if ("firefox".equals(mode)) return FIREFOX_UA;
        if ("edge".equals(mode)) return EDGE_UA;
        if ("custom".equals(mode)) {
            String custom = Core.settingGet("ua_custom").trim();
            if (!custom.isEmpty()) return custom;
        }
        return defaultUa;
    }

    private void applyWebSettings(Tab t) {
        if (t.web == null) return;
        WebSettings s = t.web.getSettings();
        s.setUserAgentString(userAgent());
        s.setJavaScriptEnabled(!"0".equals(Core.settingGet("javascript")));
        s.setLoadsImagesAutomatically(!"1".equals(Core.settingGet("data_saver")));
        s.setTextZoom(textSize());
        try {
            CookieManager.getInstance().setAcceptThirdPartyCookies(t.web, "0".equals(Core.settingGet("block_3p_cookies")));   // blocked unless switched off
        } catch (RuntimeException ignored) { }
    }

    /** The "text size" setting as a WebView text zoom, in percent (50–300; 100 when unset). */
    static int textSize() {
        try {
            int v = Integer.parseInt(Core.settingGet("text_size"));
            return Math.max(50, Math.min(300, v));
        } catch (NumberFormatException e) {
            return 100;
        }
    }

    private void applyDisplaySettings() {
        applyOrientation();
        applyKeepScreenOn();
        applyStatusBar();
    }

    /** Follow the system (and its rotation lock), or hold portrait or landscape (either way up). */
    private void applyOrientation() {
        String mode = Core.settingGet("orientation");
        setRequestedOrientation("portrait".equals(mode) ? ActivityInfo.SCREEN_ORIENTATION_USER_PORTRAIT
                : "landscape".equals(mode) ? ActivityInfo.SCREEN_ORIENTATION_USER_LANDSCAPE
                : ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
    }

    private void applyKeepScreenOn() {
        if ("1".equals(Core.settingGet("keep_screen_on"))) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    /** Hidden status bar: a swipe from the top shows it for a moment. The bar and keyboard still lay out as usual. */
    private void applyStatusBar() {
        boolean hide = "1".equals(Core.settingGet("hide_status_bar"));
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c == null) return;
            c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            if (hide) c.hide(WindowInsets.Type.statusBars());
            else c.show(WindowInsets.Type.statusBars());
        } else {
            // Not FLAG_FULLSCREEN: that stops adjustResize, and the keyboard would cover the address bar.
            View decor = getWindow().getDecorView();
            int flags = decor.getSystemUiVisibility(), mask = View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            decor.setSystemUiVisibility(hide ? flags | mask : flags & ~mask);
        }
    }

    private void applySleepSetting() {
        String minutes = Core.settingGet("sleep_minutes");
        long value = 10;
        try { if (!minutes.isEmpty()) value = Long.parseLong(minutes); } catch (NumberFormatException ignored) { }
        Core.tabsSetSleepAfterMs(core, value * 60_000);
    }

    /** Called on the UI thread after the panel changed a setting. */
    private void onSettingChanged(String key) {
        switch (key) {
            case "home_hidden":   // apps brought back in Settings
            case "home_new_apps":
            case "home_wallpaper":
            case "shortcuts":
                reloadHomeTabs();
                break;
            case "sleep_minutes":
                applySleepSetting();
                break;
            case "private_screenshots":
                privateScreenshots = "1".equals(Core.settingGet(key));
                applySecure(inPrivate());
                break;
            case "language":
                applyLanguage();
                refreshChrome();
                if (panel != null) {   // the sheet is a page in the old language: load it again and return to the settings
                    panelReady = false;
                    pendingPanelScript = panelOpen ? "Fable.show(\"settings\"," + panelState() + ")" : null;
                    panel.loadDataWithBaseURL(null, Core.panelPage(), "text/html", "utf-8", null);
                }
                if (active != null && active.web != null && active.url.isEmpty()) active.web.reload();
                break;
            case "home_button":
                applyHomeButton();
                break;
            case "address_top":
                applyAddressBarPosition();
                refreshChrome();   // the status bar takes the top bar's colour, or the page's again
                break;
            case "text_size":
                for (Tab t : tabs) applyWebSettings(t);   // takes effect at once, no reload
                break;
            case "orientation":
                applyOrientation();
                break;
            case "keep_screen_on":
                applyKeepScreenOn();
                break;
            case "hide_status_bar":
                applyStatusBar();
                break;
            case "ua_mode":
            case "ua_custom":
            case "javascript":
            case "data_saver":
            case "block_3p_cookies":
                for (Tab t : tabs) applyWebSettings(t);
                if (active != null && active.web != null && !active.url.isEmpty()) active.web.reload();
                break;
            default:
                break;   // search engine and tracker blocking are applied inside the core
        }
    }

    private void clearData(String what) {
        boolean historyCleared = !what.contains("history") || Core.historyClear();
        if (what.contains("history") && historyCleared) {
            icons.clear();
        }
        if (what.contains("cookies")) {
            CookieManager.getInstance().removeAllCookies(null);
            WebStorage.getInstance().deleteAllData();
        }
        if (what.contains("cache") && active != null && active.web != null) active.web.clearCache(true);
        toast(Core.tr(historyCleared ? "data_cleared" : "history_clear_failed"));
    }

    // ---- page web views ----------------------------------------------------

    private void createWeb(final Tab t) {
        final WebView web = new WebView(this);
        if (t.incognito && privateIsolated) {
            // Must happen before anything else touches the view: private tabs
            // get their own cookie jar and storage, deleted with the profile.
            try {
                ProfileStore.getInstance().getOrCreateProfile(PRIVATE_PROFILE);
                WebViewCompat.setProfile(web, PRIVATE_PROFILE);
            } catch (RuntimeException unsupported) {
                privateIsolated = false;   // carry on with the shared profile rather than crash
                toast(Core.tr("private_fail"));
            }
        }
        web.setVisibility(View.GONE);
        web.setBackgroundColor(t.incognito ? DARK_BAR : ground);
        WebSettings settings = web.getSettings();
        settings.setDomStorageEnabled(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setSupportMultipleWindows(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(t.document != null);   // only a tab showing a document another app shared
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if (t.incognito) settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        if (WebViewFeature.isFeatureSupported(WebViewFeature.REQUESTED_WITH_HEADER_ALLOW_LIST)) {
            // Stop WebView from naming this app to every site in an X-Requested-With header.
            try {
                WebSettingsCompat.setRequestedWithHeaderOriginAllowList(settings, Collections.<String>emptySet());
            } catch (RuntimeException ignored) { }
        }
        t.web = web;
        applyWebSettings(t);

        // The new-tab page's search box calls FableHost.go(text) (desktop
        // widths only). Visible to every page, but all it can do is navigate
        // the tab it runs in.
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public void go(final String query) {
                ui.post(() -> { if (t.web != null && query != null) navigate(t, query); });
            }
        }, "FableHost");

        web.setWebViewClient(new WebViewClient() {
            // Runs on a WebView network thread: only thread-safe state is touched.
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if ("content".equals(request.getUrl().getScheme()) && !url.equals(t.document)) {
                    // No other content:// URI, even in the tab of a shared document.
                    return new WebResourceResponse("text/plain", "utf-8", 403, "Forbidden", Collections.<String, String>emptyMap(), new ByteArrayInputStream(new byte[0]));
                }
                if (request.isForMainFrame()) {
                    t.pageUrl = url;   // the document itself is never blocked
                    Core.sniffClear(t.id);            // a new page: start its resource list afresh
                    Core.sniffNote(t.id, url, "");    // ...which may itself be a media file opened directly
                    if (!url.startsWith(HOME)) return null;
                    int kind = !t.incognito ? 0 : privateIsolated ? 1 : 2;   // 2: private, but cookies are shared on this WebView
                    String html;
                    if (!t.incognito && launcher.isDefaultHome()) {
                        int wall = wallpaperMode();
                        html = Core.launcherPage(homeIconsJson(), launcher.appsJson(), wall);
                        if (wall != homeWallpaper) {
                            homeWallpaper = wall;
                            ui.post(MainActivity.this::refreshChrome);   // the window lets the wallpaper through, or stops
                        }
                    } else {
                        html = Core.newtabPage(kind, t.incognito ? "" : homeIconsJson());
                    }
                    byte[] page = html.getBytes(StandardCharsets.UTF_8);
                    return new WebResourceResponse("text/html", "utf-8", new ByteArrayInputStream(page));
                }
                if (url.startsWith(ICON_ENDPOINT)) {
                    // Shortcut icons for the new-tab page, and for that page only: answering any
                    // other site would let it probe which hosts have been visited. An icon we do
                    // not have yet is fetched in the background; the page asks again shortly.
                    byte[] png = null;
                    if (t.pageUrl.startsWith(HOME)) {
                        String origin = request.getUrl().getQueryParameter("u");
                        png = icons.get(Icons.hostOf(origin));
                        if (png == null) icons.request(origin);
                    }
                    if (png != null) return new WebResourceResponse("image/png", null, new ByteArrayInputStream(png));
                    return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", Collections.<String, String>emptyMap(), new ByteArrayInputStream(new byte[0]));
                }
                if (url.startsWith(APP_ICON_ENDPOINT) || url.startsWith(HOME_LAUNCH) || url.startsWith(HOME_SET) || url.startsWith(HOME_INFO)) {
                    return homeRequest(t, request.getUrl());
                }
                awaitAds();   // the first page of a start may ask before the list is in
                if (Core.shouldBlock(url, t.pageUrl)) {
                    return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
                }
                // Resource sniffing: players fetch media with Range requests; the core decides what to keep.
                java.util.Map<String, String> headers = request.getRequestHeaders();
                boolean ranged = headers != null && (headers.containsKey("Range") || headers.containsKey("range"));
                Core.sniffNote(t.id, url, ranged ? "range" : "");
                return null;
            }

            @Override public void onPageStarted(WebView view, String url, Bitmap favicon) {
                t.pageUrl = url == null ? "" : url;
                t.url = shown(url);
                if (t == addressHeld) addressHeld = null;   // the bar has the load's URL now
                t.loading = true;
                t.progress = 5;
                t.icon = null;
                t.iconUri = "";
                if (t == active) refreshChrome();
            }

            @Override public void onPageFinished(WebView view, String url) {
                t.loading = false;
                t.url = shown(url);
                remember(t, view.getTitle());
                if (!t.incognito && t.document == null) saveSession();   // follows along, so a crash loses little
                if ("1".equals(Core.settingGet("block_ads"))) {
                    // Hide the ad boxes the page shows itself; the network side
                    // (Core.shouldBlock) already stops the third-party ones.
                    view.evaluateJavascript(Core.adblockScript(), null);
                }
                if (t == active) refreshChrome();
            }

            @Override public void doUpdateVisitedHistory(WebView view, String url, boolean isReload) {
                t.url = shown(url);   // also fires for in-page navigation (single-page apps)
                if (t == addressHeld) addressHeld = null;   // a jump within the page: no onPageStarted
                if (t == active) refreshChrome();
            }

            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (Core.blockExternalApp(url)) {
                    // The page tried to leave the browser for another app (an
                    // app store, or a custom scheme) and the setting says no.
                    toast(Core.tr("external_app_blocked"));
                    return true;
                }
                String scheme = request.getUrl().getScheme();
                if ("http".equals(scheme) || "https".equals(scheme)) return false;
                if ("tel".equals(scheme) || "mailto".equals(scheme)) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, request.getUrl())); } catch (RuntimeException ignored) { }
                }
                return true;   // other schemes (intent:, market:, ...) are not followed
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int percent) {
                t.progress = percent;
                if (t == active && t.loading) progress.setScaleX(Math.max(0.08f, percent / 100f));
            }

            @Override public void onReceivedTitle(WebView view, String title) {
                if (t.pageUrl.startsWith(HOME)) t.title = Core.tr("newtab");
                else t.title = TextUtils.isEmpty(title) ? t.url : title;
                remember(t, title);
            }

            @Override public void onReceivedIcon(WebView view, Bitmap icon) {
                if (t.pageUrl.startsWith(HOME)) return;
                t.icon = icon;
                t.iconUri = Icons.dataUri(icon);
                if (!t.incognito) icons.offer(Icons.hostOf(t.pageUrl), icon);   // private tabs leave no icon behind
            }

            @Override public void onReceivedTouchIconUrl(WebView view, String iconUrl, boolean precomposed) {
                // The page's home-screen icon is larger and sharper than its favicon: prefer it for tiles.
                if (!t.incognito && !t.pageUrl.startsWith(HOME)) icons.fetchLater(Icons.hostOf(t.pageUrl), iconUrl);
            }

            // target=_blank and window.open(): a tab of our own, same privacy mode.
            @Override public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                if (!isUserGesture) return false;   // no pop-ups the user did not ask for
                Tab opened = addTab(t.incognito);
                ((WebView.WebViewTransport) resultMsg.obj).setWebView(opened.web);
                resultMsg.sendToTarget();
                activate(opened);
                return true;
            }

            // A page going fullscreen (a video's fullscreen button) shows its view over the whole app.
            @Override public void onShowCustomView(View view, WebChromeClient.CustomViewCallback callback) {
                fullscreen.show(view, callback);
            }

            @Override public void onHideCustomView() {
                fullscreen.hide();
            }
        });

        // Find in page: the count goes to the panel's find view (matches count from 1 there).
        web.setFindListener((ordinal, count, done) -> {
            if (done && t == active && panelOpen) runInPanel("Fable.find(" + (count > 0 ? ordinal + 1 : 0) + "," + count + ")");
        });
        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            // A typed address that turned out to be a file: no page comes, so the bar shows the page again.
            if (t == addressHeld) {
                addressHeld = null;
                if (t == active) refreshChrome();
            }
            download(web, t.incognito, url, userAgent, contentDisposition, mimeType, t.pageUrl);
        });

        stage.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    /** Hand a file to the system download manager (it shows progress in the notification shade). */
    private void download(WebView source, boolean incognito, String url, String userAgent, String contentDisposition, String mimeType, String referer) {
        try {
            String name = URLUtil.guessFileName(url, contentDisposition, mimeType);
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            if (!TextUtils.isEmpty(mimeType)) request.setMimeType(mimeType);
            request.addRequestHeader("User-Agent", TextUtils.isEmpty(userAgent) ? userAgent() : userAgent);
            if (referer != null && referer.startsWith("http") && !referer.startsWith(HOME)) request.addRequestHeader("Referer", referer);   // many media servers insist on it
            CookieManager jar = WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)
                    ? WebViewCompat.getProfile(source).getCookieManager() : CookieManager.getInstance();
            String cookies = jar.getCookie(url);
            if (cookies != null) request.addRequestHeader("Cookie", cookies);
            request.setTitle(name);
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            if (Build.VERSION.SDK_INT >= 29) request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            else request.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, name);
            long id = ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(request);
            if (!incognito) downloads.remember(id);
            toast(Core.tr("dl_start", name));
        } catch (RuntimeException e) {
            toast(Core.tr("dl_fail"));
        }
    }

    /**
     * Resource sniffing, the part the network cannot show: ask the page for its
     * media elements and large images, pass them to the core, and let an open
     * sniffing sheet redraw.
     */
    private void scanPageForResources() {
        final Tab t = active;
        if (t == null || t.web == null) return;
        t.web.evaluateJavascript(Core.sniffJs(), result -> {
            boolean added = false;
            try {
                JSONArray found = new JSONArray(result);
                for (int i = 0; i < found.length(); i++) {
                    JSONArray pair = found.getJSONArray(i);
                    added |= Core.sniffNote(t.id, pair.getString(1), pair.getString(0));
                }
            } catch (org.json.JSONException | RuntimeException notAList) {
                return;   // the page blocked the script or returned something else
            }
            if (added && panelOpen) runInPanel("Fable.refresh('sniff')");
        });
    }

    /** Record the visit in the history, unless the tab is private or shows one of our own pages. */
    private void remember(Tab t, String title) {
        if (t.incognito || t.url.isEmpty() || !(t.url.startsWith("http://") || t.url.startsWith("https://"))) return;
        boolean named = !TextUtils.isEmpty(title) && !title.startsWith("http") && !t.url.contains(title);
        Core.historyAdd(t.url, named ? title : "", System.currentTimeMillis());
    }

    // ---- bookmarks ---------------------------------------------------------

    /** The bookmark id of the tab's page, 0 when it has none (private tabs and non-web pages never do). */
    long bookmarkId(Tab t) {
        if (t == null || t.incognito || t.document != null || !isWebUrl(t.url)) return 0;
        String id = Core.panelQuery("bookmarkId", t.url, 0);
        try { return id == null ? 0 : Long.parseLong(id); } catch (NumberFormatException e) { return 0; }
    }

    void toggleBookmark() {
        Tab t = active;
        if (t == null || t.incognito || t.document != null || !isWebUrl(t.url)) return;
        long id = bookmarkId(t);
        if (id != 0) {
            Core.panelQuery("bookmarkRemove", String.valueOf(id), 0);
            toast(Core.tr("removed_bookmark"));
        } else {
            String title = t.title == null ? "" : t.title.replace('\n', ' ');
            Core.panelQuery("bookmarkAdd", t.url + "\n" + title, 0);
            toast(Core.tr("added_bookmark"));
        }
        if (panelOpen) runInPanel("Fable.update(" + panelState() + ")");
    }

    /** Import a Chrome/Firefox bookmark file (HTML) chosen in the system picker. */
    void pickBookmarkFile() {
        Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("text/html")
                .putExtra(Intent.EXTRA_MIME_TYPES, new String[] {"text/html", "application/xhtml+xml", "application/octet-stream"});
        try {
            startActivityForResult(pick, PICK_BOOKMARKS);
        } catch (android.content.ActivityNotFoundException none) {
            toast(Core.tr("bookmark_import_failed"));
        }
    }

    /** Export the bookmarks as an HTML file Chrome and Firefox can import, where the user chooses. */
    void saveBookmarkFile() {
        Intent save = new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("text/html")
                .putExtra(Intent.EXTRA_TITLE, "bookmarks.html");
        try {
            startActivityForResult(save, SAVE_BOOKMARKS);
        } catch (android.content.ActivityNotFoundException none) {
            toast(Core.tr("bookmark_export_failed"));
        }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        final Uri uri = result == RESULT_OK && data != null ? data.getData() : null;
        if (uri == null || (request != PICK_BOOKMARKS && request != SAVE_BOOKMARKS)) return;
        final android.content.ContentResolver files = getContentResolver();
        final boolean importing = request == PICK_BOOKMARKS;
        metaLookups.execute(() -> {   // file access off the UI thread
            String message;
            if (importing) {
                String html = readBookmarkFile(files, uri);
                message = html == null ? Core.tr("bookmark_import_failed")
                        : Core.tr("bookmark_imported", Core.panelQuery("bookmarkImport", html, 0));
            } else {
                message = writeBookmarkFile(files, uri, Core.panelQuery("bookmarkExport", "", 0))
                        ? Core.tr("exported_bookmark") : Core.tr("bookmark_export_failed");
            }
            ui.post(() -> {
                toast(message);
                if (importing && panelOpen) runInPanel("Fable.refresh('bookmarks')");
            });
        });
    }

    /** The picked file as text, or null when it cannot be read or is too big to be a bookmark file. */
    static String readBookmarkFile(android.content.ContentResolver files, Uri uri) {
        try (java.io.InputStream in = files.openInputStream(uri)) {
            if (in == null) return null;
            java.io.ByteArrayOutputStream bytes = new java.io.ByteArrayOutputStream();
            byte[] buffer = new byte[16384];
            int n;
            while ((n = in.read(buffer)) != -1) {
                bytes.write(buffer, 0, n);
                if (bytes.size() > BOOKMARK_FILE_MAX) return null;
            }
            return new String(bytes.toByteArray(), java.nio.charset.StandardCharsets.UTF_8);
        } catch (java.io.IOException | RuntimeException e) {   // unreadable, gone, refused, or a provider that throws
            return null;
        }
    }

    static boolean writeBookmarkFile(android.content.ContentResolver files, Uri uri, String html) {
        if (html == null) return false;
        try (java.io.OutputStream out = files.openOutputStream(uri, "wt")) {
            if (out == null) return false;
            out.write(html.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            return true;
        } catch (java.io.IOException | RuntimeException e) {   // unreadable, gone, refused, or a provider that throws
            return false;
        }
    }

    void toggleReader() {
        if (active == null || active.web == null) return;
        active.web.evaluateJavascript(Core.readerScript(), result -> {
            if ("\"none\"".equals(result)) toast(Core.tr("no_article"));
            else if ("\"on\"".equals(result)) toast(Core.tr("reader_on"));
            else if (!"\"off\"".equals(result)) toast(Core.tr("reader_unsupported"));
        });
    }

    // ---- the panel: menu, tabs, settings, history --------------------------

    private void ensurePanel() {
        if (panel != null) return;
        panel = new WebView(this);
        panel.setBackgroundColor(0x00000000);   // the page draws its own scrim and sheet
        panel.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings s = panel.getSettings();
        s.setJavaScriptEnabled(true);
        s.setBlockNetworkLoads(true);           // this view shows our bundled page and nothing else
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setTextZoom(100);
        panel.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return true;                    // never navigate away from the bundled page
            }

            @Override public void onPageFinished(WebView view, String url) {
                panelReady = true;
                if (pendingPanelScript != null) {
                    panel.evaluateJavascript(pendingPanelScript, null);
                    pendingPanelScript = null;
                }
            }
        });
        panel.addJavascriptInterface(new PanelBridge(), "FableUI");
        panel.setVisibility(View.GONE);
        root.addView(panel, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        panel.loadDataWithBaseURL(null, Core.panelPage(), "text/html", "utf-8", null);
    }

    private String logo;

    /** The Fable logo (the icon pack's), the icon of the new-tab page. */
    private String logo() {
        if (logo == null) logo = Core.logoUri();
        return logo;
    }

    /** What the panel needs to know about the browser right now, as JSON. */
    String panelState() {   // package-private for the tests
        try {
            JSONArray list = new JSONArray();
            for (Tab t : tabs) {
                String icon = t.incognito ? t.iconUri : t.pageUrl.startsWith(HOME) ? logo() : !t.iconUri.isEmpty() ? t.iconUri : icons.dataUri(Icons.hostOf(t.url));
                list.put(new JSONObject().put("id", t.id).put("title", t.title).put("url", t.url).put("icon", icon)
                        .put("active", t == active).put("private", t.incognito).put("asleep", t.web == null));
            }
            JSONObject o = new JSONObject();
            o.put("tabs", list);
            o.put("incognito", inPrivate());
            o.put("active", active == null ? 0 : active.id);
            o.put("url", active == null ? "" : active.url);
            o.put("title", active == null ? "" : active.title);
            o.put("web", active != null && !active.incognito && !active.url.isEmpty());
            o.put("desktop", "desktop".equals(Core.settingGet("ua_mode")));
            o.put("blocked", Core.blockedCount());
            o.put("sniffed", active == null ? 0 : Core.sniffCount(active.id));
            o.put("version", Core.version());
            o.put("bookmarked", bookmarkId(active));
            boolean home = launcher.isDefaultHome();
            o.put("caps", new JSONObject().put("homeScreen", home).put("openDownload", true)
                    .put("bookmarks", true).put("restoreTabs", true).put("scan", cameraAvailable));   // home-screen settings only while Fable is the home app
            if (home && wallpaperChangeable()) {
                o.put("wallpaper", new JSONObject().put("ground", groundWallpaperUp()).put("kept", keptWallpaper().exists()).put("canKeep", canKeepWallpaper()));
            }
            return o.toString();
        } catch (org.json.JSONException impossible) {
            return "{}";
        }
    }

    /** Fetch the built-in community ad lists (at most 8 MiB each) and hand
     * them to the core, concatenated. A source that fails is skipped. */
    private void fetchAdList() {
        if (adListUpdating) return;
        adListUpdating = true;
        new Thread(() -> {
            awaitAds();   // an update must land after the start-up load, never under it
            try {
                ByteArrayOutputStream all = new ByteArrayOutputStream();
                boolean any = false;
                for (String url : Core.adsUpdateSources().split("\n")) {
                    if (url.isEmpty()) continue;
                    try {
                        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                        c.setConnectTimeout(10000);
                        c.setReadTimeout(10000);
                        if (c.getResponseCode() == HttpURLConnection.HTTP_OK) {
                            try (InputStream in = c.getInputStream();
                                 ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                                byte[] buf = new byte[8192];
                                int n, total = 0;
                                boolean tooBig = false;
                                while ((n = in.read(buf)) != -1) {
                                    if (total + n > 8 * 1024 * 1024 + 1) { tooBig = true; break; }
                                    out.write(buf, 0, n);
                                    total += n;
                                }
                                if (!tooBig) { any = true; all.write(out.toByteArray()); all.write('\n'); }
                            }
                        }
                        c.disconnect();
                    } catch (Exception ignored) {
                        // That source failed: the others still update the list.
                    }
                }
                if (any) Core.adsUpdateApply(all.toByteArray());
            } catch (Exception ignored) {
                // No network or a bad download: the old list stays.
            }
            ui.post(() -> adListUpdating = false);
        }).start();
    }

    /**
     * Wait (on a WebView or worker thread, never the main one in use) until the
     * start-up ad list is loaded. Parsing takes milliseconds; the cap only keeps
     * a failure from holding requests up.
     */
    void awaitAds() {
        try {
            adsLoaded.await(3, java.util.concurrent.TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private void runInPanel(String script) {
        if (panelReady) panel.evaluateJavascript(script, null);
        else pendingPanelScript = script;
    }

    void showPanel(String view) {
        leaveAddress();
        ensurePanel();
        panelOpen = true;
        panel.setVisibility(View.VISIBLE);
        panel.requestFocus();
        runInPanel("Fable.show(" + JSONObject.quote(view) + "," + panelState() + ")");
    }

    /** Actions the panel asks for; always on the UI thread. */
    void onPanelAction(String name, String arg) {
        switch (name) {
            case "hidden":
                panelOpen = false;
                panel.setVisibility(View.GONE);
                if (active != null && active.web != null) active.web.requestFocus();
                break;
            case "newTab":
                newTab("", false);
                break;
            case "newPrivate":
                newTab("", true);
                break;
            case "enterPrivate":
                enterPrivate();
                break;
            case "exitPrivate":
                exitPrivate();
                if (panelOpen) runInPanel("Fable.update(" + panelState() + ")");
                break;
            case "switchTab": {
                Tab t = find(parse(arg));
                if (t != null) activate(t);
                break;
            }
            case "closeTab":
                close(find(parse(arg)));
                if (panelOpen) runInPanel("Fable.update(" + panelState() + ")");
                break;
            case "open":
                if (active != null && active.web != null) navigate(active, arg);
                else newTab(arg, inPrivate());
                break;
            case "reader":
                toggleReader();
                break;
            case "bookmarkToggle":   // the star in the menu: the page in front
                toggleBookmark();
                break;
            case "bookmarkImportPick":
                pickBookmarkFile();
                break;
            case "bookmarkExport":
                saveBookmarkFile();
                break;
            case "desktop": {
                boolean on = "desktop".equals(Core.settingGet("ua_mode"));
                Core.settingSet("ua_mode", on ? "default" : "desktop");
                onSettingChanged("ua_mode");
                toast(Core.tr(on ? "mobile_on" : "desktop_on"));
                break;
            }
            case "clear":
                clearData(arg);
                break;
            case "sniffScan":
                scanPageForResources();
                break;
            case "scan":   // kept for older panels; the entry is the blank address bar's camera button now
                startScan();
                break;
            case "systemDownloads":
                try { startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)); }
                catch (RuntimeException e) { toast(Core.tr("dl_manage_error")); }
                break;
            case "downloadOpen":
                if (!downloads.open(this, arg)) toast(Core.tr("dl_manage_error"));
                break;
            case "download":
                if (active != null && active.web != null) download(active.web, active.incognito, arg, null, null, null, active.pageUrl);
                else toast(Core.tr("dl_fail"));
                break;
            case "copy":
                ((ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("link", arg));
                toast(Core.tr("link_copied"));
                break;
            case "copyText":
                ((ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Fable", arg));
                toast(Core.tr("m_copied"));
                break;
            case "system": {   // everything else for the metadata sheet; window facts here, the rest off the UI thread
                final org.json.JSONObject fromWindow = SystemInfo.window(this);
                metaLookups.execute(() -> {
                    final String info = SystemInfo.collect(this, fromWindow);
                    ui.post(() -> { if (panel != null) runInPanel("Fable.system(" + info + ")"); });
                });
                break;
            }
            case "ip": {   // public IP for the metadata sheet, looked up off the UI thread
                final String ua = userAgent();
                metaLookups.execute(() -> {
                    final String info = Meta.lookupIp(ua);
                    ui.post(() -> { if (panel != null) runInPanel("Fable.ip(" + info + ")"); });
                });
                break;
            }
            case "openNew":
                newTab(arg, active != null && active.incognito);
                break;
            case "toast":
                toast(arg);
                break;
            case "wallpaper":
                if ("ground".equals(arg)) setGroundWallpaper();
                else if ("restore".equals(arg)) restoreWallpaper();
                else if ("pick".equals(arg)) pickWallpaper();
                break;
            case "find":   // the panel's find view, as the term is typed
                if (active != null && active.web != null) {
                    if (arg.isEmpty()) active.web.clearMatches();
                    else active.web.findAllAsync(arg);
                }
                break;
            case "findNext":
                if (active != null && active.web != null) active.web.findNext(true);
                break;
            case "findPrev":
                if (active != null && active.web != null) active.web.findNext(false);
                break;
            case "findStop":
                if (active != null && active.web != null) active.web.clearMatches();
                break;
            default:
                break;
        }
    }

    private static int parse(String number) {
        try { return Integer.parseInt(number); } catch (NumberFormatException e) { return -1; }
    }

    // ---- the QR scanner ----------------------------------------------------

    /** The blank address bar's camera button: ask for the camera once, then show the scanner. */
    private void startScan() {
        if (scanner != null && scanner.isShowing()) return;
        if (!cameraAvailable) {
            toast(Core.tr("scan_camera_unavailable"));
            return;
        }
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, SCAN_QR);
            return;
        }
        showScanner();
    }

    private void showScanner() {
        if (scanner == null) {
            scanner = new QrScanner(this, new QrScanner.Listener() {
                @Override public void onQr(String text) { scanned(text); }
                @Override public void onCancel() { }
                @Override public void onUnavailable() { toast(Core.tr("scan_camera_unavailable")); }
            });
        }
        scanner.show();
    }

    /** Open what a scan found in the tab in front (a new tab only when there is none). */
    private void openScanned(String input) {
        if (active != null && active.web != null) navigate(active, input);
        else newTab(input, inPrivate());
    }

    @Override public void onRequestPermissionsResult(int request, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(request, permissions, results);
        if (request != SCAN_QR) return;
        if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) showScanner();
        else toast(Core.tr("scan_camera_unavailable"));
    }

    /**
     * A scanned payload. A web address opens in the tab in front; anything else
     * (a Wi-Fi login, a contact card, plain text) is shown first, so nothing in
     * it reaches a search engine unless the user asks.
     */
    void scanned(String text) {
        final String found = text == null ? "" : text.trim();
        if (found.isEmpty()) {
            toast(Core.tr("scan_unknown"));
            return;
        }
        if (isWebUrl(found)) {
            openScanned(found);
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle(Core.tr("scan_text"))
                .setMessage(found)
                .setPositiveButton(Core.tr("scan_search"), (d, w) -> openScanned(found))
                .setNegativeButton(Core.tr("copy"), (d, w) -> {
                    ((ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Fable", found));
                    toast(Core.tr("m_copied"));
                })
                .setNeutralButton(Core.tr("cancel"), null)
                .show();
    }

    /**
     * The privileged bridge. It exists only inside the panel view, which loads
     * nothing but the page bundled in the core. Methods are called on a
     * WebView thread: queries go straight to the (thread-safe) core, anything
     * touching views is posted to the UI thread.
     */
    final class PanelBridge {
        @JavascriptInterface public String query(String name, String arg) {
            if (name == null || arg == null) return "";
            int split = arg.indexOf('\n');
            switch (name) {
                case "get":
                    return Core.settingGet(arg);
                case "set": {
                    if (split < 0) return "";
                    final String key = arg.substring(0, split), value = arg.substring(split + 1);
                    if (!Core.panelSettingAllowed(key, value)) return "";   // only the panel's own keys, bounded values
                    Core.settingSet(key, value);
                    ui.post(() -> onSettingChanged(key));
                    return "";
                }
                case "history":
                    return Core.historyJson(arg, 300);
                case "icon":   // stored icon of a host as a data: URI; never fetches
                    return icons.dataUri(arg);
                case "sniff":  // resources found on the page in front
                    return Core.sniffJson(activeId);
                case "device": // facts for the metadata sheet that pages cannot read
                    return Meta.device(MainActivity.this, userAgent());
                case "historyDelete":
                    if (split < 0) return "";
                    try { Core.historyDelete(arg.substring(split + 1), Long.parseLong(arg.substring(0, split))); } catch (NumberFormatException ignored) { }
                    return "";
                case "downloads": return downloads.list();
                case "downloadForget": return downloads.forget(arg) ? "" : "dl_manage_error";
                case "historyClear":
                    if (!Core.historyClear()) return "history_clear_failed";
                    icons.clear();
                    return "";
                default: {
                    // bookmarks, the session snapshot, ...: the core answers these the same way everywhere
                    String answer = Core.panelQuery(name, arg, activeId);
                    return answer == null ? "" : answer;
                }
            }
        }

        @JavascriptInterface public void act(final String name, final String arg) {
            if (name != null) ui.post(() -> onPanelAction(name, arg == null ? "" : arg));
        }
    }
}
