// What only the iOS shell can see, for the metadata sheet. The core's own
// collector knows nothing on iOS (no /proc, no sysctl tables it reads there),
// so these extras carry nearly everything; for the same key the last one counts.
import UIKit
import WebKit
import Metal

enum DeviceFacts {
    /// "iPhone15,2"; in the Simulator, the model it pretends to be.
    static var machine: String {
        if let simulated = ProcessInfo.processInfo.environment["SIMULATOR_MODEL_IDENTIFIER"] { return simulated }
        var u = utsname()
        uname(&u)
        return withUnsafeBytes(of: &u.machine) { raw in String(decoding: raw.prefix { $0 != 0 }, as: UTF8.self) }
    }

    static var kernel: String {
        var u = utsname()
        uname(&u)
        let release = withUnsafeBytes(of: &u.release) { raw in String(decoding: raw.prefix { $0 != 0 }, as: UTF8.self) }
        return "Darwin \(release)"
    }

    static func sysctlString(_ name: String) -> String {
        var size = 0
        guard sysctlbyname(name, nil, &size, nil, 0) == 0, size > 0 else { return "" }
        var buffer = [CChar](repeating: 0, count: size)
        guard sysctlbyname(name, &buffer, &size, nil, 0) == 0 else { return "" }
        return String(cString: buffer)
    }

    static var os: String { "\(UIDevice.current.systemName) \(UIDevice.current.systemVersion)" }

    /// WebKit's version, e.g. 618.1.15 (iOS prefixes the major number with the OS release).
    static var webkitVersion: String {
        var v = Bundle(for: WKWebView.self).object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? ""
        if let dot = v.firstIndex(of: "."), v.distance(from: v.startIndex, to: dot) > 3 {
            v = String(v[v.index(dot, offsetBy: -3)...])
        }
        return v
    }

    static func screen(_ window: UIWindow?) -> [String: Any] {
        let screen = window?.windowScene?.screen ?? UIScreen.main
        var d: [String: Any] = [:]
        let px = screen.nativeBounds.size   // pixels, portrait
        d["w"] = Int(px.width)
        d["h"] = Int(px.height)
        d["refresh"] = screen.maximumFramesPerSecond
        d["scale"] = screen.nativeScale
        d["name"] = UIDevice.current.localizedModel
        d["wideGamut"] = screen.traitCollection.displayGamut == .P3
        if #available(iOS 16.0, *), screen.potentialEDRHeadroom > 1 { d["hdr"] = ["EDR"] }
        return d
    }

    static func battery() -> [String: Any]? {
        let device = UIDevice.current
        device.isBatteryMonitoringEnabled = true
        guard device.batteryState != .unknown, device.batteryLevel >= 0 else { return nil }   // the Simulator has none
        var b: [String: Any] = ["level": Int((device.batteryLevel * 100).rounded())]
        switch device.batteryState {
        case .charging: b["status"] = "charging"; b["plugged"] = "ac"
        case .full: b["status"] = "full"; b["plugged"] = "ac"
        default: b["status"] = "discharging"; b["plugged"] = "none"
        }
        b["tech"] = "Li-ion"
        return b
    }

    static func storage() -> [String: Any] {
        var s: [String: Any] = [:]
        let home = URL(fileURLWithPath: NSHomeDirectory())
        if let v = try? home.resourceValues(forKeys: [.volumeTotalCapacityKey, .volumeAvailableCapacityForImportantUsageKey]) {
            if let total = v.volumeTotalCapacity { s["total"] = total }
            if let free = v.volumeAvailableCapacityForImportantUsage { s["free"] = free }
        }
        return s
    }

    static func json(_ d: [String: Any]) -> String {
        guard JSONSerialization.isValidJSONObject(d), let data = try? JSONSerialization.data(withJSONObject: d) else { return "{}" }
        return String(data: data, encoding: .utf8) ?? "{}"
    }

    /// The brief page (fable_device_info).
    static func deviceExtras(window: UIWindow?) -> String {
        var d: [String: Any] = ["manufacturer": "Apple", "model": machine, "os": os, "kernel": kernel,
                                "ram": ProcessInfo.processInfo.physicalMemory, "engine": "WebKit \(webkitVersion)", "cookies": true]
        if let gpu = MTLCreateSystemDefaultDevice()?.name, !gpu.isEmpty { d["gpu"] = gpu; d["gpuVendor"] = "Apple" }
        let s = screen(window)
        d["screenW"] = s["w"]
        d["screenH"] = s["h"]
        d["refresh"] = s["refresh"]
        if let b = battery() { d["battery"] = b["level"]; d["charging"] = (b["status"] as? String) == "charging" }
        let st = storage()
        if let total = st["total"] { d["storageTotal"] = total; d["storageFree"] = st["free"] ?? 0 }
        return json(d)
    }

    /// The sections (fable_system_info): appended after the core's, so these win.
    static func systemExtras(window: UIWindow?) -> String {
        let uptime = UInt64(ProcessInfo.processInfo.systemUptime * 1000)
        var system: [String: Any] = ["manufacturer": "Apple", "brand": "Apple", "model": machine, "deviceName": UIDevice.current.name,
                                     "os": os, "build": sysctlString("kern.osversion"), "kernel": kernel,
                                     "kernelFull": sysctlString("kern.version"), "locales": Locale.preferredLanguages.joined(separator: ", "),
                                     "uptime": uptime]
        system["bootTime"] = UInt64(Date().timeIntervalSince1970 * 1000) - uptime
        var d: [String: Any] = ["system": system, "display": screen(window), "storage": storage(),
                                "memory": ["total": ProcessInfo.processInfo.physicalMemory]]
        if let b = battery() { d["battery"] = b }
        return json(d)
    }
}
