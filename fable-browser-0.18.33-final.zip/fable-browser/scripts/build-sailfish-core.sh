#!/usr/bin/env bash
# Cross-build the Fable Rust core (static library) for a Sailfish OS target.
#
# The Sailfish SDK compiles with a Scratchbox 2 (sb2) toolchain. Rust can target
# the same ARM ABIs; we point Cargo at the SDK's cross linker and let build.rs
# assemble the optional FNV-1a hash with the matching cross C compiler.
#
# Usage:
#   ./scripts/build-sailfish-core.sh armv7hl      # 32-bit ARM (SailfishOS-*-armv7hl kit)
#   ./scripts/build-sailfish-core.sh aarch64      # 64-bit ARM  (SailfishOS-*-aarch64 kit)
#
# Environment (auto-detected where possible):
#   SAILFISH_SDK   path to SDK, default $HOME/SailfishOS
#   FABLE_SRC      path to the fable-browser source tree (contains core/), default
#                  the tree this script is in
#   RUSTUP_TOOLCHAIN  Rust toolchain (rust-toolchain.toml pins 1.100.0)
#
# A static library is not linked, so Cargo needs no cross linker; the cross C
# compiler matters only with --features asm. Both targets build on any Linux
# with their Rust std (rustup target add ...): checked for 0.18.23.

set -euo pipefail

TARGET_ARCH="${1:-armv7hl}"
FABLE_SRC="${FABLE_SRC:-$(cd "$(dirname "$0")/.." && pwd)}"
SAILFISH_SDK="${SAILFISH_SDK:-$HOME/SailfishOS}"
OUT_DIR="$FABLE_SRC/shell/sailfish/3rdparty/$TARGET_ARCH"

case "$TARGET_ARCH" in
  armv7hl)
    RUST_TARGET="armv7-unknown-linux-gnueabihf"
    CROSS_CC="armv7hl-meego-linux-gnueabi-gcc"
    ;;
  aarch64)
    RUST_TARGET="aarch64-unknown-linux-gnu"
    CROSS_CC="aarch64-meego-linux-gnu-gcc"
    ;;
  *)
    echo "Unknown target: $TARGET_ARCH (use armv7hl or aarch64)" >&2
    exit 1
    ;;
esac

echo "==> Fable core -> $RUST_TARGET"
echo "    source : $FABLE_SRC/core"
echo "    output : $OUT_DIR"

# The SDK exposes its cross toolchain through sb2; when building inside the
# build engine, the plain cross-gcc is on PATH. Fall back to the common sb2
# wrapper if present.
if command -v sb2 >/dev/null 2>&1; then
  CC_WRAPPER="sb2 -t SailfishOS-$TARGET_ARCH $CROSS_CC"
else
  CC_WRAPPER="$CROSS_CC"
fi

export FABLE_CC="$CC_WRAPPER"
export FABLE_AR="${CROSS_CC%gcc}ar"

# Install the Rust std for the target if needed.
rustup target add "$RUST_TARGET" 2>/dev/null || true

# Cross-compile the static library (no default features: pure Rust hash keeps
# the toolchain requirements minimal; pass `asm` to use the fast hash).
(
  cd "$FABLE_SRC/core"
  cargo build --release --target "$RUST_TARGET"
)

mkdir -p "$OUT_DIR" "$OUT_DIR/../include"
cp "$FABLE_SRC/core/target/$RUST_TARGET/release/libfable_core.a" "$OUT_DIR/"
cp "$FABLE_SRC/core/include/fable_core.h" "$OUT_DIR/../include/"

echo "==> Done: $OUT_DIR/libfable_core.a"
echo "    Now build the RPM with: sfdk build"
