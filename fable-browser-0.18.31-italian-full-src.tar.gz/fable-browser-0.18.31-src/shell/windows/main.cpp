// Fable for Windows: Win32 + WebView2 shell.
//
// Each window is a row of native controls (back, forward, reload, address
// bar, tab strip, new tab, close tab, menu) above one WebView2 per tab. The
// menu button opens the same panel as on Android, Linux and macOS
// (ui/panel.html: menu, settings, history, resource list, metadata) in a
// popup of its own, talking to this shell by messages.
//
// Private windows, as in Chrome: WebView2's InPrivate mode (cookies, cache and
// storage kept apart and dropped when the last private window closes), no
// history, a dark title bar, and kept out of screenshots unless allowed.
// Logic lives in the Rust core (fable_core.lib). Idle background tabs are
// suspended with ICoreWebView2_3::TrySuspend and resume when shown again.
//
// Ctrl+T tab · Ctrl+N window · Ctrl+Shift+N private window · Ctrl+W close tab ·
// Ctrl+L address · Ctrl+R/F5 reload · Alt+←/→ · Ctrl+H history · Alt+F menu ·
// Ctrl+Tab next tab

#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#define NOMINMAX
#include <windows.h>
#include <commctrl.h>
#include <dwmapi.h>
#include <shlobj.h>
#include <shobjidl.h>
#include <shellapi.h>
#include <shlwapi.h>
#include <urlmon.h>
#include <winhttp.h>
#include <wrl.h>

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdlib>
#include <memory>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>

#include "WebView2.h"
#include "fable_core.h"

#pragma comment(linker, "/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' " \
                        "version='6.0.0.0' processorArchitecture='*' publicKeyToken='6595b64144ccf1df' language='*'\"")

using Microsoft::WRL::Callback;
using Microsoft::WRL::ComPtr;

namespace {

enum : int { ID_BACK = 100, ID_FORWARD, ID_RELOAD, ID_EDIT, ID_TABS, ID_NEW, ID_CLOSE, ID_MENU, ID_HOME };
enum : UINT { WM_APP_IP = WM_APP + 1, WM_APP_DOWNLOADED, WM_APP_RETIRE };
const UINT_PTR kSleepTimer = 1, kToastTimer = 2;
const UINT kSleepCheckMs = 30 * 1000;
const int kPanelWidth = 400;
const wchar_t kAndroidUa[] = L"Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36";
const wchar_t kIphoneUa[] = L"Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1";
const wchar_t kIpadUa[] = L"Mozilla/5.0 (iPad; CPU OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1";
const wchar_t kChromeWinUa[] = L"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";
const wchar_t kChromeMacUa[] = L"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";
const wchar_t kSafariMacUa[] = L"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Safari/605.1.15";
const wchar_t kFirefoxUa[] = L"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0";
const wchar_t kEdgeUa[] = L"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0";
const COLORREF kCream = RGB(0xFB, 0xF2, 0xE8), kDark = RGB(0x21, 0x16, 0x11), kDarkCard = RGB(0x33, 0x24, 0x1D), kLight = RGB(0xFB, 0xEF, 0xE4);

struct Win;

struct Tab {
    uint32_t id = 0;                       // id in the core's tab table
    Win* win = nullptr;
    ComPtr<ICoreWebView2Controller> controller;
    ComPtr<ICoreWebView2> view;            // null until the controller is ready
    std::wstring url;                      // shown in the address bar
    std::wstring title;
    std::wstring pending;                  // input to load once the view exists
    std::wstring navigating;               // URL of the top-level navigation in flight
    bool homeNext = false;                 // the next navigation is our NavigateToString of the new-tab page
    bool home = false;                     // the document shown is that page: only it may use the bridge
    bool homeBefore = false;               // `home` before the navigation in flight, for one that does not commit
    bool deferred = false;                 // restored in the background: loads `pending` when first shown
    bool findHooked = false;               // its find session reports match counts to the panel
    // The new-tab document's own URL, exactly: as our navigation started, and as it
    // finished (WebView2 may write a NavigateToString document either way). A message
    // must come from a document with one of these URLs (Source of the sender).
    std::wstring homeStarted, homeLoaded;
};

struct Win {
    HWND hwnd = nullptr, edit = nullptr, strip = nullptr;
    HWND back = nullptr, forward = nullptr, home = nullptr, reload = nullptr, plus = nullptr, close = nullptr, menu = nullptr;
    HWND toast = nullptr;
    bool priv = false;
    std::vector<std::unique_ptr<Tab>> tabs;
    int active = -1;
};

std::vector<std::unique_ptr<Win>> g_wins;
Win* g_front = nullptr;                    // the window last activated
HFONT g_font, g_iconFont;   // g_iconFont: Segoe MDL2 Assets (Windows 10+), else null
HBRUSH g_creamBrush, g_darkBrush, g_darkCardBrush;
ComPtr<ICoreWebView2Environment> g_env;
FableTabs* g_core;
bool g_noImages = false;
std::unordered_map<std::string, std::wstring> g_text;   // UI strings in use

// The panel: a popup window with a WebView2 of its own.
HWND g_panel = nullptr, g_msg = nullptr;
ComPtr<ICoreWebView2Controller> g_panelController;
ComPtr<ICoreWebView2> g_panelView;
bool g_panelLoaded = false;
bool g_panelNext = false;                  // the next panel navigation is our own NavigateToString
std::wstring g_panelDocStarted, g_panelDocLoaded; // the panel document's exact URL (see Tab::homeStarted)
std::vector<std::wstring> g_panelQueue;    // scripts waiting for the panel page
std::wstring g_panelOpen;                  // the view it was opened on; empty when hidden
int g_panelHeight = 640;

// Views being closed. A WebView2 controller must not be closed or released from
// inside one of its own callbacks (Ctrl+W arrives in AcceleratorKeyPressed,
// window.close() in WindowCloseRequested): it is hidden at once and closed from
// the message loop, with the window it lived in, once the callback has returned.
std::vector<std::pair<ComPtr<ICoreWebView2Controller>, ComPtr<ICoreWebView2>>> g_retired;
std::vector<HWND> g_retiredWindows;

Win* NewWindow(bool priv);
void NewTab(Win* w, const std::wstring& input, bool background = false);
void CloseWindow(Win* w);
void ShowNewtab(Tab& tab);
void PanelRun(const std::wstring& script);
void ShowPanel(Win* w, const wchar_t* view);
void HidePanel();
void Say(Win* w, const std::wstring& text);
void SaveSession();

// ---- helpers ---------------------------------------------------------------

std::wstring Widen(const char* utf8) {
    if (!utf8 || !*utf8) return {};
    int n = MultiByteToWideChar(CP_UTF8, 0, utf8, -1, nullptr, 0);
    std::wstring out(n > 0 ? n - 1 : 0, L'\0');
    if (n > 1) MultiByteToWideChar(CP_UTF8, 0, utf8, -1, &out[0], n);
    return out;
}

std::string Narrow(const wchar_t* wide) {
    if (!wide || !*wide) return {};
    int n = WideCharToMultiByte(CP_UTF8, 0, wide, -1, nullptr, 0, nullptr, nullptr);
    std::string out(n > 0 ? n - 1 : 0, '\0');
    if (n > 1) WideCharToMultiByte(CP_UTF8, 0, wide, -1, &out[0], n, nullptr, nullptr);
    return out;
}

// A string from the core, freed.
std::string Take(char* s) {
    std::string out = s ? s : "";
    if (s) fable_string_free(s);
    return out;
}

// ---- the skin (theme://name) --------------------------------------------------------
// Normal windows draw their bar and address field in the skin's colours, and a dark skin
// gets a dark title bar; private windows keep their own dark colours whatever the skin.
COLORREF g_skinBar = RGB(0xFB, 0xF2, 0xE8), g_skinCard = RGB(0xFF, 0xFF, 0xFF), g_skinInk = RGB(0x2A, 0x1A, 0x14);
bool g_skinDark = false;
HBRUSH g_barBrush, g_cardBrush;   // painting only: the window classes keep the brush they were registered with

COLORREF SkinColour(const char* key, COLORREF fallback) {
    std::string hex = Take(fable_theme_colour(key));
    if (hex.size() != 7 || hex[0] != '#') return fallback;
    unsigned long v = strtoul(hex.c_str() + 1, nullptr, 16);
    return RGB((v >> 16) & 0xFF, (v >> 8) & 0xFF, v & 0xFF);
}

void LoadSkin() {
    g_skinBar = SkinColour("bar", g_skinBar);
    g_skinCard = SkinColour("card", g_skinCard);
    g_skinInk = SkinColour("ink", g_skinInk);
    g_skinDark = Take(fable_theme_colour("dark_ui")) == "1";
    if (g_barBrush) DeleteObject(g_barBrush);
    if (g_cardBrush) DeleteObject(g_cardBrush);
    g_barBrush = CreateSolidBrush(g_skinBar);
    g_cardBrush = CreateSolidBrush(g_skinCard);
}

// A UI string in the language in effect.
const std::wstring& T(const char* key) {
    auto hit = g_text.find(key);
    if (hit != g_text.end()) return hit->second;
    return g_text[key] = Widen(Take(fable_tr(key)).c_str());
}

std::wstring TN(const char* key, const std::wstring& n) {
    std::wstring s = T(key);
    size_t at = s.find(L"{n}");
    if (at != std::wstring::npos) s.replace(at, 3, n);
    return s;
}

std::string Setting(const char* key) { return Take(fable_setting_get(key)); }
std::string Json(const std::string& s) { return Take(fable_json_string(s.c_str())); }

// Owns a string returned by WebView2 (allocated with CoTaskMemAlloc).
struct CoString {
    LPWSTR p = nullptr;
    ~CoString() { CoTaskMemFree(p); }
    const wchar_t* get() const { return p ? p : L""; }
};

uint64_t NowMs() { return GetTickCount64(); }
uint64_t WallMs() {
    FILETIME ft;
    GetSystemTimeAsFileTime(&ft);
    ULARGE_INTEGER t{{ft.dwLowDateTime, ft.dwHighDateTime}};
    return (t.QuadPart - 116444736000000000ULL) / 10000ULL;
}
int Scale(HWND w, int px) { return MulDiv(px, static_cast<int>(GetDpiForWindow(w)), 96); }

// What WebView2 reports for a document we load with NavigateToString (the new-tab
// page, the panel). Only a hint for display: whether a document may use a bridge
// is decided by Tab::home / g_panelNext, which only our own navigations set.
bool HomeDoc(const std::wstring& url) { return url == L"about:blank" || url.rfind(L"data:text/html", 0) == 0; }
bool IsHome(const std::wstring& url) { return url.empty() || HomeDoc(url); }
bool IsWeb(const std::wstring& url) { return url.rfind(L"http://", 0) == 0 || url.rfind(L"https://", 0) == 0; }
// A message's sender (args->get_Source) is exactly the document we loaded.
bool SameDoc(const wchar_t* source, const std::wstring& started, const std::wstring& loaded) {
    return HomeDoc(source) && ((!started.empty() && started == source) || (!loaded.empty() && loaded == source));
}

Win* WinOf(HWND hwnd) { return reinterpret_cast<Win*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA)); }
Tab* Active(Win* w) { return w && w->active >= 0 && w->active < static_cast<int>(w->tabs.size()) ? w->tabs[w->active].get() : nullptr; }
Win* Front() {
    for (auto& w : g_wins) if (w.get() == g_front) return g_front;
    return g_wins.empty() ? nullptr : g_wins.back().get();
}
Tab* FrontTab() { return Active(Front()); }

Win* FrontOf(bool priv) {
    if (Win* f = Front(); f && f->priv == priv) return f;
    for (auto it = g_wins.rbegin(); it != g_wins.rend(); ++it)
        if ((*it)->priv == priv) return it->get();
    return nullptr;
}

Tab* Find(uint32_t id) {
    for (auto& w : g_wins)
        for (auto& t : w->tabs)
            if (t->id == id) return t.get();
    return nullptr;
}

int IndexIn(Win* w, Tab* t) {
    for (size_t i = 0; i < w->tabs.size(); ++i)
        if (w->tabs[i].get() == t) return static_cast<int>(i);
    return -1;
}

RECT ContentRect(Win* w) {
    RECT rc;
    GetClientRect(w->hwnd, &rc);
    rc.top = std::min(rc.bottom, static_cast<LONG>(Scale(w->hwnd, 46)));
    return rc;
}

// ---- settings ----------------------------------------------------------------

std::wstring UserAgentSetting() {
    std::string mode = Setting("ua_mode"), custom = Setting("ua_custom");
    if (mode == "android") return kAndroidUa;
    if (mode == "iphone") return kIphoneUa;
    if (mode == "ipad") return kIpadUa;
    if (mode == "chrome_win") return kChromeWinUa;
    if (mode == "chrome_mac") return kChromeMacUa;
    if (mode == "safari_mac") return kSafariMacUa;
    if (mode == "firefox") return kFirefoxUa;
    if (mode == "edge") return kEdgeUa;
    if (mode == "custom" && !custom.empty()) return Widen(custom.c_str());
    return L"";
}

std::wstring g_defaultUa;   // WebView2's own, read from the first view

void ApplyViewSettings(ICoreWebView2* view) {
    ComPtr<ICoreWebView2Settings> settings;
    if (!view || FAILED(view->get_Settings(&settings))) return;
    settings->put_IsScriptEnabled(Setting("javascript") != "0");
    settings->put_IsStatusBarEnabled(TRUE);
    ComPtr<ICoreWebView2Settings2> s2;
    if (SUCCEEDED(settings.As(&s2))) {
        if (g_defaultUa.empty()) { CoString ua; if (SUCCEEDED(s2->get_UserAgent(&ua.p))) g_defaultUa = ua.get(); }
        std::wstring ua = UserAgentSetting();
        s2->put_UserAgent(ua.empty() ? g_defaultUa.c_str() : ua.c_str());
    }
}

// Private windows stay out of screenshots, recordings and sharing unless allowed.
void ApplyCaptureRule(Win* w) {
    if (!w->priv) return;
    DWORD affinity = Setting("private_screenshots") == "1" ? WDA_NONE : 0x11 /* WDA_EXCLUDEFROMCAPTURE, Windows 10 2004+ */;
    if (!SetWindowDisplayAffinity(w->hwnd, affinity) && affinity != WDA_NONE) SetWindowDisplayAffinity(w->hwnd, WDA_MONITOR);
}

// The "text size" setting: on desktops the default zoom of every page (50–300%).
double DefaultZoom() {
    double z = std::atof(Setting("text_size").c_str()) / 100.0;
    return z >= 0.5 && z <= 3.0 ? z : 1.0;
}

void ApplySleep() {
    std::string minutes = Setting("sleep_minutes");
    if (!minutes.empty()) fable_tabs_set_sleep_after_ms(g_core, std::strtoull(minutes.c_str(), nullptr, 10) * 60000ULL);
}

void Relabel(Win* w);
void Layout(Win* w);
void LoadPanel();

// A setting the panel just changed.
void SettingChanged(const std::string& key) {
    if (key == "language") {
        g_text.clear();
        for (auto& w : g_wins) Relabel(w.get());
        LoadPanel();
    } else if (key == "javascript" || key == "ua_mode" || key == "ua_custom") {
        for (auto& w : g_wins) for (auto& t : w->tabs) ApplyViewSettings(t->view.Get());
    } else if (key == "data_saver") {
        g_noImages = Setting("data_saver") == "1";
    } else if (key == "private_screenshots") {
        for (auto& w : g_wins) ApplyCaptureRule(w.get());
    } else if (key == "sleep_minutes") {
        ApplySleep();
    } else if (key == "home_button") {
        for (auto& w : g_wins) Layout(w.get());
    } else if (key == "text_size") {
        for (auto& w : g_wins) for (auto& t : w->tabs) if (t->controller) t->controller->put_ZoomFactor(DefaultZoom());
    }
}

// ---- chrome ---------------------------------------------------------------------

void Layout(Win* w) {
    RECT rc;
    GetClientRect(w->hwnd, &rc);
    HWND h0 = w->hwnd;
    const int pad = Scale(h0, 6), h = Scale(h0, 34), btn = Scale(h0, 34), edit = Scale(h0, 380);
    int x = pad;
    const int y = pad;
    auto place = [&](HWND c, int width) { MoveWindow(c, x, y, width, h, TRUE); x += width + Scale(h0, 2); };
    place(w->back, btn);
    place(w->forward, btn);
    if (Setting("home_button") == "1") {   // optional, off unless switched on (Settings › Display)
        ShowWindow(w->home, SW_SHOW);
        place(w->home, btn);
    } else {
        ShowWindow(w->home, SW_HIDE);
    }
    place(w->reload, btn);
    x += Scale(h0, 4);
    place(w->edit, edit);
    x += Scale(h0, 6);
    const int right = btn * 3 + Scale(h0, 2) * 3 + pad;      // new, close, menu
    const int strip = std::max(Scale(h0, 120), static_cast<int>(rc.right) - x - right);
    place(w->strip, strip);
    x += Scale(h0, 2);
    place(w->plus, btn);
    place(w->close, btn);
    place(w->menu, btn);
    if (Tab* t = Active(w); t && t->controller) t->controller->put_Bounds(ContentRect(w));
}

void SetTabTitle(Win* w, int index) {
    Tab* t = w->tabs[index].get();
    std::wstring text = !t->title.empty() ? t->title : IsHome(t->url) ? T("newtab") : t->url;
    if (text.size() > 18) text = text.substr(0, 17) + L"…";
    TCITEMW item{};
    item.mask = TCIF_TEXT;
    item.pszText = &text[0];
    TabCtrl_SetItem(w->strip, index, &item);
}

void UpdateTitle(Win* w) {
    Tab* t = Active(w);
    std::wstring page = t ? (!t->title.empty() ? t->title : IsHome(t->url) ? T("newtab") : t->url) : L"";
    std::wstring title = (page.empty() ? L"" : page + L" — ") + L"Fable" +(w->priv ? L" (" + T("private_mode") + L")" : L"");
    SetWindowTextW(w->hwnd, title.c_str());
}

void ShowAddress(Win* w, bool force) {
    Tab* t = Active(w);
    if (!t) return;
    if (force || GetFocus() != w->edit) SetWindowTextW(w->edit, IsHome(t->url) ? L"" : t->url.c_str());
    BOOL back = FALSE, fwd = FALSE;
    if (t->view) { t->view->get_CanGoBack(&back); t->view->get_CanGoForward(&fwd); }
    EnableWindow(w->back, back);
    EnableWindow(w->forward, fwd);
    UpdateTitle(w);
}

void Relabel(Win* w) {
    SendMessageW(w->edit, EM_SETCUEBANNER, TRUE, reinterpret_cast<LPARAM>(T("addr_hint").c_str()));
    for (size_t i = 0; i < w->tabs.size(); ++i) {
        SetTabTitle(w, static_cast<int>(i));
        Tab* t = w->tabs[i].get();
        if (t->view && IsHome(t->url)) ShowNewtab(*t);   // the new-tab page in the new language
    }
    UpdateTitle(w);
}

// ---- tabs --------------------------------------------------------------------------

void Retire(ComPtr<ICoreWebView2Controller> controller, ComPtr<ICoreWebView2> view) {
    if (!controller) return;
    controller->put_IsVisible(FALSE);
    g_retired.emplace_back(std::move(controller), std::move(view));
    PostMessageW(g_msg, WM_APP_RETIRE, 0, 0);
}

void ShowNewtab(Tab& tab) {
    tab.homeNext = true;
    tab.view->NavigateToString(Widen(Take(fable_newtab_page(tab.win->priv ? 1 : 0, nullptr)).c_str()).c_str());
}

// A normal window in the skin: the title bar (dark for a dark skin), the bar, the address field.
void SkinWindow(Win* w) {
    if (w->priv) return;
    const BOOL dark = g_skinDark ? TRUE : FALSE;
    DwmSetWindowAttribute(w->hwnd, 20, &dark, sizeof(dark));   // DWMWA_USE_IMMERSIVE_DARK_MODE
    InvalidateRect(w->hwnd, nullptr, TRUE);
    if (w->edit) InvalidateRect(w->edit, nullptr, TRUE);
}

void Navigate(Tab& tab, const std::wstring& input) {
    std::string resolved = Take(fable_resolve(Narrow(input.c_str()).c_str()));
    const int skin = fable_theme_apply(resolved.c_str());
    if (skin >= 0) {
        // theme://name: a skin, not a page, and nothing is said; a name that is no skin changes nothing.
        // The windows, the new-tab pages and the panel take its colours; the tab stays where it is.
        if (skin == 1) {
            LoadSkin();
            for (auto& w : g_wins) {
                SkinWindow(w.get());
                for (auto& t : w->tabs) if (t->view && IsHome(t->url)) ShowNewtab(*t);
            }
            LoadPanel();   // the panel page carries its colours
        }
        ShowAddress(tab.win, true);
        return;
    }
    if (!tab.view) { tab.pending = input; return; }
    std::wstring url = Widen(resolved.c_str());
    if (url.empty()) ShowNewtab(tab);
    else tab.view->Navigate(url.c_str());
}

void Activate(Win* w, int index) {
    if (index < 0 || index >= static_cast<int>(w->tabs.size())) return;
    if (Tab* old = Active(w); old && old->controller && w->active != index) old->controller->put_IsVisible(FALSE);
    w->active = index;
    Tab& tab = *w->tabs[index];
    fable_tabs_activate(g_core, tab.id, NowMs());
    TabCtrl_SetCurSel(w->strip, index);
    if (tab.deferred) {   // a restored tab: its page loads now (or as soon as its view is ready)
        tab.deferred = false;
        if (tab.view) { std::wstring first; first.swap(tab.pending); Navigate(tab, first); }
    }
    ShowAddress(w, true);
    if (tab.controller) {
        tab.controller->put_Bounds(ContentRect(w));
        tab.controller->put_IsVisible(TRUE);   // a suspended view resumes when it becomes visible
    }
}

void CloseTab(Win* w, int index) {
    if (index < 0 || index >= static_cast<int>(w->tabs.size())) return;
    Tab& tab = *w->tabs[index];
    fable_tabs_close(g_core, tab.id);
    fable_sniff_clear(tab.id);
    Retire(std::move(tab.controller), std::move(tab.view));
    w->tabs.erase(w->tabs.begin() + index);
    TabCtrl_DeleteItem(w->strip, index);
    w->active = -1;
    if (w->tabs.empty()) { CloseWindow(w); return; }
    Activate(w, std::min(index, static_cast<int>(w->tabs.size()) - 1));
    if (!w->priv) SaveSession();
}

void ToggleReader(Tab* t);
void HandleKey(Win* w, UINT key, bool ctrl, bool shift, bool alt, bool* handled);

void HookEvents(Tab& tab) {
    const uint32_t id = tab.id;   // look the tab up again in every callback: it may have moved or closed
    EventRegistrationToken token;

    ComPtr<ICoreWebView2_4> view4;
    if (!tab.win->priv && SUCCEEDED(tab.view.As(&view4))) {
        view4->add_DownloadStarting(Callback<ICoreWebView2DownloadStartingEventHandler>(
            [](ICoreWebView2*, ICoreWebView2DownloadStartingEventArgs* args) -> HRESULT {
                ComPtr<ICoreWebView2DownloadOperation> op;
                CoString path;
                if (FAILED(args->get_DownloadOperation(&op)) || !op || FAILED(args->get_ResultFilePath(&path.p))) return S_OK;
                std::wstring name = path.get();
                auto record = fable_download_begin(Narrow(name.substr(name.find_last_of(L"\\/") + 1).c_str()).c_str());
                EventRegistrationToken stateToken;
                HRESULT hr = op->add_StateChanged(Callback<ICoreWebView2StateChangedEventHandler>(
                    [record](ICoreWebView2DownloadOperation* download, IUnknown*) -> HRESULT {
                        COREWEBVIEW2_DOWNLOAD_STATE state;
                        if (SUCCEEDED(download->get_State(&state)) && state != COREWEBVIEW2_DOWNLOAD_STATE_IN_PROGRESS)
                            fable_download_finish(record, state == COREWEBVIEW2_DOWNLOAD_STATE_COMPLETED);
                        return S_OK;
                    }).Get(), &stateToken);
                if (FAILED(hr)) fable_download_finish(record, 0);
                return S_OK;
            }).Get(), &token);
    }

    // Remember the top-level navigation so its document request is never blocked.
    tab.view->add_NavigationStarting(Callback<ICoreWebView2NavigationStartingEventHandler>(
        [id](ICoreWebView2*, ICoreWebView2NavigationStartingEventArgs* args) -> HRESULT {
            CoString uri;
            args->get_Uri(&uri.p);
            // Icon packs are the address bar's (Navigate): a page does not pick one.
            if (_wcsnicmp(uri.get(), L"theme:", 6) == 0) {
                args->put_Cancel(TRUE);
                return S_OK;
            }
            // The page tried to leave the browser for another app.
            if (fable_block_external_app(Narrow(uri.get()).c_str())) {
                args->put_Cancel(TRUE);
                if (Tab* t = Find(id)) Say(t->win, T("external_app_blocked"));
                return S_OK;
            }
            if (Tab* t = Find(id)) {
                // Only our own NavigateToString makes the new-tab page, and with it
                // the bridge below; going back or reloading that history entry keeps it.
                bool ours = t->homeNext;
                t->homeNext = false;
                t->homeBefore = t->home;
                ComPtr<ICoreWebView2NavigationStartingEventArgs> a(args);
                ComPtr<ICoreWebView2NavigationStartingEventArgs3> a3;
                COREWEBVIEW2_NAVIGATION_KIND kind = COREWEBVIEW2_NAVIGATION_KIND_NEW_DOCUMENT;
                if (SUCCEEDED(a.As(&a3))) a3->get_NavigationKind(&kind);
                t->home = ours || (kind != COREWEBVIEW2_NAVIGATION_KIND_NEW_DOCUMENT && HomeDoc(uri.get()));
                if (t->home) t->homeStarted = uri.get();
                t->navigating = uri.get();
                const size_t hash = t->navigating.find(L'#');   // requests carry no fragment
                if (hash != std::wstring::npos) t->navigating.erase(hash);
                fable_sniff_clear(id);                          // a new page: a new resource list
            }
            return S_OK;
        }).Get(), &token);

    // Every request: trackers are answered with 403, images too when the user
    // turned them off, and media goes to the resource list.
    tab.view->AddWebResourceRequestedFilter(L"*", COREWEBVIEW2_WEB_RESOURCE_CONTEXT_ALL);
    tab.view->add_WebResourceRequested(Callback<ICoreWebView2WebResourceRequestedEventHandler>(
        [id](ICoreWebView2* sender, ICoreWebView2WebResourceRequestedEventArgs* args) -> HRESULT {
            ComPtr<ICoreWebView2WebResourceRequest> request;
            if (FAILED(args->get_Request(&request)) || !request) return S_OK;
            CoString uri, page;
            request->get_Uri(&uri.p);
            sender->get_Source(&page.p);
            COREWEBVIEW2_WEB_RESOURCE_CONTEXT context = COREWEBVIEW2_WEB_RESOURCE_CONTEXT_OTHER;
            args->get_ResourceContext(&context);
            if (context == COREWEBVIEW2_WEB_RESOURCE_CONTEXT_DOCUMENT) {
                Tab* t = Find(id);
                if (t && t->navigating == uri.get()) return S_OK;
            }
            const std::string url = Narrow(uri.get());
            bool block = fable_should_block(url.c_str(), Narrow(page.get()).c_str()) != 0;
            if (!block && g_noImages && context == COREWEBVIEW2_WEB_RESOURCE_CONTEXT_IMAGE) block = true;
            if (block) {
                ComPtr<ICoreWebView2WebResourceResponse> response;
                if (SUCCEEDED(g_env->CreateWebResourceResponse(nullptr, 403, L"Blocked", L"", &response)))
                    args->put_Response(response.Get());
                return S_OK;
            }
            ComPtr<ICoreWebView2HttpRequestHeaders> headers;
            BOOL ranged = FALSE;
            if (SUCCEEDED(request->get_Headers(&headers)) && headers) headers->Contains(L"Range", &ranged);
            const char* hint = ranged ? "range" : context == COREWEBVIEW2_WEB_RESOURCE_CONTEXT_MEDIA ? "video" : "";
            if (fable_sniff_note(id, url.c_str(), hint) && g_panelOpen == L"sniff") PanelRun(L"Fable.refresh('sniff')");
            return S_OK;
        }).Get(), &token);

    tab.view->add_SourceChanged(Callback<ICoreWebView2SourceChangedEventHandler>(
        [id](ICoreWebView2* sender, ICoreWebView2SourceChangedEventArgs*) -> HRESULT {
            Tab* t = Find(id);
            if (!t) return S_OK;
            CoString uri;
            sender->get_Source(&uri.p);
            t->url = uri.get();
            if (IsHome(t->url)) t->url.clear();   // new-tab page
            if (t == Active(t->win)) ShowAddress(t->win, false);
            return S_OK;
        }).Get(), &token);

    tab.view->add_DocumentTitleChanged(Callback<ICoreWebView2DocumentTitleChangedEventHandler>(
        [id](ICoreWebView2* sender, IUnknown*) -> HRESULT {
            Tab* t = Find(id);
            if (!t) return S_OK;
            CoString title;
            sender->get_DocumentTitle(&title.p);
            t->title = IsHome(t->url) ? L"" : title.get();
            SetTabTitle(t->win, IndexIn(t->win, t));
            if (t == Active(t->win)) UpdateTitle(t->win);
            return S_OK;
        }).Get(), &token);

    // History: a finished page in a normal window.
    tab.view->add_NavigationCompleted(Callback<ICoreWebView2NavigationCompletedEventHandler>(
        [id](ICoreWebView2* sender, ICoreWebView2NavigationCompletedEventArgs* args) -> HRESULT {
            Tab* t = Find(id);
            BOOL ok = FALSE;
            args->get_IsSuccess(&ok);
            if (!t) return S_OK;
            if (!ok) t->home = t->homeBefore;   // a download, a 204, a cancelled load: the page shown has not changed
            else if (t->home) { CoString source; sender->get_Source(&source.p); t->homeLoaded = source.get(); }
            else t->homeStarted.clear(), t->homeLoaded.clear();
            if (Setting("block_ads") == "1") {
                // Hide the ad boxes the page shows itself; the request filter
                // already stops the third-party ones.
                t->view->ExecuteScript(Widen(Take(fable_adblock_script()).c_str()).c_str(), nullptr);
            }
            if (t == Active(t->win)) ShowAddress(t->win, false);
            if (!ok || t->win->priv || !IsWeb(t->url)) return S_OK;   // private windows keep no history
            CoString title;
            sender->get_DocumentTitle(&title.p);
            fable_history_add(Narrow(t->url.c_str()).c_str(), Narrow(title.get()).c_str(), WallMs());
            SaveSession();   // the snapshot follows along, so a crash loses little
            return S_OK;
        }).Get(), &token);

    // target=_blank and window.open(): a tab of the same window, next to this one.
    tab.view->add_NewWindowRequested(Callback<ICoreWebView2NewWindowRequestedEventHandler>(
        [id](ICoreWebView2*, ICoreWebView2NewWindowRequestedEventArgs* args) -> HRESULT {
            CoString uri;
            args->get_Uri(&uri.p);
            args->put_Handled(TRUE);
            if (Tab* t = Find(id)) NewTab(t->win, uri.get());
            return S_OK;
        }).Get(), &token);

    tab.view->add_WindowCloseRequested(Callback<ICoreWebView2WindowCloseRequestedEventHandler>(
        [id](ICoreWebView2*, IUnknown*) -> HRESULT {
            if (Tab* t = Find(id)) CloseTab(t->win, IndexIn(t->win, t));
            return S_OK;
        }).Get(), &token);

    // The new-tab page posts its search box text here (see ui/newtab.html).
    // Only our own page (served as a string) may: all it can do is navigate its own tab.
    // The sender is checked, not the tab's current document: args->get_Source is the
    // document that posted, which may already have been replaced in the tab.
    tab.view->add_WebMessageReceived(Callback<ICoreWebView2WebMessageReceivedEventHandler>(
        [id](ICoreWebView2*, ICoreWebView2WebMessageReceivedEventArgs* args) -> HRESULT {
            CoString text, source;
            args->get_Source(&source.p);
            Tab* t = Find(id);
            if (!t || !t->home || !SameDoc(source.get(), t->homeStarted, t->homeLoaded)) return S_OK;
            if (SUCCEEDED(args->TryGetWebMessageAsString(&text.p))) Navigate(*t, text.get());
            return S_OK;
        }).Get(), &token);

    // Keyboard shortcuts while focus is inside the page.
    tab.controller->add_AcceleratorKeyPressed(Callback<ICoreWebView2AcceleratorKeyPressedEventHandler>(
        [id](ICoreWebView2Controller*, ICoreWebView2AcceleratorKeyPressedEventArgs* args) -> HRESULT {
            COREWEBVIEW2_KEY_EVENT_KIND kind = COREWEBVIEW2_KEY_EVENT_KIND_KEY_UP;
            UINT key = 0;
            args->get_KeyEventKind(&kind);
            args->get_VirtualKey(&key);
            if (kind != COREWEBVIEW2_KEY_EVENT_KIND_KEY_DOWN && kind != COREWEBVIEW2_KEY_EVENT_KIND_SYSTEM_KEY_DOWN) return S_OK;
            Tab* t = Find(id);
            bool handled = false;
            if (t) HandleKey(t->win, key, GetKeyState(VK_CONTROL) < 0, GetKeyState(VK_SHIFT) < 0, GetKeyState(VK_MENU) < 0, &handled);
            if (handled) args->put_Handled(TRUE);
            return S_OK;
        }).Get(), &token);
}

void NewTab(Win* w, const std::wstring& input, bool background) {
    auto tab = std::make_unique<Tab>();
    const uint32_t id = tab->id = fable_tabs_open(g_core, NowMs());
    tab->win = w;
    tab->pending = input;
    const int index = w->active < 0 ? static_cast<int>(w->tabs.size()) : w->active + 1;
    w->tabs.insert(w->tabs.begin() + index, std::move(tab));

    std::wstring title = T("newtab");
    TCITEMW item{};
    item.mask = TCIF_TEXT;
    item.pszText = &title[0];
    TabCtrl_InsertItem(w->strip, index, &item);
    if (!background) {
        Activate(w, index);
        if (input.empty()) SetFocus(w->edit);
    } else {
        if (w->active >= index) w->active++;
        TabCtrl_SetCurSel(w->strip, w->active);
        if (Tab* front = Active(w)) fable_tabs_activate(g_core, front->id, NowMs());   // the core's front tab stays in front
    }

    auto ready = Callback<ICoreWebView2CreateCoreWebView2ControllerCompletedHandler>(
        [id](HRESULT hr, ICoreWebView2Controller* controller) -> HRESULT {
            if (FAILED(hr) || !controller) return S_OK;
            Tab* t = Find(id);
            if (!t) { Retire(controller, nullptr); return S_OK; }   // closed before the view was ready
            t->controller = controller;
            controller->get_CoreWebView2(&t->view);
            controller->put_Bounds(ContentRect(t->win));
            controller->put_IsVisible(t == Active(t->win) ? TRUE : FALSE);
            controller->put_ZoomFactor(DefaultZoom());
            ApplyViewSettings(t->view.Get());
            HookEvents(*t);
            if (t->deferred) return S_OK;   // a restored background tab waits until it is shown
            std::wstring first;
            first.swap(t->pending);
            Navigate(*t, first);
            return S_OK;
        });
    // Private windows: InPrivate controllers share one profile of their own, dropped with the last of them.
    ComPtr<ICoreWebView2Environment10> env10;
    if (w->priv && SUCCEEDED(g_env.As(&env10))) {
        ComPtr<ICoreWebView2ControllerOptions> options;
        if (SUCCEEDED(env10->CreateCoreWebView2ControllerOptions(&options))) {
            options->put_IsInPrivateModeEnabled(TRUE);
            env10->CreateCoreWebView2ControllerWithOptions(w->hwnd, options.Get(), ready.Get());
            return;
        }
    }
    if (w->priv) Say(w, T("private_fail"));   // a WebView2 runtime too old for InPrivate
    g_env->CreateCoreWebView2Controller(w->hwnd, ready.Get());
}

// Suspend background tabs the core reports as idle. Suspending only works on
// hidden views; a failure just means the tab stays awake until the next tick.
void SleepIdleTabs() {
    uint32_t ids[64];
    size_t count = fable_tabs_collect_sleepers(g_core, NowMs(), ids, ARRAYSIZE(ids));
    for (size_t i = 0; i < count; ++i) {
        Tab* t = Find(ids[i]);
        ComPtr<ICoreWebView2_3> view3;
        if (!t || t == Active(t->win) || !t->view || FAILED(t->view.As(&view3))) continue;
        view3->TrySuspend(Callback<ICoreWebView2TrySuspendCompletedHandler>(
            [](HRESULT, BOOL) -> HRESULT { return S_OK; }).Get());
    }
}

// ---- reader, resources, downloads ----------------------------------------------------

void ToggleReader(Tab* t) {
    if (!t || !t->view) return;
    const uint32_t id = t->id;
    t->view->ExecuteScript(Widen(Take(fable_reader_script()).c_str()).c_str(), Callback<ICoreWebView2ExecuteScriptCompletedHandler>(
        [id](HRESULT, LPCWSTR result) -> HRESULT {
            Tab* tab = Find(id);
            if (!tab || !result) return S_OK;
            if (std::wstring(result) == L"\"none\"") Say(tab->win, T("no_article"));
            else if (std::wstring(result) == L"\"on\"") Say(tab->win, T("reader_on"));
            return S_OK;
        }).Get());
}

// What the page itself shows (media elements, large images, what it fetched).
void ScanPage(Tab* t) {
    if (!t || !t->view) return;
    const uint32_t id = t->id;
    t->view->ExecuteScript(Widen(fable_sniff_js()).c_str(), Callback<ICoreWebView2ExecuteScriptCompletedHandler>(
        [id](HRESULT hr, LPCWSTR json) -> HRESULT {
            if (SUCCEEDED(hr) && json && fable_sniff_note_scan(id, Narrow(json).c_str()) > 0) PanelRun(L"Fable.refresh('sniff')");
            return S_OK;
        }).Get());
}

std::wstring KnownFolder(REFKNOWNFOLDERID id) {
    PWSTR base = nullptr;
    std::wstring dir;
    if (SUCCEEDED(SHGetKnownFolderPath(id, 0, nullptr, &base))) dir = base;
    CoTaskMemFree(base);
    return dir;
}

// A resource from the panel's list, saved to Downloads off the UI thread.
void Download(const std::wstring& url) {
    std::wstring name = url.substr(0, url.find_first_of(L"?#"));
    name = name.substr(name.find_last_of(L'/') + 1);
    wchar_t decoded[MAX_PATH] = L"";
    DWORD size = MAX_PATH;
    if (!name.empty() && SUCCEEDED(UrlUnescapeW(&name[0], decoded, &size, 0))) name = decoded;
    for (wchar_t& c : name) if (wcschr(L"\\/:*?\"<>|", c)) c = L'_';
    if (name.empty()) name = L"download";
    std::wstring dir = KnownFolder(FOLDERID_Downloads), path = dir + L"\\" + name;
    for (int i = 2; GetFileAttributesW(path.c_str()) != INVALID_FILE_ATTRIBUTES && i < 1000; ++i) {   // name (2).ext …
        size_t dot = name.find_last_of(L'.');
        std::wstring stem = dot == std::wstring::npos || dot == 0 ? name : name.substr(0, dot), ext = stem == name ? L"" : name.substr(dot);
        path = dir + L"\\" + stem + L" (" + std::to_wstring(i) + L")" + ext;
    }
    Say(Front(), TN("dl_start", path.substr(path.find_last_of(L'\\') + 1)));
    auto record = Front() && !Front()->priv ? fable_download_begin(Narrow(path.substr(path.find_last_of(L'\\') + 1).c_str()).c_str()) : 0;
    std::thread([url, path, record]() {
        HRESULT hr = URLDownloadToFileW(nullptr, url.c_str(), path.c_str(), 0, nullptr);
        fable_download_finish(record, SUCCEEDED(hr));
        PostMessageW(g_msg, WM_APP_DOWNLOADED, SUCCEEDED(hr), reinterpret_cast<LPARAM>(new std::wstring(path)));
    }).detach();
}

// ---- metadata -------------------------------------------------------------------------

// Public IP for the metadata sheet: Cloudflare's trace, then ipify. No cookies.
std::string HttpGet(const std::wstring& url, const std::wstring& ua, size_t limit = 65536) {
    URL_COMPONENTS parts{};
    parts.dwStructSize = sizeof(parts);
    wchar_t host[256] = L"", path[1024] = L"";
    parts.lpszHostName = host; parts.dwHostNameLength = ARRAYSIZE(host);
    parts.lpszUrlPath = path; parts.dwUrlPathLength = ARRAYSIZE(path);
    std::string body;
    if (!WinHttpCrackUrl(url.c_str(), 0, 0, &parts)) return body;
    HINTERNET session = WinHttpOpen(ua.empty() ? L"Fable" : ua.c_str(), WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!session) session = WinHttpOpen(L"Fable", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);   // before Windows 8.1
    if (!session) return body;
    WinHttpSetTimeouts(session, 10000, 10000, 10000, 10000);
    HINTERNET connect = WinHttpConnect(session, host, parts.nPort, 0);
    HINTERNET request = connect ? WinHttpOpenRequest(connect, L"GET", path, nullptr, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES,
                                                     parts.nScheme == INTERNET_SCHEME_HTTPS ? WINHTTP_FLAG_SECURE : 0) : nullptr;
    DWORD redirect = WINHTTP_OPTION_REDIRECT_POLICY_ALWAYS;   // hosts that move the file (a raw file on a code host, say)
    if (request) WinHttpSetOption(request, WINHTTP_OPTION_REDIRECT_POLICY, &redirect, sizeof(redirect));
    if (request && WinHttpSendRequest(request, WINHTTP_NO_ADDITIONAL_HEADERS, 0, WINHTTP_NO_REQUEST_DATA, 0, 0, 0) && WinHttpReceiveResponse(request, nullptr)) {
        DWORD available = 0;
        bool tooBig = false;
        while (WinHttpQueryDataAvailable(request, &available) && available && body.size() < limit) {
            DWORD want = available;
            if ((size_t)want > limit - body.size()) want = (DWORD)(limit - body.size());
            std::string chunk(want, '\0');
            DWORD read = 0;
            if (!WinHttpReadData(request, &chunk[0], want, &read) || !read) break;
            body.append(chunk, 0, read);
        }
        if (body.size() >= limit && WinHttpQueryDataAvailable(request, &available) && available) tooBig = true;
        if (tooBig) body.clear();   // bigger than the limit: not a list this shell can use
    }
    if (request) WinHttpCloseHandle(request);
    if (connect) WinHttpCloseHandle(connect);
    WinHttpCloseHandle(session);
    return body;
}

void LookupIp() {
    std::wstring ua = UserAgentSetting();
    std::thread([ua]() {
        std::string info = Take(fable_parse_ip_reply(HttpGet(L"https://www.cloudflare.com/cdn-cgi/trace", ua).c_str(), "cloudflare.com"));
        if (info.empty()) info = Take(fable_parse_ip_reply(HttpGet(L"https://api.ipify.org?format=json", ua).c_str(), "ipify.org"));
        PostMessageW(g_msg, WM_APP_IP, 0, reinterpret_cast<LPARAM>(new std::string(info.empty() ? "{}" : info)));
    }).detach();
}

// Fetch the built-in community ad lists (at most 8 MiB each) and hand them
// to the core, concatenated. A source that fails is skipped. The shell
// fetches because the core builds offline and has no HTTP client.
void FetchAdList() {
    static std::atomic<bool> busy{false};
    if (busy.exchange(true)) return;
    std::thread([]() {
        std::string sources = Take(fable_ads_update_sources());
        std::string all;
        bool any = false;
        size_t pos = 0;
        while (pos <= sources.size()) {
            size_t nl = sources.find('\n', pos);
            std::string url = sources.substr(pos, nl == std::string::npos ? std::string::npos : nl - pos);
            if (!url.empty()) {
                std::string body = HttpGet(Widen(url.c_str()), L"Fable", 8 * 1024 * 1024 + 1);
                if (!body.empty()) { any = true; all += body; all += '\n'; }
            }
            if (nl == std::string::npos) break;
            pos = nl + 1;
        }
        if (any) fable_ads_update_apply(reinterpret_cast<const uint8_t*>(all.data()), all.size());
        busy = false;
    }).detach();
}

// What only the shell can see: the screen under the window, the engine.
struct Screen { int w = 0, h = 0, hz = 0, dpi = 0; std::string name; };

Screen ScreenFacts(Win* w) {
    Screen s;
    HMONITOR monitor = MonitorFromWindow(w ? w->hwnd : nullptr, MONITOR_DEFAULTTOPRIMARY);
    MONITORINFOEXW info{};
    info.cbSize = sizeof(info);
    if (!GetMonitorInfoW(monitor, &info)) return s;
    DEVMODEW mode{};
    mode.dmSize = sizeof(mode);
    if (EnumDisplaySettingsW(info.szDevice, ENUM_CURRENT_SETTINGS, &mode)) {
        s.w = static_cast<int>(mode.dmPelsWidth);
        s.h = static_cast<int>(mode.dmPelsHeight);
        s.hz = mode.dmDisplayFrequency > 1 ? static_cast<int>(mode.dmDisplayFrequency) : 0;
    }
    if (w) s.dpi = static_cast<int>(GetDpiForWindow(w->hwnd));
    DISPLAY_DEVICEW dev{};
    dev.cb = sizeof(dev);
    if (EnumDisplayDevicesW(info.szDevice, 0, &dev, 0)) s.name = Narrow(dev.DeviceString);   // the monitor's name
    return s;
}

std::string EngineName() {
    CoString version;
    if (SUCCEEDED(GetAvailableCoreWebView2BrowserVersionString(nullptr, &version.p)) && version.p) return "Chromium " + Narrow(version.get()) + " (WebView2)";
    return "WebView2";
}

std::string DeviceExtras() {
    Screen s = ScreenFacts(Front());
    std::wstring ua = UserAgentSetting();
    std::string out = "{\"engine\":" + Json(EngineName()) + ",\"cookies\":true";
    if (!ua.empty() || !g_defaultUa.empty()) out += ",\"ua\":" + Json(Narrow(ua.empty() ? g_defaultUa.c_str() : ua.c_str()));
    if (s.w) out += ",\"screenW\":" + std::to_string(s.w) + ",\"screenH\":" + std::to_string(s.h);
    if (s.hz) out += ",\"refresh\":" + std::to_string(s.hz);
    if (s.dpi) out += ",\"dpi\":" + std::to_string(s.dpi);
    return out + "}";
}

std::string SystemExtras() {
    Screen s = ScreenFacts(Front());
    std::string out = "{\"display\":{\"w\":" + std::to_string(s.w) + ",\"h\":" + std::to_string(s.h);
    if (s.hz) out += ",\"refresh\":" + std::to_string(s.hz);
    if (s.dpi) out += ",\"dpi\":" + std::to_string(s.dpi);
    if (!s.name.empty()) out += ",\"name\":" + Json(s.name);
    return out + "}}";
}

// ---- clearing data ----------------------------------------------------------------------

void ClearData(const std::string& what) {
    const bool historyCleared = what.find("history") == std::string::npos || fable_history_clear();
    COREWEBVIEW2_BROWSING_DATA_KINDS kinds = static_cast<COREWEBVIEW2_BROWSING_DATA_KINDS>(0);
    if (what.find("cookies") != std::string::npos)
        kinds = static_cast<COREWEBVIEW2_BROWSING_DATA_KINDS>(kinds | COREWEBVIEW2_BROWSING_DATA_KINDS_COOKIES | COREWEBVIEW2_BROWSING_DATA_KINDS_ALL_DOM_STORAGE);
    if (what.find("cache") != std::string::npos)
        kinds = static_cast<COREWEBVIEW2_BROWSING_DATA_KINDS>(kinds | COREWEBVIEW2_BROWSING_DATA_KINDS_DISK_CACHE);
    Win* normal = FrontOf(false);
    Tab* t = normal ? Active(normal) : nullptr;
    ComPtr<ICoreWebView2_13> view13;
    ComPtr<ICoreWebView2Profile> profile;
    ComPtr<ICoreWebView2Profile2> profile2;
    if (kinds && t && t->view && SUCCEEDED(t->view.As(&view13)) && SUCCEEDED(view13->get_Profile(&profile)) && SUCCEEDED(profile.As(&profile2)))
        profile2->ClearBrowsingData(kinds, Callback<ICoreWebView2ClearBrowsingDataCompletedHandler>([](HRESULT) -> HRESULT { return S_OK; }).Get());
    Say(Front(), T(historyCleared ? "data_cleared" : "history_clear_failed"));
}

// ---- restoring tabs ----------------------------------------------------------------------

// Snapshot the normal tabs (never private ones) for the next start:
// {"a":active index,"t":[{"u":url,"n":title}, ...]}, windows in order. The core
// keeps nothing while "restore tabs on start" is off.
void SaveSession() {
    Win* fw = Front();
    Win* normal = fw && !fw->priv ? fw : FrontOf(false);
    Tab* front = Active(normal);
    std::string s = "{\"t\":[";
    size_t index = 0, active = 0;
    for (auto& w : g_wins) {
        if (w->priv) continue;
        for (auto& t : w->tabs) {
            if (!IsWeb(t->url) || index >= 500) continue;   // 500: what the core accepts
            if (t.get() == front) active = index;
            s += std::string(index ? "," : "") + "{\"u\":" + Json(Narrow(t->url.c_str())) + ",\"n\":" + Json(Narrow(t->title.c_str())) + "}";
            index++;
        }
    }
    s += "],\"a\":" + std::to_string(active) + "}";
    fable_session_save(s.c_str());
}

// Reopen the normal tabs of the last run in `w`. Only the one in front loads;
// the others load when first shown. False when there was nothing to restore.
bool RestoreSession(Win* w) {
    if (!w || w->priv || Setting("restore_tabs") == "0") return false;
    const size_t n = fable_session_count(), wanted = fable_session_active();
    int front = -1;
    for (size_t i = 0; i < n; i++) {
        const std::wstring url = Widen(Take(fable_session_url(i)).c_str());
        if (!IsWeb(url)) continue;   // only web pages, whatever the file says
        NewTab(w, url, true);
        Tab* t = w->tabs.back().get();
        t->deferred = true;
        t->url = url;
        t->title = Widen(Take(fable_session_title(i)).c_str());
        SetTabTitle(w, static_cast<int>(w->tabs.size()) - 1);
        if (front < 0 || i == wanted) front = static_cast<int>(w->tabs.size()) - 1;
    }
    if (front < 0) return false;
    Activate(w, front);
    return true;
}

// ---- bookmarks -----------------------------------------------------------------------------

// The bookmark id of the tab's page: 0 in private windows and on non-web pages.
uint64_t BookmarkId(Tab* t) {
    return t && !t->win->priv && IsWeb(t->url) ? fable_bookmark_id(Narrow(t->url.c_str()).c_str()) : 0;
}

// A file chosen in the system dialog: Open for import, Save for export. Empty when cancelled.
std::wstring PickFile(Win* w, bool save) {
    ComPtr<IFileDialog> dialog;
    if (FAILED(CoCreateInstance(save ? __uuidof(FileSaveDialog) : __uuidof(FileOpenDialog), nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&dialog))))
        return {};
    const COMDLG_FILTERSPEC types[] = {{L"HTML", L"*.html;*.htm"}};
    dialog->SetFileTypes(1, types);
    dialog->SetTitle(T(save ? "bookmark_export" : "bookmark_import").c_str());
    if (save) { dialog->SetFileName(L"bookmarks.html"); dialog->SetDefaultExtension(L"html"); }
    ComPtr<IShellItem> item;
    LPWSTR path = nullptr;
    if (FAILED(dialog->Show(w ? w->hwnd : nullptr)) || FAILED(dialog->GetResult(&item)) || FAILED(item->GetDisplayName(SIGDN_FILESYSPATH, &path)))
        return {};
    std::wstring out = path;
    CoTaskMemFree(path);
    return out;
}

// Import a Chrome/Firefox bookmark file (NETSCAPE HTML, at most 4 MiB).
void ImportBookmarks(Win* w) {
    const std::wstring path = PickFile(w, false);
    if (path.empty()) return;
    std::string text;
    bool ok = false;
    HANDLE file = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    LARGE_INTEGER size{};
    if (file != INVALID_HANDLE_VALUE && GetFileSizeEx(file, &size) && size.QuadPart <= 4 * 1024 * 1024) {
        text.resize(static_cast<size_t>(size.QuadPart));
        DWORD read = 0;
        ok = text.empty() || (ReadFile(file, &text[0], static_cast<DWORD>(text.size()), &read, nullptr) && read == text.size());
    }
    if (file != INVALID_HANDLE_VALUE) CloseHandle(file);
    if (!ok) { Say(w, T("bookmark_import_failed")); return; }
    Say(w, TN("bookmark_imported", std::to_wstring(fable_bookmark_import(text.c_str()))));
    if (g_panelOpen == L"bookmarks") PanelRun(L"Fable.refresh('bookmarks')");
}

void ExportBookmarks(Win* w) {
    const std::wstring path = PickFile(w, true);
    if (path.empty()) return;
    const std::string html = Take(fable_bookmark_export());
    HANDLE file = CreateFileW(path.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
    DWORD written = 0;
    const bool ok = file != INVALID_HANDLE_VALUE && WriteFile(file, html.data(), static_cast<DWORD>(html.size()), &written, nullptr) && written == html.size();
    if (file != INVALID_HANDLE_VALUE) CloseHandle(file);
    Say(w, T(ok ? "exported_bookmark" : "bookmark_export_failed"));
}

// ---- find in page ---------------------------------------------------------------------------
// WebView2's own find (runtime 1.0.3405 and later), with its find bar suppressed:
// the panel's find view is the bar. Older runtimes have neither interface, and
// the panel then leaves the tile out (caps.find false).

bool FindAvailable() {
    ComPtr<ICoreWebView2Environment15> env15;   // the version that creates find options
    return g_env && SUCCEEDED(g_env.As(&env15));
}

// The tab's find session; null where the runtime has none.
ComPtr<ICoreWebView2Find> FindOf(Tab* t) {
    ComPtr<ICoreWebView2_28> view28;
    ComPtr<ICoreWebView2Find> find;
    if (t && t->view && SUCCEEDED(t->view.As(&view28)) && SUCCEEDED(view28->get_Find(&find))) return find;
    return nullptr;
}

// Tell the panel which match is shown (from 1) of how many, if tab `id` is still in front.
// By id, not pointer: an event may arrive after its tab is gone.
void FindReport(uint32_t id, ICoreWebView2Find* find) {
    Tab* front = FrontTab();
    if (!front || front->id != id || !find) return;
    INT32 index = 0, count = 0;
    find->get_ActiveMatchIndex(&index);   // from 1; -1 with no active match
    find->get_MatchCount(&count);
    if (count < 0) count = 0;
    PanelRun(L"Fable.find(" + std::to_wstring(count ? std::max<INT32>(index, 1) : 0) + L"," + std::to_wstring(count) + L")");
}

// "find" (as the term is typed; empty ends it), "findNext", "findPrev", "findStop".
void FindAct(Tab* t, const std::string& name, const std::wstring& term) {
    ComPtr<ICoreWebView2Find> find = FindOf(t);
    if (!find) return;
    const uint32_t id = t->id;
    if (!t->findHooked) {
        t->findHooked = true;
        EventRegistrationToken token;
        find->add_MatchCountChanged(Callback<ICoreWebView2FindMatchCountChangedEventHandler>(
            [id](ICoreWebView2Find* sender, IUnknown*) -> HRESULT { FindReport(id, sender); return S_OK; }).Get(), &token);
        find->add_ActiveMatchIndexChanged(Callback<ICoreWebView2FindActiveMatchIndexChangedEventHandler>(
            [id](ICoreWebView2Find* sender, IUnknown*) -> HRESULT { FindReport(id, sender); return S_OK; }).Get(), &token);
    }
    if (name == "find" && !term.empty()) {
        ComPtr<ICoreWebView2Environment15> env15;
        ComPtr<ICoreWebView2FindOptions> options;
        if (FAILED(g_env.As(&env15)) || FAILED(env15->CreateFindOptions(&options))) return;
        options->put_FindTerm(term.c_str());
        options->put_IsCaseSensitive(FALSE);
        options->put_ShouldHighlightAllMatches(TRUE);
        options->put_SuppressDefaultFindDialog(TRUE);
        ComPtr<ICoreWebView2Find> session = find;
        find->Start(options.Get(), Callback<ICoreWebView2FindStartCompletedHandler>(
            [id, session](HRESULT) -> HRESULT { FindReport(id, session.Get()); return S_OK; }).Get());
    } else if (name == "findNext") {
        find->FindNext();
    } else if (name == "findPrev") {
        find->FindPrevious();
    } else {   // "findStop", or the term emptied
        find->Stop();
    }
}

// ---- the panel ---------------------------------------------------------------------------

// What the panel shows: every tab (for the private-tab count), the front tab,
// the settings snapshot and what this shell can do.
std::string PanelState() {
    Tab* front = FrontTab();
    Win* fw = Front();
    std::string s = "{\"tabs\":[";
    bool first = true;
    for (auto& w : g_wins)
        for (auto& t : w->tabs) {
            s += first ? "" : ",";
            first = false;
            s += "{\"id\":" + std::to_string(t->id) + ",\"title\":" + Json(Narrow(t->title.c_str())) + ",\"url\":" + Json(Narrow(t->url.c_str())) +
                 ",\"active\":" + (t.get() == front ? "true" : "false") + ",\"private\":" + (w->priv ? "true" : "false") + "}";
        }
    const bool web = front && IsWeb(front->url) && !(fw && fw->priv);
    s += "],\"active\":" + std::to_string(front ? front->id : 0) + ",\"url\":" + Json(front ? Narrow(front->url.c_str()) : "") +
         ",\"title\":" + Json(front ? Narrow(front->title.c_str()) : "") + ",\"web\":" + (web ? "true" : "false") +
         ",\"incognito\":" + (fw && fw->priv ? "true" : "false") + ",\"desktop\":false,\"blocked\":" + std::to_string(fable_blocked_count()) +
         ",\"sniffed\":" + std::to_string(front ? fable_sniff_count(front->id) : 0) + ",\"bookmarked\":" + std::to_string(web ? BookmarkId(front) : 0) + ",\"version\":" + Json(fable_version()) +
         ",\"platform\":\"windows\",\"caps\":{\"thirdPartyCookies\":false,\"bookmarks\":true,\"restoreTabs\":true,\"find\":" + (FindAvailable() ? "true" : "false") + "},\"settings\":" + Take(fable_settings_json()) + "}";
    return s;
}

void PanelRun(const std::wstring& script) {
    if (!g_panelView || !g_panelLoaded) { g_panelQueue.push_back(script); return; }
    g_panelView->ExecuteScript(script.c_str(), nullptr);
}

void LoadPanel() {
    if (!g_panelView) return;
    g_panelLoaded = false;
    g_panelNext = true;
    g_panelView->NavigateToString(Widen(Take(fable_panel_page()).c_str()).c_str());
    if (!g_panelOpen.empty()) PanelRun(L"Fable.show('" + g_panelOpen + L"'," + Widen(PanelState().c_str()) + L")");
}

void PlacePanel(Win* w) {
    if (!w || !g_panel) return;
    RECT button;
    GetWindowRect(w->menu, &button);
    const int width = Scale(w->hwnd, kPanelWidth), height = Scale(w->hwnd, g_panelHeight);
    SetWindowLongPtrW(g_panel, GWLP_HWNDPARENT, reinterpret_cast<LONG_PTR>(w->hwnd));   // owned by the window it opens from
    SetWindowPos(g_panel, HWND_TOP, button.right - width, button.bottom + Scale(w->hwnd, 4), width, height, SWP_NOACTIVATE);
    if (g_panelController) {
        RECT rc{0, 0, width, height};
        g_panelController->put_Bounds(rc);
    }
}

void HidePanel() {
    if (!g_panel || !IsWindowVisible(g_panel)) return;
    g_panelOpen.clear();
    ShowWindow(g_panel, SW_HIDE);
    if (Win* w = Front()) SetForegroundWindow(w->hwnd);
}

void PanelAct(const std::string& name, const std::string& arg);

// "q\tid\tname\targ" (a request) or "a\tname\targ" (an action).
void PanelMessage(const std::string& msg) {
    if (msg.size() < 2 || msg[1] != '\t') return;
    if (msg[0] == 'q') {
        size_t a = msg.find('\t', 2), b = a == std::string::npos ? a : msg.find('\t', a + 1);
        if (a == std::string::npos) return;
        uint32_t id = static_cast<uint32_t>(std::strtoul(msg.substr(2, a - 2).c_str(), nullptr, 10));
        std::string name = msg.substr(a + 1, b == std::string::npos ? std::string::npos : b - a - 1);
        std::string arg = b == std::string::npos ? "" : msg.substr(b + 1);
        Tab* front = FrontTab();
        char* answer = fable_panel_query(name.c_str(), arg.c_str(), front ? front->id : 0);
        std::string reply = answer ? Take(answer) : name == "device" ? Take(fable_device_info(DeviceExtras().c_str())) : "";   // "icon": none kept here
        PanelRun(Widen(Take(fable_panel_reply(id, reply.c_str())).c_str()));
        if (name == "set") SettingChanged(arg.substr(0, arg.find('\n')));
    } else if (msg[0] == 'a') {
        size_t a = msg.find('\t', 2);
        PanelAct(msg.substr(2, a == std::string::npos ? std::string::npos : a - 2), a == std::string::npos ? "" : msg.substr(a + 1));
    }
}

void PanelAct(const std::string& name, const std::string& arg) {
    Win* fw = Front();
    Tab* front = FrontTab();
    const std::wstring warg = Widen(arg.c_str());
    if (name == "hidden") {
        HidePanel();
    } else if (name == "size") {   // the panel's content height
        int h = std::atoi(arg.c_str());
        if (h >= 200 && h <= 800) { g_panelHeight = h; PlacePanel(fw); }
    } else if (name == "switchTab" || name == "closeTab") {
        Tab* t = Find(static_cast<uint32_t>(std::strtoul(arg.c_str(), nullptr, 10)));
        if (!t) return;
        if (name == "closeTab") { CloseTab(t->win, IndexIn(t->win, t)); PanelRun(L"Fable.update(" + Widen(PanelState().c_str()) + L")"); return; }
        Activate(t->win, IndexIn(t->win, t));
        SetForegroundWindow(t->win->hwnd);
    } else if (name == "newTab") {                    // a normal tab: in a normal window
        Win* w = fw && !fw->priv ? fw : FrontOf(false);
        if (w) { NewTab(w, L""); SetForegroundWindow(w->hwnd); } else NewWindow(false);
    } else if (name == "newPrivate") {                // in this private window, or a new one
        if (fw && fw->priv) NewTab(fw, L""); else NewWindow(true);
    } else if (name == "enterPrivate") {              // back to a private window, or a new one
        if (Win* w = FrontOf(true)) SetForegroundWindow(w->hwnd); else NewWindow(true);
    } else if (name == "exitPrivate") {               // every private window closes
        std::vector<Win*> privates;
        for (auto& w : g_wins) if (w->priv) privates.push_back(w.get());
        if (privates.empty()) return;
        Win* stay = FrontOf(false);
        if (!stay) stay = NewWindow(false);
        HidePanel();
        for (Win* w : privates) CloseWindow(w);
        SetForegroundWindow(stay->hwnd);
        Say(stay, T("private_closed"));
    } else if (name == "bookmarkToggle") {   // the star in the menu: the page in front
        if (!front || !fw || fw->priv || !IsWeb(front->url)) return;
        if (uint64_t id = BookmarkId(front)) {
            fable_bookmark_remove(id);
            Say(fw, T("removed_bookmark"));
        } else {
            fable_bookmark_add(Narrow(front->url.c_str()).c_str(), Narrow(front->title.c_str()).c_str(), 0);
            Say(fw, T("added_bookmark"));
        }
        PanelRun(L"Fable.update(" + Widen(PanelState().c_str()) + L")");
    } else if (name == "bookmarkImportPick" || name == "bookmarkExport") {
        HidePanel();   // the dialog is modal to the window; the panel would sit on top of it
        if (name == "bookmarkExport") ExportBookmarks(fw); else ImportBookmarks(fw);
    } else if (name == "find" || name == "findNext" || name == "findPrev" || name == "findStop") {
        FindAct(front, name, warg);
    } else if (name == "open") {
        if (front) Navigate(*front, warg);
    } else if (name == "openNew") {
        if (fw) NewTab(fw, warg);
    } else if (name == "reader") {
        ToggleReader(front);
    } else if (name == "downloadFolder") {
        std::wstring dir = KnownFolder(FOLDERID_Downloads);
        if (dir.empty() || reinterpret_cast<INT_PTR>(ShellExecuteW(nullptr, L"open", dir.c_str(), nullptr, nullptr, SW_SHOWNORMAL)) <= 32)
            Say(Front(), T("dl_manage_error"));
    } else if (name == "clear") {
        ClearData(arg);
    } else if (name == "sniffScan") {
        ScanPage(front);
    } else if (name == "download") {
        Download(warg);
    } else if (name == "copy" || name == "copyText") {
        if (OpenClipboard(fw ? fw->hwnd : nullptr)) {
            EmptyClipboard();
            HGLOBAL mem = GlobalAlloc(GMEM_MOVEABLE, (warg.size() + 1) * sizeof(wchar_t));
            if (mem) {
                memcpy(GlobalLock(mem), warg.c_str(), (warg.size() + 1) * sizeof(wchar_t));
                GlobalUnlock(mem);
                if (!SetClipboardData(CF_UNICODETEXT, mem)) GlobalFree(mem);
            }
            CloseClipboard();
        }
        Say(fw, T(name == "copy" ? "link_copied" : "m_copied"));
    } else if (name == "toast") {
        Say(fw, warg);
    } else if (name == "ip") {
        LookupIp();
    } else if (name == "system") {
        PanelRun(L"Fable.system(" + Widen(Take(fable_system_info(SystemExtras().c_str())).c_str()) + L")");
    }
}

LRESULT CALLBACK PanelProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
    case WM_ACTIVATE:   // a click anywhere else closes the panel, as a menu would
        if (LOWORD(wp) == WA_INACTIVE && IsWindowVisible(hwnd)) {
            HWND to = reinterpret_cast<HWND>(lp);
            if (!to || (to != hwnd && !IsChild(hwnd, to))) { g_panelOpen.clear(); ShowWindow(hwnd, SW_HIDE); }
        }
        return 0;
    case WM_SIZE:
        if (g_panelController) { RECT rc; GetClientRect(hwnd, &rc); g_panelController->put_Bounds(rc); }
        return 0;
    case WM_CLOSE:
        HidePanel();
        return 0;
    }
    return DefWindowProcW(hwnd, msg, wp, lp);
}

void CreatePanel(Win* owner) {
    WNDCLASSEXW wc{};
    wc.cbSize = sizeof(wc);
    wc.style = CS_DROPSHADOW;
    wc.lpfnWndProc = PanelProc;
    wc.hInstance = GetModuleHandleW(nullptr);
    wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    wc.hbrBackground = g_creamBrush;
    wc.lpszClassName = L"FablePanel";
    RegisterClassExW(&wc);
    g_panel = CreateWindowExW(WS_EX_TOOLWINDOW, wc.lpszClassName, L"Fable", WS_POPUP, 0, 0, Scale(owner->hwnd, kPanelWidth), Scale(owner->hwnd, g_panelHeight),
                              owner->hwnd, nullptr, wc.hInstance, nullptr);
    const DWORD round = 2;   // DWMWCP_ROUND: rounded corners on Windows 11
    DwmSetWindowAttribute(g_panel, 33 /* DWMWA_WINDOW_CORNER_PREFERENCE */, &round, sizeof(round));
    g_env->CreateCoreWebView2Controller(g_panel, Callback<ICoreWebView2CreateCoreWebView2ControllerCompletedHandler>(
        [](HRESULT hr, ICoreWebView2Controller* controller) -> HRESULT {
            if (FAILED(hr) || !controller) return S_OK;
            g_panelController = controller;
            controller->get_CoreWebView2(&g_panelView);
            RECT rc;
            GetClientRect(g_panel, &rc);
            controller->put_Bounds(rc);
            ComPtr<ICoreWebView2Settings> settings;
            if (SUCCEEDED(g_panelView->get_Settings(&settings))) {   // the user's "JavaScript off" is for web pages, not this
                settings->put_AreDefaultContextMenusEnabled(FALSE);
                settings->put_IsStatusBarEnabled(FALSE);
                settings->put_IsZoomControlEnabled(FALSE);
                settings->put_AreDevToolsEnabled(FALSE);   // F12 here would hand the privileged bridge to anyone at the keyboard
            }
            EventRegistrationToken token;
            g_panelView->add_WebMessageReceived(Callback<ICoreWebView2WebMessageReceivedEventHandler>(
                [](ICoreWebView2*, ICoreWebView2WebMessageReceivedEventArgs* args) -> HRESULT {
                    // Only the panel page we loaded (navigation is locked to it below).
                    CoString text, source;
                    args->get_Source(&source.p);
                    if (!SameDoc(source.get(), g_panelDocStarted, g_panelDocLoaded)) return S_OK;
                    if (SUCCEEDED(args->TryGetWebMessageAsString(&text.p))) PanelMessage(Narrow(text.get()));
                    return S_OK;
                }).Get(), &token);
            g_panelView->add_NavigationCompleted(Callback<ICoreWebView2NavigationCompletedEventHandler>(
                [](ICoreWebView2* sender, ICoreWebView2NavigationCompletedEventArgs* args) -> HRESULT {
                    BOOL ok = FALSE;
                    args->get_IsSuccess(&ok);
                    if (ok) { CoString source; sender->get_Source(&source.p); g_panelDocLoaded = source.get(); }
                    g_panelLoaded = true;
                    std::vector<std::wstring> queued;
                    queued.swap(g_panelQueue);
                    for (auto& script : queued) g_panelView->ExecuteScript(script.c_str(), nullptr);
                    return S_OK;
                }).Get(), &token);
            g_panelView->add_NavigationStarting(Callback<ICoreWebView2NavigationStartingEventHandler>(
                [](ICoreWebView2*, ICoreWebView2NavigationStartingEventArgs* args) -> HRESULT {   // the panel page may not go anywhere else
                    CoString uri;
                    args->get_Uri(&uri.p);
                    const bool ours = g_panelNext && HomeDoc(uri.get());   // only LoadPanel's own NavigateToString
                    g_panelNext = false;
                    if (!ours) args->put_Cancel(TRUE);
                    else g_panelDocStarted = uri.get(), g_panelDocLoaded.clear();
                    return S_OK;
                }).Get(), &token);
            std::vector<std::wstring> waiting;
            waiting.swap(g_panelQueue);   // LoadPanel re-queues the open view's show
            LoadPanel();
            for (auto& script : waiting) g_panelQueue.push_back(script);
            return S_OK;
        }).Get());
}

void ShowPanel(Win* w, const wchar_t* view) {
    if (!w || !g_env) return;
    if (!g_panel) CreatePanel(w);
    g_panelOpen = view;
    PanelRun(std::wstring(L"Fable.show('") + view + L"'," + Widen(PanelState().c_str()) + L")");
    PlacePanel(w);
    ShowWindow(g_panel, SW_SHOW);
    SetForegroundWindow(g_panel);
    if (g_panelController) g_panelController->MoveFocus(COREWEBVIEW2_MOVE_FOCUS_REASON_PROGRAMMATIC);
}

// ---- toasts ------------------------------------------------------------------------------

LRESULT CALLBACK ToastProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    if (msg == WM_PAINT) {
        PAINTSTRUCT ps;
        HDC dc = BeginPaint(hwnd, &ps);
        RECT rc;
        GetClientRect(hwnd, &rc);
        HBRUSH bg = CreateSolidBrush(RGB(0x2A, 0x1A, 0x14));
        FillRect(dc, &rc, bg);
        DeleteObject(bg);
        wchar_t text[512] = L"";
        GetWindowTextW(hwnd, text, ARRAYSIZE(text));
        SetBkMode(dc, TRANSPARENT);
        SetTextColor(dc, kLight);
        HGDIOBJ old = SelectObject(dc, g_font);
        DrawTextW(dc, text, -1, &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
        SelectObject(dc, old);
        EndPaint(hwnd, &ps);
        return 0;
    }
    if (msg == WM_TIMER && wp == kToastTimer) { KillTimer(hwnd, kToastTimer); ShowWindow(hwnd, SW_HIDE); return 0; }
    if (msg == WM_NCHITTEST) return HTTRANSPARENT;
    return DefWindowProcW(hwnd, msg, wp, lp);
}

void Say(Win* w, const std::wstring& text) {
    if (!w || text.empty()) return;
    if (!w->toast) {
        w->toast = CreateWindowExW(WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE | WS_EX_LAYERED | WS_EX_TRANSPARENT, L"FableToast", L"", WS_POPUP,
                                   0, 0, 0, 0, w->hwnd, nullptr, GetModuleHandleW(nullptr), nullptr);
        SetLayeredWindowAttributes(w->toast, 0, 235, LWA_ALPHA);
        const DWORD round = 2;
        DwmSetWindowAttribute(w->toast, 33, &round, sizeof(round));
    }
    SetWindowTextW(w->toast, text.c_str());
    HDC dc = GetDC(w->toast);
    HGDIOBJ old = SelectObject(dc, g_font);
    SIZE size{};
    GetTextExtentPoint32W(dc, text.c_str(), static_cast<int>(text.size()), &size);
    SelectObject(dc, old);
    ReleaseDC(w->toast, dc);
    RECT rc;
    GetWindowRect(w->hwnd, &rc);
    const int width = size.cx + Scale(w->hwnd, 36), height = Scale(w->hwnd, 34);
    SetWindowPos(w->toast, HWND_TOP, (rc.left + rc.right - width) / 2, rc.bottom - height - Scale(w->hwnd, 36), width, height, SWP_NOACTIVATE | SWP_SHOWWINDOW);
    InvalidateRect(w->toast, nullptr, TRUE);
    SetTimer(w->toast, kToastTimer, 2400, nullptr);
}

// ---- keys ------------------------------------------------------------------------------------

void HandleKey(Win* w, UINT key, bool ctrl, bool shift, bool alt, bool* handled) {
    *handled = true;
    Tab* t = Active(w);
    if (alt && !ctrl && key == 'F') { ShowPanel(w, L"menu"); return; }
    if (alt && !ctrl && key == VK_HOME) { if (t) Navigate(*t, L""); return; }
    if (alt && !ctrl && (key == VK_LEFT || key == VK_RIGHT)) { if (t && t->view) { if (key == VK_LEFT) t->view->GoBack(); else t->view->GoForward(); } return; }
    if (key == VK_F5 && !ctrl) { if (t && t->view) t->view->Reload(); return; }
    if (!ctrl || alt) { *handled = false; return; }
    switch (key) {
    case 'T': NewTab(w, L""); return;
    case 'N': NewWindow(shift); return;   // Ctrl+Shift+N: a private window
    case 'W': if (shift) CloseWindow(w); else CloseTab(w, w->active); return;
    case 'L': SetFocus(w->edit); SendMessageW(w->edit, EM_SETSEL, 0, -1); return;
    case 'R': if (shift) ToggleReader(t); else if (t && t->view) t->view->Reload(); return;
    case 'H': ShowPanel(w, L"history"); return;
    case 'F': if (t) { ShowPanel(w, L"find"); } return;
    case '0': case VK_NUMPAD0: if (t && t->controller) t->controller->put_ZoomFactor(DefaultZoom()); return;   // back to the chosen size, not 100%
    case VK_TAB:
        if (!w->tabs.empty()) Activate(w, (w->active + (shift ? -1 : 1) + static_cast<int>(w->tabs.size())) % static_cast<int>(w->tabs.size()));
        return;
    }
    *handled = false;
}

// ---- windows ---------------------------------------------------------------------------------

LRESULT CALLBACK EditProc(HWND edit, UINT msg, WPARAM wp, LPARAM lp, UINT_PTR, DWORD_PTR ref) {
    Win* w = reinterpret_cast<Win*>(ref);
    if (msg == WM_KEYDOWN && wp == VK_RETURN) {
        int length = GetWindowTextLengthW(edit);
        std::wstring text(length, L'\0');
        if (length > 0) GetWindowTextW(edit, &text[0], length + 1);
        if (Tab* t = Active(w)) {
            Navigate(*t, text);
            if (t->controller) t->controller->MoveFocus(COREWEBVIEW2_MOVE_FOCUS_REASON_PROGRAMMATIC);
        }
        return 0;
    }
    if (msg == WM_KEYDOWN && wp == VK_ESCAPE) {   // Esc puts the page's address back
        ShowAddress(w, true);
        if (Tab* t = Active(w); t && t->controller) t->controller->MoveFocus(COREWEBVIEW2_MOVE_FOCUS_REASON_PROGRAMMATIC);
        return 0;
    }
    if (msg == WM_CHAR && (wp == VK_RETURN || wp == VK_ESCAPE)) return 0;   // no beep
    return DefSubclassProc(edit, msg, wp, lp);
}

HWND Child(Win* w, const wchar_t* cls, const wchar_t* text, DWORD style, int id) {
    HWND c = CreateWindowExW(0, cls, text, WS_CHILD | WS_VISIBLE | style, 0, 0, 0, 0, w->hwnd,
                             reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)), GetModuleHandleW(nullptr), nullptr);
    SendMessageW(c, WM_SETFONT, reinterpret_cast<WPARAM>(g_font), TRUE);
    return c;
}

// A toolbar button: a Segoe MDL2 Assets glyph, or plain text where that font is missing.
HWND IconButton(Win* w, wchar_t glyph, const wchar_t* fallback, int id) {
    const wchar_t text[2] = {glyph, 0};
    HWND c = Child(w, L"BUTTON", g_iconFont ? text : fallback, BS_PUSHBUTTON, id);
    if (g_iconFont) SendMessageW(c, WM_SETFONT, reinterpret_cast<WPARAM>(g_iconFont), TRUE);
    return c;
}

int CALLBACK FontFound(const LOGFONTW*, const TEXTMETRICW*, DWORD, LPARAM found) { *reinterpret_cast<bool*>(found) = true; return 0; }

HFONT IconFont(const LOGFONTW& base) {
    LOGFONTW lf{};
    lf.lfCharSet = DEFAULT_CHARSET;
    wcscpy_s(lf.lfFaceName, L"Segoe MDL2 Assets");
    bool found = false;
    HDC dc = GetDC(nullptr);
    EnumFontFamiliesExW(dc, &lf, FontFound, reinterpret_cast<LPARAM>(&found), 0);
    ReleaseDC(nullptr, dc);
    if (!found) return nullptr;
    lf.lfHeight = base.lfHeight;
    lf.lfQuality = CLEARTYPE_QUALITY;
    return CreateFontIndirectW(&lf);
}

void CloseWindow(Win* w) {
    auto it = std::find_if(g_wins.begin(), g_wins.end(), [w](const std::unique_ptr<Win>& p) { return p.get() == w; });
    if (it == g_wins.end()) return;
    if (!w->priv && !w->tabs.empty()) SaveSession();   // before its tabs go: closing the last window keeps them for the next start
    if (g_panel && reinterpret_cast<HWND>(GetWindowLongPtrW(g_panel, GWLP_HWNDPARENT)) == w->hwnd) {
        ShowWindow(g_panel, SW_HIDE);
        g_panelOpen.clear();
        Win* other = nullptr;
        for (auto& o : g_wins) if (o.get() != w) other = o.get();
        SetWindowLongPtrW(g_panel, GWLP_HWNDPARENT, reinterpret_cast<LONG_PTR>(other ? other->hwnd : nullptr));   // the panel outlives this window
    }
    for (auto& t : w->tabs) {
        fable_tabs_close(g_core, t->id);
        fable_sniff_clear(t->id);
        Retire(std::move(t->controller), std::move(t->view));   // the last InPrivate one takes the private profile's data with it
    }
    w->tabs.clear();
    HWND hwnd = w->hwnd;
    SetWindowLongPtrW(hwnd, GWLP_USERDATA, 0);
    if (g_front == w) g_front = nullptr;
    std::unique_ptr<Win> keep = std::move(*it);
    g_wins.erase(it);
    ShowWindow(hwnd, SW_HIDE);   // destroyed after its views are closed (WM_APP_RETIRE)
    g_retiredWindows.push_back(hwnd);
    PostMessageW(g_msg, WM_APP_RETIRE, 0, 0);
    if (g_wins.empty()) PostQuitMessage(0);
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    Win* w = WinOf(hwnd);
    switch (msg) {
    case WM_SIZE:
        if (w && w->strip) Layout(w);
        return 0;
    case WM_ACTIVATE:
        if (w && LOWORD(wp) != WA_INACTIVE) {
            g_front = w;
            if (Tab* t = Active(w)) fable_tabs_activate(g_core, t->id, NowMs());
        }
        return 0;
    case WM_DPICHANGED: {
        const RECT* r = reinterpret_cast<const RECT*>(lp);
        SetWindowPos(hwnd, nullptr, r->left, r->top, r->right - r->left, r->bottom - r->top, SWP_NOZORDER | SWP_NOACTIVATE);
        return 0;
    }
    case WM_ERASEBKGND:
        if (w) {
            RECT rc;
            GetClientRect(hwnd, &rc);
            FillRect(reinterpret_cast<HDC>(wp), &rc, w->priv ? g_darkBrush : g_barBrush);
            return 1;
        }
        break;
    case WM_CTLCOLOREDIT:
    case WM_CTLCOLORSTATIC:
        if (w && w->priv) {   // the address bar in a private window: dark, like the rest of private mode
            SetTextColor(reinterpret_cast<HDC>(wp), kLight);
            SetBkColor(reinterpret_cast<HDC>(wp), kDarkCard);
            return reinterpret_cast<LRESULT>(g_darkCardBrush);
        }
        if (w && reinterpret_cast<HWND>(lp) == w->edit) {   // the address bar in a normal window: the skin's
            SetTextColor(reinterpret_cast<HDC>(wp), g_skinInk);
            SetBkColor(reinterpret_cast<HDC>(wp), g_skinCard);
            return reinterpret_cast<LRESULT>(g_cardBrush);
        }
        break;
    case WM_COMMAND: {
        if (!w) return 0;
        Tab* t = Active(w);
        switch (LOWORD(wp)) {
        case ID_BACK: if (t && t->view) t->view->GoBack(); break;
        case ID_FORWARD: if (t && t->view) t->view->GoForward(); break;
        case ID_HOME: if (t) Navigate(*t, L""); break;   // the new-tab page, in this tab
        case ID_RELOAD: if (t && t->view) t->view->Reload(); break;
        case ID_NEW: if (g_env) NewTab(w, L""); break;
        case ID_CLOSE: CloseTab(w, w->active); break;
        case ID_MENU: ShowPanel(w, L"menu"); break;
        }
        return 0;
    }
    case WM_NOTIFY:
        if (w && reinterpret_cast<const NMHDR*>(lp)->idFrom == ID_TABS && reinterpret_cast<const NMHDR*>(lp)->code == TCN_SELCHANGE)
            Activate(w, TabCtrl_GetCurSel(w->strip));
        return 0;
    case WM_CLOSE:
        if (w) CloseWindow(w);
        return 0;
    case WM_APP_IP: {   // from LookupIp's thread
        std::unique_ptr<std::string> info(reinterpret_cast<std::string*>(lp));
        PanelRun(L"Fable.ip(" + Widen(info->c_str()) + L")");
        return 0;
    }
    case WM_APP_DOWNLOADED: {   // from Download's thread
        std::unique_ptr<std::wstring> path(reinterpret_cast<std::wstring*>(lp));
        Say(Front(), wp ? TN("mac_downloaded", path->substr(path->find_last_of(L'\\') + 1)) : T("dl_fail"));
        return 0;
    }
    case WM_APP_RETIRE: {   // views closed by CloseTab/CloseWindow, now outside their callbacks
        auto views = std::move(g_retired);
        g_retired.clear();
        for (auto& v : views) v.first->Close();
        views.clear();
        auto windows = std::move(g_retiredWindows);
        g_retiredWindows.clear();
        for (HWND h : windows) DestroyWindow(h);
        return 0;
    }
    case WM_TIMER:
        if (wp == kSleepTimer) SleepIdleTabs();
        return 0;
    }
    return DefWindowProcW(hwnd, msg, wp, lp);
}

Win* NewWindow(bool priv) {
    auto owned = std::make_unique<Win>();
    Win* w = owned.get();
    w->priv = priv;
    w->hwnd = CreateWindowExW(0, L"FableWindow", L"Fable", WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN,
                              CW_USEDEFAULT, CW_USEDEFAULT, 1280, 820, nullptr, nullptr, GetModuleHandleW(nullptr), nullptr);
    if (!w->hwnd) return nullptr;
    SetWindowLongPtrW(w->hwnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(w));
    g_wins.push_back(std::move(owned));
    if (priv) {
        const BOOL dark = TRUE;   // a dark title bar (DWMWA_USE_IMMERSIVE_DARK_MODE)
        DwmSetWindowAttribute(w->hwnd, 20, &dark, sizeof(dark));
        ApplyCaptureRule(w);
    } else {
        SkinWindow(w);   // a dark skin: a dark title bar too
    }
    w->back = IconButton(w, 0xE72B, L"<", ID_BACK);
    w->forward = IconButton(w, 0xE72A, L">", ID_FORWARD);
    w->home = IconButton(w, 0xE80F, L"\u2302", ID_HOME);
    w->reload = IconButton(w, 0xE72C, L"⟳", ID_RELOAD);
    w->edit = Child(w, L"EDIT", L"", WS_BORDER | ES_AUTOHSCROLL, ID_EDIT);
    w->strip = Child(w, WC_TABCONTROLW, L"", TCS_FOCUSNEVER | TCS_SINGLELINE, ID_TABS);
    w->plus = IconButton(w, 0xE710, L"+", ID_NEW);
    w->close = IconButton(w, 0xE711, L"×", ID_CLOSE);
    w->menu = IconButton(w, 0xE700, L"≡", ID_MENU);
    SetWindowSubclass(w->edit, EditProc, 0, reinterpret_cast<DWORD_PTR>(w));
    Relabel(w);
    Layout(w);
    ShowWindow(w->hwnd, SW_SHOW);
    SetForegroundWindow(w->hwnd);
    g_front = w;
    if (g_env) NewTab(w, L"");
    return w;
}

std::wstring UserDataDir() {
    std::wstring dir = KnownFolder(FOLDERID_LocalAppData);
    return dir.empty() ? dir : dir + L"\\Fable";
}

}  // namespace

int APIENTRY wWinMain(HINSTANCE instance, HINSTANCE, PWSTR, int) {
    SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);
    if (FAILED(CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED))) return 1;
    INITCOMMONCONTROLSEX controls{sizeof(controls), ICC_TAB_CLASSES | ICC_STANDARD_CLASSES};
    InitCommonControlsEx(&controls);

    NONCLIENTMETRICSW metrics{};
    metrics.cbSize = sizeof(metrics);
    SystemParametersInfoW(SPI_GETNONCLIENTMETRICS, sizeof(metrics), &metrics, 0);
    g_font = CreateFontIndirectW(&metrics.lfMessageFont);
    g_iconFont = IconFont(metrics.lfMessageFont);
    g_creamBrush = CreateSolidBrush(kCream);
    g_darkBrush = CreateSolidBrush(kDark);
    g_darkCardBrush = CreateSolidBrush(kDarkCard);

    WNDCLASSEXW wc{};
    wc.cbSize = sizeof(wc);
    wc.lpfnWndProc = WndProc;
    wc.hInstance = instance;
    wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    wc.hIcon = wc.hIconSm = LoadIconW(instance, MAKEINTRESOURCEW(1));
    wc.hbrBackground = g_creamBrush;
    wc.lpszClassName = L"FableWindow";
    RegisterClassExW(&wc);
    WNDCLASSEXW tc{};
    tc.cbSize = sizeof(tc);
    tc.lpfnWndProc = ToastProc;
    tc.hInstance = instance;
    tc.lpszClassName = L"FableToast";
    RegisterClassExW(&tc);

    const std::wstring data = UserDataDir();
    CreateDirectoryW(data.c_str(), nullptr);
    const auto profile = Narrow(data.c_str());
    fable_ad_list_file(profile.c_str(), nullptr);
    fable_store_open(profile.c_str());   // settings and history, next to WebView2's own data
    LoadSkin();                          // the skin's colours (theme://name)
    wchar_t locale[LOCALE_NAME_MAX_LENGTH] = L"";
    GetUserDefaultLocaleName(locale, LOCALE_NAME_MAX_LENGTH);
    fable_set_system_locale(Narrow(locale).c_str());   // unless the "language" setting says otherwise
    g_core = fable_tabs_new();
    g_noImages = Setting("data_saver") == "1";
    ApplySleep();
    g_msg = CreateWindowExW(0, L"FableWindow", L"", 0, 0, 0, 0, 0, HWND_MESSAGE, nullptr, instance, nullptr);   // answers from worker threads
    if (fable_ads_update_due()) FetchAdList();   // a week since the last fetch, while ad blocking is on

    Win* first = NewWindow(GetEnvironmentVariableW(L"FABLE_PRIVATE", nullptr, 0) > 0);
    if (!first) return 1;
    SetTimer(g_msg, kSleepTimer, kSleepCheckMs, nullptr);

    const std::wstring firstUrl = __argc > 1 ? std::wstring(__wargv[1]) : std::wstring();
    HRESULT hr = CreateCoreWebView2EnvironmentWithOptions(nullptr, data.c_str(), nullptr,
        Callback<ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler>(
            [firstUrl](HRESULT result, ICoreWebView2Environment* env) -> HRESULT {
                if (FAILED(result) || !env) {
                    MessageBoxW(nullptr, T("win_no_webview2").c_str(), L"Fable", MB_ICONERROR);
                    PostQuitMessage(1);
                    return S_OK;
                }
                g_env = env;
                for (auto& w : g_wins) {
                    if (!w->tabs.empty()) continue;
                    const bool restored = RestoreSession(w.get());   // the tabs of the last run, unless switched off
                    if (!restored || !firstUrl.empty()) NewTab(w.get(), firstUrl);   // a link handed over opens on top of them
                }
                return S_OK;
            }).Get());
    if (FAILED(hr)) {
        MessageBoxW(nullptr, T("win_no_webview2").c_str(), L"Fable", MB_ICONERROR);
        return 1;
    }

    MSG msg;
    while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
        if (msg.message == WM_KEYDOWN || msg.message == WM_SYSKEYDOWN) {   // shortcuts while focus is in the chrome
            HWND top = GetAncestor(msg.hwnd, GA_ROOT);
            if (Win* w = top ? WinOf(top) : nullptr) {
                bool handled = false;
                bool alt = GetKeyState(VK_MENU) < 0, ctrl = GetKeyState(VK_CONTROL) < 0;
                if ((ctrl && !alt) || (alt && !ctrl) || msg.wParam == VK_F5)
                    HandleKey(w, static_cast<UINT>(msg.wParam), ctrl, GetKeyState(VK_SHIFT) < 0, alt, &handled);
                if (handled) continue;
            }
        }
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }
    fable_tabs_free(g_core);
    CoUninitialize();
    return 0;
}
