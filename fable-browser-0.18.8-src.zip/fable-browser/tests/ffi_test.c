/* Links the Rust static library from plain C and exercises the whole C ABI,
 * the same way the platform shells use it. Exit code 0 = all checks passed. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fable_core.h"

static int failures;
#define CHECK(cond) do { if (!(cond)) { printf("FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond); failures++; } } while (0)

static void expect_resolve(const char *input, const char *want) {
    char *got = fable_resolve(input);
    if (strcmp(got, want) != 0) { printf("FAIL resolve(%s) = %s, want %s\n", input ? input : "NULL", got, want); failures++; }
    fable_string_free(got);
}

int main(void) {
    printf("fable_core %s, hash: %s\n", fable_version(), fable_native_hash() ? "assembly" : "portable");

    expect_resolve("example.com", "https://example.com");
    expect_resolve("localhost:3000", "http://localhost:3000");
    expect_resolve("  hello world ", "https://duckduckgo.com/?q=hello%20world");
    expect_resolve("", "");
    expect_resolve(NULL, "");
    expect_resolve("intent://scan/#Intent;end", "https://duckduckgo.com/?q=intent%3A%2F%2Fscan%2F%23Intent%3Bend");   /* dangerous schemes are searched for (audit Medium-4) */
    expect_resolve("ftp://example.com/", "ftp://example.com/");   /* other schemes load as typed; the web view decides what opens */
    expect_resolve("about:config", "about:config");
    expect_resolve("http:example.com", "http://example.com");   /* missing "//" is added, as browsers do */
    expect_resolve("file://attacker.example/share/a.html", "https://duckduckgo.com/?q=file%3A%2F%2Fattacker.example%2Fshare%2Fa.html");   /* another machine's file: never */
    expect_resolve("file:///tmp/a.html", "file:///tmp/a.html");   /* a local file: on the desktop platforms (this test runs on one) */
    expect_resolve("\xff\xfe", "https://duckduckgo.com/?q=%EF%BF%BD%EF%BF%BD"); /* invalid UTF-8 is replaced, not rejected */
    fable_string_free(NULL);

    CHECK(fable_should_block("https://stats.g.doubleclick.net/r/collect", "https://news.example.com/") == 1);
    CHECK(fable_should_block("https://news.example.com/app.js", "https://news.example.com/") == 0);
    CHECK(fable_should_block("https://www.hotjar.com/", "https://www.hotjar.com/") == 0);
    CHECK(fable_should_block(NULL, NULL) == 0);
    CHECK(fable_should_block("https://stats.g.doubleclick%2Enet/r", "https://news.example.com/") == 1);   /* hosts as browsers read them (Medium-6) */
    CHECK(fable_blocked_count() == 2);
    /* panel bridge, IP replies, system facts */
    char *q = fable_panel_query("set", "meta_mode\ndetailed", 0);
    CHECK(q && q[0] == 0);
    fable_string_free(q);
    q = fable_panel_query("get", "meta_mode", 0);
    CHECK(q && strcmp(q, "detailed") == 0);
    fable_string_free(q);
    q = fable_settings_json();
    CHECK(strstr(q, "\"meta_mode\":\"detailed\"") != NULL);
    fable_string_free(q);
    /* only the panel's own settings, bounded (audit Medium-9) */
    fable_string_free(fable_panel_query("set", "ffi_panel\nyes", 0));
    q = fable_panel_query("get", "ffi_panel", 0);
    CHECK(q && q[0] == 0);
    fable_string_free(q);
    CHECK(fable_panel_setting_allowed("ua_mode", "desktop") == 1);
    CHECK(fable_panel_setting_allowed("ffi_panel", "yes") == 0);
    CHECK(fable_panel_setting_allowed("ua_custom", "a\r\nb") == 0);
    CHECK(fable_panel_setting_allowed(NULL, NULL) == 0);
    CHECK(fable_panel_setting_allowed("search_template", "javascript:x//%s") == 0);
    CHECK(fable_panel_setting_allowed("home_order", "{}") == 0);
    CHECK(fable_panel_query("switchTab", "1", 0) == NULL);
    q = fable_parse_ip_reply("ip=198.51.100.9\nloc=JP\n", "cloudflare.com");
    CHECK(strcmp(q, "{\"ip\":\"198.51.100.9\",\"loc\":\"JP\",\"src\":\"cloudflare.com\"}") == 0);
    fable_string_free(q);
    q = fable_device_info("{\"engine\":\"test\"}");
    CHECK(q[0] == '{' && strstr(q, "\"engine\":\"test\"}") != NULL);
    fable_string_free(q);
    q = fable_system_info(NULL);
    CHECK(strncmp(q, "{\"system\":", 10) == 0);
    fable_string_free(q);
    char *rules = fable_content_rules();
    CHECK(rules[0] == '[' && strstr(rules, "doubleclick\\\\.net[:/]") != NULL && strstr(rules, "\"third-party\"") != NULL);
    fable_string_free(rules);

    /* language: system locale unless the "language" setting says otherwise */
    fable_set_system_locale("ja_JP");
    char *t = fable_language();
    CHECK(strcmp(t, "ja") == 0);
    fable_string_free(t);
    t = fable_tr("settings");
    CHECK(strcmp(t, "\xE8\xA8\xAD\xE5\xAE\x9A") == 0); /* 設定 */
    fable_string_free(t);
    fable_setting_set("language", "en");
    t = fable_tr("settings");
    CHECK(strcmp(t, "Settings") == 0);
    fable_string_free(t);
    t = fable_tr("no-such-key");
    CHECK(strcmp(t, "no-such-key") == 0);
    fable_string_free(t);
    t = fable_reader_script();
    CHECK(strstr(t, "data-fable-reader") != NULL && strstr(t, "\"exit\":\"Exit\"") != NULL);
    fable_string_free(t);
    t = fable_logo_uri();
    CHECK(strncmp(t, "data:image/webp;base64,", 23) == 0);
    fable_string_free(t);
    t = fable_panel_page();
    CHECK(strstr(t, "window.Fable") != NULL && strstr(t, "\"_lang\":\"en\"") != NULL);
    fable_string_free(t);
    fable_setting_set("language", "");

    /* settings, history and generated pages (in memory: no fable_store_open) */
    char *v = fable_setting_get("missing");
    CHECK(strcmp(v, "") == 0);
    fable_string_free(v);
    fable_setting_set("sleep_minutes", "30");
    v = fable_setting_get("sleep_minutes");
    CHECK(strcmp(v, "30") == 0);
    fable_string_free(v);
    fable_setting_set("block_trackers", "0");
    CHECK(fable_should_block("https://stats.g.doubleclick.net/r/collect", "https://news.example.com/") == 0);
    fable_setting_set("block_trackers", "1");
    fable_history_add("https://example.com/", "Example", 1000);
    v = fable_history_json("", 10);
    CHECK(strcmp(v, "[{\"t\":1000,\"u\":\"https://example.com/\",\"n\":\"Example\"}]") == 0);
    fable_string_free(v);
    fable_history_clear();
    v = fable_history_json(NULL, 10);
    CHECK(strcmp(v, "[]") == 0);
    fable_string_free(v);
    v = fable_newtab_page(1, NULL);
    CHECK(strstr(v, "var INCOGNITO = true;") != NULL && strstr(v, "var SHORTCUTS = null;") != NULL && strstr(v, "var ICONS = null;") != NULL);
    CHECK(strstr(v, "data:image/webp;base64,") != NULL && strstr(v, "\"_lang\":\"ja\"") != NULL);
    fable_string_free(v);
    v = fable_newtab_page(0, "{\"example.com\":[\"data:image/png;base64,AAAA\",180]}");
    CHECK(strstr(v, "var ICONS = {\"example.com\":[\"data:image/png;base64,AAAA\",180]};") != NULL && strstr(v, "var INCOGNITO = false;") != NULL);
    fable_string_free(v);
    v = fable_launcher_page(NULL, "[{\"c\":\"com.example/.Main\",\"n\":\"Example\"}]", 2);
    CHECK(strstr(v, "\"apps\":[{\"c\":\"com.example/.Main\",\"n\":\"Example\"}]") != NULL && strstr(v, "\"addNew\":true,\"wallpaper\":2}") != NULL);
    fable_string_free(v);
    fable_setting_set("home_new_apps", "0");
    v = fable_launcher_page(NULL, "[]", 9);   /* out of range: kept to 0..2 */
    CHECK(strstr(v, "\"addNew\":false,\"wallpaper\":2}") != NULL);
    fable_string_free(v);
    fable_setting_set("home_new_apps", "");
    v = fable_newtab_page(2, NULL);
    CHECK(strstr(v, "var INCOGNITO = \"shared\";") != NULL);
    fable_string_free(v);

    /* resource sniffing */
    CHECK(fable_sniff_note(3, "https://cdn.example.com/a.mp4", "range") == 1);
    CHECK(fable_sniff_note(3, "https://cdn.example.com/a.mp4", "") == 0);
    CHECK(fable_sniff_note(3, "https://cdn.example.com/seg-1.ts", "range") == 0);
    CHECK(fable_sniff_note(3, NULL, NULL) == 0);
    CHECK(fable_sniff_count(3) == 1 && fable_sniff_count(4) == 0);
    v = fable_sniff_json(3);
    CHECK(strcmp(v, "[{\"k\":\"video\",\"u\":\"https://cdn.example.com/a.mp4\",\"e\":\"mp4\"}]") == 0);
    fable_string_free(v);
    fable_sniff_clear(3);
    CHECK(fable_sniff_count(3) == 0);
    CHECK(strstr(fable_sniff_js(), "document.images") != NULL);

    FableTabs *tabs = fable_tabs_new();
    uint32_t a = fable_tabs_open(tabs, 0), b = fable_tabs_open(tabs, 1000);
    uint32_t out[4] = {0};
    CHECK(a == 1 && b == 2 && fable_tabs_count(tabs) == 2);
    fable_tabs_set_sleep_after_ms(tabs, 5000);
    CHECK(fable_tabs_collect_sleepers(tabs, 5999, out, 4) == 0);
    CHECK(fable_tabs_collect_sleepers(tabs, 6000, out, 4) == 1 && out[0] == a);
    CHECK(fable_tabs_is_asleep(tabs, a) == 1);
    CHECK(fable_tabs_activate(tabs, a, 7000) == 1 && fable_tabs_is_asleep(tabs, a) == 0);
    CHECK(fable_tabs_touch(tabs, b, 11999) == 1);
    CHECK(fable_tabs_collect_sleepers(tabs, 12000, out, 4) == 0);
    CHECK(fable_tabs_close(tabs, b) == 1 && fable_tabs_close(tabs, b) == 0 && fable_tabs_count(tabs) == 1);
    CHECK(fable_tabs_collect_sleepers(tabs, 99999, NULL, 4) == 0);
    fable_tabs_free(tabs);
    fable_tabs_free(NULL);
    CHECK(fable_tabs_open(NULL, 0) == 0 && fable_tabs_count(NULL) == 0);

    /* Ads and external app redirects. Both are off by default. */
    {
        char *ads = fable_ads_content_rules();
        CHECK(ads && ads[0] == '[' && strstr(ads, "doubleclick\\\\.net[:/]") != NULL && strstr(ads, "\"third-party\"") != NULL);
        fable_string_free(ads);

        char *script = fable_adblock_script();
        CHECK(script && strstr(script, "ad-container") != NULL && strstr(script, "})();") != NULL);
        fable_string_free(script);

        /* Nothing is blocked and nothing is stopped. */
        fable_set_blocking(0, 0);
        fable_setting_set("block_external_apps", "0");
        CHECK(fable_should_block("https://stats.g.doubleclick.net/r/collect", "https://news.example.com/") == 0);
        CHECK(fable_block_external_app("intent://scan/#Intent;end") == 0);
        CHECK(fable_block_external_app("https://example.com/") == 0);

        /* Trackers only: a tracker is stopped, an ad domain is not. */
        fable_set_blocking(1, 0);
        CHECK(fable_should_block("https://hotjar.com/app.js", "https://news.example.com/") == 1);
        CHECK(fable_should_block("https://teads.tv/track.js", "https://news.example.com/") == 0);

        /* Ads only: an ad domain is stopped, a tracker is not. */
        fable_set_blocking(0, 1);
        uint64_t ads_before = fable_ads_blocked_count();
        CHECK(fable_should_block("https://teads.tv/track.js", "https://news.example.com/") == 1);
        CHECK(fable_should_block("https://hotjar.com/app.js", "https://news.example.com/") == 0);
        CHECK(fable_ads_blocked_count() == ads_before + 1);   /* the ad one is counted as an ad */

        /* External app redirects: another app's scheme, or an app store.
         * The switch is the "block external apps" setting. */
        fable_setting_set("block_external_apps", "1");
        CHECK(fable_block_external_app("intent://scan/#Intent;end") == 1);
        CHECK(fable_block_external_app("itms-apps://itunes.apple.com/app/id1") == 1);
        CHECK(fable_block_external_app("https://apps.apple.com/us/app/id123") == 1);
        CHECK(fable_block_external_app("https://play.google.com/store/apps/details?id=com.example") == 1);
        CHECK(fable_block_external_app("https://example.com/") == 0);
        CHECK(fable_block_external_app("tel:+123456") == 0);
        CHECK(fable_block_external_app("mailto:a@b.c") == 0);
        fable_setting_set("block_external_apps", "0");
        CHECK(fable_block_external_app("intent://scan/#Intent;end") == 0);
        fable_set_blocking(0, 0);
    }

    printf(failures ? "%d check(s) failed\n" : "ffi_test: all checks passed\n", failures);
    return failures ? 1 : 0;
}
