// Stands in for a desktop shell's message channel (WebView2's chrome.webview),
// recording what the panel posts. Used by tests/panel_desktop_test.js.
window.__posted = [];
window.chrome = { webview: { postMessage: function (m) { window.__posted.push(m); } } };
