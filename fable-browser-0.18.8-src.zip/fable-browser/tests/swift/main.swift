// Runs the iOS shell's Foundation-only code (shell/ios/Fable/Core.swift and
// Panel.swift) against the host's libfable_core.a. Built by tests/ios_test.sh.
import Foundation

var passed = 0, failed = 0
func check(_ ok: Bool, _ what: String, line: Int = #line) {
    if ok { passed += 1 } else { failed += 1; print("FAIL (line \(line)): \(what)") }
}
func object(_ json: String) -> [String: Any] {
    (try? JSONSerialization.jsonObject(with: Data(json.utf8))) as? [String: Any] ?? [:]
}

let args = CommandLine.arguments
let expectedVersion = args.count > 1 ? args[1] : ""
let store = FileManager.default.temporaryDirectory.appendingPathComponent("fable-ios-test-\(getpid())")
try? FileManager.default.createDirectory(at: store, withIntermediateDirectories: true)
Core.openStore(store.path)
Core.setSystemLocale("en-US")

// The core through the bridging header.
check(Core.version == expectedVersion, "version \(Core.version) == \(expectedVersion)")
check(Core.tr("ios_open_tab") == "Open in new tab", "new string: \(Core.tr("ios_open_tab"))")
check(Core.tr("ios_downloaded", "a.pdf").hasPrefix("Downloaded a.pdf"), "placeholder")
check(Core.resolve("example.com").hasPrefix("https://example.com"), "resolve: \(Core.resolve("example.com"))")
check(Core.newtabPage(private: true).contains("<html"), "new-tab page")
check(Core.panelPage.contains("window.FableSheet"), "panel page knows the iOS sheet flag")
check(Core.logoURI.hasPrefix("data:image/"), "logo")
check(Core.panelQuery("device", "", tab: 0) == nil, "device is the shell's to answer")
check(Core.panelQuery("set", "address_top\n1", tab: 0) != nil && Core.setting("address_top") == "1", "set through the panel")
check(Core.panelReply(3, "x").hasPrefix("Fable.reply(3"), "reply")
check(Core.json("a\"b") == "\"a\\\"b\"", "json string")
let rules = (try? JSONSerialization.jsonObject(with: Data(Core.contentRules.utf8))) as? [Any] ?? []
check(rules.count > 10, "tracker rules: \(rules.count)")
for (name, json) in [("noImages", Rules.noImages), ("offline", Rules.offline)] {
    let list = (try? JSONSerialization.jsonObject(with: Data(json.utf8))) as? [[String: Any]] ?? []
    check(list.count == 1 && list[0]["trigger"] != nil && list[0]["action"] != nil, "rule list \(name)")
}
let device = object(Core.deviceInfo("{\"manufacturer\":\"Apple\",\"model\":\"iPhone15,2\",\"os\":\"iOS 17.5\"}"))
check(device["model"] as? String == "iPhone15,2" && device["os"] as? String == "iOS 17.5", "device extras win")
let system = object(Core.systemInfo("{\"system\":{\"model\":\"iPhone15,2\"},\"display\":{\"w\":1179,\"h\":2556}}"))
check((system["system"] as? [String: Any])?["model"] as? String == "iPhone15,2", "system extras win")
check((system["display"] as? [String: Any])?["w"] as? Int == 1179, "display extras")

// Panel messages.
check(PanelMessage.parse("q\t7\tget\tlanguage") == .query(id: 7, name: "get", arg: "language"), "query")
check(PanelMessage.parse("q\t8\tsettings") == .query(id: 8, name: "settings", arg: ""), "query without arg")
check(PanelMessage.parse("q\t9\tset\tua_custom\nA\tB") == .query(id: 9, name: "set", arg: "ua_custom\nA\tB"), "arg keeps its tabs")
check(PanelMessage.parse("a\topen\thttps://x.test/?a\tb") == .action(name: "open", arg: "https://x.test/?a\tb"), "action arg keeps its tabs")
check(PanelMessage.parse("a\thidden") == .action(name: "hidden", arg: ""), "action without arg")
check(PanelMessage.parse("a\thidden\t") == .action(name: "hidden", arg: ""), "action, empty arg")
check(PanelMessage.parse("q\tx\tget\ty") == nil && PanelMessage.parse("z\tq") == nil && PanelMessage.parse("") == nil, "junk")
check(PanelMessage.settingKey(ofSet: "address_top\n1") == "address_top", "set key")

// The panel's state.
let tabs = [PanelTab(id: 1, title: "Example", url: "https://example.com/", icon: "", active: false, isPrivate: false, asleep: true),
            PanelTab(id: 2, title: "New tab", url: "", icon: Core.logoURI, active: true, isPrivate: true, asleep: false)]
let state = object(Panel.state(tabs: tabs, incognito: true, desktop: false, sniffed: 3, orientation: false))
check(state["platform"] as? String == "ios", "platform")
let caps = state["caps"] as? [String: Any] ?? [:]
check(caps["screenshots"] as? Bool == false && caps["thirdPartyCookies"] as? Bool == false, "caps hide what iOS forbids")
check(caps["orientation"] as? Bool == false, "orientation cap follows the device")
check(caps["images"] == nil && caps["addressBarTop"] == nil && caps["keepScreenOn"] == nil && caps["statusBar"] == nil, "the rest is supported")
check((state["settings"] as? [String: Any])?["address_top"] as? String == "1", "settings snapshot")
check(state["active"] as? Int == 2 && state["incognito"] as? Bool == true && state["web"] as? Bool == false, "active tab")
check(state["sniffed"] as? Int == 3 && state["version"] as? String == expectedVersion, "counts")
let list = state["tabs"] as? [[String: Any]] ?? []
check(list.count == 2 && list[0]["asleep"] as? Bool == true && list[1]["private"] as? Bool == true, "tab list")
check(Panel.call("Fable.show", "menu", "{}") == "Fable.show(\"menu\",{})", "call")
check(object(Panel.state(tabs: [], incognito: false, desktop: true, sniffed: 0, settings: ""))["settings"] is [String: Any], "no settings")

// Settings for WebKit.
check(Prefs.userAgent(mode: "default", custom: "x") == nil && Prefs.userAgent(mode: "desktop", custom: "") == nil, "WebKit's own UA")
check(Prefs.userAgent(mode: "iphone", custom: "") == Prefs.iPhoneUA, "iPhone UA")
check(Prefs.userAgent(mode: "custom", custom: "  Foo/1  ") == "Foo/1" && Prefs.userAgent(mode: "custom", custom: " ") == nil, "custom UA")
check(Prefs.wantsDesktop(mode: "desktop") && !Prefs.wantsDesktop(mode: "iphone"), "desktop sites")
check(Prefs.pageZoom("150") == 1.5 && Prefs.pageZoom("") == 1 && Prefs.pageZoom("9000") == 1, "text size")
check(Prefs.orientation("portrait") == .portrait && Prefs.orientation("landscape") == .landscape && Prefs.orientation("") == .any, "orientation")
check(Prefs.sleepMinutes("") == 10 && Prefs.sleepMinutes("0") == 0 && Prefs.sleepMinutes("30") == 30, "sleep minutes")

// Downloads never overwrite.
let dir = URL(fileURLWithPath: "/docs")
let taken: Set<String> = ["/docs/a.pdf", "/docs/a (2).pdf", "/docs/README"]
func unique(_ name: String) -> String { Downloads.uniqueFile(in: dir, suggested: name) { taken.contains($0.path) }.lastPathComponent }
check(unique("a.pdf") == "a (3).pdf" && unique("b.pdf") == "b.pdf" && unique("README") == "README (2)", "unique names")
check(unique("../../etc/x") == "_.._etc_x" && unique("") == "download" && unique(".hidden") == "hidden", "safe names")

// The tab sleep policy.
let policy = TabPolicy()
let a = policy.open(now: 0), b = policy.open(now: 0)
policy.setSleepAfter(minutes: 1)
check(policy.count == 2 && a != b, "two tabs")
check(policy.collectSleepers(now: 30_000).isEmpty, "not yet")
check(policy.collectSleepers(now: 61_000) == [a] && policy.isAsleep(a) && !policy.isAsleep(b), "the background tab sleeps")
check(policy.activate(a, now: 62_000) && !policy.isAsleep(a), "waking")
check(policy.close(b) && policy.count == 1, "closing")

try? FileManager.default.removeItem(at: store)
print("ios swift: \(passed) ok, \(failed) failed")
exit(failed == 0 ? 0 : 1)
