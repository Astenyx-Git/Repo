//! Cross-compiles the native layer (assembly hash + Zig blocklist table) into
//! libfable_native.a for any target. Written for Zig 0.14 / 0.15.
//!
//!   zig build                                   # host
//!   zig build -Dtarget=aarch64-linux-android    # Android arm64
//!   zig build -Dtarget=x86_64-windows-msvc      # Windows
//!   zig build test                              # Zig unit tests
//!
//! Then build the Rust core against it:
//!   FABLE_NATIVE_LIB_DIR=$PWD/zig-out/lib cargo build --release --features zig-native

const std = @import("std");

pub fn build(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    // Small and without runtime safety by default: this is a shipped library.
    // Pass -Doptimize=Debug to get safety checks while developing.
    const optimize = b.option(std.builtin.OptimizeMode, "optimize", "Debug, ReleaseSafe, ReleaseFast or ReleaseSmall (default)") orelse .ReleaseSmall;

    const native = b.createModule(.{
        .root_source_file = b.path("native/hostset.zig"),
        .target = target,
        .optimize = optimize,
        .pic = true,
    });
    // Other architectures fall back to the portable Rust hash.
    switch (target.result.cpu.arch) {
        .x86_64 => native.addAssemblyFile(b.path("native/fnv1a_x86_64.S")),
        .aarch64 => native.addAssemblyFile(b.path("native/fnv1a_aarch64.S")),
        else => {},
    }

    const lib = b.addLibrary(.{
        .name = "fable_native",
        .linkage = .static,
        .root_module = native,
    });
    b.installArtifact(lib);

    const tests = b.addTest(.{
        .root_module = b.createModule(.{
            .root_source_file = b.path("native/hostset.zig"),
            .target = target,
            .optimize = optimize,
        }),
    });
    b.step("test", "Run the Zig unit tests").dependOn(&b.addRunArtifact(tests).step);
}
