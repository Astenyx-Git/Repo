//! Tracker blocking: is this request a third-party request to a listed domain?
//!
//! Two lists are at work. The trackers (native/trackers.txt) are consulted
//! while "block trackers" is on; the ad domains (runtime ads.txt) only while
//! "block ads" is on, which is off by default. Both follow the same rule:
//! only third-party requests are blocked, so a site may still serve its own
//! ads and trackers.

use crate::{hash::fnv1a_lower, hostset};
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};

static BLOCKED: AtomicU64 = AtomicU64::new(0);
static ENABLED: AtomicBool = AtomicBool::new(true);
static ADS_BLOCKED: AtomicU64 = AtomicU64::new(0);
static ADS_ENABLED: AtomicBool = AtomicBool::new(false);

/// Turn tracker blocking on or off for the whole process (the "block trackers"
/// setting).
pub fn set_enabled(on: bool) {
    ENABLED.store(on, Ordering::Relaxed);
}

/// Turn ad blocking on or off (the "block ads" setting). Off by default.
pub fn set_ads_enabled(on: bool) {
    ADS_ENABLED.store(on, Ordering::Relaxed);
}

/// Whether ad blocking is on.
pub fn ads_enabled() -> bool {
    ADS_ENABLED.load(Ordering::Relaxed)
}

/// Host of an http(s)/ws(s) URL, without userinfo, port or trailing dot, in
/// the form a browser would connect to: lower case, percent-decoded, full-width
/// letters and ideographic dots folded to ASCII. Browsers parse URLs that way
/// (WHATWG URL: tab and newline dropped, `\` read as `/` and any number of
/// slashes after the scheme), so `https://doubleclick%2Enet/`,
/// `https:\\DoubleClick.net` or `https://doubleclick。net` reach the same host
/// and must be looked up as `doubleclick.net`.
/// IPv6 literals, other schemes and hosts no browser would accept return `None`.
pub fn host_of(url: &str) -> Option<String> {
    let url: String = url
        .trim_matches(|c: char| c <= ' ')
        .chars()
        .filter(|c| !matches!(c, '\t' | '\n' | '\r'))
        .collect();
    let (scheme, rest) = url.split_once(':')?;
    if !["http", "https", "ws", "wss"].iter().any(|s| scheme.eq_ignore_ascii_case(s)) {
        return None;
    }
    if !rest.starts_with(['/', '\\']) {
        return None; // "http:example.com" is relative to the page, not a host
    }
    let rest = rest.trim_start_matches(['/', '\\']);
    let end = rest.find(['/', '\\', '?', '#']).unwrap_or(rest.len());
    let authority = &rest[..end];
    let host_port = authority.rsplit_once('@').map_or(authority, |(_, h)| h);
    if host_port.starts_with('[') {
        return None;
    }
    let host = match host_port.rsplit_once(':') {
        Some((h, port)) if port.bytes().all(|b| b.is_ascii_digit()) => h,
        _ => host_port,
    };
    let host = normalize_host(host)?;
    let host = host.trim_end_matches('.'); // "doubleclick.net.." is still doubleclick.net
    (!host.is_empty()).then(|| host.to_owned())
}

/// Percent-decode a host and fold what IDNA maps onto ASCII for the names
/// on our lists. `None` for a host a browser would refuse to parse.
fn normalize_host(host: &str) -> Option<String> {
    let bytes = host.as_bytes();
    let mut decoded = Vec::with_capacity(bytes.len());
    let mut i = 0;
    while i < bytes.len() {
        if bytes[i] == b'%' {
            let hex = |b: u8| (b as char).to_digit(16);
            match (bytes.get(i + 1).copied().and_then(hex), bytes.get(i + 2).copied().and_then(hex)) {
                (Some(h), Some(l)) => {
                    decoded.push((h * 16 + l) as u8);
                    i += 3;
                    continue;
                }
                _ => return None, // a stray % is not a valid host
            }
        }
        decoded.push(bytes[i]);
        i += 1;
    }
    let text = String::from_utf8(decoded).ok()?;
    let mut out = String::with_capacity(text.len());
    for c in text.chars() {
        let mut buf = [0u8; 4];
        let mapped: &str = match fold(c) {
            Fold::Ignored => continue,
            Fold::Char(m) => m.encode_utf8(&mut buf),
            Fold::Str(m) => m,
            Fold::Keep => c.encode_utf8(&mut buf),
        };
        for c in mapped.chars() {
            // Forbidden host code points (WHATWG): such a URL does not load at all.
            if c <= ' ' || c == '\u{7f}' || "#%/:<>?@[\\]^|".contains(c) {
                return None;
            }
            out.push(c.to_ascii_lowercase());
        }
    }
    Some(out)
}

enum Fold {
    Keep,
    Ignored,
    Char(char),
    Str(&'static str),
}

/// What IDNA (UTS #46 mapping, i.e. NFKC with case folding) turns `c` into,
/// for the characters that end up as ASCII letters, digits or dots: those
/// are the only ones that can spell a name on our lists (which are ASCII).
/// Browsers apply this mapping before they look the host up, so a page can
/// write `ⅾoubleclick.net` or `𝐝oubleclick.net` and still reach
/// doubleclick.net. Anything else non-ASCII is kept and cannot match a list.
fn fold(c: char) -> Fold {
    let u = c as u32;
    let letter = |i: u32| Fold::Char((b'a' + (i % 26) as u8) as char);
    let digit = |i: u32| Fold::Char((b'0' + (i % 10) as u8) as char);
    match u {
        0x3002 | 0xFF0E | 0xFF61 => Fold::Char('.'), // dots IDNA treats as label separators
        0xFF01..=0xFF5E => Fold::Char(char::from_u32(u - 0xFEE0).unwrap_or(c)), // full-width ASCII
        // Mapped to nothing: soft hyphen, joiners, zero-width and variation selectors.
        0xAD | 0x34F | 0x180B..=0x180D | 0x180F | 0x200B..=0x200D | 0x2060 | 0xFE00..=0xFE0F | 0xFEFF
        | 0x1BCA0..=0x1BCA3 | 0xE0100..=0xE01EF => Fold::Ignored,
        0x17F => Fold::Char('s'),                  // long s
        0x212A => Fold::Char('k'),                 // Kelvin sign
        0xAA => Fold::Char('a'),
        0xBA => Fold::Char('o'),
        0xB2 => Fold::Char('2'),
        0xB3 => Fold::Char('3'),
        0xB9 => Fold::Char('1'),
        0x2070 => Fold::Char('0'),
        0x2071 => Fold::Char('i'),
        0x2074..=0x2079 => digit(u - 0x2070),      // superscript 4-9
        0x207F => Fold::Char('n'),
        0x2080..=0x2089 => digit(u - 0x2080),      // subscript digits
        0x2090 => Fold::Char('a'),
        0x2091 => Fold::Char('e'),
        0x2092 => Fold::Char('o'),
        0x2093 => Fold::Char('x'),
        0x2095 => Fold::Char('h'),
        0x2096 => Fold::Char('k'),
        0x2097 => Fold::Char('l'),
        0x2098 => Fold::Char('m'),
        0x2099 => Fold::Char('n'),
        0x209A => Fold::Char('p'),
        0x209B => Fold::Char('s'),
        0x209C => Fold::Char('t'),
        // Letterlike symbols.
        0x2102 | 0x212D => Fold::Char('c'),
        0x210A => Fold::Char('g'),
        0x210B..=0x210E => Fold::Char('h'),
        0x2110 | 0x2111 | 0x2139 | 0x2148 => Fold::Char('i'),
        0x2112 | 0x2113 => Fold::Char('l'),
        0x2115 => Fold::Char('n'),
        0x2119 => Fold::Char('p'),
        0x211A => Fold::Char('q'),
        0x211B..=0x211D => Fold::Char('r'),
        0x2124 | 0x2128 => Fold::Char('z'),
        0x212C => Fold::Char('b'),
        0x212F | 0x2130 | 0x2147 => Fold::Char('e'),
        0x2131 => Fold::Char('f'),
        0x2133 => Fold::Char('m'),
        0x2134 => Fold::Char('o'),
        0x2145 | 0x2146 => Fold::Char('d'),
        0x2149 => Fold::Char('j'),
        // Roman numerals, upper and lower case.
        0x2160..=0x217F => Fold::Str(
            ["i", "ii", "iii", "iv", "v", "vi", "vii", "viii", "ix", "x", "xi", "xii", "l", "c", "d", "m"]
                [((u - 0x2160) % 16) as usize],
        ),
        // Circled digits and letters.
        0x2460..=0x2468 => digit(u - 0x2460 + 1),
        0x24EA => Fold::Char('0'),
        0x24B6..=0x24CF => letter(u - 0x24B6),
        0x24D0..=0x24E9 => letter(u - 0x24D0),
        // Mathematical alphanumeric symbols: 13 alphabets of A-Z a-z, then digits.
        0x1D400..=0x1D6A3 => letter((u - 0x1D400) % 52),
        0x1D7CE..=0x1D7FF => digit(u - 0x1D7CE),
        // Squared capital letters.
        0x1F130..=0x1F149 => letter(u - 0x1F130),
        _ => Fold::Keep,
    }
}

/// The listed domain that `host` equals or is a subdomain of, if any.
/// `a.b.doubleclick.net` is tried as itself, `b.doubleclick.net`, then
/// `doubleclick.net`; a bare top-level label is never looked up.
pub fn listed_domain(host: &str) -> Option<&str> {
    listed_in(host, hostset::contains)
}

/// The same, for the ad list.
pub fn listed_ad_domain(host: &str) -> Option<&str> {
    let ads = crate::ad_list::active();
    listed_in(host, |hash| ads.contains(hash))
}

/// Walk the label suffixes of `host` and return the first one the table has.
fn listed_in(host: &str, table: impl Fn(u64) -> bool) -> Option<&str> {
    let mut suffix = host;
    loop {
        if !suffix.contains('.') {
            return None;
        }
        if table(fnv1a_lower(suffix.as_bytes())) {
            return Some(suffix);
        }
        suffix = &suffix[suffix.find('.')? + 1..];
    }
}

fn same_site(host: &str, domain: &str) -> bool {
    if host.len() == domain.len() {
        return host.eq_ignore_ascii_case(domain);
    }
    host.len() > domain.len()
        && host.as_bytes()[host.len() - domain.len() - 1] == b'.'
        && host[host.len() - domain.len()..].eq_ignore_ascii_case(domain)
}

/// Pure decision, no counting.
pub fn is_tracker_request(request_url: &str, page_url: &str) -> bool {
    let Some(request_host) = host_of(request_url) else { return false };
    let Some(domain) = listed_domain(&request_host) else { return false };
    // First-party use (the user is visiting that site) is left alone.
    !host_of(page_url).is_some_and(|page_host| same_site(&page_host, domain))
}

/// The same, for the ad list: a third-party request to an ad domain.
pub fn is_ad_request(request_url: &str, page_url: &str) -> bool {
    let Some(request_host) = host_of(request_url) else { return false };
    let Some(domain) = listed_ad_domain(&request_host) else { return false };
    !host_of(page_url).is_some_and(|page_host| same_site(&page_host, domain))
}

/// Decision used by the shells; counts what it blocks.
pub fn should_block(request_url: &str, page_url: &str) -> bool {
    let tracker = ENABLED.load(Ordering::Relaxed) && is_tracker_request(request_url, page_url);
    let ad = ADS_ENABLED.load(Ordering::Relaxed) && is_ad_request(request_url, page_url);
    let block = tracker || ad;
    if block {
        BLOCKED.fetch_add(1, Ordering::Relaxed);
    }
    if ad {
        ADS_BLOCKED.fetch_add(1, Ordering::Relaxed);
    }
    block
}

/// Requests blocked by this process since start, trackers and ads together.
pub fn blocked_count() -> u64 {
    BLOCKED.load(Ordering::Relaxed)
}

/// The blocked ones that were ads.
pub fn ads_blocked_count() -> u64 {
    ADS_BLOCKED.load(Ordering::Relaxed)
}

/// The blocklist as a WebKit content-blocker rule list (WKContentRuleList on
/// macOS): a third-party load from a listed domain or any of its subdomains is
/// blocked, as `should_block` decides per request elsewhere. WebKit compiles the
/// rules itself, so nothing is counted for these.
pub fn content_rules_json() -> String {
    rules_json(hostset::domains())
}

/// The same, for the ad list: the rules the "block ads" setting compiles.
pub fn ads_content_rules_json() -> String {
    rules_json(crate::ad_list::active().domains.iter().map(String::as_str))
}

/// Build a WebKit content-blocker rule list from a list of domains.
fn rules_json<'a>(domains: impl Iterator<Item = &'a str>) -> String {
    let mut out = String::from("[");
    for domain in domains {
        // Only plain host names make it into a regex; anything else in the file is skipped.
        if domain.is_empty() || !domain.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'.' || b == b'-') {
            continue;
        }
        if out.len() > 1 {
            out.push(',');
        }
        out.push_str(r#"{"trigger":{"url-filter":"^[^:]+://+([^:/]+\\.)?"#);   // JSON for the regex ^[^:]+://+([^:/]+\.)?
        out.push_str(&domain.to_ascii_lowercase().replace('.', r"\\."));   // a literal dot: \. in the regex, \\. in JSON
        out.push_str(r#"[:/]","load-type":["third-party"]},"action":{"type":"block"}}"#);
    }
    out.push(']');
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    /// The two switches are process-wide, so the tests that move them take
    /// this lock: the test binary runs them in parallel.
    fn serial() -> std::sync::MutexGuard<'static, ()> {
        static LOCK: std::sync::Mutex<()> = std::sync::Mutex::new(());
        LOCK.lock().unwrap_or_else(|e| e.into_inner())
    }

    /// An ad domain that is *not* on the tracker list, so what is being
    /// measured is the ad rule alone.
    const AD_ONLY: &str = "https://teads.tv/track.js";

    #[test]
    fn content_rules_cover_the_list() {
        let json = content_rules_json();
        let rules = json.matches(r#""action":{"type":"block"}"#).count();
        assert_eq!(rules, crate::hostset::domains().count());
        assert!(json.starts_with('[') && json.ends_with(']'));
        assert!(json.contains(r#"{"trigger":{"url-filter":"^[^:]+://+([^:/]+\\.)?doubleclick\\.net[:/]","load-type":["third-party"]},"action":{"type":"block"}}"#));
        // Every backslash is escaped: a lone \ before "." would not be valid JSON.
        assert!(!json.replace(r"\\", "").contains('\\'));
        assert!(!json.contains(",,") && !json.contains("[,"));
    }

    #[test]
    fn ad_rules_cover_the_ad_list() {
        crate::ad_list::load_test_defaults();
        let json = ads_content_rules_json();
        let rules = json.matches(r#""action":{"type":"block"}"#).count();
        assert_eq!(rules, crate::ad_list::active().domains.len());
        assert!(json.contains(r"doubleclick\\.net"));
        assert!(!json.replace(r"\\", "").contains('\\'));
    }

    #[test]
    fn extracts_hosts() {
        let h = |u: &str| host_of(u);
        let some = |s: &str| Some(s.to_owned());
        assert_eq!(h("https://Example.com/a?b#c"), some("example.com"));
        assert_eq!(h("http://user:pw@a.b.example.com:8080/x"), some("a.b.example.com"));
        assert_eq!(h("wss://example.com."), some("example.com"));
        assert_eq!(h("https://example.com?q=a/b@c"), some("example.com"));
        assert_eq!(h("https://[::1]:8080/"), None);
        assert_eq!(h("data:text/html,hi"), None);
        assert_eq!(h("about:blank"), None);
        assert_eq!(h("http:example.com"), None);
        assert_eq!(h("https://"), None);
        assert_eq!(h(""), None);
        // As browsers read it: extra slashes are skipped ("https:///path" is host "path").
        assert_eq!(h("https:///path"), some("path"));
    }

    #[test]
    fn normalizes_hosts_like_a_browser() {
        let some = |s: &str| Some(s.to_owned());
        // Percent-encoding in the host.
        assert_eq!(host_of("https://doubleclick%2Enet/x"), some("doubleclick.net"));
        assert_eq!(host_of("https://%64oubleclick.net/"), some("doubleclick.net"));
        assert_eq!(host_of("https://ad.DOUBLECLICK%2enet:443/"), some("ad.doubleclick.net"));
        // Backslashes, tabs and newlines, surrounding spaces.
        assert_eq!(host_of("https:\\\\doubleclick.net\\x"), some("doubleclick.net"));
        assert_eq!(host_of(" https://double\tclick.n\net/ "), some("doubleclick.net"));
        assert_eq!(host_of("https://evil.example\\@doubleclick.net/"), some("evil.example"));
        // Full-width letters and ideographic dots, as IDNA maps them.
        assert_eq!(host_of("https://doubleclick\u{3002}net/"), some("doubleclick.net"));
        assert_eq!(host_of("https://\u{FF44}oubleclick\u{FF0E}net/"), some("doubleclick.net"));
        // Other characters IDNA maps onto ASCII (NFKC), and ones it drops.
        assert_eq!(host_of("https://\u{217E}oubleclick.net/"), some("doubleclick.net")); // small roman numeral d
        assert_eq!(host_of("https://\u{1D41D}oubleclick.net/"), some("doubleclick.net")); // bold d
        assert_eq!(host_of("https://\u{24D3}oubleclick.net/"), some("doubleclick.net")); // circled d
        assert_eq!(host_of("https://double\u{AD}click.net/"), some("doubleclick.net")); // soft hyphen
        assert_eq!(host_of("https://double\u{200B}click.net/"), some("doubleclick.net")); // zero-width space
        assert_eq!(host_of("https://\u{212A}.example/"), some("k.example")); // Kelvin sign
        assert_eq!(host_of("https://\u{2163}.example/"), some("iv.example")); // roman numeral four
        assert_eq!(host_of("https://doubleclick.net../x"), some("doubleclick.net"));
        // Non-ASCII that IDNA keeps stays as it is (no list entry can match it).
        assert_eq!(host_of("https://b\u{FC}cher.example/"), some("b\u{FC}cher.example"));
        // Hosts a browser refuses: nothing to block, nothing loads.
        assert_eq!(host_of("https://bad%zzhost/"), None);
        assert_eq!(host_of("https://a%20b.com/"), None);
        assert_eq!(host_of("https://a%2Fb.com/"), None);
        assert_eq!(host_of("https://%FF.com/"), None);
    }

    #[test]
    fn encoded_hosts_are_still_blocked() {
        let page = "https://news.example.com/story";
        for url in [
            "https://doubleclick%2Enet/pixel.gif",
            "https://AD.DoubleClick.net/pixel.gif",
            "https:\\\\ad.doubleclick.net/pixel.gif",
            "https://ad.doubleclick\u{3002}net/pixel.gif",
            "https://www.google-analytics%2ecom/collect",
            "https://www.google-analytics.com./collect",
            "https://www.google-analytics.com../collect",
            "https://ad.\u{217E}oubleclick.net/pixel.gif",
            "https://ad.\u{1D41D}\u{1D428}ubleclick.net/pixel.gif",
            "https://ad.double\u{AD}click.net/pixel.gif",
        ] {
            assert!(is_tracker_request(url, page), "{url}");
        }
        // ...and first-party stays first-party however the page URL is written.
        assert!(!is_tracker_request("https://static.hotjar.com/a.js", "https://HOTJAR%2Ecom/pricing"));
    }

    #[test]
    fn matches_listed_domains_and_subdomains() {
        assert_eq!(listed_domain("doubleclick.net"), Some("doubleclick.net"));
        assert_eq!(listed_domain("stats.g.DoubleClick.net"), Some("DoubleClick.net"));
        assert_eq!(listed_domain("hm.baidu.com"), Some("hm.baidu.com"));
        assert_eq!(listed_domain("www.baidu.com"), None);
        assert_eq!(listed_domain("notdoubleclick.net"), None);
        assert_eq!(listed_domain("net"), None);
        assert_eq!(listed_domain("example.com"), None);
    }

    #[test]
    fn ad_domains_are_a_list_of_their_own() {
        crate::ad_list::load_test_defaults();
        assert_eq!(listed_ad_domain("doubleclick.net"), Some("doubleclick.net"));
        assert_eq!(listed_ad_domain("ads.doubleclick.net"), Some("doubleclick.net"));
        // A tracker that is not an ad domain.
        assert_eq!(listed_ad_domain("hotjar.com"), None);
        assert_eq!(listed_ad_domain("example.com"), None);
    }

    #[test]
    fn blocks_third_party_only() {
        let page = "https://news.example.com/story";
        assert!(is_tracker_request("https://www.google-analytics.com/collect?v=1", page));
        assert!(is_tracker_request("https://ad.doubleclick.net/pixel.gif", page));
        assert!(!is_tracker_request("https://cdn.example.com/app.js", page));
        assert!(!is_tracker_request("data:image/png;base64,AAAA", page));
        // Visiting a listed site directly is first-party.
        assert!(!is_tracker_request("https://www.hotjar.com/app.js", "https://www.hotjar.com/"));
        assert!(!is_tracker_request("https://static.hotjar.com/a.js", "https://HOTJAR.com/pricing"));
        // ...but a look-alike page host is not.
        assert!(is_tracker_request("https://static.hotjar.com/a.js", "https://nothotjar.com/"));
        // Unknown page (empty) counts as third-party.
        assert!(is_tracker_request("https://static.hotjar.com/a.js", ""));
    }

    #[test]
    fn ads_are_blocked_only_when_the_setting_is_on() {
        crate::ad_list::load_test_defaults();
        let _guard = serial();
        let page = "https://news.example.com/story";
        // The ad rule itself does not care about the setting.
        assert!(is_ad_request(AD_ONLY, page));
        assert!(!is_tracker_request(AD_ONLY, page));   // not on the tracker list
        set_ads_enabled(false);
        assert!(!should_block(AD_ONLY, page));         // so nothing is blocked
        set_ads_enabled(true);
        assert!(should_block(AD_ONLY, page));
        // First-party is left alone even with ads on.
        assert!(!is_ad_request(AD_ONLY, "https://teads.tv/"));
        set_ads_enabled(false);
    }

    #[test]
    fn counts_blocks() {
        let _guard = serial();
        let before = blocked_count();
        assert!(should_block("https://criteo.com/x", "https://shop.example/"));
        assert!(!should_block("https://shop.example/x", "https://shop.example/"));
        assert!(blocked_count() >= before + 1);
    }

    #[test]
    fn counts_ads_separately() {
        crate::ad_list::load_test_defaults();
        let _guard = serial();
        set_ads_enabled(true);
        let before = blocked_count();
        let ads = ads_blocked_count();
        assert!(should_block("https://undertone.com/ad", "https://shop.example/"));
        assert!(ads_blocked_count() == ads + 1);
        assert!(blocked_count() == before + 1);
        set_ads_enabled(false);
    }

    #[test]
    fn list_is_loaded() {
        crate::ad_list::load_test_defaults();
        assert!(hostset::len() >= 50);
        assert!(crate::ad_list::active().domains.len() >= 50);
    }
}
