import QtQuick 2.0
QtObject { property string iconSource: ""; signal triggered() }
