#include "qrscanner.h"

#include <QAbstractVideoBuffer>
#include <QCamera>
#include <QCameraInfo>
#include <QImage>
#include <QVideoFrame>
#include <QVideoProbe>

#include "fablecore.h"

// How often a frame is tried: the probe hands us video-rate frames, and a
// decode takes a few milliseconds, so trying every one would burn battery
// for nothing. 150 ms still reacts quickly when a code comes into view.
static const int kAttemptIntervalMs = 150;

QrScanner::QrScanner(QObject *parent)
    : QObject(parent)
    , m_camera(new QCamera(this))
    , m_probe(new QVideoProbe(this))
    , m_started(false)
    , m_cameraAvailable(!QCameraInfo::availableCameras().isEmpty())
{
    // QCamera has both a signal and a getter called error; the cast picks
    // the signal.
    connect(m_camera, static_cast<void (QCamera::*)(QCamera::Error)>(&QCamera::error),
            this, &QrScanner::onCameraError);
    m_probe->setSource(m_camera);
    connect(m_probe, &QVideoProbe::videoFrameProbed, this, &QrScanner::onFrameProbed);
}

QrScanner::~QrScanner()
{
    stop();
}

QObject *QrScanner::cameraObject() const
{
    return m_camera;
}

bool QrScanner::cameraAvailable() const
{
    return m_cameraAvailable;
}

void QrScanner::start()
{
    if (m_started) return;
    // Set before starting: a camera with no device errors at once, and the
    // error must reach a scanner that already counts as running.
    m_started = true;
    m_lastAttempt.invalidate();
    m_camera->start();
}

void QrScanner::stop()
{
    if (!m_started) return;
    m_started = false;
    m_camera->stop();
}

void QrScanner::onCameraError()
{
    if (!m_started) return;
    stop();
    emit failed();
}

void QrScanner::onFrameProbed(const QVideoFrame &frame)
{
    if (!m_started) return;
    if (m_lastAttempt.isValid() && m_lastAttempt.elapsed() < kAttemptIntervalMs) return;
    m_lastAttempt.restart();
    const QString text = readFrame(frame);
    if (text.isEmpty()) return;
    stop();
    emit decoded(text);
}

QString QrScanner::readFrame(const QVideoFrame &frame)
{
    const int width = frame.width();
    const int height = frame.height();
    if (width <= 0 || height <= 0) return QString();
    // The core's limits: at most 4096 px an edge and 4 MP in all. A camera
    // preview is far below both; a bigger frame is skipped, not shrunk.
    if (width > 4096 || height > 4096 ||
        static_cast<qint64>(width) * height > 4 * 1024 * 1024) return QString();

    QVideoFrame f = frame;
    if (!f.map(QAbstractVideoBuffer::ReadOnly)) return QString();
    QString text;
    const QVideoFrame::PixelFormat format = f.pixelFormat();
    if (format == QVideoFrame::Format_YUV420P || format == QVideoFrame::Format_YV12 ||
        format == QVideoFrame::Format_NV21 || format == QVideoFrame::Format_NV12) {
        // In all four the Y plane comes first and is the luma plane, with its
        // own row stride (a row can be padded).
        const uint8_t *luma = f.bits(0);
        const size_t rowStride = static_cast<size_t>(f.bytesPerLine(0));
        text = FableCore::qrDecodeLuma(luma, rowStride * static_cast<size_t>(height),
                                       static_cast<size_t>(width),
                                       static_cast<size_t>(height),
                                       rowStride, 1);
    } else {
        // Anything else Qt can draw (RGB, ...): a grayscale image of it. Over the
        // mapped bits, not QVideoFrame::image(), which is Qt 5.15 (Sailfish has 5.6).
        const QImage::Format imageFormat = QVideoFrame::imageFormatFromPixelFormat(format);
        const QImage gray = imageFormat == QImage::Format_Invalid ? QImage()
            : QImage(f.bits(), width, height, f.bytesPerLine(), imageFormat).convertToFormat(QImage::Format_Grayscale8);
        if (!gray.isNull()) {
            text = FableCore::qrDecodeLuma(
                reinterpret_cast<const uint8_t *>(gray.constBits()),
                static_cast<size_t>(gray.bytesPerLine()) * static_cast<size_t>(gray.height()),
                static_cast<size_t>(gray.width()),
                static_cast<size_t>(gray.height()),
                static_cast<size_t>(gray.bytesPerLine()), 1);
        }
    }
    f.unmap();
    return text;
}
