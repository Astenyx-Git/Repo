pragma Singleton
import QtQuick 2.0
// What the fake WebViews were asked to do, and how they answer runJavaScript.
QtObject {
    property var views: []                 // every WebView made, in order
    property var answer: null              // function (view, script): the script's result
    function made(view) { views.push(view); }
    function last() { return views[views.length - 1]; }
}
