#!/bin/sh
# Launches build/macos/Fable.app on a CI Mac, checks it stays up and loads
# pages, and saves window snapshots and its log in build/ci. Used by
# codemagic.yaml; runs on any Mac. Exits non-zero when anything that matters
# fails: not universal, not signed, linked against a library outside the
# system, a crash or panic, a page that never finished loading, a second copy
# started for a link, no snapshots or empty ones; and any command that fails
# unexpectedly (set -e, pipefail).
#
# screencapture cannot reach the display from a CI agent (it runs outside the
# logged-in session), so the app snapshots its own window after each page load:
# FABLE_SNAPSHOT_DIR=<folder> (see snapshot_window in shell/macos/main.m).
set -eu
if (set -o pipefail) 2>/dev/null; then set -o pipefail; fi   # macOS sh (bash) has it
cd "$(dirname "$0")/../.."
OUT=build/ci; mkdir -p "$OUT"
APP=build/macos/Fable.app
BIN=$APP/Contents/MacOS/Fable
[ -x "$BIN" ] || { echo "no $BIN: run scripts/build-macos.sh first" >&2; exit 1; }
START=$(date '+%Y-%m-%d %H:%M:%S')

fail() {
    echo "Fable $1" >&2
    cat "$OUT"/macos-stdout-*.txt >&2 || true
    log show --start "$START" --predicate 'process == "Fable"' > "$OUT/macos-log.txt" 2>&1 || true
    cp ~/Library/Logs/DiagnosticReports/*Fable* "$OUT/" 2>/dev/null || true
    exit 1
}
run() {   # $1: name, then arguments; leaves the app running for $WAIT seconds, then quits it
    name=$1; shift
    FABLE_SNAPSHOT_DIR="$PWD/$OUT" "$BIN" "$@" > "$OUT/macos-stdout-$name.txt" 2>&1 &
    PID=$!
    sleep "$WAIT"
    kill -0 $PID 2>/dev/null || fail "exited ($name)"
}
quit() { kill $PID 2>/dev/null || true; wait $PID 2>/dev/null || true; sleep 1; }
snapshot() {   # $1: host part of the snapshot name; the app writes one after each finished page load
    for f in "$OUT"/macos-*-"$1".png; do
        [ -s "$f" ] && return 0   # written, and not empty
    done
    fail "never finished loading $1 (no snapshot, or an empty one)"
}

# 0. The bundle: both architectures, a valid (ad hoc) signature, system libraries only.
lipo -info "$BIN" > "$OUT/macos-lipo.txt" 2>&1 || fail "lipo failed"
cat "$OUT/macos-lipo.txt"
for arch in arm64 x86_64; do
    lipo -archs "$BIN" | tr ' ' '\n' | grep -qx "$arch" || fail "is not universal: no $arch"
done
codesign --verify --verbose "$APP" > "$OUT/macos-codesign.txt" 2>&1 || { cat "$OUT/macos-codesign.txt" >&2; fail "signature does not verify"; }
otool -L "$BIN" > "$OUT/macos-otool.txt" || fail "otool failed"
if tail -n +2 "$OUT/macos-otool.txt" | grep -v -E '^[[:space:]]+(/usr/lib/|/System/Library/)'; then
    fail "links a library outside the system (above)"
fi

# 1. A plain start: the new-tab page.
WAIT=12 run start; quit
snapshot home
# 2. Started with an address: a web page in the first tab.
WAIT=10 run address https://example.com; quit
snapshot example.com
# 3. Started by Launch Services, then handed a link (as when Fable is the
#    default browser): the link opens in a new tab of the running app.
open -a "$PWD/$APP" --env FABLE_SNAPSHOT_DIR="$PWD/$OUT" 2>"$OUT/macos-open.txt" || fail "could not be opened by Launch Services"
sleep 10
PID=$(pgrep -f "$APP/Contents/MacOS/Fable" | head -n 1) || PID=
[ -n "$PID" ] || fail "did not start from Launch Services"
open -a "$PWD/$APP" "https://www.iana.org/help/example-domains" 2>>"$OUT/macos-open.txt" || fail "could not be handed a link"
sleep 10
kill -0 "$PID" 2>/dev/null || fail "exited after opening a link"
[ "$(pgrep -f "$APP/Contents/MacOS/Fable" | wc -l | tr -d ' ')" -eq 1 ] || fail "started a second copy for a link"
snapshot www.iana.org
quit
log show --start "$START" --predicate 'process == "Fable"' > "$OUT/macos-log.txt" 2>&1 || true
# A Rust panic or an Objective-C exception in any run.
if grep -l -E "panicked at|Terminating app due to uncaught exception" "$OUT"/macos-stdout-*.txt "$OUT/macos-log.txt" 2>/dev/null; then
    fail "panicked or threw (see the files above)"
fi
ls "$OUT"/macos-*.png
echo "macOS smoke test: ok"
