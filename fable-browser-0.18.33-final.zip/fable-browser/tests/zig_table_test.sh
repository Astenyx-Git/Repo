#!/bin/sh
# The Zig build of the native layer (build.zig, native/hostset.zig) against the
# Rust core: Zig's own tests, then the core's tests linked with Zig's tables
# and assembly hash (--features zig-native), where
# hostset::tests::tables_in_use_equal_the_rust_built_ones compares each Zig
# table with the one Rust builds from the same file (audit finding High-1).
#   ZIG=<zig binary>   default: zig on PATH
set -eu
cd "$(dirname "$0")/.."
ZIG=${ZIG:-zig}
command -v "$ZIG" >/dev/null 2>&1 || { echo "zig_table_test: no zig (set ZIG)" >&2; exit 1; }
"$ZIG" build test
"$ZIG" build -p build/zig-out
(cd core && FABLE_NATIVE_LIB_DIR="$PWD/../build/zig-out/lib" CARGO_TARGET_DIR="$PWD/../build/zig-target" \
    cargo test --release -q --features zig-native)
echo "zig_table_test: Zig $("$ZIG" version) tables and hash agree with the Rust core"
