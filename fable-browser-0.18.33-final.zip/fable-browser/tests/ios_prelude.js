// Stands in for the iOS shell: WKWebView's message handler, recording what the
// panel posts, and the flag its user script sets at document start (keep the
// phone's bottom sheet). Used by tests/panel_ios_test.js.
window.__posted = [];
window.webkit = { messageHandlers: { fableui: { postMessage: function (m) { window.__posted.push(m); } } } };
window.FableSheet = true;
