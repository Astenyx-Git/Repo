import QtQuick 2.0
Item {
    property var nameFilters: []
    property var selectedContentProperties: ({})
}
