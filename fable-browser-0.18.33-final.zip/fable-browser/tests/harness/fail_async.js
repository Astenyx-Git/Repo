(function () {
  setTimeout(function () { console.log('ok later'); console.log('FAIL later'); }, 100);
  return 'started';
})();
