/*
 * PanelBridge - connects ui/panel.html (bundled in the Rust core) to the shell,
 * plus the shell logic that is easiest to get right (and to test) in C++.
 *
 * The panel speaks the message protocol the iOS shell uses: "q\tid\tname\targ"
 * for a question, answered with Fable.reply(id, text), and "a\tname\targ" for
 * an action. It picks that protocol once, as its script starts, when it finds
 * window.webkit.messageHandlers.fableui (with window.FableSheet: the phone's
 * bottom sheet). Gecko has neither, and Sailfish's WebView has no message
 * handler, so panelHtml() puts a stand-in at the top of the page's <head>: it
 * queues every message, QML drains the queue (drainScript) and hands each one
 * to handleMessage(); what QML runs in the panel goes through runScript().
 */
#ifndef PANELBRIDGE_H
#define PANELBRIDGE_H

#include <QObject>
#include <QString>
#include <QVariantList>
#include <QVariantMap>

class FableCore;

class PanelBridge : public QObject
{
    Q_OBJECT
public:
    explicit PanelBridge(FableCore *core, QObject *parent = nullptr);

    // The stand-in for the message handler, run before the panel's own script.
    static QString bootstrapScript();
    // The stand-in for FableHost, run before the new-tab page's own script.
    static QString homeBootstrapScript();

public slots:
    // ---- the panel -------------------------------------------------------------
    // The core's panel page with bootstrapScript() at the top of its <head>.
    QString panelHtml() const;
    // Run in the panel (or the new-tab page): returns its queued messages as a
    // JSON array of strings, and empties the queue.
    QString drainScript() const;
    // `script` (Fable.show(...), Fable.reply(...)) wrapped to be run in the panel.
    QString runScript(const QString &script) const;
    // One message from the panel. A question returns the Fable.reply(...) to run
    // in the panel; an action emits actionRequested and returns "". `device` is
    // the JSON of what QML knows about the device (screen, user agent).
    QString handleMessage(const QString &message, quint32 tab, const QString &device);
    // What this shell can do, as state.caps (JSON). Absent means "can".
    QString caps() const;

    // ---- the new-tab page ----------------------------------------------------------
    // Loaded with loadHtml at homeUrl(), a name no web page can have (.invalid).
    // Its search box calls FableHost.go(q): the stand-in queues "go\tq" for
    // drainScript(), which QML runs only while this page is the one shown.
    QString homeUrl() const;
    bool isHome(const QString &url) const;
    QString homeHtml(bool incognito) const;
    // What to open for a message from the new-tab page; "" for anything else.
    QString homeQuery(const QString &message) const;

    // ---- the shell ---------------------------------------------------------------
    // The user agent for a "ua_mode" setting; "" keeps the WebView's own.
    QString userAgent(const QString &mode, const QString &custom) const;
    // http(s) with a host, and not one of Fable's own pages (fable.invalid).
    bool isWeb(const QString &url) const;
    // Snapshot for "restore tabs on start": `tabs` holds {url, title, incognito}
    // maps; private tabs and pages that are not on the web never enter it.
    bool saveSession(const QVariantList &tabs, int active) const;
    // {tabs: [{url, title}], active: n} from the last snapshot; empty when there
    // is none or restoring is switched off.
    QVariantMap restoreSession() const;
    // A bookmark file: at most 4 MiB, read as UTF-8; "" when it cannot be read.
    QString readText(const QString &path) const;
    bool writeText(const QString &path, const QString &text) const;
    // A free file name in the Downloads folder ("bookmarks.html", "bookmarks-2.html", ...).
    QString downloadsPath(const QString &name) const;

signals:
    void actionRequested(const QString &name, const QString &arg);
    // The panel stored a setting: settings the shell applies itself change now.
    void settingChanged(const QString &key);

private:
    FableCore *m_core;
};

#endif // PANELBRIDGE_H
