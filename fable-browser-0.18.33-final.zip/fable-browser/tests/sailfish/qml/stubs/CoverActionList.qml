import QtQuick 2.0
Item { default property alias actions: holder.data; Item { id: holder } }
