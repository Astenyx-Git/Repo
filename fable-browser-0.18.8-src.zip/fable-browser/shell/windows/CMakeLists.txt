# Fable for Windows (MSVC, x64).
#
#   rustup target add x86_64-pc-windows-msvc
#   cd core && cargo build --release            (pure Rust hash; see README for the asm/Zig variants)
#   nuget install Microsoft.Web.WebView2 -OutputDirectory packages
#   cmake -S shell/windows -B build/windows -DWEBVIEW2_SDK=<...>/packages/Microsoft.Web.WebView2.<version>
#   cmake --build build/windows --config Release
cmake_minimum_required(VERSION 3.20)
# Static C runtime (/MT), matching core/.cargo/config.toml: no VC++ redistributable needed.
set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreaded")
project(fable_windows CXX RC)

set(FABLE_ROOT "${CMAKE_CURRENT_SOURCE_DIR}/../.." CACHE PATH "Repository root")
set(WEBVIEW2_SDK "" CACHE PATH "Unpacked Microsoft.Web.WebView2 NuGet package")
set(FABLE_CORE_LIB "${FABLE_ROOT}/core/target/release/fable_core.lib" CACHE FILEPATH "Rust core static library")

if(NOT EXISTS "${WEBVIEW2_SDK}/build/native/include/WebView2.h")
  message(FATAL_ERROR "Set -DWEBVIEW2_SDK to the unpacked Microsoft.Web.WebView2 NuGet package directory")
endif()
if(NOT EXISTS "${FABLE_CORE_LIB}")
  message(FATAL_ERROR "Build the core first: cd core && cargo build --release")
endif()

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

add_executable(fable WIN32 main.cpp fable.rc)
target_compile_options(fable PRIVATE /utf-8 /W3 /EHsc)
target_include_directories(fable PRIVATE "${FABLE_ROOT}/core/include" "${WEBVIEW2_SDK}/build/native/include")
target_link_libraries(fable PRIVATE
  "${FABLE_CORE_LIB}"
  "${WEBVIEW2_SDK}/build/native/x64/WebView2LoaderStatic.lib"
  comctl32 ole32 shell32 shlwapi version user32 gdi32 dwmapi winhttp urlmon
  # system libraries the Rust standard library needs (synchronization: WaitOnAddress, since the 1.100 toolchain)
  advapi32 bcrypt ntdll userenv ws2_32 dbghelp synchronization)
