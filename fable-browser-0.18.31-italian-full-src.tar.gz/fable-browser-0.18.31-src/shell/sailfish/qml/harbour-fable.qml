import QtQuick 2.0
import Sailfish.Silica 1.0
import Sailfish.WebEngine 1.0
import harbour.fable.Core 1.0
import "pages"
import "cover"

ApplicationWindow {
    id: app

    property Item browser: null        // the BrowserPage, for the cover's actions

    initialPage: Component {
        BrowserPage {
            id: browserPage
            Component.onCompleted: app.browser = browserPage
        }
    }
    cover: Component {
        CoverPage {
            title: app.browser ? app.browser.coverTitle : ""
            onNewTab: {
                if (app.browser) app.browser.openTab("", false);
                app.activate();
            }
            onReloadPage: if (app.browser) app.browser.reloadPage()
        }
    }
    allowedOrientations: defaultAllowedOrientations

    // The settings Sailfish's WebView takes engine-wide (WebEngineSettings), for
    // web pages and Fable's own pages alike. JavaScript is not among them: the
    // panel is JavaScript, so the panel leaves that switch out (caps.javascript).
    function applySettings() {
        WebEngineSettings.autoLoadImages = Fable.settingGet("data_saver") !== "1";
        WebEngineSettings.cookieBehavior = Fable.settingGet("block_3p_cookies") === "0"
            ? WebEngineSettings.AcceptAll : WebEngineSettings.BlockThirdParty;
        try {
            WebEngineSettings.colorScheme = WebEngineSettings.FollowsAmbience;   // newer Sailfish OS releases
        } catch (e) {}
    }

    Connections {
        target: Panel
        onSettingChanged: {
            if (key === "data_saver" || key === "block_3p_cookies") app.applySettings();
        }
    }

    Component.onCompleted: applySettings()
}
