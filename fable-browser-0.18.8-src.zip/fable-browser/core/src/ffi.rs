//! C ABI. Keep in sync with `include/fable_core.h`.
//!
//! Conventions: strings are NUL-terminated UTF-8 (invalid sequences are
//! replaced, never rejected); NULL is accepted wherever a pointer is taken;
//! `fable_should_block` and the string functions are thread-safe, a
//! `FableTabs` handle belongs to one thread (the UI thread).

use crate::{blocker, hash, i18n, omnibox, pages, panel, sniff, store, sysinfo, tabs::Tabs, SNIFF_JS, VERSION};
use std::borrow::Cow;
use std::ffi::{c_char, c_int, CStr, CString};

unsafe fn text<'a>(p: *const c_char) -> Cow<'a, str> {
    if p.is_null() {
        Cow::Borrowed("")
    } else {
        CStr::from_ptr(p).to_string_lossy()
    }
}

#[no_mangle]
pub extern "C" fn fable_version() -> *const c_char {
    VERSION.as_ptr().cast()
}

/// 1 when the assembly hash is linked in, 0 when the portable one is used.
#[no_mangle]
pub extern "C" fn fable_native_hash() -> c_int {
    hash::NATIVE as c_int
}

fn owned(s: String) -> *mut c_char {
    CString::new(s.replace('\0', "")).unwrap_or_default().into_raw()
}

/// The device language, e.g. "zh-TW" or "ja_JP"; used unless the `language` setting is set.
#[no_mangle]
pub unsafe extern "C" fn fable_set_system_locale(tag: *const c_char) {
    i18n::set_system_locale(&text(tag));
}

/// Language in effect: "zh-Hans", "zh-Hant", "ja", "en", "ko", "ru", "fr", "es" or "ar". Free with `fable_string_free`.
#[no_mangle]
pub extern "C" fn fable_language() -> *mut c_char {
    owned(i18n::current().tag().to_owned())
}

/// UI text for a key of ui/strings.tsv in the current language. Free with `fable_string_free`.
#[no_mangle]
pub unsafe extern "C" fn fable_tr(key: *const c_char) -> *mut c_char {
    owned(i18n::text(i18n::current(), &text(key)))
}

/// The reader-mode script, localized. Free with `fable_string_free`.
#[no_mangle]
pub extern "C" fn fable_reader_script() -> *mut c_char {
    owned(pages::reader_script())
}

/// The Fable logo as a data: URI. Free with `fable_string_free`.
#[no_mangle]
pub extern "C" fn fable_logo_uri() -> *mut c_char {
    owned(pages::logo_uri().to_owned())
}

/// The in-app panel page, localized. Free with `fable_string_free`.
#[no_mangle]
pub extern "C" fn fable_panel_page() -> *mut c_char {
    owned(pages::panel_page())
}

/// The new-tab page: localized, with the stored shortcuts and, optionally,
/// icons the shell already has (`{"host": [dataUri, width]}` or NULL).
/// `incognito`: 0 normal, 1 private, 2 private with cookies shared with normal tabs.
/// Free with `fable_string_free`.
#[no_mangle]
pub unsafe extern "C" fn fable_newtab_page(incognito: c_int, icons_json: *const c_char) -> *mut c_char {
    owned(pages::newtab_page(&store::setting_get("shortcuts"), &text(icons_json), incognito))
}

/// The new-tab page as the phone's home screen: shortcuts and the installed
/// apps (`apps_json`, `[{"c": "package/activity", "n": "label"}, …]`) on
/// swipeable pages, and every app in All apps (the drawer). Reads the
/// `shortcuts`, `home_order`, `home_hidden` and `home_new_apps` settings.
/// `wallpaper`: 0 the page draws its own background; 1 the system wallpaper
/// shows through it, with light text; 2 the same with dark text (a light
/// wallpaper). Free with `fable_string_free`.
#[no_mangle]
pub unsafe extern "C" fn fable_launcher_page(icons_json: *const c_char, apps_json: *const c_char, wallpaper: c_int) -> *mut c_char {
    owned(pages::launcher_page(
        &store::setting_get("shortcuts"),
        &text(icons_json),
        &text(apps_json),
        &store::setting_get("home_order"),
        &store::setting_get("home_hidden"),
        store::setting_get("home_new_apps") != "0",
        wallpaper.clamp(0, 2) as u8,
    ))
}

/// Load settings and history from `dir` (created if missing).
#[no_mangle]
pub unsafe extern "C" fn fable_store_open(dir: *const c_char) {
    store::open(&text(dir));
}

/// "" when unset. Free with `fable_string_free`.
#[no_mangle]
pub unsafe extern "C" fn fable_setting_get(key: *const c_char) -> *mut c_char {
    owned(store::setting_get(&text(key)))
}

#[no_mangle]
pub unsafe extern "C" fn fable_setting_set(key: *const c_char, value: *const c_char) {
    store::setting_set(&text(key), &text(value));
}

#[no_mangle]
pub unsafe extern "C" fn fable_history_add(url: *const c_char, title: *const c_char, time_ms: u64) {
    store::history_add(&text(url), &text(title), time_ms);
}

/// JSON array, newest first. Free with `fable_string_free`.
#[no_mangle]
pub unsafe extern "C" fn fable_history_json(query: *const c_char, limit: usize) -> *mut c_char {
    owned(store::history_json(&text(query), limit))
}

#[no_mangle]
pub unsafe extern "C" fn fable_history_delete(url: *const c_char, time_ms: u64) {
    store::history_delete(&text(url), time_ms);
}

#[no_mangle]
pub extern "C" fn fable_history_clear() {
    store::history_clear();
}

#[no_mangle]
pub extern "C" fn fable_sniff_js() -> *const c_char {
    SNIFF_JS.as_ptr().cast()
}

/// Report a URL seen in a tab; returns 1 if it was added to the tab's resource list.
#[no_mangle]
pub unsafe extern "C" fn fable_sniff_note(tab: u32, url: *const c_char, hint: *const c_char) -> c_int {
    sniff::note(tab, &text(url), &text(hint)) as c_int
}

/// ui/sniff.js's result (JSON `[[hint, url], …]`) for `tab`; returns how many were new.
#[no_mangle]
pub unsafe extern "C" fn fable_sniff_note_scan(tab: u32, json: *const c_char) -> usize {
    sniff::note_scan(tab, &text(json))
}

/// A JSON string literal (quotes included) for `s`, safe inside <script> too.
#[no_mangle]
pub unsafe extern "C" fn fable_json_string(s: *const c_char) -> *mut c_char {
    owned(store::json_string(&text(s)))
}

/// The script that hands `text` to the panel as the answer to request `id`.
#[no_mangle]
pub unsafe extern "C" fn fable_panel_reply(id: u32, answer: *const c_char) -> *mut c_char {
    owned(format!("Fable.reply({id},{})", store::json_string(&text(answer))))
}

#[no_mangle]
pub extern "C" fn fable_sniff_count(tab: u32) -> usize {
    sniff::count(tab)
}

/// JSON array of the tab's resources. Free with `fable_string_free`.
#[no_mangle]
pub extern "C" fn fable_sniff_json(tab: u32) -> *mut c_char {
    owned(sniff::json(tab))
}

#[no_mangle]
pub extern "C" fn fable_sniff_clear(tab: u32) {
    sniff::clear(tab);
}

/// Returns a newly allocated string; release it with `fable_string_free`.
#[no_mangle]
pub unsafe extern "C" fn fable_resolve(input: *const c_char) -> *mut c_char {
    let url = omnibox::resolve(&text(input));
    CString::new(url).unwrap_or_default().into_raw()
}

#[no_mangle]
pub unsafe extern "C" fn fable_string_free(s: *mut c_char) {
    if !s.is_null() {
        drop(CString::from_raw(s));
    }
}

#[no_mangle]
pub unsafe extern "C" fn fable_set_search_template(template: *const c_char) -> c_int {
    omnibox::set_search_template(&text(template)) as c_int
}

#[no_mangle]
pub unsafe extern "C" fn fable_should_block(request_url: *const c_char, page_url: *const c_char) -> c_int {
    blocker::should_block(&text(request_url), &text(page_url)) as c_int
}

#[no_mangle]
pub extern "C" fn fable_blocked_count() -> u64 {
    blocker::blocked_count()
}

/// What this process blocks: the trackers and the ads. The settings live in
/// the process that owns the store; a web process (the Linux web extension)
/// has a copy of the core of its own, so the shell tells it what to block.
#[no_mangle]
pub extern "C" fn fable_set_blocking(trackers: c_int, ads: c_int) {
    blocker::set_enabled(trackers != 0);
    blocker::set_ads_enabled(ads != 0);
}

/// The blocked ones that were ads (of fable_blocked_count()).
#[no_mangle]
pub extern "C" fn fable_ads_blocked_count() -> u64 {
    blocker::ads_blocked_count()
}

/// The ad domains as a WebKit content-blocker rule list (WKContentRuleList on
/// macOS and iOS): a third-party load from a listed ad domain or any of its
/// subdomains is blocked. For fable_string_free.
#[no_mangle]
pub extern "C" fn fable_ads_content_rules() -> *mut c_char {
    owned(blocker::ads_content_rules_json())
}

/// The script that hides the ad boxes on a page (CSS installed through the
/// CSSOM). The shell runs it in the page after it loads. For fable_string_free.
#[no_mangle]
pub extern "C" fn fable_adblock_script() -> *mut c_char {
    owned(crate::adblock::script())
}

/// 1 when following this URL would leave the browser for another app and the
/// "block external apps" setting is on, so the navigation has to be stopped.
#[no_mangle]
pub unsafe extern "C" fn fable_block_external_app(url: *const c_char) -> c_int {
    crate::external::blocks(&text(url)) as c_int
}

/// Panel requests every shell answers the same way (settings, history, the
/// resource list of `tab`). Returns NULL when the shell must answer itself.
#[no_mangle]
pub unsafe extern "C" fn fable_panel_query(name: *const c_char, arg: *const c_char, tab: u32) -> *mut c_char {
    match panel::query(&text(name), &text(arg), tab) {
        Some(answer) => owned(answer),
        None => std::ptr::null_mut(),
    }
}

/// 1 when the panel bridge may store `value` under `key` (a key the panel or
/// home page writes, a bounded value); "set" through fable_panel_query checks
/// the same. For shells that answer "set" themselves.
#[no_mangle]
pub unsafe extern "C" fn fable_panel_setting_allowed(key: *const c_char, value: *const c_char) -> c_int {
    panel::setting_allowed(&text(key), &text(value)) as c_int
}

/// Every setting as a JSON object, for panels behind an asynchronous bridge.
#[no_mangle]
pub extern "C" fn fable_settings_json() -> *mut c_char {
    owned(panel::settings_json())
}

/// A public-IP service's reply as the panel's IP card JSON ("" if unusable).
#[no_mangle]
pub unsafe extern "C" fn fable_parse_ip_reply(body: *const c_char, source: *const c_char) -> *mut c_char {
    owned(panel::parse_ip_reply(&text(body), &text(source)))
}

/// This machine's facts for the metadata sheet (desktop): the brief page's
/// `device` object, with the shell's own `extras` (a JSON object, may be NULL) appended.
#[no_mangle]
pub unsafe extern "C" fn fable_device_info(extras: *const c_char) -> *mut c_char {
    owned(sysinfo::device_json(&sysinfo::collect(), &text(extras)))
}

/// The same for the metadata sections (`system` object), with `extras` appended.
#[no_mangle]
pub unsafe extern "C" fn fable_system_info(extras: *const c_char) -> *mut c_char {
    owned(sysinfo::system_json(&sysinfo::collect(), &text(extras)))
}

/// The blocklist as WebKit content-blocker JSON (macOS). Free with `fable_string_free`.
#[no_mangle]
pub extern "C" fn fable_content_rules() -> *mut c_char {
    owned(blocker::content_rules_json())
}

#[no_mangle]
pub extern "C" fn fable_tabs_new() -> *mut Tabs {
    Box::into_raw(Box::new(Tabs::new()))
}

#[no_mangle]
pub unsafe extern "C" fn fable_tabs_free(t: *mut Tabs) {
    if !t.is_null() {
        drop(Box::from_raw(t));
    }
}

#[no_mangle]
pub unsafe extern "C" fn fable_tabs_set_sleep_after_ms(t: *mut Tabs, ms: u64) {
    if let Some(t) = t.as_mut() {
        t.set_sleep_after_ms(ms);
    }
}

/// Returns the new tab's id (>= 1), or 0 on a NULL handle.
#[no_mangle]
pub unsafe extern "C" fn fable_tabs_open(t: *mut Tabs, now_ms: u64) -> u32 {
    t.as_mut().map_or(0, |t| t.open(now_ms))
}

#[no_mangle]
pub unsafe extern "C" fn fable_tabs_activate(t: *mut Tabs, id: u32, now_ms: u64) -> c_int {
    t.as_mut().is_some_and(|t| t.activate(id, now_ms)) as c_int
}

#[no_mangle]
pub unsafe extern "C" fn fable_tabs_touch(t: *mut Tabs, id: u32, now_ms: u64) -> c_int {
    t.as_mut().is_some_and(|t| t.touch(id, now_ms)) as c_int
}

#[no_mangle]
pub unsafe extern "C" fn fable_tabs_close(t: *mut Tabs, id: u32) -> c_int {
    t.as_mut().is_some_and(|t| t.close(id)) as c_int
}

#[no_mangle]
pub unsafe extern "C" fn fable_tabs_count(t: *const Tabs) -> usize {
    t.as_ref().map_or(0, Tabs::len)
}

#[no_mangle]
pub unsafe extern "C" fn fable_tabs_is_asleep(t: *const Tabs, id: u32) -> c_int {
    t.as_ref().is_some_and(|t| t.is_asleep(id)) as c_int
}

/// Writes up to `cap` ids of tabs that should go to sleep now into `out`,
/// marks them asleep, and returns how many were written.
#[no_mangle]
pub unsafe extern "C" fn fable_tabs_collect_sleepers(t: *mut Tabs, now_ms: u64, out: *mut u32, cap: usize) -> usize {
    match t.as_mut() {
        Some(t) if !out.is_null() && cap > 0 => t.collect_sleepers(now_ms, std::slice::from_raw_parts_mut(out, cap)),
        _ => 0,
    }
}
