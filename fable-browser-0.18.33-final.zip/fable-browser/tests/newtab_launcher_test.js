// The new-tab page as the phone's home screen (see tests/launcher_apps.json and tests/launcher_prelude.js).
(function () {
  var log = [];
  function check(name, ok) { log.push((ok ? 'ok   ' : 'FAIL ') + name); }
  function tiles() { return [].slice.call(document.querySelectorAll('.page a')); }
  function byName(n) { return tiles().filter(function (a) { return a.querySelector('.name').textContent === n; })[0]; }
  function sent(op) { return window.__home.filter(function (u) { return u.indexOf('home/' + op + '?') === 0; }); }
  function lastSet(key) { var s = sent('set').filter(function (u) { return u.indexOf('k=' + key + '&') >= 0; }); return s.length ? JSON.parse(decodeURIComponent(s[s.length - 1].split('&v=')[1])) : null; }
  function fire(el, type, x, y) { el.dispatchEvent(new PointerEvent(type, { bubbles: true, pointerId: 1, clientX: x, clientY: y, isPrimary: true })); }
  function center(el) { var r = el.getBoundingClientRect(); return [r.left + r.width / 2, r.top + r.height / 2]; }

  var pages = document.getElementById('pages');
  check('home screen: pages, dots, the logo on the first page', document.body.classList.contains('launcher') && pages.children.length >= 2
        && document.querySelectorAll('#dots i').length === pages.children.length && !!pages.children[0].querySelector('header'));
  check('sites first, then apps by name; a hidden app is left out', tiles()[0].querySelector('.name').textContent === 'Claude'
        && tiles().length === 8 + 29 && !byName('录音机'));
  check('a site and an app are the same kind of tile', byName('GitHub').querySelector('span.tile') && byName('微信').querySelector('span.tile')
        && (function (img) { return img ? img.getAttribute('src') === 'app-icon?c=' + encodeURIComponent('com.app10/.Main')
                                         : byName('微信').querySelector('span.tile').textContent === '微'; })(byName('微信').querySelector('img')));   // here the icon 404s: its initial
  check('an app name is text, not markup', !!byName('Notes <b>') && !document.querySelector('.page a b'));

  byName('微信').click();
  check('tapping an app asks the shell to start it', sent('launch')[0].split('&r=')[0] === 'home/launch?c=' + encodeURIComponent('com.app10/.Main'));
  (function () {
    var b = byName('微信').querySelector('span.tile').getBoundingClientRect();
    var want = [b.left, b.top, b.width, b.height].map(Math.round).join(',');
    check('… with where its icon is, for the opening animation (' + want + ')', sent('launch')[0].split('&r=')[1] === encodeURIComponent(want));
  })();
  check('a site is an ordinary link', byName('GitHub').getAttribute('href') === 'https://github.com/');

  // Long press: editing. ✕ on an app hides it; ✕ on a site removes the shortcut.
  var p = center(byName('相机'));
  fire(byName('相机'), 'pointerdown', p[0], p[1]);
  setTimeout(function () {
    fire(document, 'pointerup', p[0], p[1]);
    check('a long press starts editing', document.body.classList.contains('editing'));
    var tr = byName('相机').querySelector('span.tile').getBoundingClientRect(), xr = byName('相机').querySelector('.x').getBoundingClientRect();
    check('the remove badge sits on the tile\'s top right corner', Math.abs((xr.left + xr.width / 2) - tr.right) < 8 && Math.abs((xr.top + xr.height / 2) - tr.top) < 10);
    var dr = document.getElementById('done').getBoundingClientRect();
    check('Done sits in the top-right corner, above the top row', dr.top <= 16 && window.innerWidth - dr.right <= 20 && dr.bottom < byName('Gemini').getBoundingClientRect().top);
    byName('相机').querySelector('.x').click();
    check('removing an app hides it and keeps the order', !byName('相机') && JSON.stringify(lastSet('home_hidden')) === JSON.stringify(['a:com.app28/.Main', 'a:com.app0/.Main'])
          && lastSet('home_order').indexOf('a:com.app0/.Main') < 0 && lastSet('home_order')[0] === 'u:https://claude.ai/');
    byName('YouTube').querySelector('.x').click();
    var sc = lastSet('shortcuts');
    check('removing a site saves the shortcuts without it', sc && sc.length === 7 && sc.every(function (s) { return s.u !== 'https://www.youtube.com/'; }));

    // Drag ChatGPT onto Claude's place.
    var from = byName('ChatGPT'), a0 = center(from), b0 = center(byName('Claude'));
    fire(from, 'pointerdown', a0[0], a0[1]);
    fire(document, 'pointermove', a0[0] + 20, a0[1]);
    fire(document, 'pointermove', b0[0], b0[1]);
    fire(document, 'pointerup', b0[0], b0[1]);
    var order = lastSet('home_order');
    check('dragging a tile onto another takes its place', tiles()[0].querySelector('.name').textContent === 'ChatGPT' && order[0] === 'u:https://chatgpt.com/' && order[1] === 'u:https://claude.ai/');
    newPage();
  }, 600);

  // Dragged past the last page, a tile starts a new page; taken back, the empty page goes.
  function newPage() {
    var before = pages.children.length;
    pages.scrollLeft = (before - 1) * pages.clientWidth;
    var lastPage = pages.children[before - 1], mover = lastPage.querySelector('a'), name = mover.querySelector('.name').textContent;
    var c = center(mover), W = window.innerWidth;
    fire(mover, 'pointerdown', c[0], c[1]);
    fire(document, 'pointermove', c[0] + 20, c[1]);
    fire(document, 'pointermove', W - 8, c[1]);
    setTimeout(function () {
      var after = pages.children.length, newest = pages.children[after - 1];
      check('holding a tile at the right edge of the last page makes a new page for it', after === before + 1
            && newest.querySelectorAll('a').length === 1 && newest.querySelector('.name').textContent === name);
      fire(document, 'pointerup', W - 8, c[1]);
      var order = lastSet('home_order');
      check('the new page is kept as a page break', order[order.length - 2] === '|' && order[order.length - 1] === mover.dataset.key);
      window.dispatchEvent(new Event('resize'));   // laid out again from the order: still on its own page
      check('a page break survives a new layout', pages.children.length === before + 1);

      // Drag it to the empty part of the page before: it joins that page, and the empty page goes.
      pages.scrollLeft = (after - 2) * pages.clientWidth;
      var tile = byName(name), t = center(tile), prev = pages.children[after - 2];
      fire(tile, 'pointerdown', t[0], t[1]);
      fire(document, 'pointermove', t[0] - 20, t[1]);
      var r = prev.getBoundingClientRect();
      fire(document, 'pointermove', W / 2, r.bottom - 40);
      fire(document, 'pointerup', W / 2, r.bottom - 40);
      var o2 = lastSet('home_order');
      check('dropped on an empty part of a page, it joins that page and the extra page goes', pages.children.length === before
            && byName(name).closest('.page') === pages.children[before - 1] && o2.indexOf('|') < 0);
      finish();
    }, 900);
  }

  function finish() {
    document.getElementById('done').click();
    check('Done ends editing', !document.body.classList.contains('editing'));
    pages.scrollLeft = pages.clientWidth;
    window.fableHome();
    setTimeout(function () {
      check('the Home key goes back to the first page', Math.abs(pages.scrollLeft) < 2);
      console.log(log.join('\n'));
    }, 600);
  }
  return 'started';
})();
