#!/bin/sh
# scripts/ci/mac-smoke.sh and ios-smoke.sh must fail when something important
# is wrong (audit finding Medium-10: they used to report problems and pass
# anyway). Runs each on any machine against a stand-in app and stand-ins for
# the macOS tools (lipo, codesign, open, xcrun simctl ...), once healthy (must
# pass) and once per fault (must fail); under sh, and under bash as well when
# it is installed (a Mac's sh is bash, where pipefail is on).
set -u
cd "$(dirname "$0")/.."
ROOT=$PWD
failures=0

scenario() {   # $1: name, $2: expected exit (0 or 1); FAULT=<what to break>
    name=$1; want=$2
    T=$(mktemp -d)
    mkdir -p "$T/scripts/ci" "$T/build/macos/Fable.app/Contents/MacOS" "$T/bin"
    cp "$ROOT/scripts/ci/mac-smoke.sh" "$T/scripts/ci/"
    # The stand-in app: writes the snapshot the real one writes after a page load, then stays up.
    cat > "$T/build/macos/Fable.app/Contents/MacOS/Fable" <<APP
#!/bin/sh
host=home
case "\${1:-}" in http*) host=\$(echo "\$1" | sed 's#^[a-z]*://##; s#/.*##') ;; esac
[ "\$FAULT" = exits ] && exit 3
[ "\$FAULT" = panic ] && echo "thread 'main' panicked at src/ffi.rs:1:1"
case "\$FAULT" in
    noload) ;;
    emptyshot) : > "\$FABLE_SNAPSHOT_DIR/macos-01-\$host.png" ;;
    *) echo png > "\$FABLE_SNAPSHOT_DIR/macos-01-\$host.png" ;;
esac
echo \$\$ > "$T/app.pid"
exec sleep 300
APP
    chmod +x "$T/build/macos/Fable.app/Contents/MacOS/Fable"
    cat > "$T/bin/lipo" <<'S'
#!/bin/sh
case "$1" in -archs) [ "$FAULT" = thin ] && echo arm64 || echo "x86_64 arm64" ;; *) echo "Architectures in the fat file: x86_64 arm64" ;; esac
S
    cat > "$T/bin/codesign" <<'S'
#!/bin/sh
[ "$FAULT" = unsigned ] && { echo "code object is not signed at all"; exit 1; }; echo valid
S
    cat > "$T/bin/otool" <<'S'
#!/bin/sh
echo "$2:"; printf '\t/System/Library/Frameworks/WebKit.framework/Versions/A/WebKit (compatibility version 1.0.0)\n\t/usr/lib/libSystem.B.dylib (compatibility version 1.0.0)\n'
[ "$FAULT" = dylib ] && printf '\t/opt/homebrew/lib/libfoo.dylib (compatibility version 1.0.0)\n'; exit 0
S
    cat > "$T/bin/open" <<S
#!/bin/sh
# open -a APP [--env K=V] [URL]: start the app once; a URL goes to the running copy.
url=""; for x in "\$@"; do case "\$x" in http*) url=\$x ;; esac; done
if [ -z "\$url" ]; then FABLE_SNAPSHOT_DIR="$T/build/ci" "$T/build/macos/Fable.app/Contents/MacOS/Fable" > /dev/null 2>&1 & exit 0; fi
[ "\$FAULT" = second ] && { FABLE_SNAPSHOT_DIR="$T/build/ci" sleep 300 & echo \$! > "$T/second.pid"; }
host=\$(echo "\$url" | sed 's#^[a-z]*://##; s#/.*##'); echo png > "$T/build/ci/macos-09-\$host.png"
S
    cat > "$T/bin/pgrep" <<S
#!/bin/sh
cat "$T/app.pid" 2>/dev/null; cat "$T/second.pid" 2>/dev/null; exit 0
S
    printf '#!/bin/sh\nexit 0\n' > "$T/bin/log"
    chmod +x "$T/bin/"*
    # Shorter waits: the script's sleeps are for a real app.
    sed -i.bak 's/WAIT=1[0-9]/WAIT=1/g; s/^sleep 10$/sleep 1/' "$T/scripts/ci/mac-smoke.sh"
    PATH="$T/bin:$PATH" FAULT=${FAULT:-} $SH "$T/scripts/ci/mac-smoke.sh" > "$T/out.txt" 2>&1
    got=$?
    [ "$got" -ne 0 ] && got=1
    for f in "$T/app.pid" "$T/second.pid"; do [ -f "$f" ] && kill "$(cat "$f")" 2>/dev/null; done
    pkill -f "$T/build/macos" 2>/dev/null
    if [ "$got" = "$want" ]; then echo "ok   mac-smoke ($SH) $name: exit $got"; else
        echo "FAIL mac-smoke ($SH) $name: exit $got, want $want"; sed 's/^/       /' "$T/out.txt" | tail -n 15; failures=$((failures + 1)); fi
    rm -rf "$T"
}

ios_scenario() {   # $1: name, $2: expected exit; FAULT=<what to break>
    name=$1; want=$2
    T=$(mktemp -d)
    mkdir -p "$T/scripts/ci" "$T/build/ios/DerivedData/Build/Products/Debug-iphonesimulator/Fable.app" "$T/bin"
    cp "$ROOT/scripts/ci/ios-smoke.sh" "$T/scripts/ci/"
    sed -i.bak 's/^sleep [0-9]*;/sleep 1;/; s/^sleep [0-9]*$/sleep 1/; s/sleep 3; shot dark/shot dark/' "$T/scripts/ci/ios-smoke.sh"
    # xcrun simctl, enough of it: one iPhone, an app that stays up after launch.
    cat > "$T/bin/xcrun" <<S
#!/bin/sh
[ "\$1" = simctl ] || exit 1; shift
cmd=\$1; shift
case "\$cmd" in
    list) case "\$*" in *-j*) echo '{"devices":{"com.apple.CoreSimulator.SimRuntime.iOS-26-5":[{"udid":"U1","name":"iPhone 17"}]}}' ;; *) echo "iPhone 17 (U1)" ;; esac ;;
    boot) exit 0 ;;
    bootstatus) [ "\$FAULT" = noboot ] && exit 1; exit 0 ;;
    install) [ "\$FAULT" = noinstall ] && exit 1; exit 0 ;;
    terminate) rm -f "$T/alive"; exit 0 ;;
    launch) [ "\$FAULT" = panic ] && echo "thread 'main' panicked at src/ffi.rs:1:1"
            [ "\$FAULT" = exits ] || touch "$T/alive"; exit 0 ;;
    spawn) shift; case "\$1" in
        launchctl) echo "PID Status Label"; [ -f "$T/alive" ] && echo "- 0 UIKitApplication:app.fable.browser[1234]"; exit 0 ;;
        log) [ "\$FAULT" = noload ] || echo "WebKit: didGeneratePageLoadTiming: 1.2s, subresources 3"; exit 0 ;;
        esac ;;
    io) out=\$3; [ "\$FAULT" = noshot ] && exit 1; [ "\$FAULT" = emptyshot ] && { : > "\$out"; exit 0; }; echo png > "\$out" ;;
    ui) [ "\$FAULT" = noui ] && exit 1; exit 0 ;;
esac
exit 0
S
    chmod +x "$T/bin/"*
    PATH="$T/bin:$PATH" FAULT=${FAULT:-} $SH "$T/scripts/ci/ios-smoke.sh" > "$T/out.txt" 2>&1
    got=$?
    [ "$got" -ne 0 ] && got=1
    if [ "$got" = "$want" ]; then echo "ok   ios-smoke ($SH) $name: exit $got"; else
        echo "FAIL ios-smoke ($SH) $name: exit $got, want $want"; sed 's/^/       /' "$T/out.txt" | tail -n 15; failures=$((failures + 1)); fi
    rm -rf "$T"
}

for SH in sh $(command -v bash >/dev/null 2>&1 && echo bash); do
    FAULT= scenario healthy 0
    for f in thin unsigned dylib exits panic noload emptyshot second; do FAULT=$f scenario "$f" 1; done
    FAULT= ios_scenario healthy 0
    for f in noboot noinstall exits panic noload noshot emptyshot noui; do FAULT=$f ios_scenario "$f" 1; done
done
[ $failures = 0 ] && echo "smoke_selftest: all checks passed" || { echo "smoke_selftest: $failures failure(s)"; exit 1; }
