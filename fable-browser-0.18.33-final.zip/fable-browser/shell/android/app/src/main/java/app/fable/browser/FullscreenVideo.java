package app.fable.browser;

import android.app.Activity;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.WebChromeClient;
import android.widget.FrameLayout;

/**
 * A page going fullscreen (a video's fullscreen button, say) hands its view over through
 * WebChromeClient.onShowCustomView. This class shows that view over the whole activity
 * with the system bars out of the way, and puts everything back — the page's view, the
 * bars, the callback — when the video leaves fullscreen, Back is pressed, or the
 * activity pauses. Kept in a class of its own so the wiring in MainActivity stays
 * three lines, and so it can be tested without any of the browser around it.
 */
final class FullscreenVideo {
    private final Activity activity;
    private final Runnable restoreBars;   // the user's status-bar setting, applied again
    private View view;                    // the page's fullscreen view, on loan until hide()
    private WebChromeClient.CustomViewCallback callback;

    FullscreenVideo(Activity activity, Runnable restoreBars) {
        this.activity = activity;
        this.restoreBars = restoreBars;
    }

    boolean showing() {
        return view != null;
    }

    /** The page's fullscreen view, over everything, with the system bars out of the way. */
    void show(View view, WebChromeClient.CustomViewCallback callback) {
        if (this.view != null) {   // already showing one: the first stays, the page is told the second is not coming
            if (callback != null) callback.onCustomViewHidden();
            return;
        }
        this.view = view;
        this.callback = callback;
        decor().addView(view, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setBars(false);
    }

    /** Back, the page leaving fullscreen, or the activity pausing: the page back the way it was. */
    boolean hide() {
        if (view == null) return false;
        decor().removeView(view);
        view = null;
        WebChromeClient.CustomViewCallback done = callback;
        callback = null;
        if (done != null) done.onCustomViewHidden();   // lets the page clean up after its fullscreen view
        setBars(true);
        restoreBars.run();   // the status bar back to the user's setting (the navigation bar is always shown)
        return true;
    }

    private ViewGroup decor() {
        return (ViewGroup) activity.getWindow().getDecorView();
    }

    /** Out of the way for the video; back (status bar to its setting, navigation bar shown) when it is over. */
    private void setBars(boolean show) {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = activity.getWindow().getInsetsController();
            if (c == null) return;
            if (show) c.show(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
            else c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
        } else {
            View decor = activity.getWindow().getDecorView();
            int flags = decor.getSystemUiVisibility();
            int mask = View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            decor.setSystemUiVisibility(show ? flags & ~mask : flags | mask);
        }
    }
}
