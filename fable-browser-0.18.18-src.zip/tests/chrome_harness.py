#!/usr/bin/env python3
"""Run a page check in headless Chrome at phone size, with touch events (which
WebKitGTK's desktop build does not construct). Same arguments as web_harness.py
for the parts the page checks use; the page is filled the same way the core does.

usage: chrome_harness.py ui/newtab.html out.png --lang zh-Hans --launcher tests/launcher_drawer.json \
           --prelude tests/launcher_prelude.js --js tests/newtab_drawer_test.js --wait 9

Needs only Python 3 and a Chrome or Chromium (google-chrome, chromium, or $CHROME):
it speaks the DevTools protocol over --remote-debugging-pipe, no Playwright.

Prints the page's console lines and the script's result. Exits 1 when a line
says FAIL, the page or the script threw, or the page did not load; 0 otherwise
(tests/ui_test.py also checks that checks ran at all)."""
import argparse, base64, json, os, re, shutil, subprocess, sys, tempfile, threading, time

ap = argparse.ArgumentParser(); ap.add_argument("url"); ap.add_argument("out")
ap.add_argument("--js"); ap.add_argument("--wait", type=float, default=1.5)
ap.add_argument("--width", type=int, default=390); ap.add_argument("--height", type=int, default=844)
ap.add_argument("--lang", default=""); ap.add_argument("--incognito", default="")
ap.add_argument("--prelude", default=""); ap.add_argument("--launcher", default="")
ap.add_argument("--timeout", type=float, default=90, help="give up (and fail) after this many seconds")
a = ap.parse_args()

here = os.path.dirname(os.path.abspath(__file__))
path, _, frag = a.url.partition("#")
html = open(path, encoding="utf-8").read()
if a.lang:
    col = ["zh-Hans", "zh-Hant", "ja", "en", "ko", "ru", "fr", "es", "ar"].index(a.lang) + 1
    strings = {"_lang": a.lang}
    for line in open(os.path.join(here, "..", "ui", "strings.tsv"), encoding="utf-8"):
        cells = line.rstrip("\n").split("\t")
        if len(cells) == 10 and not line.startswith("#"): strings[cells[0]] = cells[col]
    html = html.replace("/*FABLE_STRINGS*/null/*END*/", json.dumps(strings, ensure_ascii=False))
if a.incognito: html = html.replace("/*FABLE_INCOGNITO*/false/*END*/", "true" if a.incognito == "true" else '"shared"')
if a.launcher: html = html.replace("/*FABLE_LAUNCHER*/null/*END*/", open(a.launcher, encoding="utf-8").read().strip().replace("<", "\\u003c"))
if a.prelude:
    pre = "<script>" + open(a.prelude, encoding="utf-8").read() + "</script>"
    html = html.replace("<head>", "<head>" + pre, 1) if "<head>" in html else pre + html
page_file = tempfile.NamedTemporaryFile("w", suffix=".html", delete=False, encoding="utf-8"); page_file.write(html); page_file.close()
url = "file://" + page_file.name + ("#" + frag if frag else "")

chrome = os.environ.get("CHROME") or shutil.which("google-chrome") or shutil.which("chromium") or shutil.which("chromium-browser")
if not chrome:
    print("FAIL no Chrome found (set $CHROME)"); sys.exit(1)
profile = tempfile.mkdtemp(prefix="fable-chrome-")
# DevTools over a pipe: Chrome reads commands on fd 3 and writes replies on fd 4.
to_chrome_r, to_chrome_w = os.pipe()
from_chrome_r, from_chrome_w = os.pipe()
flags = ["--headless=new", "--no-sandbox", "--disable-gpu", "--no-first-run", "--no-default-browser-check",
         "--remote-debugging-pipe", "--user-data-dir=" + profile, "--allow-file-access-from-files",
         "--lang=" + (a.lang or "en"), "about:blank"]
proc = subprocess.Popen(["sh", "-c", 'exec "$@" 3<&%d 4>&%d' % (to_chrome_r, from_chrome_w), "sh", chrome] + flags,
                        pass_fds=(to_chrome_r, from_chrome_w), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
os.close(to_chrome_r); os.close(from_chrome_w)
writer = os.fdopen(to_chrome_w, "wb", buffering=0)
reader = os.fdopen(from_chrome_r, "rb", buffering=0)

failed = []
replies, events, lock = {}, [], threading.Condition()
def read_loop():
    buf = b""
    while True:
        chunk = reader.read(65536)
        if not chunk: break
        buf += chunk
        while b"\0" in buf:
            msg, buf = buf.split(b"\0", 1)
            d = json.loads(msg)
            with lock:
                if "id" in d: replies[d["id"]] = d
                else: events.append(d)
                lock.notify_all()
            if d.get("method") == "Runtime.consoleAPICalled":
                text = " ".join(str(x.get("value", x.get("description", ""))) for x in d["params"]["args"])
                print(text, flush=True)
                if re.search(r"\bFAIL\b", text): failed.append("console")
            elif d.get("method") == "Runtime.exceptionThrown":
                e = d["params"]["exceptionDetails"]
                print("FAIL page error:", (e.get("exception") or {}).get("description") or e.get("text"), flush=True)
                failed.append("page error")
threading.Thread(target=read_loop, daemon=True).start()

deadline = time.time() + a.timeout
next_id = [0]
def send(method, params=None, session=None):
    next_id[0] += 1; i = next_id[0]
    msg = {"id": i, "method": method, "params": params or {}}
    if session: msg["sessionId"] = session
    writer.write(json.dumps(msg).encode() + b"\0")
    with lock:
        while i not in replies:
            if time.time() > deadline or proc.poll() is not None: raise TimeoutError(method)
            lock.wait(0.2)
        d = replies.pop(i)
    if "error" in d: raise RuntimeError("%s: %s" % (method, d["error"]))
    return d.get("result", {})
def wait_event(name, session):
    with lock:
        while True:
            for e in events:
                if e.get("method") == name and e.get("sessionId") == session:
                    events.remove(e); return e
            if time.time() > deadline or proc.poll() is not None: raise TimeoutError(name)
            lock.wait(0.2)

code = 0
try:
    target = send("Target.createTarget", {"url": "about:blank"})["targetId"]
    s = send("Target.attachToTarget", {"targetId": target, "flatten": True})["sessionId"]
    send("Runtime.enable", session=s); send("Page.enable", session=s)
    send("Emulation.setDeviceMetricsOverride", {"width": a.width, "height": a.height, "deviceScaleFactor": 2, "mobile": True}, s)
    send("Emulation.setTouchEmulationEnabled", {"enabled": True, "maxTouchPoints": 5}, s)
    send("Emulation.setUserAgentOverride", {"userAgent": "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36",
                                            "acceptLanguage": a.lang or "en"}, s)
    nav = send("Page.navigate", {"url": url}, s)
    if nav.get("errorText"): print("FAIL load failed:", nav["errorText"]); failed.append("load")
    wait_event("Page.loadEventFired", s)
    time.sleep(0.3)
    if a.js:
        r = send("Runtime.evaluate", {"expression": open(a.js, encoding="utf-8").read(), "returnByValue": True, "awaitPromise": False}, s)
        if "exceptionDetails" in r:
            e = r["exceptionDetails"]
            print("FAIL js error:", (e.get("exception") or {}).get("description") or e.get("text")); failed.append("js")
        else:
            value = r.get("result", {}).get("value", r.get("result", {}).get("description"))
            print("js result:", value, flush=True)
            if re.search(r"\bFAIL\b", str(value)): failed.append("result")
    time.sleep(a.wait)
    shot = send("Page.captureScreenshot", {"format": "png"}, s)
    with open(a.out, "wb") as f: f.write(base64.b64decode(shot["data"]))
except Exception as e:  # a timeout, Chrome gone, a protocol error
    print("FAIL harness:", type(e).__name__, e); failed.append("harness")
finally:
    try: send("Browser.close") if proc.poll() is None and time.time() < deadline else None
    except Exception: pass
    try: proc.wait(5)
    except subprocess.TimeoutExpired: proc.kill()
    os.unlink(page_file.name); shutil.rmtree(profile, ignore_errors=True)
sys.stdout.flush()
sys.exit(1 if failed else 0)
