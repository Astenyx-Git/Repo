// The Sailfish shell's C++ side, run against desktop Qt 5 and the real core
// (tests/sailfish_test.sh builds it). Also writes, into the directory given as
// argv[1], the panel page the bridge builds and the scripts it hands QML, for
// tests/sailfish/panel_test.js to run in a browser.
#include <QCoreApplication>
#include <QFile>
#include <QImage>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QStringList>
#include <QVariantList>
#include <QVariantMap>
#include <cstdio>

#include "fablecore.h"
#include "panelbridge.h"

static int checks = 0, failures = 0;

static void check(const char *name, bool ok)
{
    ++checks;
    if (!ok) ++failures;
    std::printf("%s %s\n", ok ? "ok  " : "FAIL", name);
}

static QVariantMap tab(const QString &url, const QString &title, bool incognito)
{
    QVariantMap t;
    t[QStringLiteral("url")] = url;
    t[QStringLiteral("title")] = title;
    t[QStringLiteral("incognito")] = incognito;
    return t;
}

static bool writeFile(const QString &path, const QByteArray &bytes)
{
    QFile f(path);
    return f.open(QIODevice::WriteOnly) && f.write(bytes) == bytes.size();
}

int main(int argc, char **argv)
{
    QCoreApplication app(argc, argv);
    if (argc < 2) { std::printf("usage: bridge_test DIR\n"); return 2; }
    const QString dir = QString::fromLocal8Bit(argv[1]);
    FableCore *core = FableCore::instance();
    core->storeOpen(dir + QStringLiteral("/profile"));
    PanelBridge bridge(core);
    QStringList actions, settings;
    QObject::connect(&bridge, &PanelBridge::actionRequested,
                     [&](const QString &name, const QString &arg) { actions << name + QLatin1Char('|') + arg; });
    QObject::connect(&bridge, &PanelBridge::settingChanged, [&](const QString &key) { settings << key; });

    // ---- the panel page: the stand-in must run before the panel picks its protocol
    const QString html = bridge.panelHtml();
    const int stand = html.indexOf(QLatin1String("window.FableSheet=true"));
    const int panel = html.indexOf(QLatin1String("var bridge = window.FableUI"));
    check("the stand-in for the message handler sits in <head>, before the panel's script",
          stand > 0 && panel > stand && stand < html.indexOf(QLatin1String("</head>")));
    check("the panel's CSP lets the shell's scripts run, and still loads nothing",
          html.contains(QLatin1String("script-src 'unsafe-inline' 'unsafe-eval'")) && html.contains(QLatin1String("default-src 'none'")));
    writeFile(dir + QStringLiteral("/panel.html"), html.toUtf8());

    // ---- the new-tab page
    const QString home = bridge.homeHtml(false);
    const int host = home.indexOf(QLatin1String("window.FableHost="));
    check("the new-tab page gets its FableHost stand-in before its own script",
          host > 0 && host < home.indexOf(QLatin1String("function go(q)")) && host < home.indexOf(QLatin1String("</head>")));
    check("so does the new-tab page's", home.contains(QLatin1String("script-src 'unsafe-inline' 'unsafe-eval'")));
    writeFile(dir + QStringLiteral("/home.html"), home.toUtf8());
    check("only the page Fable loads counts as the new-tab page",
          bridge.isHome(QStringLiteral("https://fable.invalid/newtab")) && !bridge.isHome(QStringLiteral("https://fable.invalid/newtab.evil.example/"))
          && !bridge.isHome(QStringLiteral("https://example.com/?https://fable.invalid/newtab")));
    check("Fable's own pages are not web pages: never kept, never in history",
          !bridge.isWeb(bridge.homeUrl()) && !bridge.isWeb(QStringLiteral("https://FABLE.invalid/panel.html"))
          && bridge.isWeb(QStringLiteral("https://jolla.com/")) && !bridge.isWeb(QStringLiteral("https:///x")) && !bridge.isWeb(QStringLiteral("about:blank")));
    check("a search from the new-tab page is opened; anything else from it is not",
          bridge.homeQuery(QStringLiteral("go\t jolla phone ")) == QLatin1String("jolla phone")
          && bridge.homeQuery(QStringLiteral("a\topen\thttps://x.example/")).isEmpty());

    // ---- questions
    QString r = bridge.handleMessage(QStringLiteral("q\t7\tget\tlanguage"), 0, QStringLiteral("{}"));
    check("a question is answered with Fable.reply and its id", r.startsWith(QLatin1String("Fable.reply(7,")));
    r = bridge.handleMessage(QStringLiteral("q\t8\tset\tjavascript\n0"), 0, QStringLiteral("{}"));
    check("set stores through the core and tells the shell which setting changed",
          core->settingGet(QStringLiteral("javascript")) == QLatin1String("0") && settings == QStringList{QStringLiteral("javascript")}
          && r == QLatin1String("Fable.reply(8,\"\")"));
    r = bridge.handleMessage(QStringLiteral("q\t9\tdevice\t"), 0, QStringLiteral("{\"engine\":\"Gecko (Sailfish WebView)\",\"screenW\":1080}"));
    check("device: the core's facts with what QML knows", r.startsWith(QLatin1String("Fable.reply(9,")) && r.contains(QLatin1String("Sailfish WebView")));
    r = bridge.handleMessage(QStringLiteral("q\t10\ticon\texample.com"), 0, QStringLiteral("{}"));
    check("icon: answered empty, so the panel is not left waiting", r == QLatin1String("Fable.reply(10,\"\")"));
    check("a question without a number, or not a message at all, is dropped",
          bridge.handleMessage(QStringLiteral("q\tx\tget\tlanguage"), 0, QStringLiteral("{}")).isEmpty()
          && bridge.handleMessage(QStringLiteral("hello"), 0, QStringLiteral("{}")).isEmpty());

    // ---- actions
    bridge.handleMessage(QStringLiteral("a\topen\thttps://a.example/\tb"), 0, QStringLiteral("{}"));
    bridge.handleMessage(QStringLiteral("a\thidden\t"), 0, QStringLiteral("{}"));
    bridge.handleMessage(QStringLiteral("a\t\tnameless"), 0, QStringLiteral("{}"));
    check("actions reach the shell with their whole argument, tabs included; a nameless one does not",
          actions == QStringList{QStringLiteral("open|https://a.example/\tb"), QStringLiteral("hidden|")});

    // ---- what the shell can do
    const QJsonObject caps = QJsonDocument::fromJson(bridge.caps().toUtf8()).object();
    check("caps: no tracker blocking, cookie clearing, find, JavaScript switch, text size or tab sleep; bookmarks and restoring tabs",
          caps.value(QStringLiteral("networkBlock")) == QJsonValue(false) && caps.value(QStringLiteral("clearSiteData")) == QJsonValue(false)
          && caps.value(QStringLiteral("find")) == QJsonValue(false) && caps.value(QStringLiteral("javascript")) == QJsonValue(false)
          && caps.value(QStringLiteral("textSize")) == QJsonValue(false) && caps.value(QStringLiteral("tabSleep")) == QJsonValue(false)
          && caps.value(QStringLiteral("bookmarks")) == QJsonValue(true)
          && caps.value(QStringLiteral("restoreTabs")) == QJsonValue(true));
    check("user agents: the WebView's own by default, a Gecko one for desktop sites, custom ones tidied",
          bridge.userAgent(QStringLiteral("default"), QString()).isEmpty()
          && bridge.userAgent(QStringLiteral("desktop"), QString()).contains(QLatin1String("Firefox"))
          && bridge.userAgent(QStringLiteral("iphone"), QString()).contains(QLatin1String("iPhone"))
          && bridge.userAgent(QStringLiteral("custom"), QStringLiteral("  My   UA ")) == QLatin1String("My UA"));

    // ---- restoring tabs
    QVariantList tabs;
    tabs << tab(QStringLiteral("https://a.example/"), QStringLiteral("A"), false)
         << tab(QStringLiteral("https://p.example/"), QStringLiteral("P"), true)
         << tab(QStringLiteral("about:blank"), QString(), false)
         << tab(QStringLiteral("https://fable.invalid/newtab"), QStringLiteral("New tab"), false)
         << tab(QString(), QStringLiteral("New tab"), false)
         << tab(QStringLiteral("https://b.example/"), QStringLiteral("B \"quoted\""), false);
    check("the snapshot is taken", bridge.saveSession(tabs, 5));
    check("only the two web pages and the normal new tab enter it", !core->sessionJson().contains(QLatin1String("p.example")) && core->sessionCount() == 3);
    QVariantMap back = bridge.restoreSession();
    const QVariantList restored = back.value(QStringLiteral("tabs")).toList();
    check("they come back in order, the one in front marked",
          restored.size() == 3 && restored.at(0).toMap().value(QStringLiteral("url")) == QLatin1String("https://a.example/")
          && restored.at(1).toMap().value(QStringLiteral("url")).toString().isEmpty()
          && restored.at(2).toMap().value(QStringLiteral("title")) == QLatin1String("B \"quoted\"")
          && back.value(QStringLiteral("active")).toInt() == 2);
    core->settingSet(QStringLiteral("restore_tabs"), QStringLiteral("0"));
    check("switched off: nothing comes back, nothing is kept", bridge.restoreSession().isEmpty() && core->sessionCount() == 0);
    core->settingSet(QStringLiteral("restore_tabs"), QString());

    // ---- bookmark files
    const QString file = dir + QStringLiteral("/bookmarks.html");
    const QString text = QStringLiteral("<DL><p><DT><A HREF=\"https://jolla.com/\">旗鱼</A></DL>");
    check("a bookmark file is written and read back as UTF-8", bridge.writeText(file, text) && bridge.readText(file) == text);
    writeFile(dir + QStringLiteral("/big.html"), QByteArray(32 * 1024 * 1024 + 1, 'x'));
    check("a file over 32 MiB, or one that is not there, reads as nothing",
          bridge.readText(dir + QStringLiteral("/big.html")).isEmpty() && bridge.readText(dir + QStringLiteral("/missing.html")).isEmpty());
    const QString first = bridge.downloadsPath(QStringLiteral("bookmarks.html"));
    writeFile(first, "x");
    const QString second = bridge.downloadsPath(QStringLiteral("bookmarks.html"));
    check("exports never overwrite: bookmarks.html, then bookmarks-2.html",
          first.endsWith(QLatin1String("/bookmarks.html")) && second.endsWith(QLatin1String("/bookmarks-2.html")));

    // ---- for the browser half of the test: the scripts QML runs in the panel
    QJsonObject generated;
    generated[QStringLiteral("drain")] = bridge.drainScript();
    const QString reply = core->panelReply(424242, QStringLiteral("[{\"t\":1,\"u\":\"https://jolla.com/\",\"n\":\"Jolla \u2028</script>\"}]"));
    generated[QStringLiteral("reply")] = reply;
    generated[QStringLiteral("run")] = bridge.runScript(reply);
    writeFile(dir + QStringLiteral("/generated.js"),
              "var SAILFISH = " + QJsonDocument(generated).toJson(QJsonDocument::Compact) + ";\n");

    // ---- a QR code from a picture (FableCore::qrDecodeImage), from the core's own test plane
    {
        QFile f(QStringLiteral("tests/qr/perspective-212x210.y8"));
        const QByteArray y8 = f.open(QIODevice::ReadOnly) ? f.readAll() : QByteArray();
        const QImage plane = QImage(reinterpret_cast<const uchar *>(y8.constData()), 212, 210, 212, QImage::Format_Grayscale8).copy();
        const QString want = QStringLiteral("QR MODEL 2 / VERSION 7 / 123456789012345678901234567890");
        const QString small = dir + QStringLiteral("/qr.png"), colour = dir + QStringLiteral("/qr.jpg"), big = dir + QStringLiteral("/qr-big.png");
        check("a QR code is read from a picture", y8.size() == 212 * 210 && plane.save(small) && core->qrDecodeImage(small) == want);
        check("... a colour one", plane.convertToFormat(QImage::Format_RGB32).save(colour, "JPG", 95) && core->qrDecodeImage(colour) == want);
        // 4400 x 4359: past the decoder's 4096 px an edge and 4 MP, so it is shrunk first
        check("... one too big for the decoder, shrunk first",
              plane.scaled(4400, 4359, Qt::IgnoreAspectRatio, Qt::FastTransformation).save(big) && core->qrDecodeImage(big) == want);
        QImage blank(300, 300, QImage::Format_RGB32);
        blank.fill(Qt::white);
        check("a picture without a code, or no picture at all, reads as nothing",
              blank.save(dir + QStringLiteral("/blank.png")) && core->qrDecodeImage(dir + QStringLiteral("/blank.png")).isEmpty() &&
              core->qrDecodeImage(dir + QStringLiteral("/none.png")).isEmpty());
    }

    std::printf("bridge_test: %d checks, %d failed\n", checks, failures);
    return failures ? 1 : 0;
}
