// One tab: a WKWebView while awake, only its address while asleep.
import UIKit
import WebKit

final class Tab: NSObject {
    let id: UInt32
    let isPrivate: Bool
    /// nil while the tab sleeps; the address is kept so it can wake up.
    private(set) var web: WKWebView?
    /// What the address bar shows: "" on the new-tab page.
    var url = ""
    /// What loads when the tab wakes up.
    var pageURL = Browser.home
    var title: String
    private var observers: [NSKeyValueObservation] = []
    weak var browser: BrowserViewController?

    init(id: UInt32, isPrivate: Bool, browser: BrowserViewController) {
        self.id = id
        self.isPrivate = isPrivate
        self.browser = browser
        self.title = Core.tr("newtab")
    }

    var isHome: Bool { pageURL.hasPrefix(Browser.home) }

    /// Give the tab a web view. WebKit hands over the configuration of a
    /// window a page opens (createWebViewWith); it must be used as it is.
    @discardableResult
    func wake(configuration: WKWebViewConfiguration) -> WKWebView {
        if let web = web { return web }
        let web = WKWebView(frame: .zero, configuration: configuration)
        web.navigationDelegate = self
        web.uiDelegate = self
        web.allowsBackForwardNavigationGestures = true
        web.allowsLinkPreview = true
        web.isOpaque = false
        web.backgroundColor = isPrivate ? Palette.darkBar : Palette.ground
        web.scrollView.backgroundColor = web.backgroundColor
        web.scrollView.keyboardDismissMode = .interactive
        if #available(iOS 16.4, *) {
#if DEBUG
            web.isInspectable = true   // Safari ▸ Develop on a Mac
#endif
        }
        let refresh = UIRefreshControl()
        refresh.addTarget(self, action: #selector(pulledToRefresh(_:)), for: .valueChanged)
        web.scrollView.refreshControl = refresh
        self.web = web
        observers = [
            web.observe(\.url) { [weak self] _, _ in self?.urlChanged() },
            web.observe(\.title) { [weak self] web, _ in
                guard let self = self, let t = web.title, !t.isEmpty else { return }
                self.title = t
                self.browser?.tabChanged(self)
            },
            web.observe(\.isLoading) { [weak self] _, _ in self.map { $0.browser?.tabChanged($0) } },
            web.observe(\.estimatedProgress) { [weak self] _, _ in self.map { $0.browser?.tabChanged($0) } },
            web.observe(\.canGoBack) { [weak self] _, _ in self.map { $0.browser?.tabChanged($0) } },
            web.observe(\.canGoForward) { [weak self] _, _ in self.map { $0.browser?.tabChanged($0) } },
        ]
        return web
    }

    /// Drop the web view to free its memory; the address stays.
    func sleep() {
        guard let web = web else { return }
        observers.forEach { $0.invalidate() }
        observers = []
        web.stopLoading()
        web.navigationDelegate = nil
        web.uiDelegate = nil
        web.removeFromSuperview()
        self.web = nil
    }

    func load(_ address: String) {
        pageURL = address
        url = address.hasPrefix(Browser.home) ? "" : address
        guard let web = web, let u = URL(string: address) else { return }
        web.load(URLRequest(url: u))
    }

    private func urlChanged() {
        guard let u = web?.url?.absoluteString, !u.isEmpty else { return }
        pageURL = u
        url = u.hasPrefix(Browser.home) ? "" : u
        if url.isEmpty { title = Core.tr("newtab") }
        browser?.tabChanged(self)
    }

    @objc private func pulledToRefresh(_ control: UIRefreshControl) {
        web?.reload()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { control.endRefreshing() }
    }

    var isWebPage: Bool { url.hasPrefix("http://") || url.hasPrefix("https://") }
}

// MARK: - navigation

extension Tab: WKNavigationDelegate {
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 preferences: WKWebpagePreferences, decisionHandler: @escaping (WKNavigationActionPolicy, WKWebpagePreferences) -> Void) {
        guard let url = navigationAction.request.url, let scheme = url.scheme?.lowercased() else {
            decisionHandler(.cancel, preferences); return
        }
        // Our own page always runs its script; other pages follow the "javascript" setting.
        preferences.allowsContentJavaScript = scheme == Browser.scheme || Core.setting("javascript") != "0"
        preferences.preferredContentMode = Prefs.wantsDesktop(mode: Core.setting("ua_mode")) ? .desktop : .mobile
        if navigationAction.shouldPerformDownload {
            decisionHandler(.download, preferences); return
        }
        // The page tried to leave the browser for another app.
        if Core.blockExternalApp(url.absoluteString) {
            browser?.toast(Core.tr("external_app_blocked"))
            decisionHandler(.cancel, preferences); return
        }
        switch scheme {
        case "http", "https", "about", "data", "blob":
            decisionHandler(.allow, preferences)
        case "theme":
            decisionHandler(.cancel, preferences)   // icon packs are the address bar's; a page does not pick one
        case Browser.scheme:
            decisionHandler(url.absoluteString.hasPrefix(Browser.home) ? .allow : .cancel, preferences)
        default:
            // tel:, mailto:, maps:, App Store and app links: the system's apps, after a tap on a link only.
            if navigationAction.navigationType == .linkActivated {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            }
            decisionHandler(.cancel, preferences)
        }
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse,
                 decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        var attachment = false
        if let http = navigationResponse.response as? HTTPURLResponse,
           let disposition = http.value(forHTTPHeaderField: "Content-Disposition") {
            attachment = disposition.lowercased().hasPrefix("attachment")
        }
        decisionHandler(navigationResponse.isForMainFrame && (attachment || !navigationResponse.canShowMIMEType) ? .download : .allow)
    }

    func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) {
        browser?.track(download)
    }

    func webView(_ webView: WKWebView, navigationResponse: WKNavigationResponse, didBecome download: WKDownload) {
        browser?.track(download)
    }

    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
        Core.sniffClear(id)
        if isHome { title = Core.tr("newtab") }
        browser?.tabChanged(self)
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        webView.scrollView.refreshControl?.endRefreshing()
        if let t = webView.title, !t.isEmpty { title = t }
        if Core.setting("block_ads") == "1" {
            // Hide the ad boxes the page shows itself; the rule list already
            // stops the third-party ones.
            webView.evaluateJavaScript(Core.adblockScript, completionHandler: nil)
        }
        // History: real web pages of normal tabs only.
        if !isPrivate && isWebPage { Core.historyAdd(url, title: title, timeMs: Core.wallMs) }
        if !isPrivate { browser?.saveSession() }   // the snapshot follows along, so a crash loses little
        browser?.tabChanged(self)
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        webView.scrollView.refreshControl?.endRefreshing()
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        webView.scrollView.refreshControl?.endRefreshing()
    }

    /// iOS killed the page's process (memory pressure): load it again.
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        webView.reload()
    }
}

// MARK: - windows, dialogs, long press

extension Tab: WKUIDelegate {
    /// window.open and target=_blank: a new tab of the same kind, sharing the opener's configuration.
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        guard navigationAction.targetFrame == nil, let browser = browser else { return nil }
        return browser.openTab(nil, isPrivate: isPrivate, configuration: configuration).web
    }

    func webViewDidClose(_ webView: WKWebView) {
        browser?.close(self)
    }

    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        guard let browser = browser else { completionHandler(); return }
        let alert = UIAlertController(title: frame.request.url?.host, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: Core.tr("mac_ok"), style: .default) { _ in completionHandler() })
        browser.presentDialog(alert, otherwise: completionHandler)
    }

    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        guard let browser = browser else { completionHandler(false); return }
        let alert = UIAlertController(title: frame.request.url?.host, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: Core.tr("mac_cancel"), style: .cancel) { _ in completionHandler(false) })
        alert.addAction(UIAlertAction(title: Core.tr("mac_ok"), style: .default) { _ in completionHandler(true) })
        browser.presentDialog(alert) { completionHandler(false) }
    }

    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String, defaultText: String?,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (String?) -> Void) {
        guard let browser = browser else { completionHandler(nil); return }
        let alert = UIAlertController(title: frame.request.url?.host, message: prompt, preferredStyle: .alert)
        alert.addTextField { $0.text = defaultText }
        alert.addAction(UIAlertAction(title: Core.tr("mac_cancel"), style: .cancel) { _ in completionHandler(nil) })
        alert.addAction(UIAlertAction(title: Core.tr("mac_ok"), style: .default) { [weak alert] _ in
            completionHandler(alert?.textFields?.first?.text ?? "")
        })
        browser.presentDialog(alert) { completionHandler(nil) }
    }

    /// Long press on a link: open it in a new tab (normal or private), or copy it.
    func webView(_ webView: WKWebView, contextMenuConfigurationForElement elementInfo: WKContextMenuElementInfo,
                 completionHandler: @escaping (UIContextMenuConfiguration?) -> Void) {
        guard let link = elementInfo.linkURL, ["http", "https"].contains(link.scheme?.lowercased() ?? ""), let browser = browser else {
            completionHandler(nil); return
        }
        let address = link.absoluteString
        completionHandler(UIContextMenuConfiguration(identifier: nil, previewProvider: nil) { _ in
            UIMenu(title: address, children: [
                UIAction(title: Core.tr("ios_open_tab"), image: UIImage(systemName: "plus.square.on.square")) { [weak browser] _ in
                    browser?.openTab(address, isPrivate: false, background: true)
                },
                UIAction(title: Core.tr("ios_open_private"), image: UIImage(systemName: "eye.slash")) { [weak browser] _ in
                    browser?.openTab(address, isPrivate: true)
                },
                UIAction(title: Core.tr("copy_link"), image: UIImage(systemName: "link")) { [weak browser] _ in
                    UIPasteboard.general.url = link
                    browser?.toast(Core.tr("link_copied"))
                },
            ])
        })
    }
}
