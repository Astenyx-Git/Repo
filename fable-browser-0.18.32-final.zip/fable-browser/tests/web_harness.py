#!/usr/bin/env python3
"""Render a page in WebKitGTK at phone size and save a PNG.
usage: web_harness.py <url-or-file> <out.png> [--js file.js] [--wait seconds] [--width 390 --height 844] [--bg rrggbb]

Prints the page's console lines and the script's result. Exits 1 when a line
says FAIL, the page or the script threw, the page did not load, or no snapshot
was taken in time; 0 otherwise (tests/ui_test.py also checks that checks ran)."""
import sys, argparse, os, re
import gi
gi.require_version("Gtk", "3.0"); gi.require_version("WebKit2", "4.1")
from gi.repository import Gtk, WebKit2, GLib, Gdk

ap = argparse.ArgumentParser(); ap.add_argument("url"); ap.add_argument("out")
ap.add_argument("--js"); ap.add_argument("--wait", type=float, default=1.5); ap.add_argument("--width", type=int, default=390)
ap.add_argument("--height", type=int, default=844); ap.add_argument("--bg", default="ffffff"); ap.add_argument("--full", action="store_true"); ap.add_argument("--lang", default="", help="fill a local page's UI strings: zh-Hans, zh-Hant, ja, en, ko, ru, fr, es, ar, nl, de, pt, it or hi")
ap.add_argument("--incognito", default="", help="true or shared: the new-tab page's private slot (needs --lang)")
ap.add_argument("--prelude", default="", help="a script file run before the page's own scripts (needs --lang)")
ap.add_argument("--launcher", default="", help="a JSON file for the new-tab page's home-screen slot, as the Android shell fills it (needs --lang)")
a = ap.parse_args()
if a.lang and "://" not in a.url:
    # What the core does when it serves the page: put the language's strings into the marked slot.
    import json, tempfile
    path, _, frag = a.url.partition("#")
    table = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "ui", "strings.tsv")
    col = ["zh-Hans", "zh-Hant", "ja", "en", "ko", "ru", "fr", "es", "ar", "nl", "de", "pt", "it", "hi"].index(a.lang) + 1
    strings = {"_lang": a.lang}
    for line in open(table, encoding="utf-8"):
        cells = line.rstrip("\n").split("\t")
        if len(cells) == 15 and not line.startswith("#"): strings[cells[0]] = cells[col]
    html = open(path, encoding="utf-8").read().replace("/*FABLE_STRINGS*/null/*END*/", json.dumps(strings, ensure_ascii=False)).replace("{brand}", "Fable").replace("{motto}", "Here beginneth thy fable.")
    if a.incognito: html = html.replace("/*FABLE_INCOGNITO*/false/*END*/", "true" if a.incognito == "true" else '"shared"')
    if a.launcher: html = html.replace("/*FABLE_LAUNCHER*/null/*END*/", open(a.launcher, encoding="utf-8").read().strip().replace("<", "\\u003c"))
    if a.prelude: html = html.replace("<head>", "<head><script>" + open(a.prelude, encoding="utf-8").read() + "</script>", 1) if "<head>" in html else "<script>" + open(a.prelude, encoding="utf-8").read() + "</script>" + html
    filled = tempfile.NamedTemporaryFile("w", suffix=".html", delete=False, encoding="utf-8"); filled.write(html); filled.close()
    a.url = filled.name + ("#" + frag if frag else "")
url = a.url if "://" in a.url else "file://" + os.path.abspath(a.url.split("#")[0]) + ("#" + a.url.split("#")[1] if "#" in a.url else "")
win = Gtk.OffscreenWindow(); win.set_default_size(a.width, a.height)
failed = []
# The page's console and uncaught errors come back here (WebKit's own console
# output goes to the web process's stdout, which this process cannot read).
# Installed before any page script, so a prelude that replaces window.webkit
# does not cut it off.
CAPTURE = """(function () {
  var h = window.webkit.messageHandlers.fableharness;
  function send(s) { try { h.postMessage(String(s)); } catch (e) {} }
  ['log', 'info', 'warn', 'error'].forEach(function (k) {
    var orig = console[k];
    console[k] = function () { orig.apply(console, arguments); send(Array.prototype.map.call(arguments, String).join(' ')); };
  });
  window.addEventListener('error', function (e) { send('FAIL page error: ' + (e.error && e.error.stack || e.message)); });
  window.addEventListener('unhandledrejection', function (e) { send('FAIL page error: unhandled rejection ' + (e.reason && e.reason.stack || e.reason)); });
})();"""
def on_console(manager, res):
    text = res.get_js_value().to_string()
    print(text, flush=True)
    if re.search(r"\bFAIL\b", text): failed.append(text)
ucm = WebKit2.UserContentManager()
ucm.register_script_message_handler("fableharness")
ucm.connect("script-message-received::fableharness", on_console)
ucm.add_script(WebKit2.UserScript(CAPTURE, WebKit2.UserContentInjectedFrames.TOP_FRAME, WebKit2.UserScriptInjectionTime.START, None, None))
view = WebKit2.WebView.new_with_user_content_manager(ucm)
s = view.get_settings()
s.set_user_agent("Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36")
s.set_enable_developer_extras(True)
c = Gdk.RGBA(); c.parse("#" + a.bg); view.set_background_color(c)
win.add(view); win.show_all()
result = {}
def shot():
    def done(v, res):
        surf = v.get_snapshot_finish(res); surf.write_to_png(a.out); result['shot'] = True; Gtk.main_quit()
    view.get_snapshot(WebKit2.SnapshotRegion.FULL_DOCUMENT if a.full else WebKit2.SnapshotRegion.VISIBLE, WebKit2.SnapshotOptions.NONE, None, done)
    return False
def after_js(v, res):
    try:
        r = v.evaluate_javascript_finish(res); text = r.to_string(); print("js result:", text, flush=True)
        if re.search(r"\bFAIL\b", text): failed.append("result")
    except Exception as e: print("FAIL js error:", e, flush=True); failed.append("js")
    GLib.timeout_add(int(a.wait * 1000), shot)
def loaded(v, ev):
    if ev != WebKit2.LoadEvent.FINISHED or result.get('ran'): return
    result['ran'] = True
    if a.js:
        GLib.timeout_add(int(a.wait * 1000), lambda: (v.evaluate_javascript(open(a.js, encoding="utf-8").read(), -1, None, None, None, after_js) and False))
    else:
        GLib.timeout_add(int(a.wait * 1000), shot)
view.connect("load-changed", loaded)
def load_failed(v, ev, uri, err):
    print("FAIL load failed", uri, err.message, flush=True); failed.append("load"); return False
view.connect("load-failed", load_failed)
view.load_uri(url)
GLib.timeout_add(45000, Gtk.main_quit)
Gtk.main()
if not result.get('shot'): print("FAIL no snapshot (timed out)", flush=True); failed.append("timeout")
sys.exit(1 if failed else 0)
