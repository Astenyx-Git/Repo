package app.fable.browser;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.Base64;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Site icons, one PNG per host in a private directory.
 *
 * Icons arrive two ways: WebView hands over the favicon of every page it
 * loads ({@link #offer}), and for a home-page shortcut that was never visited
 * the icon is downloaded from the site itself ({@link #request}, {@link #fetch}). The largest
 * version seen for a host wins. Everything here may be called from any thread.
 */
final class Icons {
    private static final int MAX_EDGE = 192;          // stored icons are scaled down to this
    private static final int SHARP = 64;              // below this an icon looks soft on a home-page tile
    private static final int MAX_DOWNLOAD = 512 * 1024;
    private static final int MAX_FILES = 400;
    private static final int TIMEOUT_MS = 4000;

    private final File dir;
    private volatile int version;
    private final String userAgent;
    private final ExecutorService background = Executors.newFixedThreadPool(3);
    private final Set<String> inFlight = Collections.synchronizedSet(new HashSet<String>());
    private final Set<String> failed = Collections.synchronizedSet(new HashSet<String>());   // hosts with nothing to fetch, this run
    private final Map<String, String> uris = new LinkedHashMap<String, String>(64, 0.75f, true) {   // small cache of data: URIs
        @Override protected boolean removeEldestEntry(Map.Entry<String, String> eldest) { return size() > 64; }
    };

    Icons(File dir, String userAgent) {
        this.dir = dir;
        this.userAgent = userAgent;
        dir.mkdirs();
    }

    /** Host of an http(s) URL in lower case, or "" for anything else. */
    static String hostOf(String url) {
        if (url == null) return "";
        Uri u = Uri.parse(url);
        String scheme = u.getScheme(), host = u.getHost();
        if (host == null || !("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme))) return "";
        return host.toLowerCase(Locale.ROOT);
    }

    private File file(String host) {
        return new File(dir, host.replaceAll("[^a-z0-9.-]", "_") + ".png");
    }

    /** The stored PNG for a host, or null. Never touches the network. */
    synchronized byte[] get(String host) {
        if (host == null || host.isEmpty()) return null;
        File f = file(host);
        if (!f.isFile()) return null;
        try (FileInputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream((int) f.length());
            byte[] buf = new byte[8192];
            for (int n; (n = in.read(buf)) > 0; ) out.write(buf, 0, n);
            return out.toByteArray();
        } catch (Exception e) {
            return null;
        }
    }

    /** The stored icon as a data: URI for our own UI page, or "" when there is none. */
    String dataUri(String host) {
        if (host == null || host.isEmpty()) return "";
        synchronized (uris) {
            String cached = uris.get(host);
            if (cached != null) return cached;
        }
        byte[] png = get(host);
        String uri = png == null ? "" : "data:image/png;base64," + Base64.encodeToString(png, Base64.NO_WRAP);
        if (!uri.isEmpty()) synchronized (uris) { uris.put(host, uri); }
        return uri;
    }

    static String dataUri(Bitmap icon) {
        if (icon == null) return "";
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        scaled(icon).compress(Bitmap.CompressFormat.PNG, 100, out);
        return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
    }

    private static Bitmap scaled(Bitmap icon) {
        int edge = Math.max(icon.getWidth(), icon.getHeight());
        if (edge <= MAX_EDGE) return icon;
        float k = MAX_EDGE / (float) edge;
        return Bitmap.createScaledBitmap(icon, Math.max(1, Math.round(icon.getWidth() * k)), Math.max(1, Math.round(icon.getHeight() * k)), true);
    }

    /** Changes whenever the stored icons do, so callers can cache what they built from them. */
    int version() {
        return version;
    }

    /**
     * The stored icons of these hosts as {"host": [dataUri, width], ...} for the
     * new-tab page, which then draws them without a request per tile.
     */
    String bundle(Iterable<String> hosts) {
        StringBuilder out = new StringBuilder("{");
        for (String host : hosts) {
            String uri = dataUri(host);
            if (uri.isEmpty() || !host.matches("[a-z0-9.-]+")) continue;
            byte[] png = Base64.decode(uri.substring(uri.indexOf(',') + 1), Base64.NO_WRAP);
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(png, 0, png.length, bounds);
            if (out.length() > 1) out.append(',');
            out.append('"').append(host).append("\":[\"").append(uri).append("\",").append(Math.max(bounds.outWidth, 0)).append(']');
        }
        return out.append('}').toString();
    }

    /** Keep this icon for the host unless a larger one is already stored. */
    synchronized void offer(String host, Bitmap icon) {
        if (host == null || host.isEmpty() || icon == null || icon.getWidth() < 8 || icon.getHeight() < 8) return;
        File f = file(host);
        if (f.isFile()) {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getPath(), bounds);
            if (bounds.outWidth >= Math.min(icon.getWidth(), MAX_EDGE)) return;
        }
        File tmp = new File(dir, f.getName() + ".tmp");
        try (FileOutputStream out = new FileOutputStream(tmp)) {
            scaled(icon).compress(Bitmap.CompressFormat.PNG, 100, out);
        } catch (Exception e) {
            tmp.delete();
            return;
        }
        if (!tmp.renameTo(f)) tmp.delete();
        synchronized (uris) { uris.remove(host); }
        version++;
        trim();
    }

    /** Drop the oldest quarter once the directory grows past its cap. */
    private void trim() {
        File[] all = dir.listFiles();
        if (all == null || all.length <= MAX_FILES) return;
        Arrays.sort(all, (a, b) -> Long.compare(a.lastModified(), b.lastModified()));
        for (int i = 0; i < all.length / 4; i++) all[i].delete();
    }

    /**
     * Icon for a site given its origin ("https://example.com"): the stored one,
     * else downloaded from the site. Tried in order: its home-screen icon at the
     * usual address (large and crisp), else the classic /favicon.ico; if that
     * yields nothing or only a tiny image, the icons its home page declares in
     * <link> tags. Blocks; call off the UI
     * thread. Returns PNG bytes or null.
     */
    byte[] fetch(String origin) {
        String host = hostOf(origin);
        if (host.isEmpty()) return null;
        byte[] stored = get(host);
        if (stored != null) return stored;
        if (failed.contains(host)) return null;
        Uri u = Uri.parse(origin);
        String base = u.getScheme().toLowerCase(Locale.ROOT) + "://" + u.getEncodedAuthority();
        Bitmap icon = download(base + "/apple-touch-icon.png");
        if (icon == null) icon = download(base + "/favicon.ico");
        boolean found = icon != null;
        if (found) offer(host, icon);
        if (icon == null || icon.getWidth() < SHARP) {
            // Nothing at the usual addresses, or only a tiny favicon: see what the home page declares.
            int tried = 0;
            for (String candidate : declaredIcons(base + "/")) {
                if (tried++ == 3) break;
                Bitmap declared = download(candidate);
                if (declared == null) continue;
                offer(host, declared);   // kept only if larger than what is stored
                found = true;
                if (declared.getWidth() >= SHARP) break;
            }
        }
        if (!found) failed.add(host);
        return get(host);
    }

    /** Start {@link #fetch} in the background; a later {@link #get} finds the result. */
    void request(final String origin) {
        final String host = hostOf(origin);
        if (host.isEmpty() || failed.contains(host) || !inFlight.add(host)) return;
        background.execute(() -> {
            try { fetch(origin); } finally { inFlight.remove(host); }
        });
    }

    private static final Pattern LINK = Pattern.compile("<link\\b[^>]*>", Pattern.CASE_INSENSITIVE);

    private static String attribute(String tag, String name) {
        Matcher m = Pattern.compile("\\b" + name + "\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))", Pattern.CASE_INSENSITIVE).matcher(tag);
        if (!m.find()) return "";
        return m.group(1) != null ? m.group(1) : m.group(2) != null ? m.group(2) : m.group(3);
    }

    /** Icon addresses a page declares with <link rel="...icon...">, home-screen icons first. */
    private List<String> declaredIcons(String pageUrl) {
        List<String> touch = new ArrayList<>(), plain = new ArrayList<>();
        byte[] page = bytes(pageUrl, "text/html", 128 * 1024, true);
        if (page == null) return plain;
        Matcher m = LINK.matcher(new String(page, StandardCharsets.ISO_8859_1));   // tags and URLs are ASCII
        while (m.find()) {
            String rel = attribute(m.group(), "rel").toLowerCase(Locale.ROOT), href = attribute(m.group(), "href");
            if (!rel.contains("icon") || href.isEmpty() || href.startsWith("data:")) continue;
            try {
                String resolved = new URL(new URL(pageUrl), href.replace("&amp;", "&")).toString();
                if (!hostOf(resolved).isEmpty()) (rel.contains("apple-touch") ? touch : plain).add(resolved);
            } catch (Exception ignored) { }
        }
        touch.addAll(plain);
        return touch;
    }

    /** Download a larger icon a page advertised (rel="apple-touch-icon") in the background. */
    void fetchLater(final String host, final String iconUrl) {
        if (host == null || host.isEmpty() || hostOf(iconUrl).isEmpty()) return;
        background.execute(() -> {
            Bitmap icon = download(iconUrl);
            if (icon != null) offer(host, icon);
        });
    }

    private Bitmap download(String address) {
        byte[] data = bytes(address, "image/*", MAX_DOWNLOAD, false);
        return data == null ? null : BitmapFactory.decodeByteArray(data, 0, data.length);   // null when it is not an image
    }

    /** GET a URL. With {@code truncate} a longer body is cut at {@code limit}; without, it is refused. */
    private byte[] bytes(String address, String accept, int limit, boolean truncate) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(address).openConnection();
            c.setConnectTimeout(TIMEOUT_MS);
            c.setReadTimeout(TIMEOUT_MS);
            c.setInstanceFollowRedirects(true);
            c.setRequestProperty("User-Agent", userAgent);
            c.setRequestProperty("Accept", accept);
            if (c.getResponseCode() != 200) return null;
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try (InputStream in = c.getInputStream()) {
                byte[] buf = new byte[8192];
                for (int n; (n = in.read(buf)) > 0; ) {
                    out.write(buf, 0, n);
                    if (out.size() > limit) {
                        if (!truncate) return null;
                        break;
                    }
                }
            }
            return out.toByteArray();
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    /** Forget every icon (they reveal which sites were visited). */
    synchronized void clear() {
        File[] all = dir.listFiles();
        if (all != null) for (File f : all) f.delete();
        synchronized (uris) { uris.clear(); }
        failed.clear();
        version++;
    }

    void shutdown() {
        background.shutdown();
    }
}
