/*
 * PanelView - ui/panel.html (from the Rust core) over the browser: the menu,
 * tabs, settings, history, bookmarks, media and metadata, as on every Fable
 * platform. It has its own WebView, made the first time the panel opens and
 * loaded from Panel.panelHtml() at a name no web page can have (.invalid);
 * PanelBridge (src/panelbridge.h) says how messages travel between them.
 *
 * QML JavaScript here is ES5: Sailfish OS ships Qt 5.6.
 */
import QtQuick 2.0
import Sailfish.Silica 1.0
import Sailfish.WebView 1.0
import harbour.fable.Core 1.0

Item {
    id: panel
    visible: false

    property var host: null            // the BrowserPage: state, actions, device facts
    property bool used: false          // opened once: its WebView exists
    property bool ready: false         // the page has loaded: scripts can run
    property var waiting: []           // scripts for the page until then
    readonly property string address: "https://fable.invalid/panel.html"

    function show(view) {
        used = true;
        visible = true;
        run("Fable.show(" + Fable.jsonString(view || "menu") + "," + host.panelState() + ")");
    }

    function update() {
        if (visible) run("Fable.update(" + host.panelState() + ")");
    }

    function hide() { visible = false; }

    function run(script) {
        if (!ready || !loader.item) { waiting.push(script); return; }
        loader.item.runJavaScript(Panel.runScript(script));
    }

    function loadedNow(view) {
        if (view.loading || !view.loaded || ready) return;
        ready = true;
        var list = waiting;
        waiting = [];
        for (var i = 0; i < list.length; ++i) view.runJavaScript(Panel.runScript(list[i]));
    }

    // The language changed: the page carries its strings, so it is loaded again.
    function reload() {
        waiting = [];
        if (!loader.item) return;
        ready = false;
        loader.item.loadHtml(Panel.panelHtml(), address);
    }

    Loader {
        id: loader
        anchors.fill: parent
        active: panel.used
        sourceComponent: Component {
            WebView {
                id: view
                // Never private: a private panel would keep private browsing (its cookies)
                // alive after the last private tab is closed.
                privateMode: false
                active: panel.visible
                Component.onCompleted: loadHtml(Panel.panelHtml(), panel.address)
                // Whichever of loading and loaded changes last.
                onLoadingChanged: panel.loadedNow(view)
                onLoadedChanged: panel.loadedNow(view)
            }
        }
    }

    // The panel's messages, every 50 ms while it is shown.
    Timer {
        interval: 50
        repeat: true
        running: panel.visible && panel.ready
        onTriggered: {
            if (!loader.item) return;
            loader.item.runJavaScript(Panel.drainScript(), function (json) {
                var list;
                try { list = JSON.parse(json || "[]"); } catch (e) { return; }
                for (var i = 0; i < list.length; ++i) {
                    var reply = Panel.handleMessage(String(list[i]), panel.host.frontId(), panel.host.deviceExtras());
                    if (reply) panel.run(reply);
                }
            });
        }
    }
}
