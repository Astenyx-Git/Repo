package app.fable.browser;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.robolectric.Shadows.shadowOf;

import android.app.DownloadManager;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewFeature;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.GraphicsMode;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.time.Duration;
import java.util.Collections;
import java.util.Map;

/**
 * Drives the real activity on the JVM (Robolectric) against the real Rust
 * core. There is no web engine here: page events are fired by hand through the
 * clients the activity installed, which is exactly the code a device would
 * call. What this cannot show is how anything looks or how a real WebView
 * behaves; it catches crashes and wrong state.
 *
 * Needs build/jni/libfable_jni.so for the host: run tests/jni_test.sh first.
 */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34)
@GraphicsMode(GraphicsMode.Mode.NATIVE)   // real bitmaps, for the site icons
public class MainActivityTest {
    private ActivityController<MainActivity> controller;
    private MainActivity a;

    @Before public void start() {
        Launcher.homeForTests = false;   // another launcher is the home app unless a test says otherwise
        controller = Robolectric.buildActivity(MainActivity.class).setup();
        a = controller.get();
        Core.historyClear();
        for (String key : new String[] {"ua_mode", "ua_custom", "search_template", "block_trackers", "sleep_minutes", "javascript", "data_saver", "block_3p_cookies", "shortcuts", "private_screenshots", "home_order", "home_hidden", "home_new_apps", "home_wallpaper", "home_button", "address_top"}) {
            Core.settingSet(key, "");
        }
        Core.settingSet("language", "zh-Hans");   // the tests below read Simplified Chinese text
    }

    @After public void stop() {
        controller.pause().stop().destroy();
        Launcher.homeForTests = null;
    }

    // ---- helpers -----------------------------------------------------------

    private static void idle() {
        shadowOf(Looper.getMainLooper()).idle();
    }

    private static WebViewClient client(WebView w) {
        return shadowOf(w).getWebViewClient();
    }

    private static WebChromeClient chrome(WebView w) {
        return shadowOf(w).getWebChromeClient();
    }

    private static WebResourceRequest request(String url, boolean mainFrame) {
        return request(url, mainFrame, Collections.<String, String>emptyMap());
    }

    private static WebResourceRequest request(final String url, final boolean mainFrame, final Map<String, String> headers) {
        return new WebResourceRequest() {
            @Override public Uri getUrl() { return Uri.parse(url); }
            @Override public boolean isForMainFrame() { return mainFrame; }
            @Override public boolean isRedirect() { return false; }
            @Override public boolean hasGesture() { return false; }
            @Override public String getMethod() { return "GET"; }
            @Override public Map<String, String> getRequestHeaders() { return headers; }
        };
    }

    private static String body(WebResourceResponse response) throws Exception {
        InputStream in = response.getData();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        for (int n; (n = in.read(buf)) > 0; ) out.write(buf, 0, n);
        return out.toString("UTF-8");
    }

    /** Pretend the tab in front loaded a page, the way WebView reports it. */
    private void load(String url, String title) {
        WebView w = a.active.web;
        client(w).shouldInterceptRequest(w, request(url, true));
        client(w).onPageStarted(w, url, null);
        chrome(w).onProgressChanged(w, 60);
        chrome(w).onReceivedTitle(w, title);
        client(w).onPageFinished(w, url);
    }

    /** Make Fable the default home app, with one other app installed that has a launcher icon. */
    private void beHomeWithAnApp() {
        Launcher.homeForTests = true;
        ActivityInfo info = new ActivityInfo();
        info.packageName = "com.example.notes";
        info.name = "com.example.notes.Main";
        info.nonLocalizedLabel = "Notes <b>";
        info.applicationInfo = new android.content.pm.ApplicationInfo();
        info.applicationInfo.packageName = info.packageName;
        ResolveInfo notes = new ResolveInfo();
        notes.activityInfo = info;
        notes.nonLocalizedLabel = info.nonLocalizedLabel;
        shadowOf(a.getPackageManager()).addResolveInfoForIntent(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), notes);
        shadowOf(a.getPackageManager()).addOrUpdateActivity(info);
    }

    private MainActivity.PanelBridge bridge() {
        return (MainActivity.PanelBridge) shadowOf(a.panel).getJavascriptInterface("FableUI");
    }

    private int barColor() {
        return ((ColorDrawable) a.bar.getBackground()).getColor();
    }

    // ---- tests -------------------------------------------------------------

    @Test public void startsOnTheNewTabPageServedByTheCore() throws Exception {
        assertEquals(1, a.tabs.size());
        WebView w = a.active.web;
        assertEquals(MainActivity.HOME, shadowOf(w).getLastLoadedUrl());
        assertEquals("", a.address.getText().toString());
        assertEquals("1", a.tabCount.getText().toString());
        assertFalse("the address field must not grab focus (and the keyboard) at launch", a.address.hasFocus());

        WebResourceResponse page = client(w).shouldInterceptRequest(w, request(MainActivity.HOME, true));
        assertNotNull(page);
        assertEquals("text/html", page.getMimeType());
        String html = body(page);
        assertTrue(html.contains("<h1 id=\"brand\">Fable</h1>") && html.contains("var INCOGNITO = false;"));
        // The page is only handed out as a top-level document, never to a page that embeds or fetches it.
        assertNull(client(w).shouldInterceptRequest(w, request(MainActivity.HOME, false)));
    }

    @Test public void homeScreenListsAppsOnlyWhenFableIsTheHomeApp() throws Exception {
        WebView w = a.active.web;
        String plain = body(client(w).shouldInterceptRequest(w, request(MainActivity.HOME, true)));
        assertTrue("an ordinary new tab is no home screen", plain.contains("var LAUNCHER = null;"));
        String launch = MainActivity.HOME_LAUNCH + "c=" + Uri.encode("com.example.notes/.Main");
        beHomeWithAnApp();
        a.reloadHomeTabs();
        String home = body(client(w).shouldInterceptRequest(w, request(MainActivity.HOME, true)));
        assertTrue(home, home.contains("\"apps\":[{\"c\":\"com.example.notes\\/.Main\",\"n\":\"Notes \\u003cb>\"}]"));   // org.json writes "/" as "\/"

        // The page's own requests: an app icon (a square PNG), starting the app, saving the layout.
        WebResourceResponse icon = client(w).shouldInterceptRequest(w, request(MainActivity.APP_ICON_ENDPOINT + "c=" + Uri.encode("com.example.notes/.Main"), false));
        assertEquals("image/png", icon.getMimeType());
        assertEquals(204, client(w).shouldInterceptRequest(w, request(launch, false)).getStatusCode());
        idle();
        Intent started = shadowOf(a).getNextStartedActivity();
        assertEquals(new ComponentName("com.example.notes", "com.example.notes.Main"), started.getComponent());
        assertTrue(started.hasCategory(Intent.CATEGORY_LAUNCHER));
        assertNull("no icon place given: a plain start", started.getSourceBounds());
        // With the icon's place (CSS px): the app opens out of it, and knows where it came from.
        assertEquals(204, client(w).shouldInterceptRequest(w, request(launch + "&r=" + Uri.encode("20,300,58,58"), false)).getStatusCode());
        idle();
        org.robolectric.shadows.ShadowActivity.IntentForResult withIcon = shadowOf(a).getNextStartedActivityForResult();
        shadowOf(a).getNextStartedActivity();   // the same start, from the other list
        float d = a.getResources().getDisplayMetrics().density;
        int[] at = new int[2];
        w.getLocationOnScreen(at);
        assertEquals(new android.graphics.Rect(Math.round(20 * d) + at[0], Math.round(300 * d) + at[1], Math.round(78 * d) + at[0], Math.round(358 * d) + at[1]), withIcon.intent.getSourceBounds());
        assertNotNull("launch options", withIcon.options);
        assertNull("a bad box is ignored", MainActivity.iconRect("1,2,0,4", 2f));
        assertNull(MainActivity.iconRect("a,b,c,d", 2f));
        assertNull(MainActivity.iconRect("1,2,3", 2f));
        assertEquals(new android.graphics.Rect(-20, 600, 96, 716), MainActivity.iconRect("-10,300,58,58", 2f));
        String order = "[\"a:com.example.notes/.Main\",\"u:https://claude.ai/\"]";
        assertEquals(204, client(w).shouldInterceptRequest(w, request(MainActivity.HOME_SET + "k=home_order&v=" + Uri.encode(order), false)).getStatusCode());
        assertEquals(order, Core.settingGet("home_order"));
        assertEquals("only the home screen's own keys", 404, client(w).shouldInterceptRequest(w, request(MainActivity.HOME_SET + "k=javascript&v=" + Uri.encode("[0]"), false)).getStatusCode());
        assertEquals("only listed apps start", 404, client(w).shouldInterceptRequest(w, request(MainActivity.HOME_LAUNCH + "c=" + Uri.encode("com.android.settings/.Settings"), false)).getStatusCode());

        // Any other page asking gets nothing: no app list, no starting apps.
        load("https://evil.example/", "Evil");
        assertEquals(404, client(w).shouldInterceptRequest(w, request(launch, false)).getStatusCode());
        assertEquals(404, client(w).shouldInterceptRequest(w, request(MainActivity.APP_ICON_ENDPOINT + "c=" + Uri.encode("com.example.notes/.Main"), false)).getStatusCode());
        idle();
        assertNull(shadowOf(a).getNextStartedActivity());

        // Home key: back to a tab on the home page instead of opening one more; Back on it stays.
        load(MainActivity.HOME, "新标签页");   // this tab back on the home screen
        WebView homeTab = a.active.web;
        int count = a.tabs.size();
        a.newTab("", false);
        load("https://example.com/", "Example");
        a.onNewIntent(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME));
        idle();
        assertEquals(count + 1, a.tabs.size());
        assertSame(homeTab, a.active.web);
        a.onBackPressed();
        assertFalse("a home screen does not close on Back", a.isFinishing());
    }

    @Test public void theHomeScreenShowsTheUsersWallpaperWithoutTouchingIt() throws Exception {
        // 0.17.0 development builds swapped the wallpaper for Fable's colour; nothing of that is left.
        java.io.File old = new java.io.File(a.getFilesDir(), "home-wallpaper-backup.png");
        assertTrue(old.createNewFile());
        controller.pause().stop().destroy();
        controller = Robolectric.buildActivity(MainActivity.class).setup();
        a = controller.get();
        assertFalse("the old copy is dropped", old.exists());
        int showWallpaper = android.view.WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER;
        WebView w = a.active.web;

        // Not the home app: the new tab keeps Fable's own background.
        load(MainActivity.HOME, "新标签页");
        idle();
        assertEquals(0, a.getWindow().getAttributes().flags & showWallpaper);

        // The home app: the page is built see-through, the window lets the wallpaper through.
        beHomeWithAnApp();
        String home = body(client(w).shouldInterceptRequest(w, request(MainActivity.HOME, true)));
        assertTrue(home, home.contains("\"wallpaper\":1}"));   // light text unless the system says the wallpaper is light
        load(MainActivity.HOME, "新标签页");
        idle();
        assertEquals("the wallpaper behind the home screen", showWallpaper, a.getWindow().getAttributes().flags & showWallpaper);
        assertEquals("a see-through status bar on it", Color.TRANSPARENT, a.getWindow().getStatusBarColor());
        assertEquals("light status icons on a dark wallpaper", 0, a.getWindow().getDecorView().getSystemUiVisibility() & View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        assertEquals("a see-through page", Color.TRANSPARENT, shadowOf(w).getBackgroundColor());

        // A web page in the same tab: the plain window again.
        load("https://example.com/", "Example");
        idle();
        assertEquals(0, a.getWindow().getAttributes().flags & showWallpaper);
        assertEquals(0xFFFDF7F0, shadowOf(w).getBackgroundColor());
        assertEquals(0xFFFDF7F0, a.getWindow().getStatusBarColor());

        // The setting off: Fable's own background on the home screen too.
        load(MainActivity.HOME, "新标签页");
        idle();
        assertEquals(showWallpaper, a.getWindow().getAttributes().flags & showWallpaper);
        a.showPanel("settings");
        bridge().query("set", "home_wallpaper\n0");
        load(MainActivity.HOME, "新标签页");   // the home tab is built again
        idle();
        assertTrue(body(client(w).shouldInterceptRequest(w, request(MainActivity.HOME, true))).contains("\"wallpaper\":0}"));
        assertEquals(0, a.getWindow().getAttributes().flags & showWallpaper);
        assertEquals(0xFFFDF7F0, a.getWindow().getStatusBarColor());

        // Showing the wallpaper never sets one.
        assertNull(org.robolectric.Shadows.shadowOf(android.app.WallpaperManager.getInstance(a)).getBitmap(android.app.WallpaperManager.FLAG_SYSTEM));
    }

    @Test public void theSystemWallpaperCanBeCreamAndTheUsersAgain() throws Exception {
        android.app.WallpaperManager wm = android.app.WallpaperManager.getInstance(a);
        android.content.pm.PackageInfo me = a.getPackageManager().getPackageInfo(a.getPackageName(), android.content.pm.PackageManager.GET_PERMISSIONS);
        assertTrue("SET_WALLPAPER, install-time", java.util.Arrays.asList(me.requestedPermissions).contains("android.permission.SET_WALLPAPER"));

        // Only while Fable is the home app does Settings offer it.
        assertFalse(a.panelState().contains("\"wallpaper\""));
        beHomeWithAnApp();
        JSONObject w = new JSONObject(a.panelState()).getJSONObject("wallpaper");
        assertFalse("Android 14: the wallpaper cannot be read, so not kept", w.getBoolean("canKeep"));
        assertFalse(w.getBoolean("kept"));

        // Cream: one pixel of Fable's ground colour, the home wallpaper only.
        a.onPanelAction("wallpaper", "ground");
        Bitmap set = null;
        for (int i = 0; i < 100 && (set = org.robolectric.Shadows.shadowOf(wm).getBitmap(android.app.WallpaperManager.FLAG_SYSTEM)) == null; i++) Thread.sleep(20);
        assertNotNull("the home wallpaper was set", set);
        assertEquals(1, set.getWidth());
        assertEquals(0xFFFDF7F0, set.getPixel(0, 0));
        assertNull("the lock screen's is left alone", org.robolectric.Shadows.shadowOf(wm).getBitmap(android.app.WallpaperManager.FLAG_LOCK));
        idle();
        assertEquals("壁纸已设为 Fable", a.toast.getText().toString());
        assertFalse("nothing kept where nothing can be read", new java.io.File(a.getFilesDir(), "wallpaper-kept.png").exists());

        // Back with nothing kept: the system's own wallpaper picker, to choose it again.
        a.onPanelAction("wallpaper", "restore");
        Intent picker = shadowOf(a).getNextStartedActivity();
        assertEquals(Intent.ACTION_CHOOSER, picker.getAction());
        assertEquals(Intent.ACTION_SET_WALLPAPER, ((Intent) picker.getParcelableExtra(Intent.EXTRA_INTENT)).getAction());

        // Custom while it already is: the picker too.
        a.onPanelAction("wallpaper", "pick");
        assertEquals(Intent.ACTION_SET_WALLPAPER, ((Intent) shadowOf(a).getNextStartedActivity().getParcelableExtra(Intent.EXTRA_INTENT)).getAction());

        // Back with a kept one (Android before 8.1): it is set again, then forgotten.
        java.io.File kept = new java.io.File(a.getFilesDir(), "wallpaper-kept.png");
        Bitmap mine = Bitmap.createBitmap(4, 4, Bitmap.Config.ARGB_8888);
        mine.eraseColor(0xFF336699);
        try (java.io.FileOutputStream out = new java.io.FileOutputStream(kept)) { mine.compress(Bitmap.CompressFormat.PNG, 100, out); }
        assertTrue(new JSONObject(a.panelState()).getJSONObject("wallpaper").getBoolean("kept"));
        a.onPanelAction("wallpaper", "restore");
        for (int i = 0; i < 100 && kept.exists(); i++) Thread.sleep(20);
        assertFalse("forgotten once back", kept.exists());
        assertEquals(0xFF336699, org.robolectric.Shadows.shadowOf(wm).getBitmap(android.app.WallpaperManager.FLAG_SYSTEM).getPixel(0, 0));
        idle();
        assertEquals("已恢复原壁纸", a.toast.getText().toString());
    }

    @Test public void allAppsOnTheHomeScreen() throws Exception {
        WebView w = a.active.web;
        load(MainActivity.HOME, "新标签页");
        a.newTab("", false);
        load(MainActivity.HOME, "新标签页");
        a.onBackPressed();   // an ordinary new-tab page: Back does not ask the page, it goes on at once (here: closes the extra tab)
        assertEquals(1, a.tabs.size());
        assertTrue(shadowOf(w).getLastEvaluatedJavascript() == null || !shadowOf(w).getLastEvaluatedJavascript().contains("fableBack"));
        a.showPanel("settings");
        client(a.panel).onPageFinished(a.panel, "about:blank");
        String script = shadowOf(a.panel).getLastEvaluatedJavascript();
        assertFalse("home-screen settings only while Fable is the home app",
                new JSONObject(script.substring(script.indexOf(',') + 1, script.length() - 1)).getJSONObject("caps").getBoolean("homeScreen"));
        a.onPanelAction("hidden", "");

        beHomeWithAnApp();
        a.reloadHomeTabs();
        String home = body(client(w).shouldInterceptRequest(w, request(MainActivity.HOME, true)));
        assertTrue("new apps go onto the home screen unless the setting says otherwise", home.contains("\"addNew\":true,"));
        Core.settingSet("home_new_apps", "0");
        assertTrue(body(client(w).shouldInterceptRequest(w, request(MainActivity.HOME, true))).contains("\"addNew\":false,"));
        a.showPanel("settings");
        script = shadowOf(a.panel).getLastEvaluatedJavascript();
        assertTrue(new JSONObject(script.substring(script.indexOf(',') + 1, script.length() - 1)).getJSONObject("caps").getBoolean("homeScreen"));
        a.onPanelAction("hidden", "");
        idle();

        // App info, from the long-press menu in All apps: the system's screen for that package; listed apps only.
        assertEquals(204, client(w).shouldInterceptRequest(w, request(MainActivity.HOME_INFO + "c=" + Uri.encode("com.example.notes/.Main"), false)).getStatusCode());
        idle();
        Intent info = shadowOf(a).getNextStartedActivity();
        assertEquals(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, info.getAction());
        assertEquals("package:com.example.notes", info.getDataString());
        assertEquals(404, client(w).shouldInterceptRequest(w, request(MainActivity.HOME_INFO + "c=" + Uri.encode("com.android.settings/.Settings"), false)).getStatusCode());
        load("https://evil.example/", "Evil");
        assertEquals("no other page opens App info", 404, client(w).shouldInterceptRequest(w, request(MainActivity.HOME_INFO + "c=" + Uri.encode("com.example.notes/.Main"), false)).getStatusCode());
        idle();
        assertNull(shadowOf(a).getNextStartedActivity());

        // Back on the home screen: the page first closes what it has open (All apps, a menu, editing).
        load(MainActivity.HOME, "新标签页");
        a.newTab("", false);
        load(MainActivity.HOME, "新标签页");
        WebView second = a.active.web;
        int count = a.tabs.size();
        a.onBackPressed();
        assertEquals("window.fableBack ? fableBack() : false", shadowOf(second).getLastEvaluatedJavascript());
        shadowOf(second).getLastEvaluatedJavascriptCallback().onReceiveValue("true");
        assertEquals("the page closed something: Back stops there", count, a.tabs.size());
        // Two presses before the page answers: one question, so one tab closes, not two.
        a.onBackPressed();
        android.webkit.ValueCallback<String> answer = shadowOf(second).getLastEvaluatedJavascriptCallback();
        a.onBackPressed();
        assertSame("the second press asks nothing new", answer, shadowOf(second).getLastEvaluatedJavascriptCallback());
        answer.onReceiveValue("false");
        assertEquals("nothing open: Back goes on as before (here it closes the extra tab)", count - 1, a.tabs.size());
        a.onBackPressed();
        shadowOf(a.active.web).getLastEvaluatedJavascriptCallback().onReceiveValue("false");
        assertFalse("the home screen itself never closes", a.isFinishing());
    }

    @Test public void pageLoadUpdatesTheBarTheTitleAndTheHistory() {
        load("https://example.com/article", "示例文章");
        assertEquals("https://example.com/article", a.address.getText().toString());
        assertEquals("示例文章", a.active.title);
        assertFalse(a.active.loading);
        String history = Core.historyJson("", 10);
        assertTrue(history, history.contains("\"u\":\"https://example.com/article\"") && history.contains("\"n\":\"示例文章\""));
        assertEquals("one visit, not one per callback", 1, history.split("\"t\":").length - 1);

        // Back on the new-tab page: nothing internal leaks into the bar or the history.
        load(MainActivity.HOME, "新标签页");
        assertEquals("", a.address.getText().toString());
        assertEquals("新标签页", a.active.title);
        assertFalse(Core.historyJson("", 10).contains("fable.invalid"));
    }

    @Test public void blocksThirdPartyTrackersOnly() {
        load("https://news.example.com/", "News");
        WebView w = a.active.web;
        assertNotNull("tracker request is answered with an empty response", client(w).shouldInterceptRequest(w, request("https://ad.doubleclick.net/pixel.gif", false)));
        assertNull("first-party request passes", client(w).shouldInterceptRequest(w, request("https://news.example.com/app.js", false)));
        assertNull("the document itself is never blocked", client(w).shouldInterceptRequest(w, request("https://www.doubleclick.net/", true)));

        a.showPanel("settings");
        bridge().query("set", "block_trackers\n0");
        assertNull("switched off in settings", client(w).shouldInterceptRequest(w, request("https://ad.doubleclick.net/pixel.gif", false)));
    }

    @Test public void typingInTheAddressBarSearchesWithTheChosenEngine() {
        a.address.requestFocus();
        assertEquals("navigation row makes room for the keyboard", View.GONE, a.navRow.getVisibility());
        a.address.setText("rust 语言");
        a.address.onEditorAction(EditorInfo.IME_ACTION_GO);
        assertEquals("https://duckduckgo.com/?q=rust%20%E8%AF%AD%E8%A8%80", shadowOf(a.active.web).getLastLoadedUrl());
        assertFalse(a.address.hasFocus());
        assertEquals(View.VISIBLE, a.navRow.getVisibility());

        a.showPanel("settings");
        bridge().query("set", "search_template\nhttps://www.bing.com/search?q=%s");
        a.address.setText("example.com");
        a.address.onEditorAction(EditorInfo.IME_ACTION_GO);
        assertEquals("https://example.com", shadowOf(a.active.web).getLastLoadedUrl());
        a.address.setText("hello");
        a.address.onEditorAction(EditorInfo.IME_ACTION_GO);
        assertEquals("https://www.bing.com/search?q=hello", shadowOf(a.active.web).getLastLoadedUrl());

        // Another scheme passes the address bar but is not a web page: said so, the page stays.
        a.address.setText("ftp://example.com/file");
        a.address.onEditorAction(EditorInfo.IME_ACTION_GO);
        assertEquals("https://www.bing.com/search?q=hello", shadowOf(a.active.web).getLastLoadedUrl());
        assertEquals(Core.tr("link_not_opened"), a.toast.getText().toString());
    }

    @Test public void panelOpensWithStateAndItsBridgeWorks() throws Exception {
        load("https://example.com/", "Example");
        assertNull(a.panel);
        a.showPanel("menu");
        assertEquals(View.VISIBLE, a.panel.getVisibility());
        assertTrue("the panel page comes from the core", shadowOf(a.panel).getLastLoadDataWithBaseURL().data.contains("window.Fable"));
        assertTrue("the panel can never load anything from the network", a.panel.getSettings().getBlockNetworkLoads());
        assertTrue("and never navigates away", client(a.panel).shouldOverrideUrlLoading(a.panel, request("https://evil.example/", true)));
        assertNull("web pages do not get the privileged bridge", shadowOf(a.active.web).getJavascriptInterface("FableUI"));

        client(a.panel).onPageFinished(a.panel, "about:blank");   // the page is ready: the queued call runs
        String script = shadowOf(a.panel).getLastEvaluatedJavascript();
        assertTrue(script, script.startsWith("Fable.show(\"menu\",{"));
        JSONObject state = new JSONObject(script.substring(script.indexOf(',') + 1, script.length() - 1));
        assertEquals(1, state.getJSONArray("tabs").length());
        assertEquals("Example", state.getJSONArray("tabs").getJSONObject(0).getString("title"));
        assertTrue(state.getBoolean("web"));
        assertEquals("0.18.9", state.getString("version"));

        MainActivity.PanelBridge bridge = bridge();
        assertEquals("", bridge.query("get", "ua_mode"));
        bridge.query("set", "ua_mode\ndesktop");
        assertEquals("desktop", bridge.query("get", "ua_mode"));
        assertTrue(bridge.query("history", "").contains("example.com"));
        bridge.query("historyDelete", "0\nhttps://example.com/");
        assertEquals("[]", bridge.query("history", ""));
        assertEquals("", bridge.query("no-such-query", "x"));
        assertEquals("", bridge.query(null, null));

        bridge.act("toast", "你好");
        bridge.act("hidden", "");
        idle();
        assertEquals("你好", a.toast.getText().toString());
        assertEquals(View.GONE, a.panel.getVisibility());
    }

    @Test public void userAgentModesReachEveryTab() {
        String normal = a.active.web.getSettings().getUserAgentString();
        assertFalse("the default UA does not announce an embedded WebView", normal.contains("; wv"));
        a.newTab("", false);
        a.showPanel("settings");

        bridge().query("set", "ua_mode\ndesktop");
        idle();
        for (MainActivity.Tab t : a.tabs) assertTrue(t.web.getSettings().getUserAgentString().contains("Windows NT 10.0"));
        bridge().query("set", "ua_mode\niphone");
        idle();
        assertTrue(a.active.web.getSettings().getUserAgentString().contains("iPhone"));
        bridge().query("set", "ua_mode\nipad");
        idle();
        assertTrue(a.active.web.getSettings().getUserAgentString().contains("iPad"));
        bridge().query("set", "ua_mode\nfirefox");
        idle();
        assertTrue(a.active.web.getSettings().getUserAgentString().contains("Firefox/"));
        bridge().query("set", "ua_mode\nedge");
        idle();
        assertTrue(a.active.web.getSettings().getUserAgentString().contains("Edg/"));
        bridge().query("set", "ua_custom\nFableTest/1.0");
        bridge().query("set", "ua_mode\ncustom");
        idle();
        assertEquals("FableTest/1.0", a.active.web.getSettings().getUserAgentString());

        a.onPanelAction("desktop", "");   // the menu shortcut toggles desktop mode
        assertTrue(a.active.web.getSettings().getUserAgentString().contains("Windows NT 10.0"));
        a.onPanelAction("desktop", "");
        assertEquals(normal, a.active.web.getSettings().getUserAgentString());

        bridge().query("set", "javascript\n0");
        bridge().query("set", "data_saver\n1");
        idle();
        assertFalse(a.active.web.getSettings().getJavaScriptEnabled());
        assertFalse(a.active.web.getSettings().getLoadsImagesAutomatically());
    }

    @Test public void privateTabsLeaveNoHistoryAndRecolourTheBar() throws Exception {
        int cream = barColor();
        a.onPanelAction("newPrivate", "");
        assertEquals(2, a.tabs.size());
        assertTrue(a.active.incognito);
        assertTrue("bar turns dark for a private tab", barColor() != cream);

        WebView w = a.active.web;
        String page = body(client(w).shouldInterceptRequest(w, request(MainActivity.HOME, true)));
        // A WebView with profiles keeps private cookies apart; without, the page says they are shared.
        assertTrue(page.contains(WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE) ? "var INCOGNITO = true;" : "var INCOGNITO = \"shared\";"));
        load("https://secret.example/", "Secret");
        assertEquals("https://secret.example/", a.address.getText().toString());
        assertFalse(Core.historyJson("", 10).contains("secret.example"));

        a.onPanelAction("switchTab", String.valueOf(a.tabs.get(0).id));
        assertFalse(a.active.incognito);
        assertEquals(cream, barColor());

        a.onPanelAction("closeTab", String.valueOf(a.tabs.get(1).id));
        idle();
        assertEquals(1, a.tabs.size());
        assertEquals("1", a.tabCount.getText().toString());
    }

    private boolean secure() {
        return (a.getWindow().getAttributes().flags & WindowManager.LayoutParams.FLAG_SECURE) != 0;
    }

    @Test public void privateIsAModeWithItsOwnTabs() throws Exception {
        load("https://example.com/", "Example");
        MainActivity.Tab normal = a.active;
        a.newTab("", false);
        MainActivity.Tab second = a.active;
        a.onPanelAction("switchTab", String.valueOf(normal.id));
        assertEquals("2", a.tabCount.getText().toString());
        assertFalse(secure());

        a.onPanelAction("enterPrivate", "");   // no private tabs yet: entering opens one
        MainActivity.Tab firstPrivate = a.active;
        assertTrue(a.inPrivate());
        assertEquals(3, a.tabs.size());
        assertEquals("the count is of this mode's tabs", "1", a.tabCount.getText().toString());
        assertTrue("private pages stay out of screenshots and recent apps", secure());
        assertTrue(new JSONObject(bridgeState()).getBoolean("incognito"));

        a.plusButton.performClick();   // "+" opens a tab of the mode you are in
        MainActivity.Tab secondPrivate = a.active;
        assertTrue(secondPrivate.incognito);
        assertEquals("2", a.tabCount.getText().toString());
        assertEquals("新建无痕标签页", a.plusButton.getContentDescription().toString());

        a.onPanelAction("switchTab", String.valueOf(normal.id));   // to normal mode from the switcher: private tabs stay
        assertFalse(a.inPrivate());
        assertFalse(secure());
        assertEquals(4, a.tabs.size());
        assertEquals("2", a.tabCount.getText().toString());
        a.onPanelAction("newPrivate", "");   // opened from the switcher's private side...
        a.close(a.active);                   // ...and closed again: its neighbour is private
        assertSame(secondPrivate, a.active);
        a.onPanelAction("switchTab", String.valueOf(normal.id));
        a.onPanelAction("enterPrivate", "");   // back to the private tab last in front
        assertSame(secondPrivate, a.active);

        a.onBackPressed();   // Back with no page history closes private tabs one by one...
        assertSame(firstPrivate, a.active);
        a.onBackPressed();   // ...and the last one hands back to normal mode where it was left
        assertFalse(a.inPrivate());
        assertSame(normal, a.active);
        assertEquals(2, a.tabs.size());
        assertFalse(secure());

        a.onPanelAction("enterPrivate", "");
        a.newTab("", true);
        a.onPanelAction("switchTab", String.valueOf(second.id));
        a.onPanelAction("enterPrivate", "");
        a.onPanelAction("exitPrivate", "");   // exit: every private tab closes
        assertFalse(a.inPrivate());
        assertEquals(2, a.tabs.size());
        assertSame("back to the normal tab last in front", second, a.active);
        assertEquals("已关闭全部无痕标签页", a.toast.getText().toString());

        a.onPanelAction("enterPrivate", "");
        a.onPanelAction("switchTab", String.valueOf(second.id));
        a.close(second);   // a normal tab's neighbour is normal, never private
        assertSame(normal, a.active);
        a.onBackPressed();   // the last normal tab is not closed by Back
        assertEquals(2, a.tabs.size());
        assertTrue(a.tabs.contains(normal));
    }

    @Test public void screenshotsInPrivateModeCanBeAllowed() {
        a.onPanelAction("newPrivate", "");
        assertTrue(secure());
        a.showPanel("settings");
        bridge().query("set", "private_screenshots\n1");
        idle();
        assertFalse(secure());
        bridge().query("set", "private_screenshots\n0");
        idle();
        assertTrue(secure());
        Core.settingSet("private_screenshots", "");
    }

    @Test public void privateModeDarkensTheStatusBarWhereverTheAddressBarIs() {
        int light = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        for (String top : new String[] {"0", "1"}) {
            a.showPanel("settings");
            bridge().query("set", "address_top\n" + top);
            idle();
            a.enterPrivate();
            idle();
            assertEquals("private, address_top=" + top, 0xFF211611, a.getWindow().getStatusBarColor());
            assertEquals("light icons on it", 0, a.getWindow().getDecorView().getSystemUiVisibility() & light);
            a.onPanelAction("exitPrivate", "");
            idle();
            assertEquals("normal, address_top=" + top, "1".equals(top) ? 0xFFFBF2E8 : 0xFFFDF7F0, a.getWindow().getStatusBarColor());
            assertEquals("dark icons", light, a.getWindow().getDecorView().getSystemUiVisibility() & light);
        }
        Core.settingSet("address_top", "");
    }

    @Test public void homeButtonIsOptionalAndOpensTheHomePageInThisTab() {
        assertEquals("off unless switched on", View.GONE, a.homeButton.getVisibility());
        assertEquals("+ is the orange pill", Math.round(52 * a.getResources().getDisplayMetrics().density), a.plusButton.getLayoutParams().width);
        a.showPanel("settings");
        bridge().query("set", "home_button\n1");
        idle();
        assertEquals(View.VISIBLE, a.homeButton.getVisibility());
        assertEquals("with Home there, + is a plain button filling its cell like the others",
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT, a.plusButton.getLayoutParams().width);
        assertEquals("tinted like the others", a.homeButton.getColorFilter(), a.plusButton.getColorFilter());
        load("https://example.com/", "Example");
        WebView here = a.active.web;
        int count = a.tabs.size();
        a.homeButton.performClick();
        idle();
        assertSame(here, a.active.web);
        assertEquals(count, a.tabs.size());
        assertEquals(MainActivity.HOME, shadowOf(here).getLastLoadedUrl());
        bridge().query("set", "home_button\n0");
        idle();
        assertEquals(View.GONE, a.homeButton.getVisibility());
        assertEquals("the pill again", Math.round(52 * a.getResources().getDisplayMetrics().density), a.plusButton.getLayoutParams().width);
        assertEquals(new android.graphics.PorterDuffColorFilter(0xFFFFFFFF, android.graphics.PorterDuff.Mode.SRC_ATOP), a.plusButton.getColorFilter());
    }

    @Test public void addressBarCanMoveToTheTopAsInChrome() {
        ViewGroup column = (ViewGroup) a.bar.getParent();
        assertSame("at the bottom unless moved", a.bar, a.pill.getParent());
        assertEquals(View.GONE, a.topBar.getVisibility());
        beHomeWithAnApp();   // as asked for: Fable as the phone's home screen
        a.reloadHomeTabs();
        a.showPanel("settings");
        bridge().query("set", "address_top\n1");
        idle();
        assertSame(a.topBar, a.pill.getParent());
        assertEquals(View.VISIBLE, a.topBar.getVisibility());
        assertEquals("the top bar is above the page", 0, column.indexOfChild(a.topBar));
        assertSame("the buttons stay at the bottom", a.bar, a.navRow.getParent());
        assertEquals(1, a.bar.getChildCount());
        assertEquals(barColor(), ((ColorDrawable) a.topBar.getBackground()).getColor());

        // Typed up there, it still goes where the bottom one would.
        a.address.requestFocus();
        a.address.setText("example.com");
        a.address.onEditorAction(EditorInfo.IME_ACTION_GO);
        idle();
        assertEquals("https://example.com", shadowOf(a.active.web).getLastLoadedUrl());

        a.onPanelAction("newPrivate", "");   // private mode recolours the top bar too
        idle();
        assertEquals(barColor(), ((ColorDrawable) a.topBar.getBackground()).getColor());
        a.onPanelAction("exitPrivate", "");
        idle();

        bridge().query("set", "address_top\n0");
        idle();
        assertSame(a.bar, a.pill.getParent());
        assertEquals("the pill under the loading line, above the buttons", 1, a.bar.indexOfChild(a.pill));
        assertEquals(2, a.bar.indexOfChild(a.navRow));
        assertEquals(View.GONE, a.topBar.getVisibility());
        assertEquals(0, a.topBar.getChildCount());
    }

    @Test public void displaySettingsReachTheWindowAndEveryTab() {
        a.newTab("", false);
        a.showPanel("settings");
        for (MainActivity.Tab t : a.tabs) assertEquals(100, t.web.getSettings().getTextZoom());
        bridge().query("set", "text_size\n150");
        idle();
        for (MainActivity.Tab t : a.tabs) assertEquals(150, t.web.getSettings().getTextZoom());
        a.newTab("", false);   // later tabs too
        assertEquals(150, a.active.web.getSettings().getTextZoom());

        assertEquals(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED, a.getRequestedOrientation());
        bridge().query("set", "orientation\nlandscape");
        idle();
        assertEquals(ActivityInfo.SCREEN_ORIENTATION_USER_LANDSCAPE, a.getRequestedOrientation());
        bridge().query("set", "orientation\nportrait");
        idle();
        assertEquals(ActivityInfo.SCREEN_ORIENTATION_USER_PORTRAIT, a.getRequestedOrientation());
        bridge().query("set", "orientation\nauto");
        idle();
        assertEquals(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED, a.getRequestedOrientation());

        int on = WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
        assertEquals(0, a.getWindow().getAttributes().flags & on);
        bridge().query("set", "keep_screen_on\n1");
        idle();
        assertEquals(on, a.getWindow().getAttributes().flags & on);
        bridge().query("set", "keep_screen_on\n0");
        idle();
        assertEquals(0, a.getWindow().getAttributes().flags & on);

        bridge().query("set", "hide_status_bar\n1");   // Robolectric has no status bar to look at: just no crash
        idle();
        bridge().query("set", "hide_status_bar\n0");
        idle();
        for (String k : new String[] {"text_size", "orientation", "keep_screen_on", "hide_status_bar"}) Core.settingSet(k, "");
    }

    private String bridgeState() throws Exception {
        java.lang.reflect.Method m = MainActivity.class.getDeclaredMethod("panelState");
        m.setAccessible(true);
        return (String) m.invoke(a);
    }

    @Test public void closingTheLastTabOpensAFreshOne() {
        load("https://example.com/", "Example");
        int old = a.active.id;
        a.close(a.active);
        assertEquals(1, a.tabs.size());
        assertTrue(a.active.id != old);
        assertEquals(MainActivity.HOME, shadowOf(a.active.web).getLastLoadedUrl());
        a.onPanelAction("closeTab", "9999");   // unknown ids are ignored
        a.onPanelAction("switchTab", "abc");
        assertEquals(1, a.tabs.size());
    }

    @Test public void linksThatOpenANewWindowBecomeTabs() {
        WebView w = a.active.web;
        Message message = Message.obtain(new Handler(Looper.getMainLooper()));
        message.obj = w.new WebViewTransport();
        assertFalse("pop-ups without a tap are refused", chrome(w).onCreateWindow(w, false, false, message));
        assertEquals(1, a.tabs.size());
        assertTrue(chrome(w).onCreateWindow(w, false, true, message));
        assertEquals(2, a.tabs.size());
        assertEquals(a.tabs.get(1), a.active);
        assertEquals(a.active.web, ((WebView.WebViewTransport) message.obj).getWebView());
    }

    @Test public void idleBackgroundTabsSleepAndWake() {
        load("https://example.com/long-read", "Long read");
        MainActivity.Tab first = a.active;
        a.newTab("", false);
        a.showPanel("settings");
        bridge().query("set", "sleep_minutes\n5");
        idle();

        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMinutes(4));
        assertNotNull("not idle long enough yet", first.web);
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMinutes(2));
        assertNull("view released", first.web);
        assertNotNull("the tab in front never sleeps", a.active.web);

        a.onPanelAction("switchTab", String.valueOf(first.id));
        assertNotNull(first.web);
        assertEquals("reloads where it was", "https://example.com/long-read", shadowOf(first.web).getLastLoadedUrl());
    }

    @Test public void readerHistoryOpenAndBackButton() {
        load("https://example.com/", "Example");
        a.toggleReader();
        assertTrue(shadowOf(a.active.web).getLastEvaluatedJavascript().contains("data-fable-reader"));

        a.onPanelAction("open", "https://zh.wikipedia.org/wiki/土星");
        assertEquals("https://zh.wikipedia.org/wiki/土星", shadowOf(a.active.web).getLastLoadedUrl());

        a.showPanel("history");
        client(a.panel).onPageFinished(a.panel, "about:blank");
        a.onBackPressed();   // with a sheet open, Back belongs to the sheet
        assertEquals("Fable.back()", shadowOf(a.panel).getLastEvaluatedJavascript());

        a.onPanelAction("clear", "history,cookies,cache");
        assertEquals("[]", Core.historyJson("", 10));
        assertEquals("已清除所选数据", a.toast.getText().toString());
    }

    @Test public void siteIconsAreStoredShownAndKeptPrivate() throws Exception {
        Bitmap favicon = Bitmap.createBitmap(48, 48, Bitmap.Config.ARGB_8888);
        favicon.eraseColor(Color.RED);
        load("https://example.com/", "Example");
        WebView w = a.active.web;
        chrome(w).onReceivedIcon(w, favicon);
        assertNotNull("the page's favicon is stored for its host", a.icons.get("example.com"));

        // The tab list and the history get the icon as a data: URI.
        a.showPanel("tabs");
        client(a.panel).onPageFinished(a.panel, "about:blank");
        String script = shadowOf(a.panel).getLastEvaluatedJavascript();
        JSONObject state = new JSONObject(script.substring(script.indexOf(',') + 1, script.length() - 1));
        assertTrue(state.getJSONArray("tabs").getJSONObject(0).getString("icon").startsWith("data:image/png;base64,"));
        assertTrue(bridge().query("icon", "example.com").startsWith("data:image/png;base64,"));
        assertEquals("", bridge().query("icon", "never-visited.example"));

        // The new-tab page can ask for a shortcut's icon...
        String endpoint = MainActivity.ICON_ENDPOINT + "u=" + Uri.encode("https://example.com");
        load(MainActivity.HOME, "新标签页");
        WebResourceResponse served = client(w).shouldInterceptRequest(w, request(endpoint, false));
        assertEquals("image/png", served.getMimeType());
        assertTrue(body(served).length() > 20);
        // ...but a web page asking the same thing learns nothing about what was visited.
        load("https://snoop.example/", "Snoop");
        WebResourceResponse refused = client(w).shouldInterceptRequest(w, request(endpoint, false));
        assertEquals(404, refused.getStatusCode());

        // Private tabs show their icon while open and leave nothing behind.
        a.onPanelAction("newPrivate", "");
        load("https://secret.example/", "Secret");
        chrome(a.active.web).onReceivedIcon(a.active.web, favicon);
        assertTrue(a.active.iconUri.startsWith("data:image/png"));
        assertNull(a.icons.get("secret.example"));

        // Clearing the history clears the icons with it: they show where you have been.
        bridge().query("historyClear", "");
        assertNull(a.icons.get("example.com"));
    }

    @Test public void sniffsMediaFromRequestsAndFromThePage() throws Exception {
        load("https://video.example.com/watch/1", "A video");
        WebView w = a.active.web;
        Map<String, String> ranged = Collections.singletonMap("Range", "bytes=0-");
        // What a player does: a ranged request for the file, a playlist, hundreds of segments.
        assertNull(client(w).shouldInterceptRequest(w, request("https://cdn.example.com/media/clip.mp4?sig=1", false, ranged)));
        client(w).shouldInterceptRequest(w, request("https://cdn.example.com/live/master.m3u8", false));
        client(w).shouldInterceptRequest(w, request("https://cdn.example.com/live/seg-001.ts", false, ranged));
        client(w).shouldInterceptRequest(w, request("https://cdn.example.com/live/seg-002.ts", false, ranged));
        client(w).shouldInterceptRequest(w, request("https://video.example.com/app.js", false));
        client(w).shouldInterceptRequest(w, request("https://video.example.com/logo.png", false));
        client(w).shouldInterceptRequest(w, request("https://ad.doubleclick.net/ad.mp4", false, ranged));   // blocked, so never listed
        assertEquals(2, Core.sniffCount(a.active.id));

        // The menu shows the count; the sheet lists them and asks the page for the rest.
        a.showPanel("menu");
        client(a.panel).onPageFinished(a.panel, "about:blank");
        String script = shadowOf(a.panel).getLastEvaluatedJavascript();
        assertEquals(2, new JSONObject(script.substring(script.indexOf(',') + 1, script.length() - 1)).getInt("sniffed"));
        a.onPanelAction("sniffScan", "");
        assertTrue("the page scan script runs in the page", shadowOf(w).getLastEvaluatedJavascript().contains("document.images"));
        shadowOf(w).getLastEvaluatedJavascriptCallback().onReceiveValue(
                "[[\"video\",\"blob:https://video.example.com/1f\"],[\"image\",\"https://img.example.com/poster?id=9\"],[\"\",\"https://video.example.com/extras/song.mp3\"]]");
        JSONArray found = new JSONArray(bridge().query("sniff", ""));
        assertEquals("blob: addresses cannot be saved and are left out", 4, found.length());
        assertEquals("video", found.getJSONObject(0).getString("k"));
        assertEquals("https://cdn.example.com/media/clip.mp4?sig=1", found.getJSONObject(0).getString("u"));
        assertEquals("stream", found.getJSONObject(1).getString("k"));
        assertEquals("image", found.getJSONObject(2).getString("k"));
        assertEquals("audio", found.getJSONObject(3).getString("k"));
        assertEquals("the open sheet is told to redraw", "Fable.refresh('sniff')", shadowOf(a.panel).getLastEvaluatedJavascript());
        shadowOf(w).getLastEvaluatedJavascriptCallback().onReceiveValue("null");   // a page that blocks scripts: nothing breaks
        assertEquals(4, Core.sniffCount(a.active.id));

        // Acting on a resource.
        a.onPanelAction("copy", "https://cdn.example.com/media/clip.mp4?sig=1");
        ClipboardManager clipboard = (ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE);
        assertEquals("https://cdn.example.com/media/clip.mp4?sig=1", clipboard.getPrimaryClip().getItemAt(0).getText().toString());
        assertEquals("已复制链接", a.toast.getText().toString());
        a.onPanelAction("download", "https://cdn.example.com/media/clip.mp4?sig=1");
        DownloadManager downloads = (DownloadManager) a.getSystemService(Context.DOWNLOAD_SERVICE);
        assertEquals(1, shadowOf(downloads).getRequestCount());
        assertTrue(a.toast.getText().toString(), a.toast.getText().toString().startsWith("开始下载：clip"));
        int before = a.tabs.size();
        a.onPanelAction("openNew", "https://cdn.example.com/media/clip.mp4?sig=1");
        assertEquals(before + 1, a.tabs.size());
        assertEquals("https://cdn.example.com/media/clip.mp4?sig=1", shadowOf(a.active.web).getLastLoadedUrl());

        // Lists are per tab and start afresh on the next page.
        assertEquals(0, Core.sniffCount(a.active.id));
        a.onPanelAction("switchTab", String.valueOf(a.tabs.get(0).id));
        assertEquals(4, Core.sniffCount(a.active.id));
        load("https://video.example.com/watch/2", "Another");
        assertEquals(0, Core.sniffCount(a.active.id));
        load("https://cdn.example.com/direct/file.webm", "file.webm");   // a media file opened directly lists itself
        assertEquals(1, Core.sniffCount(a.active.id));
    }

    @Test public void switchesLanguageEverywhere() throws Exception {
        a.showPanel("settings");
        client(a.panel).onPageFinished(a.panel, "about:blank");
        assertTrue(shadowOf(a.panel).getLastLoadDataWithBaseURL().data.contains("\"_lang\":\"zh-Hans\""));

        bridge().query("set", "language\nja");
        idle();
        assertEquals("検索または URL を入力", a.address.getHint().toString());
        assertEquals("新しいタブ", a.active.title);
        assertTrue("the sheet is loaded again in the new language", shadowOf(a.panel).getLastLoadDataWithBaseURL().data.contains("\"_lang\":\"ja\""));
        client(a.panel).onPageFinished(a.panel, "about:blank");
        assertTrue("and returns to the settings", shadowOf(a.panel).getLastEvaluatedJavascript().startsWith("Fable.show(\"settings\","));
        a.onPanelAction("copy", "https://example.com/");
        assertEquals("リンクをコピーしました", a.toast.getText().toString());
        WebView w = a.active.web;
        assertTrue(body(client(w).shouldInterceptRequest(w, request(MainActivity.HOME, true))).contains("\"newtab\":\"新しいタブ\""));

        bridge().query("set", "language\nzh-Hant");
        idle();
        assertEquals("搜尋或輸入網址", a.address.getHint().toString());
        bridge().query("set", "language\nen");
        idle();
        assertEquals("Search or type an address", a.address.getHint().toString());
        a.onPanelAction("clear", "cache");
        assertEquals("Selected data cleared", a.toast.getText().toString());

        // No choice: follow the device. Robolectric's device speaks US English.
        bridge().query("set", "language\n");
        idle();
        assertEquals("en", Core.language());
        Core.setSystemLocale("zh-HK");
        assertEquals("zh-Hant", Core.language());
        Core.setSystemLocale("en-US");
    }

    @Test public void knownIconsArePartOfTheNewTabPage() throws Exception {
        Bitmap favicon = Bitmap.createBitmap(120, 120, Bitmap.Config.ARGB_8888);
        favicon.eraseColor(Color.RED);
        WebView w = a.active.web;
        String before = body(client(w).shouldInterceptRequest(w, request(MainActivity.HOME, true)));
        assertTrue("nothing stored yet", before.contains("var ICONS = {};"));

        load("https://claude.ai/new", "Claude");   // one of the default shortcuts
        chrome(w).onReceivedIcon(w, favicon);
        String after = body(client(w).shouldInterceptRequest(w, request(MainActivity.HOME, true)));
        assertTrue("its icon now travels inside the page, with its size", after.contains("var ICONS = {\"claude.ai\":[\"data:image/png;base64,") && after.contains("\",120]};"));

        // The user's own shortcut list decides which icons are sent.
        Core.settingSet("shortcuts", "[{\"n\":\"Example\",\"u\":\"https://example.com/\"}]");
        assertTrue(body(client(w).shouldInterceptRequest(w, request(MainActivity.HOME, true))).contains("var ICONS = {};"));
        load("https://example.com/", "Example");
        chrome(w).onReceivedIcon(w, favicon);
        assertTrue(body(client(w).shouldInterceptRequest(w, request(MainActivity.HOME, true))).contains("var ICONS = {\"example.com\":["));

        // Private tabs get no icons, and clearing history empties the bundle.
        a.onPanelAction("newPrivate", "");
        assertTrue(body(client(a.active.web).shouldInterceptRequest(a.active.web, request(MainActivity.HOME, true))).contains("var ICONS = null;"));
        a.showPanel("history");
        bridge().query("historyClear", "");
        assertTrue(body(client(w).shouldInterceptRequest(w, request(MainActivity.HOME, true))).contains("var ICONS = {};"));
    }

    @Test public void metadataComesFromTheDeviceAndOneIpLookup() throws Exception {
        a.showPanel("settings");
        client(a.panel).onPageFinished(a.panel, "about:blank");

        JSONObject device = new JSONObject(bridge().query("device", ""));
        for (String key : new String[] {"manufacturer", "model", "android", "sdk", "abi", "screenW", "screenH", "dpi", "refresh", "storageTotal", "storageFree", "cookies", "ua"}) {
            assertTrue("device." + key + " in " + device, device.has(key));
        }
        assertTrue(device.getInt("screenW") <= device.getInt("screenH"));
        assertEquals("the User-Agent the tabs send", a.active.web.getSettings().getUserAgentString(), device.getString("ua"));
        bridge().query("set", "ua_mode\ndesktop");
        assertTrue(new JSONObject(bridge().query("device", "")).getString("ua").contains("Windows NT 10.0"));

        // A local server stands in for Cloudflare.
        java.net.ServerSocket server = new java.net.ServerSocket(0, 4, java.net.InetAddress.getByName("127.0.0.1"));
        final java.util.List<String> userAgents = Collections.synchronizedList(new java.util.ArrayList<String>());
        Thread loop = new Thread(() -> {
            while (!server.isClosed()) {
                try (java.net.Socket s = server.accept()) {
                    java.io.BufferedReader in = new java.io.BufferedReader(new java.io.InputStreamReader(s.getInputStream(), "UTF-8"));
                    String path = in.readLine().split(" ")[1];
                    for (String line; (line = in.readLine()) != null && !line.isEmpty(); ) {
                        if (line.toLowerCase().startsWith("user-agent:")) userAgents.add(line.substring(11).trim());
                    }
                    String body = path.startsWith("/trace") ? "fl=1\nip=203.0.113.9\nloc=SG\ncolo=SIN\nhttp=http/3\ntls=TLSv1.3\nwarp=off\n" : "";
                    int status = body.isEmpty() ? 404 : 200;
                    s.getOutputStream().write(("HTTP/1.1 " + status + " X\r\nContent-Length: " + body.length() + "\r\nConnection: close\r\n\r\n" + body).getBytes("UTF-8"));
                } catch (Exception closed) { return; }
            }
        });
        loop.setDaemon(true);
        loop.start();
        String base = "http://127.0.0.1:" + server.getLocalPort();
        String trace = Meta.traceEndpoint, fallback = Meta.fallbackEndpoint;
        try {
            Meta.traceEndpoint = base + "/trace";
            Meta.fallbackEndpoint = base + "/missing";
            JSONObject ip = new JSONObject(Meta.lookupIp("FableTest/1.0"));
            assertEquals("203.0.113.9", ip.getString("ip"));
            assertEquals("SG", ip.getString("loc"));
            assertEquals("http/3", ip.getString("http"));
            assertEquals("127.0.0.1", ip.getString("src"));
            assertFalse("only the fields the sheet shows", ip.has("warp") || ip.has("fl"));
            assertEquals(Collections.singletonList("FableTest/1.0"), userAgents);

            // Through the panel: the answer is handed to the sheet.
            a.onPanelAction("ip", "");
            for (int i = 0; i < 100 && !shadowOf(a.panel).getLastEvaluatedJavascript().startsWith("Fable.ip("); i++) {
                Thread.sleep(30);
                idle();
            }
            String delivered = shadowOf(a.panel).getLastEvaluatedJavascript();
            assertTrue(delivered, delivered.startsWith("Fable.ip({") && delivered.contains("\"ip\":\"203.0.113.9\""));

            Meta.traceEndpoint = base + "/missing";
            assertEquals("nothing answers: an empty object", "{}", Meta.lookupIp("x"));
        } finally {
            Meta.traceEndpoint = trace;
            Meta.fallbackEndpoint = fallback;
            server.close();
        }

        a.onPanelAction("copyText", "Google Pixel 8");
        ClipboardManager clipboard = (ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE);
        assertEquals("Google Pixel 8", clipboard.getPrimaryClip().getItemAt(0).getText().toString());
        assertEquals("已复制", a.toast.getText().toString());
    }

    @Test public void systemFactsAreCollectedAndHandedToTheSheet() throws Exception {
        a.showPanel("settings");
        client(a.panel).onPageFinished(a.panel, "about:blank");
        a.onPanelAction("system", "");
        for (int i = 0; i < 200 && !shadowOf(a.panel).getLastEvaluatedJavascript().startsWith("Fable.system("); i++) {
            Thread.sleep(25);
            idle();
        }
        String script = shadowOf(a.panel).getLastEvaluatedJavascript();
        assertTrue(script.substring(0, Math.min(80, script.length())), script.startsWith("Fable.system({"));
        JSONObject info = new JSONObject(script.substring("Fable.system(".length(), script.length() - 1));
        for (String part : new String[] {"system", "cpu", "memory", "storage", "display", "gl", "network", "wifi", "carrier", "battery", "audio", "media", "sensors", "cameras", "features"}) {
            assertTrue("part " + part + " in " + info.names(), info.has(part));
        }
        JSONObject system = info.getJSONObject("system");
        assertEquals(android.os.Build.MODEL, system.getString("model"));
        assertTrue(system.has("android") && system.has("sdk") && system.has("fingerprint") && system.has("uptime"));
        assertTrue(info.getJSONObject("cpu").getInt("cores") > 0);
        assertTrue(info.getJSONObject("display").getInt("w") <= info.getJSONObject("display").getInt("h"));
        assertTrue(info.getJSONObject("memory").has("appLimit"));   // the emulated device reports no total RAM, so that one is left out
        assertTrue(info.getJSONObject("storage").has("volumes"));   // the emulated file system reports no size either
        assertTrue(info.getJSONObject("media").has("codecs") && info.getJSONObject("media").has("drm"));

        // Identifiers the system withholds are never asked for.
        String raw = info.toString();
        for (String forbidden : new String[] {"imei", "serial", "macAddress", "deviceUniqueId", "ssid", "bssid"}) {
            assertFalse(forbidden, raw.toLowerCase().contains("\"" + forbidden.toLowerCase() + "\""));
        }
        // Static facts are read once per process; a second collection is quick and identical for them.
        a.onPanelAction("system", "");
        for (int i = 0; i < 200 && shadowOf(a.panel).getLastEvaluatedJavascript() == script; i++) {
            Thread.sleep(25);
            idle();
        }
        JSONObject again = new JSONObject(shadowOf(a.panel).getLastEvaluatedJavascript().replaceFirst("^Fable\\.system\\(", "").replaceFirst("\\)$", ""));
        assertEquals(info.getJSONArray("features").toString(), again.getJSONArray("features").toString());
    }

    @Test public void theNewTabPageCarriesTheLogoAsItsIcon() throws Exception {
        WebView w = a.active.web;
        String page = body(client(w).shouldInterceptRequest(w, request(MainActivity.HOME, true)));
        assertTrue(page.contains("<link id=\"favicon\" rel=\"icon\""));
        a.newTab("https://example.com/", false);
        a.onPanelAction("newPrivate", "");
        a.showPanel("tabs");
        client(a.panel).onPageFinished(a.panel, "about:blank");
        String script = shadowOf(a.panel).getLastEvaluatedJavascript();
        JSONArray tabs = new JSONObject(script.substring(script.indexOf(',') + 1, script.length() - 1)).getJSONArray("tabs");
        assertEquals("the new-tab page shows the Fable logo", Core.logoUri(), tabs.getJSONObject(0).getString("icon"));
        assertTrue("a page tab is not given the logo", !tabs.getJSONObject(1).getString("icon").startsWith("data:image/webp"));
        assertEquals("a private new tab keeps its own glyph", "", tabs.getJSONObject(2).getString("icon"));
    }

    @Test public void settingsSurviveARestart() {
        a.showPanel("settings");
        bridge().query("set", "shortcuts\n[{\"n\":\"例子\",\"u\":\"https://example.com/\"}]");
        bridge().query("set", "ua_mode\ndesktop");
        Core.storeOpen(new java.io.File(a.getFilesDir(), "fable").getAbsolutePath());   // what the next launch does
        assertEquals("desktop", Core.settingGet("ua_mode"));
        assertTrue(Core.newtabPage(0, "").contains("\"n\":\"例子\""));
    }

    // ---- what other apps and pages can reach (audit findings Medium-2, -5, -9) ----

    @Test public void intentsOnlyOpenWebLinks() {
        int before = a.tabs.size();
        // The activity is exported: an explicit intent may carry any data URI, whatever the filters say.
        for (String url : new String[] {"javascript:alert(document.cookie)", "file:///data/data/app.fable.browser/files/fable/settings.tsv",
                                        "content://com.example.provider/secret", "intent://scan/#Intent;scheme=zxing;end", "fable://newtab/", "data:text/html,<b>x</b>"}) {
            a.onNewIntent(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            idle();
            assertEquals(url + " must not open a tab", before, a.tabs.size());
            assertEquals("and the user is told why", Core.tr("link_not_opened"), a.toast.getText().toString());
            a.toast.setText("");
        }
        a.onNewIntent(new Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com/page")));
        idle();
        assertEquals(before + 1, a.tabs.size());
        assertEquals("https://example.com/page", shadowOf(a.active.web).getLastLoadedUrl());
        // Shared text follows the address bar's rules: an app scheme becomes a search, never a load.
        a.onNewIntent(new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, "intent://x#Intent;end"));
        idle();
        assertTrue(shadowOf(a.active.web).getLastLoadedUrl(), shadowOf(a.active.web).getLastLoadedUrl().startsWith("https://duckduckgo.com/?q=intent%3A"));
    }

    @Test public void appInitiatedLoadsAreWebOnly() {
        // loadUrl does not go through shouldOverrideUrlLoading: navigate() checks the scheme itself.
        a.newTab("file:///sdcard/Download/page.html", false);
        assertEquals(MainActivity.HOME, shadowOf(a.active.web).getLastLoadedUrl());
        a.newTab("content://com.example.provider/secret", false);
        assertTrue(shadowOf(a.active.web).getLastLoadedUrl().startsWith("https://duckduckgo.com/"));
        a.newTab("example.com", false);
        assertEquals("https://example.com", shadowOf(a.active.web).getLastLoadedUrl());
    }

    @Test public void contentAccessIsOffExceptForASharedDocument() throws Exception {
        assertFalse("tabs cannot read content:// URIs", a.active.web.getSettings().getAllowContentAccess());
        a.showPanel("settings");
        assertFalse("nor can the panel", a.panel.getSettings().getAllowContentAccess());
        // A text document shared from another app opens in a tab of its own...
        String doc = "content://com.example.docs/notes/1";
        a.onNewIntent(new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_STREAM, Uri.parse(doc)));
        idle();
        WebView w = a.active.web;
        assertEquals(doc, shadowOf(w).getLastLoadedUrl());
        assertTrue(w.getSettings().getAllowContentAccess());
        assertNull("the shared document itself loads", client(w).shouldInterceptRequest(w, request(doc, true)));
        // ...which may load that URI and no other.
        WebResourceResponse other = client(w).shouldInterceptRequest(w, request("content://com.example.docs/notes/2", false));
        assertNotNull(other);
        assertEquals(403, other.getStatusCode());
        WebResourceResponse fromWeb = client(a.tabs.get(0).web).shouldInterceptRequest(a.tabs.get(0).web, request(doc, false));
        assertNotNull("another tab cannot load it either", fromWeb);
        assertEquals(403, fromWeb.getStatusCode());
        assertFalse(a.tabs.get(0).web.getSettings().getAllowContentAccess());
    }

    @Test public void thePanelBridgeSetsOnlyItsOwnSettings() {
        a.showPanel("settings");
        bridge().query("set", "panel_evil_key\nx");
        assertEquals("", Core.settingGet("panel_evil_key"));
        StringBuilder huge = new StringBuilder();
        for (int i = 0; i < 5000; i++) huge.append('x');
        bridge().query("set", "ua_custom\n" + huge);
        assertEquals("an over-long value is refused", "", Core.settingGet("ua_custom"));
        bridge().query("set", "ua_custom\nMozilla/5.0\r\nX-Evil: 1");
        assertEquals("control characters are refused", "", Core.settingGet("ua_custom"));
        bridge().query("set", "ua_custom\nMozilla/5.0 Fable");
        assertEquals("Mozilla/5.0 Fable", Core.settingGet("ua_custom"));
        // The rules of the home page's own channel (home/set) apply here too: lists are JSON arrays...
        bridge().query("set", "shortcuts\nnot a list");
        assertEquals("", Core.settingGet("shortcuts"));
        // ...and the search engine stays an http(s) template.
        bridge().query("set", "search_template\njavascript:alert(1)//%s");
        assertEquals("", Core.settingGet("search_template"));
        bridge().query("set", "search_template\nhttps://search.example/?q=%s");
        assertEquals("https://search.example/?q=%s", Core.settingGet("search_template"));
    }
}
