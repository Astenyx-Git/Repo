//! HarmonyOS / OpenHarmony: the Linux reader for what /proc and /sys show an
//! app (CPU, memory, storage, kernel, network), then the system's own device
//! information and battery API for the rest. Linked against
//! libdeviceinfo_ndk.z.so and libohbattery_info.so by the HarmonyOS shell.

use crate::sysinfo::{meaningful, Battery, Facts};
use std::ffi::CStr;
use std::os::raw::{c_char, c_int};

#[path = "sysinfo_linux.rs"]
mod linux;

#[link(name = "deviceinfo_ndk.z")]
extern "C" {
    fn OH_GetManufacture() -> *const c_char;
    fn OH_GetBrand() -> *const c_char;
    fn OH_GetMarketName() -> *const c_char;
    fn OH_GetProductModel() -> *const c_char;
    fn OH_GetHardwareModel() -> *const c_char;
    fn OH_GetBootloaderVersion() -> *const c_char;
    fn OH_GetDisplayVersion() -> *const c_char;
    fn OH_GetOSFullName() -> *const c_char;
    fn OH_GetSdkApiVersion() -> c_int;
    fn OH_GetDistributionOSName() -> *const c_char;
    fn OH_GetDistributionOSVersion() -> *const c_char;
}

#[link(name = "ohbattery_info")]
extern "C" {
    fn OH_BatteryInfo_GetCapacity() -> i32;
    fn OH_BatteryInfo_GetPluggedType() -> c_int;
}

fn text(p: *const c_char) -> String {
    if p.is_null() {
        return String::new();
    }
    // SAFETY: the device-info functions return NUL-terminated strings owned by the system.
    meaningful(&unsafe { CStr::from_ptr(p) }.to_string_lossy())
}

/// "HarmonyOS 5.0.1 (API 13)": the distribution's name and version where the
/// device says them, else OpenHarmony's full name ("OpenHarmony-5.0.1.115").
fn os_name(dist_name: &str, dist_version: &str, full: &str, api: i32) -> String {
    let base = if !dist_name.is_empty() && !dist_version.is_empty() {
        format!("{dist_name} {dist_version}")
    } else if !full.is_empty() {
        full.replacen('-', " ", 1)
    } else {
        dist_name.to_string()
    };
    if api > 0 && !base.is_empty() { format!("{base} (API {api})") } else { base }
}

fn plugged(kind: c_int) -> &'static str {
    match kind {
        0 => "none",
        1 => "ac",
        2 => "usb",
        3 => "wireless",
        _ => "",
    }
}

pub fn fill(f: &mut Facts) {
    linux::fill(f);
    // SAFETY: plain getters of the system's device information, callable from any thread.
    unsafe {
        let manufacturer = text(OH_GetManufacture());
        let brand = text(OH_GetBrand());
        if !manufacturer.is_empty() {
            f.manufacturer = manufacturer;
        } else if !brand.is_empty() {
            f.manufacturer = brand;
        }
        let market = text(OH_GetMarketName());
        let model = text(OH_GetProductModel());
        f.model = match (market.is_empty(), model.is_empty()) {
            (false, false) if market != model => format!("{market} ({model})"),
            (false, _) => market,
            (true, false) => model,
            _ => std::mem::take(&mut f.model),
        };
        let hardware = text(OH_GetHardwareModel());
        if !hardware.is_empty() {
            f.board = hardware;
        }
        f.firmware = text(OH_GetBootloaderVersion());
        let os = os_name(&text(OH_GetDistributionOSName()), &text(OH_GetDistributionOSVersion()), &text(OH_GetOSFullName()), OH_GetSdkApiVersion());
        if !os.is_empty() {
            f.os = os;
        }
        f.build = text(OH_GetDisplayVersion());
        let level = OH_BatteryInfo_GetCapacity();
        if (0..=100).contains(&level) {
            let mut b = f.battery.take().unwrap_or_default();   // /sys may have said more (voltage, temperature)
            b.level = Some(level as u32);
            let source = plugged(OH_BatteryInfo_GetPluggedType());
            if !source.is_empty() {
                b.plugged = source;
                if b.status.is_empty() {
                    b.status = if source == "none" { "discharging" } else if level >= 100 { "full" } else { "charging" };
                }
            }
            f.battery = Some(Battery { ..b });
        }
    }
    f.hostname.clear();   // "localhost" on phones; the market name says it better
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn os_names() {
        assert_eq!(os_name("HarmonyOS", "5.0.1", "OpenHarmony-5.0.1.115", 13), "HarmonyOS 5.0.1 (API 13)");
        assert_eq!(os_name("", "", "OpenHarmony-6.0.0.47", 20), "OpenHarmony 6.0.0.47 (API 20)");
        assert_eq!(os_name("", "", "", 0), "");
        assert_eq!(plugged(2), "usb");
    }
}
