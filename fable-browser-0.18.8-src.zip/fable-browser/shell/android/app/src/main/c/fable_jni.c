/* JNI glue between app.fable.browser.Core (Java) and the Rust core's C ABI.
 * Text is exchanged as UTF-8 byte arrays; see Core.java for why. */
#include <jni.h>
#include <stdlib.h>
#include <string.h>
#include "fable_core.h"

#define CORE(name) Java_app_fable_browser_Core_##name

/* Copy a Java byte[] into a NUL-terminated C string. Caller frees. NULL on failure. */
static char *to_cstr(JNIEnv *env, jbyteArray bytes) {
    jsize n = bytes ? (*env)->GetArrayLength(env, bytes) : 0;
    char *s = malloc((size_t)n + 1);
    if (!s) return NULL;
    if (n > 0) (*env)->GetByteArrayRegion(env, bytes, 0, n, (jbyte *)s);
    s[n] = '\0';
    return s;
}

static jbyteArray to_bytes(JNIEnv *env, const char *s) {
    jsize n = (jsize)strlen(s);
    jbyteArray out = (*env)->NewByteArray(env, n);
    if (out && n > 0) (*env)->SetByteArrayRegion(env, out, 0, n, (const jbyte *)s);
    return out;
}

/* Hand a heap string from the core to Java and release it. */
static jbyteArray take(JNIEnv *env, char *s) {
    jbyteArray out = to_bytes(env, s);
    fable_string_free(s);
    return out;
}

JNIEXPORT jbyteArray JNICALL CORE(resolve0)(JNIEnv *env, jclass cls, jbyteArray input) {
    (void)cls;
    char *in = to_cstr(env, input);
    char *url = fable_resolve(in);
    jbyteArray out = to_bytes(env, url);
    fable_string_free(url);
    free(in);
    return out;
}

JNIEXPORT jboolean JNICALL CORE(shouldBlock0)(JNIEnv *env, jclass cls, jbyteArray request, jbyteArray page) {
    (void)cls;
    char *r = to_cstr(env, request);
    char *p = to_cstr(env, page);
    jboolean block = fable_should_block(r, p) ? JNI_TRUE : JNI_FALSE;
    free(r);
    free(p);
    return block;
}

JNIEXPORT jlong JNICALL CORE(blockedCount)(JNIEnv *env, jclass cls) {
    (void)env; (void)cls;
    return (jlong)fable_blocked_count();
}

/* ---- settings, history, generated pages --------------------------------- */

JNIEXPORT void JNICALL CORE(storeOpen0)(JNIEnv *env, jclass cls, jbyteArray dir) {
    (void)cls;
    char *d = to_cstr(env, dir);
    fable_store_open(d);
    free(d);
}

JNIEXPORT jbyteArray JNICALL CORE(settingGet0)(JNIEnv *env, jclass cls, jbyteArray key) {
    (void)cls;
    char *k = to_cstr(env, key);
    jbyteArray out = take(env, fable_setting_get(k));
    free(k);
    return out;
}

JNIEXPORT void JNICALL CORE(settingSet0)(JNIEnv *env, jclass cls, jbyteArray key, jbyteArray value) {
    (void)cls;
    char *k = to_cstr(env, key);
    char *v = to_cstr(env, value);
    fable_setting_set(k, v);
    free(k);
    free(v);
}

JNIEXPORT void JNICALL CORE(historyAdd0)(JNIEnv *env, jclass cls, jbyteArray url, jbyteArray title, jlong time_ms) {
    (void)cls;
    char *u = to_cstr(env, url);
    char *t = to_cstr(env, title);
    fable_history_add(u, t, (uint64_t)time_ms);
    free(u);
    free(t);
}

JNIEXPORT jbyteArray JNICALL CORE(historyJson0)(JNIEnv *env, jclass cls, jbyteArray query, jint limit) {
    (void)cls;
    char *q = to_cstr(env, query);
    jbyteArray out = take(env, fable_history_json(q, limit > 0 ? (size_t)limit : 0));
    free(q);
    return out;
}

JNIEXPORT void JNICALL CORE(historyDelete0)(JNIEnv *env, jclass cls, jbyteArray url, jlong time_ms) {
    (void)cls;
    char *u = to_cstr(env, url);
    fable_history_delete(u, (uint64_t)time_ms);
    free(u);
}

JNIEXPORT void JNICALL CORE(historyClear)(JNIEnv *env, jclass cls) {
    (void)env; (void)cls;
    fable_history_clear();
}

JNIEXPORT jbyteArray JNICALL CORE(newtabPage0)(JNIEnv *env, jclass cls, jint incognito, jbyteArray icons) {
    (void)cls;
    char *i = to_cstr(env, icons);
    jbyteArray out = take(env, fable_newtab_page((int)incognito, i));
    free(i);
    return out;
}

JNIEXPORT jbyteArray JNICALL CORE(launcherPage0)(JNIEnv *env, jclass cls, jbyteArray icons, jbyteArray apps, jint wallpaper) {
    (void)cls;
    char *i = to_cstr(env, icons), *a = to_cstr(env, apps);
    jbyteArray out = take(env, fable_launcher_page(i, a, (int)wallpaper));
    free(i);
    free(a);
    return out;
}

JNIEXPORT jbyteArray JNICALL CORE(logoUri0)(JNIEnv *env, jclass cls) {
    (void)cls;
    return take(env, fable_logo_uri());
}

JNIEXPORT jbyteArray JNICALL CORE(panelPage0)(JNIEnv *env, jclass cls) {
    (void)cls;
    return take(env, fable_panel_page());
}

JNIEXPORT jbyteArray JNICALL CORE(readerScript0)(JNIEnv *env, jclass cls) {
    (void)cls;
    return take(env, fable_reader_script());
}

JNIEXPORT jbyteArray JNICALL CORE(adblockScript0)(JNIEnv *env, jclass cls) {
    (void)cls;
    return take(env, fable_adblock_script());
}

JNIEXPORT jboolean JNICALL CORE(panelSettingAllowed0)(JNIEnv *env, jclass cls, jbyteArray key, jbyteArray value) {
    (void)cls;
    char *k = to_cstr(env, key), *v = to_cstr(env, value);
    jboolean ok = fable_panel_setting_allowed(k, v) ? JNI_TRUE : JNI_FALSE;
    free(k);
    free(v);
    return ok;
}

JNIEXPORT jboolean JNICALL CORE(blockExternalApp0)(JNIEnv *env, jclass cls, jbyteArray url) {
    (void)cls;
    char *u = to_cstr(env, url);
    jboolean block = fable_block_external_app(u) ? JNI_TRUE : JNI_FALSE;
    free(u);
    return block;
}

JNIEXPORT void JNICALL CORE(setSystemLocale0)(JNIEnv *env, jclass cls, jbyteArray tag) {
    (void)cls;
    char *t = to_cstr(env, tag);
    fable_set_system_locale(t);
    free(t);
}

JNIEXPORT jbyteArray JNICALL CORE(language0)(JNIEnv *env, jclass cls) {
    (void)cls;
    return take(env, fable_language());
}

JNIEXPORT jbyteArray JNICALL CORE(tr0)(JNIEnv *env, jclass cls, jbyteArray key) {
    (void)cls;
    char *k = to_cstr(env, key);
    jbyteArray out = take(env, fable_tr(k));
    free(k);
    return out;
}

JNIEXPORT jbyteArray JNICALL CORE(version0)(JNIEnv *env, jclass cls) {
    (void)cls;
    return to_bytes(env, fable_version());
}

/* ---- resource sniffing --------------------------------------------------- */

JNIEXPORT jbyteArray JNICALL CORE(sniffJs0)(JNIEnv *env, jclass cls) {
    (void)cls;
    return to_bytes(env, fable_sniff_js());
}

JNIEXPORT jboolean JNICALL CORE(sniffNote0)(JNIEnv *env, jclass cls, jint tab, jbyteArray url, jbyteArray hint) {
    (void)cls;
    char *u = to_cstr(env, url);
    char *h = to_cstr(env, hint);
    jboolean added = fable_sniff_note((uint32_t)tab, u, h) ? JNI_TRUE : JNI_FALSE;
    free(u);
    free(h);
    return added;
}

JNIEXPORT jbyteArray JNICALL CORE(sniffJson0)(JNIEnv *env, jclass cls, jint tab) {
    (void)cls;
    return take(env, fable_sniff_json((uint32_t)tab));
}

JNIEXPORT jint JNICALL CORE(sniffCount)(JNIEnv *env, jclass cls, jint tab) {
    (void)env; (void)cls;
    return (jint)fable_sniff_count((uint32_t)tab);
}

JNIEXPORT void JNICALL CORE(sniffClear)(JNIEnv *env, jclass cls, jint tab) {
    (void)env; (void)cls;
    fable_sniff_clear((uint32_t)tab);
}

/* The requests every shell answers the same way (settings, history, sniff,
 * bookmarks, the session): NULL means the shell answers itself. */
JNIEXPORT jbyteArray JNICALL CORE(panelQuery0)(JNIEnv *env, jclass cls, jbyteArray name, jbyteArray arg, jint tab) {
    (void)cls;
    char *n = to_cstr(env, name);
    char *a = to_cstr(env, arg);
    char *answer = fable_panel_query(n, a, (uint32_t)tab);
    free(n);
    free(a);
    if (!answer) return NULL;
    jbyteArray out = take(env, answer);
    return out;
}

/* ---- tabs: the handle travels through Java as a long ------------------- */

static FableTabs *tabs(jlong handle) { return (FableTabs *)(intptr_t)handle; }

JNIEXPORT jlong JNICALL CORE(tabsNew)(JNIEnv *env, jclass cls) {
    (void)env; (void)cls;
    return (jlong)(intptr_t)fable_tabs_new();
}

JNIEXPORT void JNICALL CORE(tabsFree)(JNIEnv *env, jclass cls, jlong handle) {
    (void)env; (void)cls;
    fable_tabs_free(tabs(handle));
}

JNIEXPORT jint JNICALL CORE(tabsOpen)(JNIEnv *env, jclass cls, jlong handle, jlong now_ms) {
    (void)env; (void)cls;
    return (jint)fable_tabs_open(tabs(handle), (uint64_t)now_ms);
}

JNIEXPORT jboolean JNICALL CORE(tabsActivate)(JNIEnv *env, jclass cls, jlong handle, jint id, jlong now_ms) {
    (void)env; (void)cls;
    return fable_tabs_activate(tabs(handle), (uint32_t)id, (uint64_t)now_ms) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL CORE(tabsClose)(JNIEnv *env, jclass cls, jlong handle, jint id) {
    (void)env; (void)cls;
    return fable_tabs_close(tabs(handle), (uint32_t)id) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL CORE(tabsSetSleepAfterMs)(JNIEnv *env, jclass cls, jlong handle, jlong ms) {
    (void)env; (void)cls;
    fable_tabs_set_sleep_after_ms(tabs(handle), (uint64_t)ms);
}

JNIEXPORT jintArray JNICALL CORE(tabsCollectSleepers)(JNIEnv *env, jclass cls, jlong handle, jlong now_ms) {
    (void)cls;
    uint32_t ids[64];
    size_t n = fable_tabs_collect_sleepers(tabs(handle), (uint64_t)now_ms, ids, sizeof ids / sizeof ids[0]);
    jintArray out = (*env)->NewIntArray(env, (jsize)n);
    if (out && n > 0) (*env)->SetIntArrayRegion(env, out, 0, (jsize)n, (const jint *)ids);
    return out;
}
