//! The sets of blocked domains, stored as sorted 64-bit hashes.
//!
//! Two lists live here: the trackers (consulted while "block trackers" is on)
//! and the ad domains (consulted only while "block ads" is on). Each is built
//! the same way from its own file, and each may come either from Zig at
//! compile time or from Rust at first use.
//!
//! With `zig-native` the tables are produced at compile time by
//! native/hostset.zig; otherwise they are built here on first use from the
//! same files. Hash collisions are possible in principle (64-bit FNV over a
//! few hundred entries makes them negligible) and would only cause one
//! extra third-party request to be blocked.

#[cfg(feature = "zig-native")]
mod imp {
    extern "C" {
        fn fable_hostset_contains(hash: u64) -> bool;
        fn fable_hostset_len() -> usize;
    }
    pub fn contains(hash: u64) -> bool {
        unsafe { fable_hostset_contains(hash) }
    }
    pub fn len() -> usize {
        unsafe { fable_hostset_len() }
    }
}

#[cfg(not(feature = "zig-native"))]
mod imp {
    use std::sync::OnceLock;

    static LIST: &str = include_str!("../../native/trackers.txt");
    static TABLE: OnceLock<Vec<u64>> = OnceLock::new();

    fn table() -> &'static [u64] {
        TABLE.get_or_init(|| super::build_table(LIST))
    }
    pub fn contains(hash: u64) -> bool {
        table().binary_search(&hash).is_ok()
    }
    pub fn len() -> usize {
        table().len()
    }
}

/// The ad domains: the same shape as the tracker table, from native/ads.txt.
#[cfg(feature = "zig-native")]
mod adimp {
    extern "C" {
        fn fable_adhostset_contains(hash: u64) -> bool;
        fn fable_adhostset_len() -> usize;
    }
    pub fn contains(hash: u64) -> bool {
        unsafe { fable_adhostset_contains(hash) }
    }
    pub fn len() -> usize {
        unsafe { fable_adhostset_len() }
    }
}

#[cfg(not(feature = "zig-native"))]
mod adimp {
    use std::sync::OnceLock;

    static LIST: &str = include_str!("../../native/ads.txt");
    static TABLE: OnceLock<Vec<u64>> = OnceLock::new();

    fn table() -> &'static [u64] {
        TABLE.get_or_init(|| super::build_table(LIST))
    }
    pub fn contains(hash: u64) -> bool {
        table().binary_search(&hash).is_ok()
    }
    pub fn len() -> usize {
        table().len()
    }
}

/// A table the way Rust builds it: entries (the same characters the Zig build
/// trims, so both read the files the same way), hashed, sorted, without repeats.
/// Built here even with `zig-native`, where the tests compare the two.
#[cfg_attr(feature = "zig-native", allow(dead_code))]
fn build_table(list: &str) -> Vec<u64> {
    let mut t: Vec<u64> = list
        .lines()
        .map(|l| l.trim_matches(|c: char| c.is_ascii_whitespace()))
        .filter(|l| !l.is_empty() && !l.starts_with('#'))
        .map(|l| crate::hash::fnv1a_lower_portable(l.as_bytes()))
        .collect();
    t.sort_unstable();
    t.dedup();
    t
}

pub use imp::{contains, len};

/// The ad domains, as a table of their own.
pub mod ads {
    pub use super::adimp::{contains, len};
}

/// The listed domains themselves, in file order, for shells whose engine
/// blocks by declarative rules instead of asking per request (macOS).
pub fn domains() -> impl Iterator<Item = &'static str> {
    static LIST: &str = include_str!("../../native/trackers.txt");
    LIST.lines().map(|l| l.trim_matches(|c: char| c.is_ascii_whitespace())).filter(|l| !l.is_empty() && !l.starts_with('#'))
}

/// The ad domains themselves, in file order, for the same reason.
pub fn ad_domains() -> impl Iterator<Item = &'static str> {
    static LIST: &str = include_str!("../../native/ads.txt");
    LIST.lines().map(|l| l.trim_matches(|c: char| c.is_ascii_whitespace())).filter(|l| !l.is_empty() && !l.starts_with('#'))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn both_tables_are_loaded() {
        assert!(len() >= 50, "trackers: {}", len());
        assert!(ads::len() >= 50, "ads: {}", ads::len());
    }

    #[test]
    fn a_domain_is_in_the_table_it_belongs_to() {
        use crate::hash::fnv1a_lower_portable;
        let h = fnv1a_lower_portable(b"doubleclick.net");
        assert!(contains(h));
        assert!(ads::contains(h));
        // A tracker that is not an ad domain.
        assert!(contains(fnv1a_lower_portable(b"hotjar.com")));
        assert!(!ads::contains(fnv1a_lower_portable(b"hotjar.com")));
    }

    /// The tables in use (Zig's with `zig-native`) are the ones Rust builds from
    /// the same files: same length, every entry found, and nothing else found.
    #[test]
    fn tables_in_use_equal_the_rust_built_ones() {
        let lists: [(&str, Vec<u64>, fn(u64) -> bool, usize); 2] = [
            ("trackers", build_table(include_str!("../../native/trackers.txt")), contains, len()),
            ("ads", build_table(include_str!("../../native/ads.txt")), ads::contains, ads::len()),
        ];
        for (name, table, has, n) in lists {
            assert_eq!(n, table.len(), "{name}: table length");
            for h in &table {
                assert!(has(*h), "{name}: {h:#018x} missing");
                assert!(!has(h ^ 1) || table.contains(&(h ^ 1)), "{name}: {:#018x} found but not listed", h ^ 1);
            }
        }
        // Built from a list with a comment, blank lines, odd spacing and a repeat.
        assert_eq!(build_table("# x\n\n a.com\r\nA.COM\n\tb.com \n"), {
            let mut t = vec![crate::hash::fnv1a_lower_portable(b"a.com"), crate::hash::fnv1a_lower_portable(b"b.com")];
            t.sort_unstable();
            t
        });
    }

    #[test]
    fn the_files_hold_plain_unique_domains() {
        for (name, list) in [("trackers", domains().collect::<Vec<_>>()), ("ads", ad_domains().collect::<Vec<_>>())] {
            for d in &list {
                assert!(!d.is_empty(), "{name}: empty line");
                assert!(
                    d.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'.' || b == b'-'),
                    "{name}: {d} is not a plain domain"
                );
                assert!(d.contains('.'), "{name}: {d} has no dot");
            }
            let mut sorted = list.clone();
            sorted.sort_unstable();
            sorted.dedup();
            assert_eq!(sorted.len(), list.len(), "{name}: the list repeats a domain");
        }
    }
}
