# The Kotlin standard library is deliberately not packaged (see build.gradle).
-dontwarn kotlin.**
# Reached from native code and from page scripts by name.
-keep class app.fable.browser.Core { *; }
-keepclassmembers class * { @android.webkit.JavascriptInterface <methods>; }
