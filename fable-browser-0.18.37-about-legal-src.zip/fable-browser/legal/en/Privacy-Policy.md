# Fable Browser Privacy Policy

Version: V1.2
Effective Date: November 25, 2026

Licensor: Fable browser team
Contact Email: [fable-browser-team@astermail.org](mailto:fable-browser-team@astermail.org)

---

## 1. Our Core Commitments

Fable Browser is a lightweight browser. We make the following commitments and honestly inform you of the verifiable boundaries:

- **No Accounts**: This software does not require registration or login, and has no account system.
- **No Servers**: We do not operate any servers to receive your data; we have no way to collect, receive, or store your personal data.
- **No Telemetry**: This software does not include usage statistics, crash reporting, advertising analysis, or any form of data transmission.
- **Data Stays Local**: Your browsing history, bookmarks, settings, and other data are saved on your own device.

## 2. Network Requests That May Occur

The following requests are all sent directly from your device to the third-party websites listed below. We do not handle, relay, or store them. These are all types of network requests for this software:

**2.1 Public IP Query**: When you open the "Metadata" page or refresh it, the device sends a request to Cloudflare's IP query service (==https://www.cloudflare.com/cdn-cgi/trace==) to obtain the public IP. If it fails, it sends a request to api.ipify.org. This request does not carry browser cookies and has a timeout of 6 seconds (consistent across Android, iOS, macOS, Windows, Sailfish). If you do not open this page, this request will not occur.

**2.2 Web Browsing**: Requests for each website you visit are sent directly from your device to that website. How the website handles your data is subject to its own privacy policy.

**2.3 Search Requests**: When you search in the address bar or new tab, the search request is sent to the search engine you selected in settings (built-in options include DuckDuckGo, Bing, Google, Baidu, Sogou, as well as other options and custom templates provided in some language versions).

**2.4 Site Icons**: If the website corresponding to the new tab shortcut has not been visited yet, the device will request its site icon (apple-touch-icon.png, favicon.ico, or the icon declared on the page) from the website to display the shortcut icon.

**2.5 Blocklist Updates**: Ad blocking uses the built-in domain list distributed with the app, and tracking blocking uses the built-in tracking domain list. When the "Block Ads" switch is on, the app checks for list updates upon startup. If it has been more than a week since the last successful update, it pulls new lists from the built-in community list sources (EasyList and EasyPrivacy provided by easylist.to) in the background. This traffic does not occur when the switch is off. This request does not carry browser cookies or cache information, has a timeout of 10 seconds, and reads up to 8 MiB per source.

Except for the above five categories, and traffic that the operating system and system web engine itself may initiate (such as engine updates, safe browsing checks, etc., which the Licensor does not control), this software does not issue other application-layer network requests. QR code scanning and recognition are completed entirely offline on the device and do not issue any requests.

## 3. Use of Device Permissions

**Camera**: Used only for the scanning function; the system will only ask for camera permission when you tap the scan button for the first time.

**Network State and Wi-Fi State**: These two permissions are automatically granted by the system after installation on some platforms (such as Android). Network state is used to determine the current connection type (Wi-Fi / Cellular / Ethernet / VPN), etc.; the "Metadata" page displays local information such as Wi-Fi switch, frequency band, signal, and negotiation rate, but does not read or display the Wi-Fi name (SSID).

**Storage**: Used to save files you actively download, import and export bookmarks, etc.

The above permissions are not used to collect or upload data.

## 4. Information We Explicitly Do Not Read

This software does not read or request the following information: device IMEI, device serial number, MAC address, Widevine device ID, Wi-Fi name (SSID), location information. Network and Wi-Fi state permissions that may be automatically granted by the system will not be used to read the SSID.

## 5. Display of Device Information ("Metadata" Function)

This software has a "Metadata" function that aggregates and displays device and environment information readable from the device (such as resolution, refresh rate, CPU, memory, storage, battery, sensors, codecs, network interfaces, kernel version, etc.) to help you understand what information on your device can be read. This information is only displayed on your screen and you can copy it; except for the requests listed in Article 2 of this policy, this information will not be sent to us or any third party.

## 6. Locally Stored Data and Clearing Methods

**Locally Stored Data**: Browsing history, bookmarks, settings, download history, tab snapshots upon exit, site icon cache, blocklist files.

**Storage Location**: Linux in ==~/.local/share/fable/== (following XDG_DATA_HOME); Windows in ==%LOCALAPPDATA%\Fable\==; macOS in ==~/Library/Application Support/Fable/==; Android, HarmonyOS, iOS use the app's private data directory.

**Clearing Methods**: Use functions such as "Clear Browsing Data" in settings; uninstalling the mobile app deletes its private directory data. Incognito tabs and incognito windows do not write history locally.

## 7. Truthful Explanation of Incognito Mode

Incognito tabs or incognito windows do not save browsing history, site icons, cookies, and website data; downloaded files are retained. But this is not equivalent to anonymity: the websites you visit, your employer or school, and your internet service provider may still see your activity. When older system engines on some platforms cannot isolate cookies, the app will truthfully prompt on the interface that incognito tabs and regular tabs share cookies.

## 8. Minors

This software does not collect any data, so it does not involve the collection of children's data. Minors should use this software with the consent and accompaniment of their guardians.

## 9. Data Security

Since this software does not have servers and does not upload data, there is no data breach surface targeting us. The security of the data stored on your device depends on the condition of your device itself (such as lock screen, encryption status). It is recommended that you keep your device system updated and enable the device lock.

## 10. Policy Changes

This policy is released with software version updates; the changed policy indicates the new version number and effective date, and is publicized on the official release channel ([https://github.com/Fable-browser/Fable-browser](https://github.com/Fable-browser/Fable-browser)).

## 11. Contact Us

For any questions about this policy or data processing, please contact: [fable-browser-team@astermail.org](mailto:fable-browser-team@astermail.org).
