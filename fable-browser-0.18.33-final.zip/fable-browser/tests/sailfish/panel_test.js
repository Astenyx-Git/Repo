// The browser half of tests/sailfish_test.sh: the panel page exactly as the
// Sailfish bridge builds it (stand-in for the message handler first), driven
// with the scripts QML runs (SAILFISH.drain; SAILFISH.run, a Fable.reply from
// the core wrapped by runScript), both written by tests/sailfish/bridge_test.cpp.
// Headless Chrome stands in for Gecko, and enforces the page's CSP as Gecko would.
(function () {
  var log = [];
  function check(name, ok) { log.push((ok ? 'ok   ' : 'FAIL ') + name); }
  function drain() { return JSON.parse(eval(SAILFISH.drain)); }
  function queued() { return document.documentElement.getAttribute('data-fable-queue'); }
  check('the stand-in ran before the panel: messages, and the phone\'s bottom sheet',
        !!(window.webkit && window.webkit.messageHandlers.fableui) && !document.documentElement.classList.contains('desk'));
  var state = { tabs: [{ id: 1, title: 'Jolla', url: 'https://jolla.com/', active: true }], url: 'https://jolla.com/', title: 'Jolla', web: true,
                active: 1, incognito: false, platform: 'sailfish', caps: { networkBlock: false, clearSiteData: false, find: false, bookmarks: true },
                settings: {}, version: '0.18.23' };
  drain();
  Fable.show('tabs', state);
  document.querySelector('#body [role=button]').click();
  check('an action is queued in <html data-fable-queue> as a\\tname\\targ, and draining empties it',
        drain().indexOf('a\tswitchTab\t1') >= 0 && queued() === null);
  Fable.show('history', state);
  var asks = drain().filter(function (m) { var f = m.split('\t'); return f[0] === 'q' && f[2] === 'history'; });
  check('a question is queued as q\\tid\\tname\\targ', asks.length === 1);
  check('runScript sends the script as the detail of a fable-run event',
        SAILFISH.run === "document.dispatchEvent(new CustomEvent('fable-run',{detail:" + JSON.stringify(SAILFISH.reply).replace(/</g, '\\u003c').replace(/>/g, '\\u003e').replace(/\u2028/g, '\\u2028') + "}));");
  var reply = SAILFISH.reply.replace('424242', asks[0].split('\t')[1]);
  // From a timer: Chrome lets eval through while a DevTools evaluation (this script)
  // runs, so only outside it does the page's CSP decide, as it will on the device.
  setTimeout(function () {
    document.dispatchEvent(new CustomEvent('fable-run', { detail: reply }));
    console.log((document.getElementById('body').textContent.indexOf('Jolla \u2028</script>') >= 0 ? 'ok   ' : 'FAIL ')
                + 'the core\'s Fable.reply, run by the page from a fable-run event under its CSP, reaches the view that asked');
  }, 50);
  return log.join('\n');
})();
