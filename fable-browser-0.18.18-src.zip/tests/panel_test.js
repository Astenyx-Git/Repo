(function () {
  var log = [];
  function q(sel) { return document.querySelector(sel); }
  function rows() { return [].slice.call(document.querySelectorAll('#body .row')); }
  function rowByText(t) { return rows().filter(function (r) { return r.textContent.indexOf(t) >= 0; })[0]; }
  function title() { return q('#title').textContent; }
  function check(name, ok) { log.push((ok ? 'ok   ' : 'FAIL ') + name); }
  var acts = [];
  var SAMPLE = window.__fableSampleSystem;
  function bridge_get(k) { var rowsNow = null; Fable.show('language', null); var on = [].slice.call(document.querySelectorAll('#body .row')).filter(function (r) { return r.querySelector('.radio.on'); })[0]; Fable.show('settings', null); return on && on.textContent === '日本語' ? 'ja' : ''; }
  // The preview bridge is in-page; record what the shell would be asked to do.
  var realLog = console.log; console.log = function (a, name, arg) { if (a === 'act') acts.push(name + ':' + arg); };

  Fable.show('settings', { tabs: [], url: 'https://example.com/x', title: 'Example', web: true, active: 1, desktop: false, blocked: 7, version: '0.2.0' });
  check('settings title', title() === '设置');
  check('language row shows the default', rowByText('语言').textContent.indexOf('跟随系统') >= 0);
  rowByText('语言').click();
  check('language list names each language in itself', title() === '语言' && rows().length === 10 && !!rowByText('繁體中文') && !!rowByText('日本語') && !!rowByText('English') && !!rowByText('한국어') && !!rowByText('Русский') && !!rowByText('Français') && !!rowByText('Español') && !!rowByText('العربية'));
  rowByText('日本語').click();
  check('choosing a language stores it', bridge_get('language') === 'ja');
  q('#back').click();
  check('default engine shown', rowByText('搜索引擎').textContent.indexOf('DuckDuckGo') >= 0);
  check('settings rows carry no explanatory captions', document.querySelectorAll('#body .row small').length === 0);

  // Display: text size with a live sample, orientation, keep screen on, status bar (phones).
  check('the Home button switch, off by default', !!rowByText('显示主页按钮') && !rowByText('显示主页按钮').querySelector('.switch.on'));
  check('the address bar can go to the top (Android), off by default: it stays at the bottom', !!rowByText('地址栏置于顶部') && !rowByText('地址栏置于顶部').querySelector('.switch.on'));
  check('display section on a phone', !!rowByText('文字大小') && rowByText('文字大小').textContent.indexOf('100%') >= 0 && !!rowByText('屏幕方向') && !!rowByText('屏幕常亮') && !!rowByText('隐藏状态栏'));
  rowByText('文字大小').click();
  var sample = q('#body .sample');
  var slider = q('#body input[type=range]');
  check('text size: a slider from 50% to 300% and a sample at 16 px',
        title() === '文字大小' && !!slider && slider.min === '50' && slider.max === '300' && sample && sample.style.fontSize === '16px');
  var tick100 = [].slice.call(document.querySelectorAll('#body .slider-ticks span')).filter(function (t) { return t.textContent === '100%'; })[0];
  check('the 100% label sits under 100% on the track (a fifth of the way), not a third', !!tick100 && tick100.style.left === '20%');
  var ticks = [].slice.call(document.querySelectorAll('#body .slider-ticks span')).map(function (t) { return t.textContent + '@' + t.style.left; });
  check('a tick label every 50% (50% to 300%)', ticks.join() === '50%@0%,100%@20%,150%@40%,200%@60%,250%@80%,300%@100%');
  slider.value = '150';
  slider.dispatchEvent(new Event('input', { bubbles: true }));
  check('moving the slider redraws the sample at that size',
        q('#body .sample').style.fontSize === '24px' && q('#body .slider-val').textContent === '150%');
  slider.dispatchEvent(new Event('change', { bubbles: true }));
  q('#back').click();
  check('the row shows the chosen size', rowByText('文字大小').textContent.indexOf('150%') >= 0);
  rowByText('屏幕方向').click();
  check('orientation: three choices, following the system first', rows().length === 3 && !!rows()[0].querySelector('.radio.on') && !!rowByText('竖屏') && !!rowByText('横屏'));
  rowByText('横屏').click();
  q('#back').click();
  check('the row shows the chosen orientation', rowByText('屏幕方向').textContent.indexOf('横屏') >= 0);

  var sw = rowByText('拦截追踪器'); sw.click();
  check('switch turns off', sw.querySelector('.switch').className === 'switch' && sw.querySelector('.switch').getAttribute('aria-checked') === 'false');
  sw.click();
  check('switch turns on again', sw.querySelector('.switch').className === 'switch on');

  var ads = rowByText('拦截广告'), ext = rowByText('拦截外部应用跳转');
  check('ad blocking and app redirects are off by default',
        !!ads && !!ext && !ads.querySelector('.switch.on') && !ext.querySelector('.switch.on'));
  ads.click();
  check('ad blocking turns on', ads.querySelector('.switch').className === 'switch on');
  ext.click();
  check('blocking app redirects turns on', ext.querySelector('.switch').className === 'switch on');
  ads.click(); ext.click();
  check('both turn off again', !ads.querySelector('.switch.on') && !ext.querySelector('.switch.on'));

  rowByText('搜索引擎').click();
  check('search view', title() === '搜索引擎');
  rowByText('必应').click();
  check('bing selected', rowByText('必应').querySelector('.radio').className === 'radio on');
  check('Yandex, Naver and Seznam are offered', !!rowByText('Yandex') && !!rowByText('Naver') && !!rowByText('Seznam') && rows().length === 9);
  q('#back').click();
  check('back to settings shows new engine', title() === '设置' && rowByText('搜索引擎').textContent.indexOf('必应') >= 0);

  rowByText('浏览器标识').click();
  rowByText('自定义').click();
  var box = q('#body textarea');
  check('custom UA box appears', !!box);
  box.value = '  My UA\n 1.0 '; box.onchange();
  q('#back').click();
  check('UA label', rowByText('浏览器标识').textContent.indexOf('自定义') >= 0);

  rowByText('主页快捷方式').click();
  check('eight default shortcuts', document.querySelectorAll('#body .edit').length === 8);
  [].slice.call(document.querySelectorAll('#body .btn')).filter(function (b) { return b.textContent.indexOf('添加') >= 0; })[0].click();
  var edits = document.querySelectorAll('#body .edit'), last = edits[edits.length - 1].querySelectorAll('input');
  last[0].value = '<b>测试</b>'; last[0].oninput(); last[1].value = 'example.org/path'; last[1].oninput();
  edits[0].querySelector('[aria-label="删除"]').click();
  [].slice.call(document.querySelectorAll('#body .btn')).filter(function (b) { return b.textContent === '保存'; })[0].click();
  check('saved and back', title() === '设置' && rowByText('主页快捷方式').textContent.indexOf('8 个') >= 0);

  rowByText('清除浏览数据').click();
  rowByText('缓存').click();
  [].slice.call(document.querySelectorAll('#body .btn'))[0].click();
  check('clearing data that includes history asks first', title() === '确认删除' && acts.indexOf('clear:history,cookies') < 0);
  [].slice.call(document.querySelectorAll('#body .btn')).filter(function (b) { return b.textContent === '清除所选数据'; })[0].click();
  check('confirming asks the shell for history and cookies only', acts.indexOf('clear:history,cookies') >= 0);
  rowByText('清除浏览数据').click();
  rowByText('历史记录').click();
  [].slice.call(document.querySelectorAll('#body .btn'))[0].click();
  check('clearing without history does not ask', title() === '设置' && acts.indexOf('clear:cookies,cache') >= 0);

  Fable.show('history', null);
  check('history lists four visits in three day groups', rows().length === 4 && document.querySelectorAll('#body .day').length === 3);
  var input = q('#body input'); input.value = 'github'; input.oninput();
  check('history search', rows().length === 1 && rows()[0].textContent.indexOf('GitHub') >= 0);
  check('a stored site icon is shown as an image', !!rows()[0].querySelector('.fav img') && /^data:image\//.test(rows()[0].querySelector('.fav img').src));
  input.value = 'claude'; input.oninput();
  check('no stored icon: a globe, never a letter', !rows()[0].querySelector('.fav img') && !!rows()[0].querySelector('.fav svg') && rows()[0].querySelector('.fav').textContent === '');
  rows()[0].querySelector('[aria-label="删除这条记录"]').click();
  check('deleting one visit asks first and names it', title() === '确认删除' && q('#body').textContent.indexOf('Claude') >= 0);
  [].slice.call(document.querySelectorAll('#body .btn')).filter(function (b) { return b.textContent === '取消'; })[0].click();
  check('cancelling the delete keeps the visit and the search', title() === '历史记录' && rows().length === 1 && rows()[0].textContent.indexOf('Claude') >= 0);
  input = q('#body input'); input.value = ''; input.oninput();
  rows()[1].querySelector('[aria-label="删除这条记录"]').click();
  [].slice.call(document.querySelectorAll('#body .btn')).filter(function (b) { return b.textContent === '删除'; })[0].click();
  check('confirming the delete goes back to history', title() === '历史记录' && rows().length === 4);
  [].slice.call(document.querySelectorAll('#body .btn.ghost')).filter(function (b) { return b.textContent.indexOf('清空全部历史记录') >= 0; })[0].click();
  check('clearing all history asks first', title() === '确认删除' && q('#body').textContent.indexOf('清空全部历史记录吗') >= 0);
  [].slice.call(document.querySelectorAll('#body .btn')).filter(function (b) { return b.textContent === '删除'; })[0].click();
  check('confirming the clear-all goes back to history', title() === '历史记录');
  input = q('#body input'); input.value = 'github'; input.oninput();
  rows()[0].click();
  check('opening a visit', acts.indexOf('open:https://github.com/') >= 0);

  // Tab switcher: a normal side and a private side, as in Chrome.
  var mixed = [{ id: 5, title: '<img src=x onerror=alert(1)>', url: 'https://a.example/', active: true, icon: 'data:image/png;base64,iVBORw0KGgo=' },
               { id: 6, title: '', url: '', private: true, icon: 'https://evil.example/track.png' },
               { id: 7, title: 'Secret', url: 'https://secret.example/', private: true }];
  function tabsNow() { return [].slice.call(document.querySelectorAll('#body .tab')); }
  function sides() { return [].slice.call(document.querySelectorAll('#mode button')); }
  Fable.show('tabs', { tabs: mixed, active: 5, incognito: false });
  var tabs = tabsNow();
  check('normal mode opens on the normal side, light, with only normal tabs', title() === '标签页' && document.documentElement.className === '' && tabs.length === 1);
  check('markup in titles stays text, data URI icons only', tabs[0].textContent.indexOf('<img') >= 0 && document.querySelectorAll('#body .tab .fav img').length === 1);
  check('the toggle counts each side', q('#mode').className === 'seg show' && sides().length === 2 && sides()[0].className === 'on' && sides()[0].textContent === '1' && sides()[1].textContent === '2');
  check('the normal side offers a normal tab only', document.querySelectorAll('#body .btn').length === 1 && !q('#body .btn.ghost'));
  tabs[0].click();
  check('tapping a tab switches', acts.indexOf('switchTab:5') >= 0);
  sides()[1].click();
  tabs = tabsNow();
  check('the private side is dark, titled private mode, with the private tabs', document.documentElement.className === 'incog' && title() === '无痕模式' && tabs.length === 2 && sides()[1].className === 'on');
  check('a private tab with a web icon URL gets a glyph', !tabs[0].querySelector('.fav img') && !!tabs[0].querySelector('.fav svg'));
  tabs[0].querySelector('.icon-btn').click();
  check('close button closes without switching', acts.indexOf('closeTab:6') >= 0 && acts.indexOf('switchTab:6') < 0);
  var buttons = document.querySelectorAll('#body .btn');
  check('the private side offers a new private tab and close all', buttons.length === 2 && buttons[0].textContent === '新建无痕标签页' && buttons[1].textContent === '全部关闭');
  buttons[1].click();
  check('close all asks the shell to leave private mode', acts.indexOf('exitPrivate:') >= 0);
  Fable.update({ tabs: [mixed[0]], active: 5, incognito: false });
  check('with the last private tab gone the switcher turns to the normal side', title() === '标签页' && document.documentElement.className === '' && tabsNow().length === 1);
  Fable.show('tabs', { tabs: mixed.map(function (t) { return { id: t.id, title: t.title, url: t.url, private: t.private, active: t.id === 7 }; }), active: 7, incognito: true });
  check('private mode opens on the private side', document.documentElement.className === 'incog' && sides()[1].className === 'on' && q('#body .tab.active').textContent.indexOf('Secret') >= 0);
  Fable.show('tabs', { tabs: [mixed[0]], active: 5, incognito: false });
  sides()[1].click();
  check('an empty private side explains private mode and offers a tab', !!q('#body .incog-empty') && tabsNow().length === 0 && sides()[1].textContent === '0');
  q('#body .btn').click();
  check('which opens a private tab', acts.indexOf('newPrivate:') >= 0);

  Fable.show('menu', { tabs: [], url: 'https://example.com/x', title: 'Example', web: true, active: 1, desktop: true, blocked: 7, version: '0.2.0' });
  var tiles = [].slice.call(document.querySelectorAll('#body .tile'));
  check('menu has nine tiles (downloads; bookmarks only where the shell has them), desktop one lit', tiles.length === 9 && tiles[5].className.indexOf('on') >= 0);
  check('no badge without resources', !tiles[6].querySelector('.badge'));
  check('summary shows the count', q('#body .summary').textContent.indexOf('7') >= 0);
  tiles[7].click();
  check('add to home tells the shell', acts.indexOf('toast:已添加到主页') >= 0);

  // The menu in each mode.
  acts.length = 0;
  Fable.show('menu', { tabs: mixed, url: 'https://a.example/', title: 'A', web: true, active: 5, incognito: false, blocked: 0, version: '0.8.0' });
  tiles = [].slice.call(document.querySelectorAll('#body .tile'));
  check('normal menu: light, enter private mode with a count of private tabs', document.documentElement.className === '' && tiles[1].textContent === '2无痕模式' && tiles[1].querySelector('.badge').textContent === '2');
  tiles[0].click(); tiles[1].click();
  check('new tab is a normal tab; the private tile enters private mode', acts.indexOf('newTab:') >= 0 && acts.indexOf('enterPrivate:') >= 0 && acts.indexOf('newPrivate:') < 0);
  acts.length = 0;
  Fable.show('menu', { tabs: mixed, url: 'https://secret.example/', title: 'Secret', web: false, active: 7, incognito: true, blocked: 0, version: '0.8.0' });
  tiles = [].slice.call(document.querySelectorAll('#body .tile'));
  check('private menu: dark, exit instead of enter, nothing added to the home page', document.documentElement.className === 'incog' && tiles[1].textContent === '退出无痕' && tiles.length === 7);
  tiles[0].click(); tiles[1].click();
  check('new tab stays private; exit closes the private tabs', acts.indexOf('newPrivate:') >= 0 && acts.indexOf('exitPrivate:') >= 0 && acts.indexOf('newTab:') < 0);
  Fable.show('settings', { tabs: mixed, active: 7, incognito: true, version: '0.8.0' });
  check('the sheet stays dark in private mode', document.documentElement.className === 'incog' && !!rowByText('允许无痕模式截图'));
  rowByText('允许无痕模式截图').click();
  check('screenshots switch is off by default and stores 1', rowByText('允许无痕模式截图').querySelector('.switch').className === 'switch on');

  // Bookmarks: the tree with a folder, search, new folder, removing, and the star in the menu.
  Fable.show('bookmarks', { tabs: [], url: 'https://example.com/x', title: 'Example', web: true, active: 1, desktop: true, version: '0.2.0' });
  check('bookmarks title', title() === '书签');
  function topRows() { return rows().filter(function (r) { return !r.closest('.fold'); }); }
  check('bookmarks listed, the folder collapsed', topRows().length === 2 && !!q('#body .fold') && !q('#body .fold').classList.contains('open'));
  q('#body .fold .head').click();
  check('the folder opens with its two bookmarks', q('#body .fold').classList.contains('open') && q('#body .fold').querySelectorAll('.items .row').length === 2);
  acts.length = 0;
  q('#body .fold .items .row').click();
  check('a bookmark opens in the tab in front', acts.indexOf('open:https://github.com/') >= 0);
  var bmInput = q('#body input[type=search]');
  bmInput.value = 'github'; bmInput.oninput();
  check('search keeps the folder chain of a match, opened', topRows().length === 0 && document.querySelectorAll('#body .fold .items .row').length === 1
        && q('#body .fold').classList.contains('open'));
  bmInput.value = ''; bmInput.oninput();
  acts.length = 0;
  [].slice.call(document.querySelectorAll('#body .btn')).filter(function (b) { return b.textContent.indexOf('新建文件夹') >= 0; })[0].click();
  var fi = q('#body .edit input');
  check('new folder opens an inline name field', !!fi);
  fi.value = 'News';
  q('#body .edit .side .icon-btn').click();
  check('saving the folder closes the field and lists it', !q('#body .edit') && !!rowByText('News'));
  rowByText('Dev').querySelector('.icon-btn').click();
  check('removing a folder removes its contents', !rowByText('GitHub') && !rowByText('Dev') && !!rowByText('News'));
  Fable.show('menu', { tabs: [], url: 'https://zh.wikipedia.org/wiki/土星', title: '土星', web: true, active: 1, desktop: true, blocked: 0, version: '0.2.0', bookmarked: 1, caps: { bookmarks: true } });
  tiles = [].slice.call(document.querySelectorAll('#body .tile'));
  check('the star tile is lit for a bookmarked page when the shell wired it up', tiles[tiles.length - 2].className.indexOf('on') >= 0 && tiles[tiles.length - 2].textContent.indexOf('取消收藏') >= 0);
  acts.length = 0;
  tiles[tiles.length - 2].click();
  check('the star asks the shell to toggle the bookmark', acts.indexOf('bookmarkToggle:') >= 0);
  check('the bookmarks tile opens the bookmarks view', tiles[tiles.length - 1].textContent === '书签');
  Fable.show('settings', { tabs: [], version: '0.2.0' });
  check('no restore-on-start switch where the shell does not restore tabs', !rowByText('启动时恢复上次标签页'));
  Fable.show('menu', { tabs: [], url: 'https://example.com/', title: 'Example', web: true, active: 1, version: '0.2.0' });
  check('no bookmarks tile where the shell has no bookmarks', [].slice.call(document.querySelectorAll('#body .tile')).every(function (x) { return x.textContent !== '书签'; }));
  Fable.show('settings', { tabs: [], version: '0.2.0', caps: { restoreTabs: true } });
  var rt = rowByText('启动时恢复上次标签页');
  check('restore-on-start switch is on by default', !!rt && !!rt.querySelector('.switch.on'));
  rt.click();
  check('the switch turns off', rt.querySelector('.switch').className === 'switch');
  Fable.show('settings', { tabs: [], version: '0.2.0', caps: { restoreTabs: true } });
  check('the choice is stored (off now)', !rowByText('启动时恢复上次标签页').querySelector('.switch.on'));
  rowByText('启动时恢复上次标签页').click();
  Fable.show('settings', { tabs: [], version: '0.2.0', caps: { restoreTabs: true } });
  check('and back on', !!rowByText('启动时恢复上次标签页').querySelector('.switch.on'));

  // Resource sniffing.
  Fable.show('menu', { tabs: [], url: 'https://example.com/x', title: 'Example', web: true, active: 1, desktop: false, blocked: 0, sniffed: 5, version: '0.3.0' });
  var sniffTile = document.querySelectorAll('#body .tile')[6];
  check('sniff tile shows the count', sniffTile.querySelector('.badge').textContent === '5');
  sniffTile.click();
  check('opening the sheet asks the shell to scan the page', title() === '资源嗅探' && acts.indexOf('sniffScan:') >= 0);
  check('five resources listed', rows().length === 5);
  check('file names are decoded, nameless ones fall back to the host', rows()[2].querySelector('b').textContent === '第12期.mp3' && rows()[4].querySelector('b').textContent === 'videoplayback');
  check('type tag and host', rows()[1].querySelector('small').textContent === 'M3U8 · cdn.example.com' && rows()[4].querySelector('small').textContent === 'VIDEO · r4.example.net');
  var chips = document.querySelectorAll('#body .chip');
  check('chips count each kind, streams under video', chips[0].textContent === '全部 5' && chips[1].textContent === '视频 3' && chips[2].textContent === '音频 1' && chips[3].textContent === '图片 1');
  chips[2].click();
  check('filtering', rows().length === 1 && document.querySelectorAll('#body .chip')[2].className.indexOf('on') >= 0);
  rows()[0].querySelector('[aria-label="下载"]').click();
  rows()[0].querySelector('[aria-label="复制链接"]').click();
  check('download and copy go to the shell without opening the resource',
        acts.indexOf('download:https://cdn.example.com/podcast/%E7%AC%AC12%E6%9C%9F.mp3') >= 0 && acts.indexOf('copy:https://cdn.example.com/podcast/%E7%AC%AC12%E6%9C%9F.mp3') >= 0 && acts.join().indexOf('openNew') < 0);
  rows()[0].click();
  check('tapping a row opens it in a new tab', acts.indexOf('openNew:https://cdn.example.com/podcast/%E7%AC%AC12%E6%9C%9F.mp3') >= 0);

  // Metadata: home page with sections, sub-pages, folded lists.
  Fable.show('settings', null);
  rowByText('元数据').click();
  check('metadata opens from settings', title() === '元数据');
  check('opening asks the shell for the IP and the system facts, once each', acts.filter(function (x) { return x === 'ip:'; }).length === 1 && acts.filter(function (x) { return x === 'system:'; }).length === 1);
  check('the IP card waits', !!q('#body .hero .ip.wait'));
  var cats = function () { return [].slice.call(document.querySelectorAll('#body .row.cat')); };
  check('brief by default: the switch says so', q('#mode').className === 'seg show' && q('#mode .on').textContent === '简略');
  var labelsNow = function () { return [].slice.call(document.querySelectorAll('#body .label')).map(function (l) { return l.textContent; }).join('|'); };
  check('brief is one page, laid out as in 0.5.0', cats().length === 0 && labelsNow() === '显示|硬件|浏览器|时间与地区|指纹');
  check('brief page: tiles, rows, the User-Agent card, three hashes', document.querySelectorAll('#body .stat').length === 6 && !!q('#body .code') &&
        document.querySelectorAll('#body .hash').length === 3 && !q('#body .fold'));
  q('#mode button:not(.on)').click();
  check('Detailed brings every section back', q('#mode .on').textContent === '详细' && cats().length === 12);
  check('twelve sections listed', cats().length === 12);
  check('sections needing system facts say they are loading', cats()[6].querySelector('small').textContent === '读取中' && cats()[6].querySelector('small').className === 'wait');
  check('page-visible sections are ready at once', cats()[9].querySelector('small').textContent.indexOf('UTC') >= 0 && /^[0-9a-f]{8}$/.test(cats()[11].querySelector('small').textContent));
  check('overview tiles come from the quick device query', document.querySelectorAll('#body .stat').length === 6 && q('#body .stat b').textContent === '1080×2400');
  Fable.system(SAMPLE);
  check('system facts fill the summaries in place', cats()[2].querySelector('small').textContent === 'Tensor G3 · 9 核' && cats()[5].querySelector('small').textContent === 'Widevine L1 · AV1 / HEVC / VP9 硬件');
  check('a redraw does not ask again', acts.filter(function (x) { return x === 'system:'; }).length === 1);
  Fable.ip({ ip: '2001:db8::7', loc: 'JP', colo: 'NRT', http: 'http/2', tls: 'TLSv1.3', src: 'cloudflare.com' });
  check('the IP answer fills the card', q('#body .hero .ip').textContent === '2001:db8::7' && q('#body .hero').textContent.indexOf('日本 · JP') >= 0);

  cats()[2].click();
  check('a section opens as a sub-page with its own title', title() === '处理器与图形' && q('#back').style.display === '');
  function kvValue(label) { var r = [].slice.call(document.querySelectorAll('#body .kv')).filter(function (k) { return k.querySelector('.k').textContent === label; })[0]; return r && r.querySelector('.v').textContent; }
  check('rows from the system facts', kvValue('芯片') === 'Google Tensor G3' && kvValue('Vulkan') === '1.3.0' && kvValue('4 ×') === 'Cortex-A510 · 1.7 GHz');
  check('rows the page reads itself sit in the same section', !!kvValue('GPU'));
  var fold = q('#body .fold');
  check('long lists start folded, with a count', fold.className === 'fold' && fold.querySelector('.count').textContent === '47' && getComputedStyle(fold.querySelector('.items')).display === 'none');
  fold.querySelector('.head').click();
  check('and open on tap', fold.className === 'fold open' && getComputedStyle(fold.querySelector('.items')).display === 'block');
  q('#back').click();
  cats()[2].click();
  check('a list stays open when you come back', q('#body .fold').className === 'fold open');
  q('#body .fold .head').click();
  q('#back').click();

  cats()[6].click();
  check('cameras open by default, sensors folded', document.querySelectorAll('#body .fold')[0].className === 'fold open' && document.querySelectorAll('#body .fold')[1].className === 'fold');
  check('camera entries: facing, megapixels, tags', q('#body .item b').textContent === '后置 · 50 MP' && q('#body .item .tag.on').textContent === '闪光灯');
  q('#body .item').click();
  check('tapping an entry copies it', acts.filter(function (x) { return x.indexOf('copyText:后置 · 50 MP · 焦距 6.9 mm') === 0; }).length === 1);
  q('#back').click();

  cats()[4].click();
  check('battery: localized status, health, source, units', kvValue('状态') === '充电中' && kvValue('健康') === '良好' && kvValue('电源') === '充电器' && kvValue('剩余容量') === '3412 mAh');
  q('#back').click();
  cats()[7].click();
  check('system: ANDROID_ID as a chip, build fingerprint as a code card', /^[0-9a-f]{16}$/.test(q('#body .hash').textContent) && q('#body .code .text').textContent.indexOf('google/shiba') === 0);
  q('#body .btn.ghost').click();
  var page = acts.filter(function (x) { return x.indexOf('copyText:[系统]') === 0; })[0] || '';
  check('copy on a sub-page copies that section, folded lists included', page.indexOf('安全补丁: 2025-01-05') > 0 && page.indexOf('Linux version 6.1.99') > 0);
  q('#back').click();
  [].slice.call(document.querySelectorAll('#body .btn.ghost')).pop().click();
  var all = acts.filter(function (x) { return x.indexOf('copyText:[公网 IP]') === 0; })[0] || '';
  check('copy all: IP first, then every section', all.indexOf('2001:db8::7 · JP · NRT') > 0 && all.indexOf('[网络]') > 0 && all.indexOf('[指纹]') > 0 && all.indexOf('AV1 · 解码 硬件') > 0);

  q('#body .hero [aria-label="刷新"]').click();
  check('refresh asks again and shows the waiting state', !!q('#body .hero .ip.wait') && acts.filter(function (x) { return x === 'ip:'; }).length === 2);
  Fable.ip({});
  check('a failed lookup offers a retry', q('#body .hero').textContent.indexOf('无法获取') >= 0 && !!q('#body .hero .retry'));
  q('#body .hero .retry').click();
  check('retry asks again', acts.filter(function (x) { return x === 'ip:'; }).length === 3);
  Fable.show('settings', null);
  Fable.ip({ ip: '198.51.100.1' });
  rowByText('元数据').click();
  check('reopening refreshes the system facts but keeps the IP', q('#body .hero .ip').textContent === '198.51.100.1' && acts.filter(function (x) { return x === 'ip:'; }).length === 3 && acts.filter(function (x) { return x === 'system:'; }).length === 2);

  // Back to Brief.
  Fable.ip({ ip: '198.51.100.1', loc: 'SG', colo: 'SIN', http: 'http/3', tls: 'TLSv1.3', src: 'cloudflare.com' });
  cats()[7].click();
  check('detailed sub-page open', title() === '系统');
  q('#mode button:not(.on)').click();
  check('switching to Brief on a sub-page returns to the single brief page', title() === '元数据' && labelsNow() === '显示|硬件|浏览器|时间与地区|指纹');
  check('the IP card is the full 0.5.0 card in Brief too', document.querySelectorAll('#body .hero .pill').length === 5 && !!q('#body .hero .src'));
  check('brief rows come from the quick device query', kvValue('设备') === 'Google Pixel 8' && kvValue('存储空间') === '119 GB · 可用 39 GB');
  [].slice.call(document.querySelectorAll('#body .btn.ghost')).pop().click();
  var briefAll = acts.filter(function (x) { return x.indexOf('copyText:[公网 IP]') === 0; }).pop() || '';
  check('brief copy-all: what the page shows', briefAll.indexOf('[显示]') > 0 && briefAll.indexOf('User-Agent: Mozilla') > 0 && briefAll.indexOf('[指纹]') > 0 && briefAll.indexOf('[传感器与相机]') < 0);
  Fable.show('settings', null);
  check('the switch only appears on metadata pages', q('#mode').className === 'seg');
  rowByText('元数据').click();
  check('the choice is remembered', q('#mode .on').textContent === '简略' && cats().length === 0);

  // HarmonyOS uses this same bridge: a phone, so the desktop-site tile and every setting stay.
  Fable.show('menu', { tabs: [], url: 'https://example.com/', title: 'Example', web: true, active: 1, desktop: false, blocked: 0, version: '0.11.0', platform: 'harmony' });
  check('HarmonyOS menu offers desktop sites, as on Android', [].slice.call(document.querySelectorAll('#body .tile')).some(function (t) { return t.textContent.indexOf('桌面版') >= 0; }));
  Fable.show('settings', null);
  check('HarmonyOS settings keep every privacy switch', !!rowByText('第三方 Cookie') && !!rowByText('截图') && !!rowByText('图片'));
  Fable.show('settings', { tabs: [], url: '', title: '', web: false, active: 1, desktop: false, blocked: 0, version: '0.15.0', platform: 'harmony', caps: { addressBarTop: false } });
  check('HarmonyOS keeps its address bar at the bottom: no switch for the top, the other display rows stay', !rowByText('地址栏置于顶部') && !!rowByText('显示主页按钮') && !!rowByText('屏幕常亮'));

  // Android with Fable as the home app: new apps may go to All apps only; removed apps come back onto the home screen.
  check('no home-screen switch unless the shell says Fable is the home app', !rowByText('新应用添加到主屏幕') && !rowByText('主屏幕显示壁纸'));
  var homeState = { tabs: [], url: '', title: '', web: false, active: 1, desktop: false, blocked: 0, version: '0.17.0', platform: 'android', caps: { homeScreen: true },
                    settings: { home_hidden: '["a:com.b/.M"]', home_order: '["u:https://claude.ai/","a:com.a/.M"]' } };
  Fable.show('settings', homeState);
  var newApps = rowByText('新应用添加到主屏幕');
  check('with Fable as the home app: "Add new apps to Home", on by default', !!newApps && !!newApps.querySelector('.switch.on'));
  newApps.click();
  check('turned off, it is stored as 0', homeState.settings.home_new_apps === '0');
  var wall = rowByText('主屏幕显示壁纸');
  check('"Show wallpaper on Home", on by default, only with Fable as the home app', !!wall && !!wall.querySelector('.switch.on'));
  wall.click();
  check('turned off, it is stored as 0', homeState.settings.home_wallpaper === '0');
  Fable.show('settings', homeState);
  check('no System wallpaper row unless the shell offers it', !rowByText('系统壁纸'));
  homeState.wallpaper = { ground: false, kept: false, canKeep: false };
  Fable.show('settings', homeState);
  check('settings shows the wallpaper is the user\'s own', rowByText('系统壁纸').textContent.indexOf('自定义') >= 0);
  rowByText('系统壁纸').click();
  check('System wallpaper: Fable or Custom, no captions', title() === '系统壁纸' && rows().length === 2 && !!rowByText('Fable') && !!rowByText('自定义')
        && !!rowByText('自定义').querySelector('.radio.on') && document.querySelectorAll('#body .row small').length === 0);
  acts.length = 0;
  rowByText('Fable').click();
  check('choosing Fable asks the shell for it, and goes back', acts.join() === 'wallpaper:ground' && title() === '设置');
  homeState.wallpaper = { ground: true, kept: false, canKeep: false };
  Fable.show('settings', homeState);
  check('settings shows Fable', rowByText('系统壁纸').textContent.indexOf('Fable') >= 0);
  rowByText('系统壁纸').click();
  acts.length = 0;
  rowByText('自定义').click();
  check('Custom from Fable: the shell restores (or opens the picker)', acts.join() === 'wallpaper:restore');
  homeState.wallpaper = { ground: false, kept: false, canKeep: false };
  Fable.show('settings', homeState);
  rowByText('系统壁纸').click();
  acts.length = 0;
  rowByText('自定义').click();
  check('Custom again: the picker', acts.join() === 'wallpaper:pick');
  rowByText('快捷方式').click();
  rowByText('恢复移除的应用').click();
  check('restoring removed apps puts them back at the end of the home screen, also with new apps kept off it',
        homeState.settings.home_hidden === '[]' && homeState.settings.home_order === '["u:https://claude.ai/","a:com.a/.M","a:com.b/.M"]');
  console.log = realLog;
  return log.join('\n');
})();
