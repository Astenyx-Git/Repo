/*
 * QrScanner - the camera QR scanner for Sailfish OS.
 *
 * QtMultimedia opens the camera; the probe hands us its frames, and the
 * core's decoder reads the QR code in them. The QML page only shows the
 * viewfinder (VideoOutput on the camera below) and starts/stops this object;
 * a code read comes back on decoded, a camera problem on failed.
 *
 * The camera is the default one (the back camera). Frames come in at video
 * rate, so only one in a few is tried: a decode is tried at most every
 * 150 ms, and the scanner stops itself the moment a code reads. The
 * address bar's QR button is shown only where cameraAvailable is true
 * and the field is empty (0.18.31: the QR entry is the blank address bar).
 */
#ifndef QRSCANNER_H
#define QRSCANNER_H

#include <QElapsedTimer>
#include <QObject>

class QCamera;
class QVideoFrame;
class QVideoProbe;

class QrScanner : public QObject
{
    Q_OBJECT
    // The camera for the viewfinder: VideoOutput takes a media object.
    Q_PROPERTY(QObject *camera READ cameraObject CONSTANT)
    // Whether this device has a camera at all (read once, at startup).
    Q_PROPERTY(bool cameraAvailable READ cameraAvailable CONSTANT)

public:
    explicit QrScanner(QObject *parent = nullptr);
    ~QrScanner();

    QObject *cameraObject() const;
    bool cameraAvailable() const;

    // Open the camera and start reading frames; a no-op when already running.
    Q_INVOKABLE void start();
    // Stop reading and close the camera; a no-op when already stopped.
    Q_INVOKABLE void stop();

signals:
    // A QR code read: its text (a web address, Wi-Fi, plain text, ...).
    void decoded(const QString &text);
    // The camera could not be opened or failed while running.
    void failed();

private slots:
    void onFrameProbed(const QVideoFrame &frame);
    void onCameraError();

private:
    // The text in a frame, or empty when it holds no readable code.
    QString readFrame(const QVideoFrame &frame);

    QCamera *m_camera;
    QVideoProbe *m_probe;
    bool m_started;
    bool m_cameraAvailable;
    QElapsedTimer m_lastAttempt;
};

#endif // QRSCANNER_H
