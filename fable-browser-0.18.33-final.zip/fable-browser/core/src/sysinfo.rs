//! Facts about the machine for the metadata sheet on desktop shells (Linux,
//! macOS, Windows) and HarmonyOS, in the shape ui/panel.html reads from Android:
//! `device_json` for the brief page, `system_json` for the sections.
//!
//! Only what can be read without asking the user: no serial numbers, no MAC
//! addresses, no Wi-Fi names. A shell adds what only it can see (screen,
//! engine version, battery on macOS…) as `extras`, a JSON object whose keys
//! are appended to the result.

use crate::store::json_string;

#[derive(Default, Debug)]
pub struct Volume {
    pub name: String,
    pub fs: String,
    pub primary: bool,
    pub removable: bool,
}

#[derive(Default, Debug)]
pub struct Battery {
    pub level: Option<u32>,
    pub status: &'static str, // charging, discharging, full, not_charging
    pub plugged: &'static str, // ac, none
    pub tech: String,
    pub cycles: Option<u32>,
    pub voltage_mv: Option<u32>,
    pub temp_c: Option<f64>,
}

#[derive(Default, Debug)]
pub struct Network {
    pub offline: bool,
    pub transports: Vec<&'static str>, // wifi, ethernet, vpn
    pub iface: String,
    pub addresses: Vec<String>,
    pub dns: Vec<String>,
    pub mtu: Option<u32>,
    pub rssi: Option<i32>,
}

#[derive(Default, Debug)]
pub struct Facts {
    pub manufacturer: String,
    pub model: String,
    pub board: String,
    pub firmware: String, // BIOS / UEFI version
    pub hostname: String,
    pub os: String,       // "Ubuntu 24.04.1 LTS", "macOS 15.1 (24B83)", "Windows 11 Pro 23H2 (22631.4460)"
    pub build: String,
    pub kernel: String,
    pub kernel_full: String,
    pub arch: String,
    pub cpu_name: String,
    pub gpu: String,        // what the system says, not WebGL's masked string
    pub gpu_vendor: String,
    pub cores: u32,
    pub clusters: Vec<(u32, u32, String)>, // (count, max MHz, name)
    pub flags: String,
    pub mem_total: u64,
    pub mem_avail: u64,
    pub disk_total: u64,
    pub disk_free: u64,
    pub volumes: Vec<Volume>,
    pub battery: Option<Battery>,
    pub network: Option<Network>,
    pub uptime_ms: u64,
    pub locales: String,
}

/// A small JSON object writer that leaves out empty values.
struct Obj(String);

impl Obj {
    fn new() -> Self {
        Obj(String::from("{"))
    }
    fn key(&mut self, k: &str) {
        if self.0.len() > 1 {
            self.0.push(',');
        }
        self.0.push_str(&json_string(k));
        self.0.push(':');
    }
    fn str(&mut self, k: &str, v: &str) -> &mut Self {
        let v = v.trim();
        if !v.is_empty() {
            self.key(k);
            self.0.push_str(&json_string(v));
        }
        self
    }
    fn num(&mut self, k: &str, v: u64) -> &mut Self {
        if v > 0 {
            self.key(k);
            self.0.push_str(&v.to_string());
        }
        self
    }
    fn opt<T: ToString>(&mut self, k: &str, v: Option<T>) -> &mut Self {
        if let Some(v) = v {
            self.key(k);
            self.0.push_str(&v.to_string());
        }
        self
    }
    fn bool(&mut self, k: &str, v: bool) -> &mut Self {
        self.key(k);
        self.0.push_str(if v { "true" } else { "false" });
        self
    }
    fn raw(&mut self, k: &str, json: &str) -> &mut Self {
        self.key(k);
        self.0.push_str(json);
        self
    }
    fn strings(&mut self, k: &str, v: &[String]) -> &mut Self {
        if !v.is_empty() {
            let items: Vec<String> = v.iter().map(|s| json_string(s)).collect();
            self.raw(k, &format!("[{}]", items.join(",")));
        }
        self
    }
    /// Adds the keys of another JSON object (the shell's extras). A key the
    /// shell gives replaces the core's (an object is merged key by key), so
    /// the result has no duplicate keys, whichever JSON parser reads it.
    fn extras(&mut self, json: &str) -> &mut Self {
        let Some(extra) = entries(json) else { return self };
        if extra.is_empty() {
            return self;
        }
        let mut base = entries(&format!("{}}}", self.0)).unwrap_or_default();
        for (k, v) in extra {
            match base.iter_mut().find(|(bk, _)| *bk == k) {
                Some(slot) => {
                    slot.1 = match (entries(&slot.1), entries(&v)) {
                        (Some(_), Some(_)) => {
                            let mut inner = Obj::new();
                            inner.0 = slot.1[..slot.1.len() - 1].to_string();
                            inner.extras(&v).done()
                        }
                        _ => v,
                    }
                }
                None => base.push((k, v)),
            }
        }
        let body: Vec<String> = base.iter().map(|(k, v)| format!("{k}:{v}")).collect();
        self.0 = format!("{{{}", body.join(","));
        self
    }
    fn done(&mut self) -> String {
        let mut s = std::mem::take(&mut self.0);
        s.push('}');
        s
    }
}

/// The top-level entries of a JSON object as (raw key with its quotes, raw
/// value), or None when `json` is not an object. Values are kept as written.
fn entries(json: &str) -> Option<Vec<(String, String)>> {
    let t = json.trim();
    if !(t.starts_with('{') && t.ends_with('}')) {
        return None;
    }
    let b = t.as_bytes();
    let mut out = Vec::new();
    let mut i = 1;
    let skip_ws = |i: &mut usize| while *i < b.len() && (b[*i] as char).is_ascii_whitespace() { *i += 1 };
    // End of the JSON string starting at b[i] == '"' (index after the closing quote).
    let string_end = |mut i: usize| -> Option<usize> {
        i += 1;
        while i < b.len() {
            match b[i] {
                b'\\' => i += 2,
                b'"' => return Some(i + 1),
                _ => i += 1,
            }
        }
        None
    };
    loop {
        skip_ws(&mut i);
        if i >= b.len() - 1 {
            return Some(out);
        }
        if b[i] != b'"' {
            return None;
        }
        let ke = string_end(i)?;
        let key = t[i..ke].to_string();
        i = ke;
        skip_ws(&mut i);
        if b.get(i) != Some(&b':') {
            return None;
        }
        i += 1;
        skip_ws(&mut i);
        let vs = i;
        let mut depth = 0i32;
        while i < b.len() - 1 || depth > 0 {
            match b[i] {
                b'"' => {
                    i = string_end(i)?;
                    continue;
                }
                b'{' | b'[' => depth += 1,
                b'}' | b']' => depth -= 1,
                b',' if depth == 0 => break,
                _ => {}
            }
            if depth < 0 {
                return None;
            }
            i += 1;
        }
        let value = t[vs..i].trim_end().to_string();
        if value.is_empty() {
            return None;
        }
        out.push((key, value));
        if b.get(i) == Some(&b',') {
            i += 1;
        }
    }
}

fn now_ms() -> u64 {
    std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_millis() as u64).unwrap_or(0)
}

/// The brief page's facts.
pub fn device_json(facts: &Facts, extras: &str) -> String {
    let mut o = Obj::new();
    o.str("manufacturer", &facts.manufacturer)
        .str("model", &facts.model)
        .str("os", &facts.os)
        .str("abi", &facts.arch)
        .str("kernel", &facts.kernel)
        .num("cores", facts.cores as u64)
        .str("gpu", &facts.gpu)
        .str("gpuVendor", &facts.gpu_vendor)
        .num("ram", facts.mem_total)
        .num("storageTotal", facts.disk_total)
        .num("storageFree", facts.disk_free);
    if let Some(b) = &facts.battery {
        o.opt("battery", b.level).bool("charging", b.status == "charging");
    }
    o.extras(extras).done()
}

/// The sections' facts.
pub fn system_json(facts: &Facts, extras: &str) -> String {
    let mut system = Obj::new();
    system
        .str("manufacturer", &facts.manufacturer)
        .str("brand", &facts.manufacturer)
        .str("model", &facts.model)
        .str("deviceName", &facts.hostname)
        .str("board", &facts.board)
        .str("bootloader", &facts.firmware)
        .str("os", &facts.os)
        .str("build", &facts.build)
        .str("kernel", &facts.kernel)
        .str("kernelFull", &facts.kernel_full)
        .str("locales", &facts.locales)
        .num("uptime", facts.uptime_ms);
    if facts.uptime_ms > 0 {
        system.num("bootTime", now_ms().saturating_sub(facts.uptime_ms));
    }

    let mut cpu = Obj::new();
    cpu.num("cores", facts.cores as u64).str("hardware", &facts.cpu_name).str("flags", &facts.flags);
    if !facts.arch.is_empty() {
        cpu.strings("abis", &[facts.arch.clone()]);
    }
    if !facts.clusters.is_empty() {
        let list: Vec<String> = facts
            .clusters
            .iter()
            .map(|(count, mhz, name)| Obj::new().num("count", *count as u64).num("mhz", *mhz as u64).str("name", name).done())
            .collect();
        cpu.raw("clusters", &format!("[{}]", list.join(",")));
    }

    let mut memory = Obj::new();
    memory.num("total", facts.mem_total).num("avail", facts.mem_avail);

    let mut storage = Obj::new();
    storage.num("total", facts.disk_total).num("free", facts.disk_free);
    if !facts.volumes.is_empty() {
        let list: Vec<String> = facts
            .volumes
            .iter()
            .map(|v| Obj::new().str("name", &v.name).str("state", &v.fs).bool("primary", v.primary).bool("removable", v.removable).done())
            .collect();
        storage.raw("volumes", &format!("[{}]", list.join(",")));
    }

    let mut out = Obj::new();
    out.raw("system", &system.done()).raw("cpu", &cpu.done()).raw("memory", &memory.done()).raw("storage", &storage.done());

    if let Some(b) = &facts.battery {
        let mut battery = Obj::new();
        battery
            .opt("level", b.level)
            .str("status", b.status)
            .str("plugged", b.plugged)
            .str("tech", &b.tech)
            .opt("cycles", b.cycles)
            .opt("voltage", b.voltage_mv)
            .opt("temp", b.temp_c.map(|t| (t * 10.0).round() / 10.0));
        out.raw("battery", &battery.done());
    }

    if let Some(n) = &facts.network {
        let mut network = Obj::new();
        if n.offline {
            network.bool("offline", true);
        }
        let transports: Vec<String> = n.transports.iter().map(|t| t.to_string()).collect();
        network.strings("transports", &transports).str("iface", &n.iface).strings("addresses", &n.addresses).strings("dns", &n.dns).opt("mtu", n.mtu);
        out.raw("network", &network.done());
        if let Some(rssi) = n.rssi {
            out.raw("wifi", &Obj::new().opt("rssi", Some(rssi)).done());
        }
    }
    out.extras(extras).done()
}

/// Strings firmware vendors leave in place of a real value.
pub fn meaningful(s: &str) -> String {
    let t = s.trim().trim_matches('\0').trim();
    let junk = ["to be filled by o.e.m.", "default string", "system product name", "system manufacturer", "none", "not applicable",
                "not specified", "o.e.m.", "oem", "invalid", "unknown", "base board product name", "type1productconfigid", "0"];
    if junk.contains(&t.to_ascii_lowercase().as_str()) { String::new() } else { t.to_string() }
}

/// Facts for this machine. On platforms without a collector (Android) almost
/// everything is empty: the Android shell collects its own.
pub fn collect() -> Facts {
    let mut f = Facts { arch: std::env::consts::ARCH.to_string(), ..Default::default() };
    f.cores = std::thread::available_parallelism().map(|n| n.get() as u32).unwrap_or(0);
    platform::fill(&mut f);
    f
}

#[cfg(all(target_os = "linux", not(target_env = "ohos")))]
#[path = "sysinfo_linux.rs"]
mod platform;

#[cfg(all(target_os = "linux", target_env = "ohos"))]
#[path = "sysinfo_ohos.rs"]
mod platform;

#[cfg(target_os = "macos")]
#[path = "sysinfo_macos.rs"]
mod platform;

#[cfg(windows)]
#[path = "sysinfo_windows.rs"]
mod platform;

#[cfg(not(any(target_os = "linux", target_os = "macos", windows)))]
mod platform {
    pub fn fill(_f: &mut super::Facts) {}
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn json_leaves_out_what_is_unknown_and_takes_extras() {
        let f = Facts { manufacturer: "Framework".into(), model: "Laptop 13".into(), os: "Fedora Linux 41".into(), arch: "x86_64".into(),
                        mem_total: 16 << 30, cores: 12, clusters: vec![(4, 4800, String::new()), (8, 3600, String::new())],
                        battery: Some(Battery { level: Some(80), status: "charging", plugged: "ac", ..Default::default() }), ..Default::default() };
        let d = device_json(&f, r#"{"engine":"WebKitGTK 2.46.3","refresh":120}"#);
        assert_eq!(d, r#"{"manufacturer":"Framework","model":"Laptop 13","os":"Fedora Linux 41","abi":"x86_64","cores":12,"ram":17179869184,"battery":80,"charging":true,"engine":"WebKitGTK 2.46.3","refresh":120}"#);
        let s = system_json(&f, "");
        assert!(s.starts_with(r#"{"system":{"manufacturer":"Framework","brand":"Framework","model":"Laptop 13","os":"Fedora Linux 41"}"#), "{s}");
        assert!(s.contains(r#""cpu":{"cores":12,"abis":["x86_64"],"clusters":[{"count":4,"mhz":4800},{"count":8,"mhz":3600}]}"#), "{s}");
        assert!(s.contains(r#""battery":{"level":80,"status":"charging","plugged":"ac"}"#), "{s}");
        assert!(!s.contains("network"));
        assert_eq!(device_json(&Facts::default(), "{}"), "{}");
        // The shell's value wins without a second copy of the key; objects merge.
        assert_eq!(device_json(&f, r#"{"model":"iPhone15,2", "os" : "iOS 17.5"}"#),
                   r#"{"manufacturer":"Framework","model":"iPhone15,2","os":"iOS 17.5","abi":"x86_64","cores":12,"ram":17179869184,"battery":80,"charging":true}"#);
        let s = system_json(&f, r#"{"system":{"model":"a,\"b}"},"display":{"w":1179,"list":[1,{"x":2}]}}"#);
        assert!(s.starts_with(r#"{"system":{"manufacturer":"Framework","brand":"Framework","model":"a,\"b}","os":"Fedora Linux 41"}"#), "{s}");
        assert!(s.ends_with(r#""display":{"w":1179,"list":[1,{"x":2}]}}"#), "{s}");
        assert_eq!(s.matches("\"system\"").count(), 1);
        assert_eq!(device_json(&Facts::default(), "not json"), "{}");
    }

    #[test]
    fn junk_firmware_strings_are_dropped() {
        assert_eq!(meaningful("To Be Filled By O.E.M."), "");
        assert_eq!(meaningful(" ThinkPad X1 Carbon Gen 11\n"), "ThinkPad X1 Carbon Gen 11");
    }

    #[test]
    fn this_machine_reads_back_as_json() {
        let f = collect();
        let s = system_json(&f, "");
        assert!(s.starts_with("{\"system\":") && s.ends_with('}'));
        #[cfg(any(all(target_os = "linux", not(target_os = "android")), windows))]
        {
            assert!(!f.os.is_empty(), "os: {f:?}");
            assert!(f.mem_total > 0 && f.mem_avail > 0 && f.mem_avail <= f.mem_total, "memory: {f:?}");
            assert!(f.disk_total > 0 && f.disk_free <= f.disk_total, "disk: {f:?}");
            assert!(f.uptime_ms > 0, "uptime");
            assert!(!f.kernel.is_empty(), "kernel");
        }
        println!("{}", device_json(&f, ""));
        println!("{s}");
    }
}
