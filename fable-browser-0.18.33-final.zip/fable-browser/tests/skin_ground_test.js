// Run by tests/skin_ground_test.py on the new-tab page as the core serves it in one skin.
// The default Claude logo is the standard: only the planet, see-through all round it, so the page
// (or the wallpaper behind a launcher's home screen) shows exactly its own colour wherever the
// planet is not. Every skin's logo is held to the same:
//   * its outer edge is see-through all round, and at least half of it is (the default: two thirds);
//   * whatever is not see-through belongs to the drawing: within STRAY px of its solid part, so no
//     box, tile or speck of the artwork's ground is left;
// and tests/skin_ground_test.py compares screenshots with the logo shown and hidden: wherever the
// logo is see-through they must be the same to the last unit, on the page and over a wallpaper.
// window.SKIN_MODE: 'page' (the default) or 'wall'; window.SKIN_HIDE: the logo hidden.
(function () {
  var log = [], img = document.getElementById('icon'), root = document.documentElement;
  function check(name, ok, detail) { log.push((ok ? 'ok   ' : 'FAIL ') + name + (ok || !detail ? '' : ': ' + detail)); }
  if (window.SKIN_MODE === 'wall') {
    root.classList.add('wall', 'wall-light');
    root.style.background = 'linear-gradient(135deg, #2E6B4F, #C46A3A 50%, #3B4E8C)';
  }
  // The logo's drop shadow over a wallpaper is the page's own; the comparison is about the logo's pixels.
  var st = document.createElement('style');
  st.textContent = '#icon { filter: none !important; }' + (window.SKIN_HIDE ? ' #icon { visibility: hidden !important; }' : '');
  document.head.appendChild(st);

  var bg = getComputedStyle(document.body).backgroundColor.match(/\d+/g).map(Number);
  var hex = function (c) { return '#' + [c[0], c[1], c[2]].map(function (v) { return (v | 256).toString(16).slice(1); }).join('').toUpperCase(); };
  var w = img.naturalWidth, h = img.naturalHeight;
  check('the logo has loaded', img.complete && w > 0 && h > 0, w + 'x' + h);
  var c = document.createElement('canvas'); c.width = w; c.height = h;
  var g = c.getContext('2d'); g.drawImage(img, 0, 0);
  var px = g.getImageData(0, 0, w, h).data;
  function alpha(x, y) { return px[(y * w + x) * 4 + 3]; }

  var BAND = Math.round(w * 0.04), STRAY = Math.round(w * 0.04);
  var clear = 0, edge = 0, edgeAt = '';
  for (var y = 0; y < h; y++) for (var x = 0; x < w; x++) {
    if (alpha(x, y) === 0) clear++;
    else if (Math.min(x, y, w - 1 - x, h - 1 - y) < BAND) { edge++; if (!edgeAt) edgeAt = x + ',' + y + ' alpha ' + alpha(x, y); }
  }
  check('see-through all round its edge (' + BAND + ' px), like the default logo', edge === 0, edge + ' px are not, first ' + edgeAt);
  check('see-through over at least half of it', clear * 2 >= w * h, Math.round(100 * clear / (w * h)) + '%');
  // Distance (chessboard, in px) from the solid drawing, by two sweeps: nothing faint may lie far from it.
  var far = new Int32Array(w * h), BIG = 1 << 20;
  for (var i = 0; i < w * h; i++) far[i] = px[i * 4 + 3] >= 250 ? 0 : BIG;
  for (var pass = 0; pass < 2; pass++) {
    for (var n = 0; n < w * h; n++) {
      // forward: the neighbours above and to the left; backward: below and to the right
      var k = pass ? w * h - 1 - n : n, xx = k % w, yy = (k / w) | 0, s = pass ? -1 : 1;
      for (var dy = -1; dy <= 0; dy++) for (var dx = -1; dx <= 1; dx++) {
        if (dy === 0 && dx >= 0) continue;
        var nx = xx + s * dx, ny = yy + s * dy;
        if (nx >= 0 && nx < w && ny >= 0 && ny < h && far[ny * w + nx] + 1 < far[k]) far[k] = far[ny * w + nx] + 1;
      }
    }
  }
  var stray = 0, strayAt = '';
  for (i = 0; i < w * h; i++) if (px[i * 4 + 3] > 0 && far[i] > STRAY) { stray++; if (!strayAt) strayAt = (i % w) + ',' + ((i / w) | 0) + ' alpha ' + px[i * 4 + 3]; }
  check('nothing but the drawing: every visible pixel within ' + STRAY + ' px of its solid part', stray === 0, stray + ' px are not, first ' + strayAt);

  // A skin's logo is cut from its artwork (scripts/gen_themes.py: the artwork at 92% of the side, in
  // the middle): laid over the page's ground it must be the artwork again, but for the ground's grain.
  // Compared as 4x4 blocks, so an edge resampled a fraction of a pixel apart does not count; a part of
  // the drawing lost or a piece of ground kept (a ring cut short, a gap filled) does.
  var art = document.getElementById('skin-art');
  if (art) {
    // 16: the browser's resampling of the artwork is not the generator's (a sharp edge, up to 10 apart);
    // a lost or kept part of the drawing is 30 and more.
    var TOL = 16, side = Math.round(w * 0.92), off = (w - side) >> 1;
    function over(draw) {
      var cv = document.createElement('canvas'); cv.width = w; cv.height = h;
      var cx = cv.getContext('2d'); cx.imageSmoothingQuality = 'high';
      cx.fillStyle = hex(bg); cx.fillRect(0, 0, w, h); draw(cx);
      return cx.getImageData(0, 0, w, h).data;
    }
    var want = over(function (cx) { cx.drawImage(art, off, off, side, side); }), got = over(function (cx) { cx.drawImage(img, 0, 0); });
    var worst = 0, worstAt = '', bad = 0;
    for (var by = Math.ceil(off / 4); by < Math.floor((off + side) / 4); by++) for (var bx = Math.ceil(off / 4); bx < Math.floor((off + side) / 4); bx++) {
      var e = 0;
      for (var ch = 0; ch < 3; ch++) {
        var sw = 0, sg = 0;
        for (y = by * 4; y < by * 4 + 4; y++) for (x = bx * 4; x < bx * 4 + 4; x++) { sw += want[(y * w + x) * 4 + ch]; sg += got[(y * w + x) * 4 + ch]; }
        e = Math.max(e, Math.abs(sw - sg) / 16);
      }
      if (e > TOL) bad++;
      if (e > worst) { worst = e; worstAt = bx * 4 + ',' + by * 4; }
    }
    check('over its ground it is its artwork, 4x4 blocks within ' + TOL + ' (the worst ' + worst.toFixed(1) + ')', bad === 0, bad + ' blocks are not, the worst at ' + worstAt);
  }

  // Where the logo is see-through, with its neighbours (the screenshot's pixel grid may sit between
  // the image's): 1 bit per pixel, row by row, for the screenshot comparison.
  var bits = new Uint8Array(Math.ceil(w * h / 8)), open = 0;
  for (y = 0; y < h; y++) for (x = 0; x < w; x++) {
    var ok = true;
    for (dy = -1; dy <= 1 && ok; dy++) for (dx = -1; dx <= 1 && ok; dx++) {
      var ax = x + dx, ay = y + dy;
      if (ax >= 0 && ax < w && ay >= 0 && ay < h && alpha(ax, ay) !== 0) ok = false;
    }
    if (ok) { bits[(y * w + x) >> 3] |= 1 << ((y * w + x) & 7); open++; }
  }
  var bin = ''; for (i = 0; i < bits.length; i++) bin += String.fromCharCode(bits[i]);
  var r = img.getBoundingClientRect();
  return log.join('\n') + '\nrect ' + JSON.stringify({ x: r.left, y: r.top, w: r.width, h: r.height, dpr: devicePixelRatio, ground: hex(bg),
    nw: w, nh: h, clear: clear, open: open }) + '\nmask ' + btoa(bin);
})()
