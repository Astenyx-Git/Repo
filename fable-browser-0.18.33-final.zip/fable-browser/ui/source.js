// Run in the active page. Serialize top-level comments and the doctype as well as the root.
(function () {
  if (!document.documentElement) return null;
  var serializer = new XMLSerializer();
  return Array.prototype.map.call(document.childNodes, function (node) {
    return node.nodeType === 1 ? node.outerHTML : serializer.serializeToString(node);
  }).join('');
})()
