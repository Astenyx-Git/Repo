/*
 * QrScannerPage - the camera QR scanner: the viewfinder, a frame to aim at,
 * and a cancel button. The camera itself lives in C++ (QrScanner): this page
 * only shows it and starts/stops it. A code read comes back on scanned, a
 * camera problem on failed; both are handled where the page was opened from
 * (BrowserPage), which then shows the result the same way a picked image
 * does. QML JavaScript here is ES5: Sailfish OS ships Qt 5.6.
 */
import QtQuick 2.0
import Sailfish.Silica 1.0
import QtMultimedia 5.0
import harbour.fable.Core 1.0

Page {
    id: scannerPage
    allowedOrientations: Orientation.All

    signal scanned(string text)
    signal failed()

    property int frameSize: Math.min(width, height) * 0.7

    Component.onCompleted: QrScanner.start()
    Component.onDestruction: QrScanner.stop()

    Connections {
        target: QrScanner
        onDecoded: { scanned(text); pageStack.pop(); }
        onFailed: { failed(); pageStack.pop(); }
    }

    VideoOutput {
        anchors.fill: parent
        source: QrScanner.camera
        fillMode: VideoOutput.PreserveAspectCrop
    }

    // Dim everything outside the frame, so the eye goes to the middle.
    Rectangle {
        id: topShade
        anchors.top: parent.top
        anchors.left: parent.left
        anchors.right: parent.right
        height: (parent.height - frameSize) / 2
        color: "black"
        opacity: 0.5
    }
    Rectangle {
        id: bottomShade
        anchors.bottom: parent.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        height: (parent.height - frameSize) / 2
        color: "black"
        opacity: 0.5
    }
    Rectangle {
        anchors.top: topShade.bottom
        anchors.bottom: bottomShade.top
        anchors.left: parent.left
        width: (parent.width - frameSize) / 2
        color: "black"
        opacity: 0.5
    }
    Rectangle {
        anchors.top: topShade.bottom
        anchors.bottom: bottomShade.top
        anchors.right: parent.right
        width: (parent.width - frameSize) / 2
        color: "black"
        opacity: 0.5
    }

    Rectangle {
        width: frameSize
        height: frameSize
        anchors.centerIn: parent
        color: "transparent"
        border.width: 2
        border.color: "white"
    }

    Label {
        anchors.top: parent.top
        anchors.topMargin: Theme.paddingLarge
        anchors.horizontalCenter: parent.horizontalCenter
        text: Fable.tr("scan_title")
        color: "white"
    }

    Label {
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: cancel.top
        anchors.bottomMargin: Theme.paddingMedium
        text: Fable.tr("scan_hint")
        color: "white"
    }

    Button {
        id: cancel
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: parent.bottom
        anchors.bottomMargin: Theme.paddingLarge
        text: Fable.tr("cancel")
        onClicked: pageStack.pop()
    }
}
