// App and scene lifecycle: one window holding the browser.
import UIKit

@main
final class AppDelegate: UIResponder, UIApplicationDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Settings and history live in Application Support (not in Documents,
        // which the Files app shows: that folder is for downloads).
        let fm = FileManager.default
        if let support = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask).first {
            var dir = support.appendingPathComponent("Fable", isDirectory: true)
            #if targetEnvironment(simulator)
            if ProcessInfo.processInfo.environment["FABLE_SMOKE_PROFILE"] == "1" {
                dir = fm.temporaryDirectory.appendingPathComponent("fable-smoke", isDirectory: true)
            }
            #endif
            try? fm.createDirectory(at: dir, withIntermediateDirectories: true)
            fable_ad_list_file(dir.path, Bundle.main.path(forResource: "ads", ofType: "txt"))
            Core.openStore(dir.path)
        }
        Core.setSystemLocale(Locale.preferredLanguages.first ?? "en")
        Palette.load()   // the skin's colours (theme://name), before anything is drawn
        return true
    }
}

private final class LicenseViewController: UIViewController {
    var onAgree: (() -> Void)?

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        let heading = UILabel()
        heading.text = Core.tr("legal_title")
        heading.font = .preferredFont(forTextStyle: .title1)
        heading.accessibilityTraits = .header
        let terms = UITextView()
        terms.isEditable = false
        terms.font = .preferredFont(forTextStyle: .body)
        terms.adjustsFontForContentSizeCategory = true
        terms.text = Core.panelQuery("legalText", "", tab: 0)
        let agree = UIButton(type: .system)
        agree.setTitle(Core.tr("eula_agree"), for: .normal)
        agree.addTarget(self, action: #selector(accept), for: .touchUpInside)
        let stack = UIStackView(arrangedSubviews: [heading, terms, agree])
        stack.axis = .vertical
        stack.spacing = 12
        stack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stack)
        let guide = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            stack.topAnchor.constraint(equalTo: guide.topAnchor, constant: 12),
            stack.bottomAnchor.constraint(equalTo: guide.bottomAnchor, constant: -12),
            stack.leadingAnchor.constraint(equalTo: guide.leadingAnchor, constant: 16),
            stack.trailingAnchor.constraint(equalTo: guide.trailingAnchor, constant: -16),
            agree.heightAnchor.constraint(greaterThanOrEqualToConstant: 44)
        ])
    }

    @objc private func accept() { onAgree?() }
}

final class SceneDelegate: UIResponder, UIWindowSceneDelegate {
    var window: UIWindow?
    private var browser: BrowserViewController? { window?.rootViewController as? BrowserViewController }

    private var pendingURLs: [URL] = []

    private func open(_ url: URL) {
        if let browser = browser { browser.openExternal(url) }
        else { pendingURLs.append(url) }
    }

    private func startBrowser() {
        let controller = BrowserViewController()
        window?.rootViewController = controller
        controller.loadViewIfNeeded()
        for url in pendingURLs { controller.openExternal(url) }
        pendingURLs.removeAll()
    }

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let scene = scene as? UIWindowScene else { return }
        let window = UIWindow(windowScene: scene)
        self.window = window
        if Core.panelQuery("legalAccepted", "", tab: 0) == "true" {
            startBrowser()
        } else {
            let license = LicenseViewController()
            license.onAgree = { [weak self] in
                _ = Core.panelQuery("legalAccept", "", tab: 0)
                self?.startBrowser()
            }
            window.rootViewController = license
        }
        window.tintColor = Palette.spark
        window.makeKeyAndVisible()
        for context in connectionOptions.urlContexts { open(context.url) }
        if let url = connectionOptions.userActivities.first(where: { $0.activityType == NSUserActivityTypeBrowsingWeb })?.webpageURL {
            open(url)
        }
    }

    /// http(s) links handed to Fable (Shortcuts, "Open in", a share).
    func scene(_ scene: UIScene, openURLContexts URLContexts: Set<UIOpenURLContext>) {
        for context in URLContexts { open(context.url) }
    }

    func scene(_ scene: UIScene, continue userActivity: NSUserActivity) {
        if let url = userActivity.webpageURL { open(url) }
    }

    // Private tabs stay out of the app switcher's snapshot.
    func sceneWillResignActive(_ scene: UIScene) { browser?.coverForAppSwitcher() }
    func sceneDidBecomeActive(_ scene: UIScene) { browser?.uncover() }
    // The app may be ended while in the background: the open tabs come back on the next start.
    func sceneDidEnterBackground(_ scene: UIScene) { browser?.saveSession() }
}
