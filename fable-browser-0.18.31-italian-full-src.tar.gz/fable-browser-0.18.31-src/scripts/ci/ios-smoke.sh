#!/bin/sh
# Installs the Simulator build of the iOS app (scripts/build-ios.sh), launches it
# on an iPhone simulator, checks it stays up, and saves screenshots, page-load
# times and its log in build/ci. Used by codemagic.yaml; runs on any Mac with Xcode.
# Exits non-zero when anything that matters fails: the simulator does not boot,
# the app does not install, exits, panics, a screenshot cannot be taken or is
# empty, no page finishes loading (no page-load timing in the log), or any
# command fails unexpectedly (set -e, pipefail).
set -eu
if (set -o pipefail) 2>/dev/null; then set -o pipefail; fi   # macOS sh (bash) has it
cd "$(dirname "$0")/../.."
OUT=build/ci; mkdir -p "$OUT"
APP=build/ios/DerivedData/Build/Products/Debug-iphonesimulator/Fable.app
ID=app.fable.browser
[ -d "$APP" ] || { echo "no $APP: run scripts/build-ios.sh first" >&2; exit 1; }
# The newest iPhone simulator Xcode ships.
UDID=$(xcrun simctl list devices available -j | /usr/bin/python3 -c '
import json,sys
d=json.load(sys.stdin)["devices"]
ios=sorted((k for k in d if "iOS" in k), key=lambda k: [int(x) for x in k.rsplit("iOS-",1)[1].split("-")])
for k in reversed(ios):
    for dev in d[k]:
        if dev["name"].startswith("iPhone"): print(dev["udid"], dev["name"], k.rsplit(".",1)[1], file=sys.stderr); print(dev["udid"]); sys.exit()
') || UDID=""
[ -n "$UDID" ] || { echo "no iPhone simulator" >&2; xcrun simctl list devices > "$OUT/ios-devices.txt"; exit 1; }
xcrun simctl boot "$UDID" 2>/dev/null || true   # "already booted" is fine; bootstatus decides
xcrun simctl bootstatus "$UDID" -b || { echo "the simulator did not boot" >&2; exit 1; }
xcrun simctl install "$UDID" "$APP" || { echo "the app did not install" >&2; exit 1; }
START=$(date +%s)

alive() {   # (through a file: grep -q closing a pipe early would fail it under pipefail)
    xcrun simctl spawn "$UDID" launchctl list > "$OUT/.launchctl.txt" 2>/dev/null || return 1
    grep -q "UIKitApplication:$ID" "$OUT/.launchctl.txt"
}
shot() {
    xcrun simctl io "$UDID" screenshot "$OUT/ios-$1.png" >/dev/null 2>&1 && [ -s "$OUT/ios-$1.png" ] \
        || { echo "screenshot $1 failed" >&2; exit 1; }
    echo "screenshot: ios-$1.png"
}
launch() {   # $1: name for the console file, then launch arguments
    name=$1; shift
    xcrun simctl terminate "$UDID" $ID 2>/dev/null || true
    xcrun simctl launch --console-pty "$UDID" $ID "$@" > "$OUT/ios-console-$name.txt" 2>&1 &
}
check() {
    alive && return
    echo "Fable is not running ($1)" >&2
    cat "$OUT"/ios-console-*.txt >&2 || true
    xcrun simctl spawn "$UDID" log show --last 5m --predicate 'process == "Fable"' > "$OUT/ios-log.txt" 2>&1 || true
    exit 1
}

# 1. First launch: the new-tab page, early and settled (a cold simulator is slow).
launch first
sleep 6;  check "first launch"; shot first-6s
sleep 20; check "first launch, later"; shot first-26s
# 2. The same in dark mode (bars keep Fable's colours; the page follows the system).
xcrun simctl ui "$UDID" appearance dark || { echo "could not switch to dark mode" >&2; exit 1; }
sleep 3; shot dark
xcrun simctl ui "$UDID" appearance light || true
# 3. Second launch: warm.
launch second
sleep 6; check "second launch"; shot second-6s
# 4. Launched with an address: a web page in the first tab.
launch address https://example.com
sleep 12; check "launch with an address"; shot example
xcrun simctl spawn "$UDID" log show --start "$(date -r "$START" '+%Y-%m-%d %H:%M:%S')" --predicate 'process == "Fable"' > "$OUT/ios-log.txt" 2>&1 || true
# How long each page took: WebKit's own timing line per load.
grep -o 'didGeneratePageLoadTiming.*' "$OUT/ios-log.txt" | sed 's/, subresources.*//' > "$OUT/ios-page-timing.txt" || true
cat "$OUT/ios-page-timing.txt"
[ -s "$OUT/ios-page-timing.txt" ] || { echo "no page finished loading (no didGeneratePageLoadTiming in the log)" >&2; cat "$OUT"/ios-console-*.txt >&2 || true; exit 1; }
# A Rust panic or an uncaught exception in any launch.
if grep -l -E "panicked at|Terminating app due to uncaught exception" "$OUT"/ios-console-*.txt "$OUT/ios-log.txt" 2>/dev/null; then
    echo "Fable panicked or threw (see the files above)" >&2; exit 1
fi
xcrun simctl terminate "$UDID" $ID || true
echo "iOS smoke test: ok"
