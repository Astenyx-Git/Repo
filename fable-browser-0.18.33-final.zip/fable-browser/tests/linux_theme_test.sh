#!/bin/sh
# Skins on Linux, end to end with the real build/fable (make linux):
#
# 1. theme://Kimi typed in the address bar puts on the Kimi skin, silently: the
#    setting is stored, the window's bar and the new-tab page take Kimi's
#    colours (pixels read from a screenshot), and no message shows where
#    messages show (the bottom of the window stays one colour).
# 2. theme://winamp, no skin, changes nothing.
# 3. A web page that sends itself to theme://grok changes nothing: only the
#    address bar picks the skin.
#
# Needs xvfb-run, xdotool, ImageMagick (import, convert) and python3; skips
# (exit 0) without them or without build/fable, unless FABLE_REQUIRE_UI=1.
set -u
cd "$(dirname "$0")/.."
skip() { echo "linux_theme_test: $1, skipped"; [ "${FABLE_REQUIRE_UI:-0}" = 1 ] && exit 1; exit 0; }
[ -x build/fable ] || skip "no build/fable (make linux)"
for tool in xvfb-run xdotool python3 import convert; do command -v $tool >/dev/null 2>&1 || skip "no $tool"; done

WORK=$(mktemp -d)
PORT=$(python3 -c 'import socket; s = socket.socket(); s.bind(("127.0.0.1", 0)); print(s.getsockname()[1])')
cp tests/linux_theme/page.html "$WORK/"
cat > "$WORK/run.sh" <<SCRIPT
#!/bin/sh
cd "$WORK"
python3 -m http.server $PORT --bind 127.0.0.1 > server.log 2>&1 &
SERVER=\$!
export HOME="$WORK/home"; mkdir -p "\$HOME"
unset XDG_DATA_HOME XDG_CONFIG_HOME XDG_CACHE_HOME   # the profile goes under HOME, not the caller's
mkdir -p "$WORK/home/.local/share/fable"
printf 'accepted_eula\tV1.2\n' > "$WORK/home/.local/share/fable/settings.tsv"
"$PWD/build/fable" > fable.log 2>&1 &
APP=\$!
sleep 6; import -window root before.png
xdotool key ctrl+l; sleep 0.3; xdotool type --delay 20 "theme://Kimi"; xdotool key Return
sleep 0.8; import -window root after.png     # a message would still be up
xdotool key ctrl+l; sleep 0.3; xdotool type --delay 20 "theme://winamp"; xdotool key Return
sleep 0.8; import -window root unknown.png
xdotool key ctrl+l; sleep 0.3; xdotool type --delay 20 "http://127.0.0.1:$PORT/page.html"; xdotool key Return
sleep 5; kill \$APP \$SERVER; wait \$APP 2>/dev/null
SCRIPT
timeout 120 xvfb-run -a -s "-screen 0 1280x900x24" sh "$WORK/run.sh"
settings="$WORK/home/.local/share/fable/settings.tsv"
px() { convert "$WORK/$1.png" -format "%[pixel:p{$2}]" info: 2>/dev/null; }
colours() { convert "$WORK/$1.png" -crop "$2" +repage -format %k info: 2>/dev/null; }
fail=0
grep -q "GET /page.html" "$WORK/server.log" || { echo "FAIL linux_theme_test: the page never loaded, so nothing was tested"; fail=1; }
grep -qP "^icon_theme\tkimi$" "$settings" 2>/dev/null || { echo "FAIL linux_theme_test: theme://Kimi did not store the Kimi skin (or something changed it)"; cat "$settings" 2>/dev/null; fail=1; }
# Before: the default skin's bar (#FBF2E8) and page (#FDF7F0). After: Kimi's (#111114, #000000).
[ "$(px before 1100,20)" = "srgb(251,242,232)" ] || { echo "FAIL linux_theme_test: the default bar is $(px before 1100,20)"; fail=1; }
[ "$(px after 1100,20)" = "srgb(17,17,20)" ] || { echo "FAIL linux_theme_test: the bar after theme://Kimi is $(px after 1100,20), not Kimi's"; fail=1; }
[ "$(px before 100,700)" = "srgb(253,247,240)" ] || { echo "FAIL linux_theme_test: the default new-tab page is $(px before 100,700)"; fail=1; }
[ "$(px after 100,700)" = "srgb(0,0,0)" ] || { echo "FAIL linux_theme_test: the new-tab page after theme://Kimi is $(px after 100,700), not Kimi's"; fail=1; }
# Messages show at the bottom of the window: nothing there but the page.
for shot in after unknown; do
    n=$(colours $shot 400x60+440+740)
    [ "$n" = 1 ] || { echo "FAIL linux_theme_test: something shows at the bottom after $shot ($n colours): a message?"; fail=1; }
done
[ "$(px unknown 1100,20)" = "srgb(17,17,20)" ] || { echo "FAIL linux_theme_test: theme://winamp changed the bar"; fail=1; }
[ -n "${KEEP:-}" ] && cp "$WORK"/before.png "$WORK"/after.png "$WORK"/unknown.png "$KEEP"/ 2>/dev/null
rm -rf "$WORK"
[ $fail = 0 ] || exit 1
echo "linux_theme_test: theme://Kimi puts on the skin silently (bar and new-tab page in its colours), an unknown name and a page change nothing"
