#!/bin/sh
# Builds the Android JNI glue for the host and runs Core.java against it on a
# desktop JVM. Skips (exit 0) when no JDK is installed.
set -eu
cd "$(dirname "$0")/.."
command -v javac >/dev/null 2>&1 || { echo "jni_test: no JDK, skipped"; exit 0; }
JAVA_HOME=${JAVA_HOME:-$(dirname "$(dirname "$(readlink -f "$(command -v javac)")")")}
out=build/jni
mkdir -p "$out/classes"
${CC:-cc} -O2 -Wall -Wextra -fPIC -shared -Icore/include -I"$JAVA_HOME/include" -I"$JAVA_HOME/include/linux" \
    shell/android/app/src/main/c/fable_jni.c core/target/release/libfable_core.a -lpthread -ldl -lm -o "$out/libfable_jni.so"
javac -encoding UTF-8 -d "$out/classes" shell/android/app/src/main/java/app/fable/browser/Core.java tests/java/app/fable/browser/CoreTest.java
# The legal documents have Chinese file names; the JVM decodes paths with the
# locale's charset, so run it in a UTF-8 locale whatever the caller has.
LC_ALL=C.UTF-8 java -Djava.library.path="$out" -cp "$out/classes" app.fable.browser.CoreTest
