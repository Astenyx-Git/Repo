// A saved home-screen order with page breaks (tests/launcher_breaks.json): breaks at the ends are
// dropped, two in a row count as one, and new tiles join the last page instead of starting one.
(function () {
  var pages = [].map.call(document.getElementById('pages').children, function (pg) {
    return [].map.call(pg.querySelectorAll('a .name'), function (n) { return n.textContent; });
  });
  var ok = pages.length >= 2 && pages[0].join() === 'GitHub' && pages[1][0] === '微信' && pages[1][1] === 'Claude';
  return (ok ? 'ok   ' : 'FAIL ') + 'saved page breaks: ' + pages.map(function (p) { return p.slice(0, 3).join(',') + ' (' + p.length + ')'; }).join(' | ');
})();
