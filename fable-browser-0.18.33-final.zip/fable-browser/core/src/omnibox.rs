//! Address bar: turn what the user typed into a URL to load.
//!
//! * an `http://`/`https://` URL (the `//` may be left out) or any `about:`
//!   page -> loaded; a local `file:///` URL too, on the desktop platforms
//!   only (see LOCAL_FILES)
//! * any other scheme followed by `//` (`ftp://`, `chrome://`, an app's own
//!   `myapp://`…), or `view-source:` of a loadable URL -> loaded as typed;
//!   the shell's web view decides what it can actually open
//! * schemes that run script or reach local or internal content
//!   (`javascript:`, `data:`, `intent:`, `content:`…) -> always a search
//! * something shaped like a host (`example.com/x`, `localhost:3000`, an IP)
//!   -> `https://` is added (`http://` for local hosts)
//! * anything else, including all non-ASCII input -> a search

use std::sync::RwLock;

const DEFAULT_SEARCH: &str = "https://duckduckgo.com/?q=%s";
static SEARCH: RwLock<Option<String>> = RwLock::new(None);

/// Replace the search engine. The template must be http(s) and contain `%s`.
pub fn set_search_template(template: &str) -> bool {
    let ok = (template.starts_with("https://") || template.starts_with("http://")) && template.contains("%s");
    if ok {
        *SEARCH.write().unwrap_or_else(|e| e.into_inner()) = Some(template.to_owned());
    }
    ok
}

/// Back to the built-in search engine.
pub fn reset_search_template() {
    *SEARCH.write().unwrap_or_else(|e| e.into_inner()) = None;
}

/// Empty input resolves to an empty string (the shells show the new-tab page).
pub fn resolve(input: &str) -> String {
    let s = input.trim();
    if s.is_empty() {
        return String::new();
    }
    if has_loadable_scheme(s) {
        return add_authority_slashes(s).replace(' ', "%20");
    }
    if s.is_ascii() && !s.contains(|c: char| c.is_ascii_whitespace()) {
        match host_kind(s) {
            Some(HostKind::Local) => return format!("http://{s}"),
            Some(HostKind::Public) => return format!("https://{s}"),
            None => {}
        }
    }
    search_url(s)
}

/// The schemes the address bar loads. A denylist: only schemes that run
/// script in the page's context or reach local or internal content are
/// refused (turned into a search); any other well-formed scheme is passed
/// to the web view as typed. Leaving an app through a page's redirect is
/// the shells' "block external apps" setting's job, not the address bar's.
fn has_loadable_scheme(s: &str) -> bool {
    let Some((scheme, rest)) = s.split_once(':') else { return false };
    if !valid_scheme(scheme) || blocked_scheme(scheme) {
        return false;
    }
    if scheme.eq_ignore_ascii_case("file") {
        return LOCAL_FILES && is_local_file(rest);
    }
    if scheme.eq_ignore_ascii_case("view-source") {
        return has_loadable_scheme(rest);
    }
    if scheme.eq_ignore_ascii_case("about") {
        return !rest.is_empty();
    }
    if scheme.eq_ignore_ascii_case("http") || scheme.eq_ignore_ascii_case("https") {
        return !rest.trim_start_matches('/').is_empty();
    }
    // An unknown scheme needs an authority ("myapp://x") to look like a URL;
    // "foo:bar" stays a search.
    rest.starts_with("//")
}

/// Schemes that execute script or reach local or internal content: never
/// loaded, whatever their shape (audit Medium-4).
fn blocked_scheme(scheme: &str) -> bool {
    ["javascript", "vbscript", "data", "blob", "filesystem", "intent", "content"]
        .iter()
        .any(|b| scheme.eq_ignore_ascii_case(b))
}

/// RFC 3986 scheme syntax: a letter, then letters, digits, `+`, `-`, `.`.
fn valid_scheme(scheme: &str) -> bool {
    let mut bytes = scheme.bytes();
    bytes.next().is_some_and(|b| b.is_ascii_alphabetic())
        && bytes.all(|b| b.is_ascii_alphanumeric() || matches!(b, b'+' | b'-' | b'.'))
}

/// `http:example.com` and `https:/example.com` mean the same as with `//`
/// (browsers read them that way); other loadable URLs pass through unchanged.
fn add_authority_slashes(s: &str) -> String {
    let (scheme, rest) = s.split_once(':').unwrap_or((s, ""));
    if (scheme.eq_ignore_ascii_case("http") || scheme.eq_ignore_ascii_case("https")) && !rest.starts_with("//") {
        return format!("{scheme}://{}", rest.trim_start_matches('/'));
    }
    s.to_owned()
}

/// Whether `file:` URLs load at all: on Linux, Windows and macOS, where Fable
/// is registered for .html files (fable.desktop, Info.plist) and is handed
/// them as file:// URLs, and where a user may type one. Not on Android, iOS or
/// HarmonyOS (`linux` with the `ohos` environment): their web views have file
/// access turned off, and nothing there hands Fable a local page.
const LOCAL_FILES: bool =
    cfg!(all(any(target_os = "linux", target_os = "windows", target_os = "macos"), not(target_env = "ohos")));

/// A file on this machine: `file:///path` or `file://localhost/path`. A file
/// URL naming another host (`file://server/share/x.html`) is a network share
/// on Windows, which would connect to that server and offer it the user's
/// credentials, so it is not loaded.
fn is_local_file(rest: &str) -> bool {
    rest.starts_with("///") || rest.get(..12).is_some_and(|h| h.eq_ignore_ascii_case("//localhost/"))
}

enum HostKind {
    Local,
    Public,
}

fn host_kind(s: &str) -> Option<HostKind> {
    let end = s.find(['/', '?', '#']).unwrap_or(s.len());
    let authority = &s[..end];
    if authority.is_empty() || authority.contains('@') {
        return None; // "me@example.com" is an e-mail address, not a site
    }
    if let Some(inner) = authority.strip_prefix('[') {
        let (addr, after) = inner.split_once(']')?;
        let ok = addr.contains(':')
            && addr.bytes().all(|b| b.is_ascii_hexdigit() || b == b':' || b == b'.')
            && (after.is_empty() || after.strip_prefix(':').is_some_and(valid_port));
        return ok.then_some(HostKind::Local);
    }
    let (host, port) = match authority.rsplit_once(':') {
        Some((h, p)) => (h, Some(p)),
        None => (authority, None),
    };
    if port.is_some_and(|p| !valid_port(p)) {
        return None;
    }
    let host = host.strip_suffix('.').unwrap_or(host);
    let labels: Vec<&str> = host.split('.').collect();
    if !labels.iter().all(|l| valid_label(l)) {
        return None;
    }
    if host.eq_ignore_ascii_case("localhost") {
        return Some(HostKind::Local);
    }
    if labels.len() == 1 {
        // A single word is a search, unless a port makes it clearly a host ("nas:8080").
        return port.map(|_| HostKind::Local);
    }
    if labels.len() == 4 && labels.iter().all(|l| l.parse::<u8>().is_ok()) {
        return Some(HostKind::Local); // IPv4
    }
    let tld = labels[labels.len() - 1];
    let named = tld.len() >= 2 && tld.bytes().all(|b| b.is_ascii_alphabetic());
    let punycode = tld.len() > 4 && tld[..4].eq_ignore_ascii_case("xn--");
    (named || punycode).then_some(HostKind::Public)
}

fn valid_port(p: &str) -> bool {
    !p.is_empty() && p.len() <= 5 && p.bytes().all(|b| b.is_ascii_digit())
}

fn valid_label(l: &str) -> bool {
    !l.is_empty()
        && l.len() <= 63
        && !l.starts_with('-')
        && !l.ends_with('-')
        && l.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'-')
}

fn search_url(query: &str) -> String {
    let mut encoded = String::with_capacity(query.len() * 3);
    for b in query.bytes() {
        if b.is_ascii_alphanumeric() || matches!(b, b'-' | b'_' | b'.' | b'~') {
            encoded.push(b as char);
        } else {
            encoded.push('%');
            encoded.push(char::from(b"0123456789ABCDEF"[(b >> 4) as usize]));
            encoded.push(char::from(b"0123456789ABCDEF"[(b & 15) as usize]));
        }
    }
    let guard = SEARCH.read().unwrap_or_else(|e| e.into_inner());
    guard.as_deref().unwrap_or(DEFAULT_SEARCH).replacen("%s", &encoded, 1)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn urls_pass_through() {
        assert_eq!(resolve("  https://example.com/a?b=1  "), "https://example.com/a?b=1");
        assert_eq!(resolve("HTTP://Example.com"), "HTTP://Example.com");
        assert_eq!(resolve("about:blank"), "about:blank");
        if LOCAL_FILES {
            assert_eq!(resolve("file:///tmp/a b.html"), "file:///tmp/a%20b.html");
        }
    }

    #[test]
    fn hosts_get_a_scheme() {
        assert_eq!(resolve("example.com"), "https://example.com");
        assert_eq!(resolve("sub.example.co.uk/path?x=1#y"), "https://sub.example.co.uk/path?x=1#y");
        assert_eq!(resolve("example.com:8443/x"), "https://example.com:8443/x");
        assert_eq!(resolve("xn--fsq.xn--0zwm56d"), "https://xn--fsq.xn--0zwm56d");
        assert_eq!(resolve("localhost"), "http://localhost");
        assert_eq!(resolve("localhost:3000/app"), "http://localhost:3000/app");
        assert_eq!(resolve("192.168.1.1"), "http://192.168.1.1");
        assert_eq!(resolve("10.0.0.2:8080/admin"), "http://10.0.0.2:8080/admin");
        assert_eq!(resolve("[::1]:8080/"), "http://[::1]:8080/");
        assert_eq!(resolve("nas:8080"), "http://nas:8080");
    }

    #[test]
    fn everything_else_is_a_search() {
        let q = |s: &str| format!("https://duckduckgo.com/?q={s}");
        assert_eq!(resolve("rust"), q("rust"));
        assert_eq!(resolve("hello world"), q("hello%20world"));
        assert_eq!(resolve("3.14"), q("3.14"));
        assert_eq!(resolve("1.2.3.4.5"), q("1.2.3.4.5"));
        assert_eq!(resolve("256.1.1.1"), q("256.1.1.1"));
        assert_eq!(resolve("what is c++?"), q("what%20is%20c%2B%2B%3F"));
        assert_eq!(resolve("me@example.com"), q("me%40example.com"));
        assert_eq!(resolve("javascript:alert(1)"), q("javascript%3Aalert%281%29"));
        assert_eq!(resolve("javascript://x%0aalert(1)"), q("javascript%3A%2F%2Fx%250aalert%281%29"));
        assert_eq!(resolve("星球 寓言"), q("%E6%98%9F%E7%90%83%20%E5%AF%93%E8%A8%80"));
        assert_eq!(resolve("例子.中国"), q("%E4%BE%8B%E5%AD%90.%E4%B8%AD%E5%9B%BD"));
        assert_eq!(resolve("-bad-.com"), q("-bad-.com"));
        assert_eq!(resolve("a..b.com"), q("a..b.com"));
        assert_eq!(resolve("foo:bar"), q("foo%3Abar"));
        assert_eq!(resolve("   "), "");
    }

    #[test]
    fn dangerous_schemes_never_load() {
        let q = |s: &str| format!("https://duckduckgo.com/?q={s}");
        // Still loaded as typed.
        assert_eq!(resolve("https://example.com/"), "https://example.com/");
        assert_eq!(resolve("http://localhost:8080/x"), "http://localhost:8080/x");
        assert_eq!(resolve("ABOUT:BLANK"), "ABOUT:BLANK");
        // Script and local/internal-content schemes are searched for, never loaded.
        assert_eq!(resolve("intent://scan/#Intent;scheme=zxing;end"), q("intent%3A%2F%2Fscan%2F%23Intent%3Bscheme%3Dzxing%3Bend"));
        assert_eq!(resolve("content://com.example.provider/secret"), q("content%3A%2F%2Fcom.example.provider%2Fsecret"));
        assert_eq!(resolve("data:text/html,<script>alert(1)</script>"), q("data%3Atext%2Fhtml%2C%3Cscript%3Ealert%281%29%3C%2Fscript%3E"));
        assert_eq!(resolve("data://text/html,x"), q("data%3A%2F%2Ftext%2Fhtml%2Cx"));
        assert_eq!(resolve("blob:https://a.com/uuid"), q("blob%3Ahttps%3A%2F%2Fa.com%2Fuuid"));
        assert_eq!(resolve("view-source:javascript:alert(1)"), q("view-source%3Ajavascript%3Aalert%281%29"));
    }

    #[test]
    fn other_schemes_load_as_typed() {
        let q = |s: &str| format!("https://duckduckgo.com/?q={s}");
        assert_eq!(resolve("myapp://open?x=1"), "myapp://open?x=1");
        assert_eq!(resolve("fable://newtab/"), "fable://newtab/");
        assert_eq!(resolve("chrome://settings"), "chrome://settings");
        assert_eq!(resolve("ftp://example.com/"), "ftp://example.com/");
        assert_eq!(resolve("about:config"), "about:config");
        assert_eq!(resolve("view-source:https://a.com"), "view-source:https://a.com");
        // http(s) tolerate a missing or single "//", as browsers do.
        assert_eq!(resolve("http:example.com"), "http://example.com");
        assert_eq!(resolve("https:/example.com/x"), "https://example.com/x");
        // Without an authority an unknown scheme is still words, not a URL.
        assert_eq!(resolve("mailto:me@example.com"), q("mailto%3Ame%40example.com"));
        assert_eq!(resolve("1nota://scheme"), q("1nota%3A%2F%2Fscheme"));
    }

    #[test]
    fn file_urls_are_local_and_desktop_only() {
        let q = |s: &str| format!("https://duckduckgo.com/?q={s}");
        let local = ["file:///home/me/a.html", "FILE:///C:/Users/me/a.html", "file://localhost/etc/hosts"];
        for url in local {
            assert_eq!(resolve(url), if LOCAL_FILES { url.to_owned() } else { search_url(url) }, "{url}");
        }
        // Another machine's file (a Windows network share): never loaded.
        assert_eq!(resolve("file://attacker.example/share/a.html"), q("file%3A%2F%2Fattacker.example%2Fshare%2Fa.html"));
        assert_eq!(resolve("file://localhost.attacker.example/a"), q("file%3A%2F%2Flocalhost.attacker.example%2Fa"));
        assert_eq!(resolve("file:/etc/passwd"), q("file%3A%2Fetc%2Fpasswd"));
        // The platforms the core is built for decide it: desktop yes, phones no.
        let desktop = cfg!(any(target_os = "linux", target_os = "windows", target_os = "macos")) && !cfg!(target_env = "ohos");
        assert_eq!(LOCAL_FILES, desktop);
    }

    #[test]
    fn search_engine_can_be_changed() {
        assert!(!set_search_template("https://example.com/search"));
        assert!(!set_search_template("ftp://example.com/?q=%s"));
        // Not applied here: other tests rely on the default and run in parallel.
    }
}
