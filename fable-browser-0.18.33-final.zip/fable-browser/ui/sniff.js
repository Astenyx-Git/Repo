// Fable resource sniffing: what the page itself shows. The shell runs this in
// the current page and gets back [[hint, url], ...]; the core decides what to
// keep. Media that players fetch over the network is caught separately by the
// shell, so this only has to cover what is visible in the document: media
// elements, large images, and links that point straight at media files.
(function () {
  var out = [], seen = {};
  function add(hint, url) {
    if (!url || !/^https?:\/\//i.test(url) || seen[url] || out.length >= 300) return;
    seen[url] = 1;
    out.push([hint, url]);
  }
  var i, j;
  var media = document.querySelectorAll('video, audio');
  for (i = 0; i < media.length; i++) {
    var hint = media[i].tagName === 'AUDIO' ? 'audio' : 'video';
    add(hint, media[i].currentSrc || media[i].src);
    var sources = media[i].querySelectorAll('source');
    for (j = 0; j < sources.length; j++) add(hint, sources[j].src);
    if (media[i].poster) add('image', media[i].poster);
  }
  var images = document.images;
  for (i = 0; i < images.length; i++) {
    if (images[i].naturalWidth >= 200 && images[i].naturalHeight >= 200) add('image', images[i].currentSrc || images[i].src);
  }
  // What the page fetched (players load media and playlists this way); the
  // core keeps only what looks like media, so plain scripts and styles drop out.
  var loaded = window.performance && performance.getEntriesByType ? performance.getEntriesByType('resource') : [];
  for (i = 0; i < loaded.length; i++) {
    var how = loaded[i].initiatorType;
    add(how === 'video' || how === 'audio' ? how : '', loaded[i].name);
  }
  var links = document.querySelectorAll('a[href]');
  for (i = 0; i < links.length; i++) {
    if (/\.(mp4|m4v|webm|mov|mkv|flv|mp3|m4a|aac|flac|wav|ogg|opus|m3u8)([?#]|$)/i.test(links[i].href)) add('', links[i].href);
  }
  return out;
})();
