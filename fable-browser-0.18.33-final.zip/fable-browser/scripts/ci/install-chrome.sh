#!/bin/sh
# Installs the headless Chrome the page checks run in (tests/ui_test.py through
# tests/chrome_harness.py): a pinned Chrome for Testing build, checked against
# its SHA-256 before it is unpacked. CI Macs have no Chrome of their own, and a
# browser that changes under the tests would make a failure mean nothing.
# Prints the path of the browser binary, for $CHROME.
#
#   CHROME_DIR=<folder>  where to put it (default: $HOME/.chrome-for-testing)
#
# To move to a newer build: pick a version from
# https://googlechromelabs.github.io/chrome-for-testing/ and record the SHA-256
# of each downloaded zip below (Google publishes no checksums for these).
set -eu
VERSION=158.0.8127.36
case "$(uname -s)-$(uname -m)" in
    Darwin-arm64)  PLATFORM=mac-arm64; SHA256=c24d40a3786322ff3a5e3ac6eed162226cbaf07ebe468715407827226b0f8897 ;;
    Darwin-x86_64) PLATFORM=mac-x64;   SHA256=e0c5d07d8f5bcc5bdd5ef370e7daf3770856b585fcc9eecf441c7e3bb2e3d1cf ;;
    Linux-x86_64)  PLATFORM=linux64;   SHA256=2d3a23017323c54fd457a678e4351f895c4076d8050e39d5aa6247f93448b73a ;;
    *) echo "install-chrome.sh: no pinned Chrome for $(uname -s)-$(uname -m)" >&2; exit 1 ;;
esac
DIR=${CHROME_DIR:-$HOME/.chrome-for-testing}/$VERSION
BIN=$DIR/chrome-headless-shell-$PLATFORM/chrome-headless-shell
if [ ! -x "$BIN" ]; then
    mkdir -p "$DIR"
    tmp=$(mktemp -d)
    trap 'rm -rf "$tmp"' EXIT
    curl --proto '=https' --tlsv1.2 -sSf -o "$tmp/chrome.zip" \
        "https://storage.googleapis.com/chrome-for-testing-public/$VERSION/$PLATFORM/chrome-headless-shell-$PLATFORM.zip"
    if command -v sha256sum >/dev/null 2>&1; then got=$(sha256sum "$tmp/chrome.zip" | cut -d' ' -f1)
    else got=$(shasum -a 256 "$tmp/chrome.zip" | cut -d' ' -f1); fi
    [ "$got" = "$SHA256" ] || { echo "install-chrome.sh: checksum mismatch: got $got, want $SHA256" >&2; exit 1; }
    unzip -q "$tmp/chrome.zip" -d "$DIR"
fi
case "$("$BIN" --version 2>/dev/null)" in
    *"$VERSION"*) ;;
    *) echo "install-chrome.sh: $BIN is not Chrome $VERSION" >&2; exit 1 ;;
esac
echo "$BIN"
