// Wires the optional native layer into the Rust core.
// 
// * no feature      -> pure Rust everywhere.
// * `asm`           -> assemble native/fnv1a_<arch>.S with a C compiler driver.
//                      Compiler: $FABLE_CC, else $CC, else `cc` (may contain
//                      arguments, e.g. "clang --target=aarch64-linux-android24").
//                      Archiver: $FABLE_AR, else $AR, else `ar`.
// * `zig-native`    -> link libfable_native.a from `zig build`, found in
//                      $FABLE_NATIVE_LIB_DIR (assembly hash + Zig table).
// 
// When an assembly hash is linked, the cfg `fable_native_hash` is set.

use std::env;
use std::path::PathBuf;
use std::process::Command;

fn tool(vars: &[&str], default: &str) -> Vec<String> {
    let value = vars.iter().find_map(|v| env::var(v).ok()).unwrap_or_else(|| default.to_string());
    value.split_whitespace().map(str::to_string).collect()
}

fn run(mut argv: Vec<String>, extra: &[&str]) {
    argv.extend(extra.iter().map(|s| s.to_string()));
    let status = Command::new(&argv[0]).args(&argv[1..]).status();
    match status {
        Ok(s) if s.success() => {}
        other => panic!("fable_core build: `{}` failed: {:?}", argv.join(" "), other),
    }
}

fn main() {
    println!("cargo:rustc-check-cfg=cfg(fable_native_hash)");
    println!("cargo:rerun-if-changed=build.rs");
    println!("cargo:rerun-if-changed=../native");
    println!("cargo:rerun-if-changed=../ui");
    for var in ["FABLE_CC", "CC", "FABLE_AR", "AR", "FABLE_NATIVE_LIB_DIR"] {
        println!("cargo:rerun-if-env-changed={var}");
    }

    let arch = env::var("CARGO_CFG_TARGET_ARCH").unwrap_or_default();
    let source = match arch.as_str() {
        "x86_64" => Some("fnv1a_x86_64.S"),
        "aarch64" => Some("fnv1a_aarch64.S"),
        _ => None, // other architectures use the portable Rust hash
    };

    if env::var_os("CARGO_FEATURE_ZIG_NATIVE").is_some() {
        let dir = env::var("FABLE_NATIVE_LIB_DIR")
            .expect("feature `zig-native` needs FABLE_NATIVE_LIB_DIR (run `zig build`, then point it at zig-out/lib)");
        println!("cargo:rustc-link-search=native={dir}");
        println!("cargo:rustc-link-lib=static=fable_native");
        if source.is_some() {
            println!("cargo:rustc-cfg=fable_native_hash");
        }
        return;
    }

    if env::var_os("CARGO_FEATURE_ASM").is_none() {
        return;
    }
    let Some(source) = source else { return };

    let manifest = PathBuf::from(env::var("CARGO_MANIFEST_DIR").unwrap());
    let out = PathBuf::from(env::var("OUT_DIR").unwrap());
    let src = manifest.join("../native").join(source);
    let obj = out.join("fable_fnv1a.o");
    let lib = out.join("libfable_asm.a");
    let _ = std::fs::remove_file(&lib);

    run(tool(&["FABLE_CC", "CC"], "cc"), &["-c", src.to_str().unwrap(), "-o", obj.to_str().unwrap()]);
    run(tool(&["FABLE_AR", "AR"], "ar"), &["crs", lib.to_str().unwrap(), obj.to_str().unwrap()]);

    println!("cargo:rustc-link-search=native={}", out.display());
    println!("cargo:rustc-link-lib=static=fable_asm");
    println!("cargo:rustc-cfg=fable_native_hash");
}
