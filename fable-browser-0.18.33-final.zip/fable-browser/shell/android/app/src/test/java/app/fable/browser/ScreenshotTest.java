package app.fable.browser;

import static org.robolectric.Shadows.shadowOf;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Looper;
import android.view.View;
import android.webkit.WebView;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.GraphicsMode;

import java.io.File;
import java.io.FileOutputStream;

/**
 * Renders the activity's own views (not the web content: there is no web
 * engine on the JVM) with Android's real drawing code and saves PNGs to
 * app/build/screenshots, so the bottom bar can be looked at without a device.
 */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = 34, qualifiers = "w390dp-h844dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class ScreenshotTest {
    private static MainActivity launch() {
        MainActivity activity = Robolectric.buildActivity(MainActivity.class).setup().get();
        if (!"true".equals(Core.panelQuery("legalAccepted", "", 0))) {
            org.robolectric.shadows.ShadowAlertDialog.getLatestAlertDialog()
                    .getButton(android.app.AlertDialog.BUTTON_POSITIVE).performClick();
        }
        return activity;
    }

    private static void save(MainActivity a, String name) throws Exception {
        shadowOf(Looper.getMainLooper()).idle();
        View root = a.getWindow().getDecorView();
        Bitmap bitmap = Bitmap.createBitmap(root.getWidth(), root.getHeight(), Bitmap.Config.ARGB_8888);
        root.draw(new Canvas(bitmap));
        File dir = new File("build/screenshots");
        dir.mkdirs();
        try (FileOutputStream out = new FileOutputStream(new File(dir, name + ".png"))) {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
        }
    }

    @Test public void bottomBar() throws Exception {
        MainActivity a = launch();
        save(a, "bar-newtab");

        WebView w = a.active.web;
        shadowOf(w).getWebViewClient().onPageStarted(w, "https://zh.wikipedia.org/wiki/土星", null);
        shadowOf(w).getWebChromeClient().onProgressChanged(w, 60);
        save(a, "bar-loading");
        shadowOf(w).getWebViewClient().onPageFinished(w, "https://zh.wikipedia.org/wiki/土星");
        a.newTab("", false);
        a.onPanelAction("toast", "已添加到主页");
        save(a, "bar-page");

        a.onPanelAction("newPrivate", "");
        save(a, "bar-private");

        a.address.requestFocus();
        a.address.setText("rust lang");
        save(a, "bar-typing");
    }

    @Test public void withTheHomeButton() throws Exception {
        MainActivity a = launch();
        Core.settingSet("home_button", "1");
        try {
            java.lang.reflect.Method apply = MainActivity.class.getDeclaredMethod("applyHomeButton");
            apply.setAccessible(true);
            apply.invoke(a);
            save(a, "bar-home-button");
            a.onPanelAction("newPrivate", "");
            save(a, "bar-home-button-private");
        } finally {
            Core.settingSet("home_button", "");
        }
    }

    @Test public void addressBarAtTheTop() throws Exception {
        MainActivity a = launch();
        try {
            a.showPanel("settings");   // switched on the way the settings sheet does it
            ((MainActivity.PanelBridge) shadowOf(a.panel).getJavascriptInterface("FableUI")).query("set", "address_top\n1");
            a.onPanelAction("hidden", "");
            WebView w = a.active.web;
            shadowOf(w).getWebViewClient().onPageStarted(w, "https://zh.wikipedia.org/wiki/土星", null);
            shadowOf(w).getWebChromeClient().onProgressChanged(w, 60);
            save(a, "bar-top-loading");
            a.onPanelAction("newPrivate", "");
            save(a, "bar-top-private");
        } finally {
            Core.settingSet("address_top", "");
        }
    }
}
