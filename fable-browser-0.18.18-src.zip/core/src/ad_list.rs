//! One runtime snapshot for request matching and WebKit rule generation.
use std::fs::File;
use std::io::Read;
use std::path::Path;
use std::sync::{RwLock, RwLockReadGuard};

/// A list file is at most 4 MiB: the community lists the updater extracts
/// (EasyList, EasyPrivacy) hold tens of thousands of domains, about 2 MB
/// serialised, so the old 1 MiB cap would reject every real update.
pub(crate) const MAX_BYTES: usize = 4 * 1024 * 1024;
/// At most this many domains in one list (the updater's estimate for the
/// community lists is well under half of this).
pub(crate) const MAX_DOMAINS: usize = 200_000;

/// A bare domain a list may hold: ASCII letters, digits and hyphens, at
/// least one dot, every label 1-63 chars and not starting or ending with '-'.
pub(crate) fn valid_domain(name: &str) -> bool {
    !name.is_empty()
        && name.len() <= 253
        && name.contains('.')
        && name.split('.').all(|label| {
            !label.is_empty()
                && label.len() <= 63
                && !label.starts_with('-')
                && !label.ends_with('-')
                && label.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'-')
        })
}

#[derive(Default)]
pub(crate) struct AdList {
    /// Domain texts - only stored on Apple platforms (for WKContentRuleList generation)
    /// On other platforms, this is empty to save ~2.3MB memory
    #[cfg(any(target_os = "ios", target_os = "macos"))]
    pub domains: Vec<String>,
    /// Hash table - used by all platforms for blocking
    pub hashes: Vec<u64>,
}

impl AdList {
    pub fn contains(&self, hash: u64) -> bool {
        self.hashes.binary_search(&hash).is_ok()
    }

    pub fn parse(bytes: &[u8]) -> Option<Self> {
        if bytes.len() > MAX_BYTES {
            return None;
        }
        let text = std::str::from_utf8(bytes).ok()?.trim_start_matches('\u{feff}');
        
        // Parse domains (only stored on Apple platforms)
        let mut domains = Vec::new();
        for line in text.lines() {
            let name = line.trim();
            if name.is_empty() || name.starts_with('#') {
                continue;
            }
            if domains.len() == MAX_DOMAINS || !valid_domain(name) {
                return None;
            }
            domains.push(name.to_ascii_lowercase());
        }
        if domains.is_empty() {
            return None;
        }
        domains.sort_unstable();
        domains.dedup();
        
        // Always build hash table
        let mut hashes: Vec<_> = domains.iter().map(|d| crate::hash::fnv1a_lower(d.as_bytes())).collect();
        hashes.sort_unstable();
        
        // Build AdList based on platform
        #[cfg(any(target_os = "ios", target_os = "macos"))]
        {
            Some(Self { domains, hashes })
        }
        
        #[cfg(not(any(target_os = "ios", target_os = "macos")))]
        {
            // On non-Apple platforms, drop domains to save memory
            Some(Self { hashes })
        }
    }

    pub fn from_file(path: &Path) -> Option<Self> {
        let mut bytes = Vec::new();
        let metadata = path.metadata().ok()?;
        if !metadata.is_file() || metadata.len() > MAX_BYTES as u64 {
            return None;
        }
        File::open(path).ok()?.take(MAX_BYTES as u64 + 1).read_to_end(&mut bytes).ok()?;
        Self::parse(&bytes)
    }
    
    /// Get domain count (for Apple platforms and stats)
    #[cfg(any(target_os = "ios", target_os = "macos"))]
    pub fn domain_count(&self) -> usize {
        self.domains.len()
    }
    
    /// Get domain count for non-Apple platforms (always 0 since we don't store them)
    #[cfg(not(any(target_os = "ios", target_os = "macos")))]
    pub fn domain_count(&self) -> usize {
        // We can calculate from hash count since each domain produces one hash
        self.hashes.len()
    }
}

static ACTIVE: RwLock<AdList> = RwLock::new(AdList { 
    #[cfg(any(target_os = "ios", target_os = "macos"))]
    domains: Vec::new(),
    hashes: Vec::new() 
});

pub(crate) fn active() -> RwLockReadGuard<'static, AdList> {
    ACTIVE.read().unwrap_or_else(|e| e.into_inner())
}

/// Install the first valid source. A failed reload preserves the active rules.
pub(crate) fn load(profile: &str, packaged: impl FnOnce() -> Option<AdList>) -> bool {
    let override_list = if profile.is_empty() { None } else { AdList::from_file(&Path::new(profile).join("ads.txt")) };
    if let Some(list) = override_list.or_else(packaged) {
        *ACTIVE.write().unwrap_or_else(|e| e.into_inner()) = list;
        true
    } else {
        false
    }
}

#[cfg(test)]
pub(crate) fn load_test_defaults() {
    static INIT: std::sync::Once = std::sync::Once::new();
    INIT.call_once(|| {
        let path = Path::new(env!("CARGO_MANIFEST_DIR")).join("../rules/ads.txt");
        assert!(load("", || AdList::from_file(&path)));
    });
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn packaged_domains_match_the_request_table() {
        load_test_defaults();
        let list = active();
        // On Apple platforms, verify domains match hashes
        #[cfg(any(target_os = "ios", target_os = "macos"))]
        {
            for domain in &list.domains {
                assert!(list.contains(crate::hash::fnv1a_lower_portable(domain.as_bytes())), "{domain}");
            }
        }
        // On all platforms, verify hash table works
        for hash in &list.hashes {
            assert!(list.contains(*hash));
        }
    }

    #[test]
    fn parses_and_bounds_runtime_input() {
        let list = AdList::parse("\u{feff}# ads\r\n ADS.Example \r\nads.example\n".as_bytes()).unwrap();
        
        #[cfg(any(target_os = "ios", target_os = "macos"))]
        {
            assert_eq!(list.domains, ["ads.example"]);
        }
        
        // Hash table should work on all platforms
        assert!(list.contains(crate::hash::fnv1a_lower(b"ads.example")));
        
        for bad in ["", "# only", "ok.example\n||bad.net^", "*.example", "local", "a..b", "-a.b", "a.b-", "a.b\0x"] {
            assert!(AdList::parse(bad.as_bytes()).is_none());
        }
        assert!(AdList::parse(&[0xff]).is_none());
        assert!(AdList::parse(&vec![b' '; MAX_BYTES + 1]).is_none());
        assert!(AdList::parse("a.b\n".repeat(MAX_DOMAINS + 1).as_bytes()).is_none());
    }
}
