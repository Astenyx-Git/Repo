// What the iOS shell says to ui/panel.html and to WebKit, kept free of UIKit
// so tests/ios_test.sh can check it on Linux. Foundation only.
import Foundation

/// A message from the panel page: "q\tid\tname\targ" (a request answered with
/// Fable.reply) or "a\tname\targ" (an action). Arguments may hold tabs.
enum PanelMessage: Equatable {
    case query(id: UInt32, name: String, arg: String)
    case action(name: String, arg: String)

    static func parse(_ text: String) -> PanelMessage? {
        let f = text.split(separator: "\t", maxSplits: 3, omittingEmptySubsequences: false).map(String.init)
        if f.count >= 3 && f[0] == "q", let id = UInt32(f[1]) {
            return .query(id: id, name: f[2], arg: f.count > 3 ? f[3] : "")
        }
        if f.count >= 2 && f[0] == "a" {
            let rest = text.split(separator: "\t", maxSplits: 2, omittingEmptySubsequences: false).map(String.init)
            return .action(name: rest[1], arg: rest.count > 2 ? rest[2] : "")
        }
        return nil
    }

    /// The setting a "set" request changes: its argument is "key\nvalue".
    static func settingKey(ofSet arg: String) -> String {
        String(arg.split(separator: "\n", maxSplits: 1, omittingEmptySubsequences: false).first ?? "")
    }
}

/// One tab as the panel lists it.
struct PanelTab {
    var id: UInt32
    var title: String
    var url: String        // "" on the new-tab page
    var icon: String       // a data: URI or ""
    var active: Bool
    var isPrivate: Bool
    var asleep: Bool
}

enum Panel {
    /// iOS has no API for these, so the panel hides their settings:
    /// screenshots of private tabs (iOS cannot block them) and a separate
    /// third-party cookie switch (WebKit always partitions them, no toggle).
    static func caps(orientation: Bool) -> String {
        "{\"screenshots\":false,\"thirdPartyCookies\":false,\"orientation\":\(orientation),\"scan\":true,\"bookmarks\":true,\"restoreTabs\":true}"
    }

    /// Everything the panel needs to draw itself, as the JSON Fable.show/update take.
    static func state(tabs: [PanelTab], incognito: Bool, desktop: Bool, sniffed: Int,
                      blocked: UInt64 = 0, orientation: Bool = true, bookmarked: UInt64 = 0, settings: String = Core.settingsJSON) -> String {
        let active = tabs.first { $0.active }
        let list = tabs.map { t in
            "{\"id\":\(t.id),\"title\":\(Core.json(t.title)),\"url\":\(Core.json(t.url)),\"icon\":\(Core.json(t.icon)),"
                + "\"active\":\(t.active),\"private\":\(t.isPrivate),\"asleep\":\(t.asleep)}"
        }
        let web = active.map { !$0.isPrivate && !$0.url.isEmpty } ?? false
        return "{\"tabs\":[\(list.joined(separator: ","))],\"incognito\":\(incognito),\"active\":\(active?.id ?? 0),"
            + "\"url\":\(Core.json(active?.url ?? "")),\"title\":\(Core.json(active?.title ?? "")),\"web\":\(web),"
            + "\"desktop\":\(desktop),\"blocked\":\(blocked),\"sniffed\":\(sniffed),\"bookmarked\":\(web ? bookmarked : 0),\"version\":\(Core.json(Core.version)),"
            + "\"platform\":\"ios\",\"caps\":\(caps(orientation: orientation)),\"settings\":\(settings.isEmpty ? "{}" : settings)}"
    }

    /// The snapshot "restore tabs on start" keeps: web pages of normal tabs
    /// only, at most 500 (what the core accepts); `front` is the tab in front.
    static func session(_ tabs: [(url: String, title: String, isPrivate: Bool)], front: Int) -> String {
        var list: [String] = []
        var active = 0
        for (i, t) in tabs.enumerated() where !t.isPrivate && (t.url.hasPrefix("http://") || t.url.hasPrefix("https://")) && list.count < 500 {
            if i == front { active = list.count }
            list.append("{\"u\":\(Core.json(t.url)),\"n\":\(Core.json(t.title))}")
        }
        return "{\"a\":\(active),\"t\":[\(list.joined(separator: ","))]}"
    }

    /// Run at document start in the panel view: keep the phone's bottom sheet
    /// although the page talks through webkit.messageHandlers like the desktops.
    static let sheetScript = "window.FableSheet = true;"

    /// A JavaScript call with a JSON-quoted string argument, e.g. Fable.show("menu", …).
    static func call(_ function: String, _ text: String, _ rest: String...) -> String {
        "\(function)(\(([Core.json(text)] + rest).joined(separator: ",")))"
    }
}

/// Content-blocker lists besides the core's tracker list.
enum Rules {
    /// "Don't load images" (the data_saver setting): network images only, so
    /// our own pages keep their inline logo.
    static let noImages = #"[{"trigger":{"url-filter":"^https?://","resource-type":["image"]},"action":{"type":"block"}}]"#
    /// The panel shows the page bundled in the core and must load nothing else.
    static let offline = #"[{"trigger":{"url-filter":"^(https?|wss?)://"},"action":{"type":"block"}}]"#
}

/// Settings turned into what WebKit on iOS understands.
enum Prefs {
    static let androidUA = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
    static let iPhoneUA = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1"
    static let iPadUA = "Mozilla/5.0 (iPad; CPU OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1"
    static let chromeWinUA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    static let chromeMacUA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    static let safariMacUA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Safari/605.1.15"
    static let firefoxUA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0"
    static let edgeUA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0"

    /// nil: WebKit's own. "desktop" is not a string here: WKWebView asks for
    /// desktop sites itself (preferredContentMode), which also sets the UA.
    static func userAgent(mode: String, custom: String) -> String? {
        switch mode {
        case "android": return androidUA
        case "iphone": return iPhoneUA
        case "ipad": return iPadUA
        case "chrome_win": return chromeWinUA
        case "chrome_mac": return chromeMacUA
        case "safari_mac": return safariMacUA
        case "firefox": return firefoxUA
        case "edge": return edgeUA
        case "custom": let c = custom.trimmingCharacters(in: .whitespacesAndNewlines); return c.isEmpty ? nil : c
        default: return nil
        }
    }

    static func wantsDesktop(mode: String) -> Bool {
        switch mode {
        case "desktop", "ipad", "chrome_win", "chrome_mac", "safari_mac", "firefox", "edge": return true
        default: return false
        }
    }

    /// text_size is a percentage ("100" or empty = as the page says).
    static func textSizePercent(_ value: String) -> Int {
        guard let n = Int(value.trimmingCharacters(in: .whitespaces)), n >= 50, n <= 300 else { return 100 }
        return n
    }

    /// WKWebView.pageZoom (iOS 14): the page reflows at the new size, as with
    /// Safari's "Aa" menu. 1 = as the page says.
    static func pageZoom(_ value: String) -> Double { Double(textSizePercent(value)) / 100 }

    /// "portrait", "landscape" or anything else (follow the device).
    enum Orientation: Equatable { case any, portrait, landscape }
    static func orientation(_ value: String) -> Orientation {
        value == "portrait" ? .portrait : value == "landscape" ? .landscape : .any
    }

    static func sleepMinutes(_ value: String) -> Int { Int(value) ?? 10 }
}

/// Where a download goes: Documents (the app's folder in the Files app),
/// never overwriting a file already there.
enum Downloads {
    static func safeName(_ suggested: String) -> String {
        var name = suggested.replacingOccurrences(of: "/", with: "_").replacingOccurrences(of: ":", with: "_")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        while name.hasPrefix(".") { name.removeFirst() }
        return name.isEmpty ? "download" : name
    }

    static func uniqueFile(in dir: URL, suggested: String, exists: (URL) -> Bool = { FileManager.default.fileExists(atPath: $0.path) }) -> URL {
        let name = safeName(suggested)
        var url = dir.appendingPathComponent(name)
        let ext = (name as NSString).pathExtension, base = (name as NSString).deletingPathExtension
        var n = 2
        while exists(url) {
            url = dir.appendingPathComponent(ext.isEmpty ? "\(base) (\(n))" : "\(base) (\(n)).\(ext)")
            n += 1
        }
        return url
    }
}
