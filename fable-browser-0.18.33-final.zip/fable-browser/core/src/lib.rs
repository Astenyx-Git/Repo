//! Fable browser core. Platform shells (C on Linux, C++ on Windows, Java + C
//! JNI glue on Android) drive a system web view and call into this crate
//! through the C ABI declared in `include/fable_core.h`.

mod ad_list;
mod ads_update;
pub mod adblock;
pub mod blocker;
pub mod bookmarks;
pub mod external;
pub mod hash;
pub mod hostset;
pub mod i18n;
pub mod omnibox;
pub mod pages;
pub mod panel;
pub mod qr;
pub mod sniff;
pub mod store;
pub mod sysinfo;
pub mod tabs;
pub mod theme;

mod ffi;

/// New-tab page, NUL-terminated so it can be handed to C as is.
pub const NEWTAB_HTML: &str = concat!(include_str!("../../ui/newtab.html"), "\0");
/// Reader-mode script, NUL-terminated.
pub const READER_JS: &str = concat!(include_str!("../../ui/reader.js"), "\0");
/// In-app UI (menu, tabs, settings, history) shown by the shell in its own privileged web view. NUL-terminated.
pub const PANEL_HTML: &str = concat!(include_str!("../../ui/panel.html"), "\0");
/// Script that lists the media and large images in a page's DOM (see sniff.rs). NUL-terminated.
pub const SNIFF_JS: &str = concat!(include_str!("../../ui/sniff.js"), "\0");
pub const VERSION: &str = concat!(env!("CARGO_PKG_VERSION"), "\0");
