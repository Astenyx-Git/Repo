//! Resource sniffing: remember the media a page loads so the user can save it.
//!
//! The shell reports what it sees for each tab: every sub-resource request
//! (with whether it carried a `Range` header, which is how players fetch media)
//! and, on demand, what a scan of the page's DOM found. This module decides
//! what counts as a resource, de-duplicates, and hands the list back as JSON.
//! Nothing is stored on disk.

use crate::store::json_string;
use std::collections::HashMap;
use std::sync::{Mutex, MutexGuard};

/// Most resources remembered per tab; later ones are dropped.
const CAP: usize = 300;

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Kind {
    Video,
    Audio,
    Image,
    /// A streaming playlist (HLS / DASH): a list of segments, not one file.
    Stream,
}

impl Kind {
    fn name(self) -> &'static str {
        match self {
            Kind::Video => "video",
            Kind::Audio => "audio",
            Kind::Image => "image",
            Kind::Stream => "stream",
        }
    }
}

const VIDEO: &[&str] = &["mp4", "m4v", "webm", "mov", "mkv", "flv", "avi", "3gp", "ogv", "wmv"];
const AUDIO: &[&str] = &["mp3", "m4a", "aac", "ogg", "oga", "opus", "wav", "flac", "wma"];
const STREAM: &[&str] = &["m3u8", "mpd"];
/// Pieces of a stream, fetched by the hundred: never worth listing one by one.
const SEGMENT: &[&str] = &["ts", "m4s", "cmfv", "cmfa", "vtt", "srt", "key"];

/// Lower-case file extension of a URL's path ("" if none).
pub fn extension(url: &str) -> String {
    let after_scheme = url.split_once("://").map_or(url, |(_, rest)| rest);
    let path = &after_scheme[..after_scheme.find(['?', '#']).unwrap_or(after_scheme.len())];
    let Some((_host, rest)) = path.split_once('/') else {
        return String::new(); // no path at all: "https://host"
    };
    let file = rest.rsplit('/').next().unwrap_or("");
    match file.rsplit_once('.') {
        Some((stem, ext)) if !stem.is_empty() && !ext.is_empty() && ext.len() <= 5 && ext.bytes().all(|b| b.is_ascii_alphanumeric()) => {
            ext.to_ascii_lowercase()
        }
        _ => String::new(),
    }
}

/// What kind of resource a URL is, if any.
///
/// `hint` says where the URL came from:
/// * `"video"`, `"audio"`, `"image"` — the page's DOM (a media element or a large image)
/// * `"range"` — a network request that carried a `Range` header
/// * `""` — any other network request, or a link
pub fn classify(url: &str, hint: &str) -> Option<Kind> {
    let lower = url.get(..8).unwrap_or(url).to_ascii_lowercase();
    if !(lower.starts_with("http://") || lower.starts_with("https://")) {
        return None; // blob:, data:, about: ... cannot be fetched again
    }
    let ext = extension(url);
    let ext = ext.as_str();
    if STREAM.contains(&ext) {
        return Some(Kind::Stream);
    }
    if SEGMENT.contains(&ext) {
        return None;
    }
    if VIDEO.contains(&ext) {
        return Some(Kind::Video);
    }
    if AUDIO.contains(&ext) {
        return Some(Kind::Audio);
    }
    match hint {
        "video" => return Some(Kind::Video),
        "audio" => return Some(Kind::Audio),
        "image" => return Some(Kind::Image),
        _ => {}
    }
    // Media served from addresses without a telling file name.
    let query = url.split_once('?').map_or("", |(_, q)| q).to_ascii_lowercase();
    if query.contains("mime=video") || query.contains("mime_type=video") {
        return Some(Kind::Video);
    }
    if query.contains("mime=audio") || query.contains("mime_type=audio") {
        return Some(Kind::Audio);
    }
    // A ranged request for something with no recognisable extension is how
    // players pull video from addresses like ".../videoplayback?id=...".
    if hint == "range" && (ext.is_empty() || ext == "php" || ext == "bin") {
        return Some(Kind::Video);
    }
    None
}

struct Item {
    kind: Kind,
    url: String,
}

static TABS: Mutex<Option<HashMap<u32, Vec<Item>>>> = Mutex::new(None);

fn tabs() -> MutexGuard<'static, Option<HashMap<u32, Vec<Item>>>> {
    TABS.lock().unwrap_or_else(|e| e.into_inner())
}

/// Report a URL seen in `tab`. Returns true if it was added to the tab's list.
pub fn note(tab: u32, url: &str, hint: &str) -> bool {
    let Some(kind) = classify(url, hint) else { return false };
    let mut guard = tabs();
    let list = guard.get_or_insert_with(HashMap::new).entry(tab).or_default();
    if list.len() >= CAP || list.iter().any(|i| i.url == url) {
        return false;
    }
    list.push(Item { kind, url: url.to_owned() });
    true
}

/// The JSON strings of a flat array, in order (enough for ui/sniff.js's
/// `[[hint, url], …]`, whose items are only strings). Nesting is ignored.
fn json_strings(text: &str) -> Vec<String> {
    let mut out = Vec::new();
    let mut chars = text.chars();
    while let Some(c) = chars.next() {
        if c != '"' {
            continue;
        }
        let mut s = String::new();
        loop {
            match chars.next() {
                None => return out,
                Some('"') => break,
                Some('\\') => match chars.next() {
                    Some('n') => s.push('\n'),
                    Some('t') => s.push('\t'),
                    Some('r') => s.push('\r'),
                    Some('b') | Some('f') => {}
                    Some('u') => {
                        let hex: String = chars.by_ref().take(4).collect();
                        if let Some(ch) = u32::from_str_radix(&hex, 16).ok().and_then(char::from_u32) {
                            s.push(ch);
                        }
                    }
                    Some(other) => s.push(other),
                    None => return out,
                },
                Some(ch) => s.push(ch),
            }
        }
        out.push(s);
    }
    out
}

/// Records what ui/sniff.js found in a page: its result as JSON,
/// `[[hint, url], …]`. Returns how many were new for `tab`.
pub fn note_scan(tab: u32, json: &str) -> usize {
    json_strings(json).chunks(2).filter(|pair| pair.len() == 2 && note(tab, &pair[1], &pair[0])).count()
}

pub fn count(tab: u32) -> usize {
    tabs().as_ref().and_then(|m| m.get(&tab)).map_or(0, Vec::len)
}

/// Forget a tab's list (it navigated to another page, or was closed).
pub fn clear(tab: u32) {
    if let Some(map) = tabs().as_mut() {
        map.remove(&tab);
    }
}

/// `[{"k":"video","u":"https://…","e":"mp4"}, …]` in the order found.
pub fn json(tab: u32) -> String {
    let guard = tabs();
    let mut out = String::from("[");
    for (i, item) in guard.as_ref().and_then(|m| m.get(&tab)).map_or(&[][..], Vec::as_slice).iter().enumerate() {
        if i > 0 {
            out.push(',');
        }
        out.push_str(&format!(
            "{{\"k\":\"{}\",\"u\":{},\"e\":{}}}",
            item.kind.name(),
            json_string(&item.url),
            json_string(&extension(&item.url))
        ));
    }
    out.push(']');
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn page_scan_results_are_noted() {
        let tab = 9101;
        let scan = r#"[["video","https://cdn.example.com/a\u002Fb.mp4"],["image","https://x.example/p.png"],["","https://x.example/page.html"],["audio","https://x.example/s.mp3"]]"#;
        assert_eq!(note_scan(tab, scan), 3);
        assert_eq!(note_scan(tab, scan), 0, "already there");
        assert!(json(tab).contains("https://cdn.example.com/a/b.mp4"));
        assert_eq!(note_scan(tab, "null"), 0);
        assert_eq!(note_scan(tab, r#"["odd"]"#), 0);
        clear(tab);
    }

    #[test]
    fn finds_extensions() {
        assert_eq!(extension("https://cdn.example.com/v/Clip.MP4?token=a.b/c#t=10"), "mp4");
        assert_eq!(extension("https://example.com/a.b/c/playlist.m3u8"), "m3u8");
        assert_eq!(extension("https://example.com/videoplayback?mime=video%2Fmp4"), "");
        assert_eq!(extension("https://example.com/"), "");
        assert_eq!(extension("https://example.com"), "");
        assert_eq!(extension("https://v1.2.example.com"), ""); // dots in the host are not an extension
        assert_eq!(extension("https://example.com/.hidden"), "");
        assert_eq!(extension("https://example.com/archive.tar.gz"), "gz");
        assert_eq!(extension("https://example.com/name.with-a-very-long-tail"), "");
    }

    #[test]
    fn classifies_by_extension_hint_and_request_shape() {
        let c = classify;
        assert_eq!(c("https://cdn.example.com/movie.mp4", ""), Some(Kind::Video));
        assert_eq!(c("HTTPS://CDN.EXAMPLE.COM/SONG.MP3?x=1", ""), Some(Kind::Audio));
        assert_eq!(c("https://cdn.example.com/live/index.m3u8", "range"), Some(Kind::Stream));
        assert_eq!(c("https://cdn.example.com/manifest.mpd", ""), Some(Kind::Stream));
        // stream segments and subtitles are noise
        assert_eq!(c("https://cdn.example.com/live/seg-00042.ts", "range"), None);
        assert_eq!(c("https://cdn.example.com/live/chunk-7.m4s", "video"), None);
        // the DOM says what it is even when the address does not
        assert_eq!(c("https://img.example.com/photo?id=7", "image"), Some(Kind::Image));
        assert_eq!(c("https://cdn.example.com/play?id=7", "video"), Some(Kind::Video));
        assert_eq!(c("https://cdn.example.com/cover.jpg", "image"), Some(Kind::Image));
        // ...but an extension wins over a wrong hint (a video's poster reported as video)
        assert_eq!(c("https://cdn.example.com/a.mp3", "video"), Some(Kind::Audio));
        // network requests: recognisable query, or ranged with no extension
        assert_eq!(c("https://r4.example.com/videoplayback?expire=1&mime=video%2Fmp4", ""), Some(Kind::Video));
        assert_eq!(c("https://r4.example.com/videoplayback?mime=audio%2Fwebm", ""), Some(Kind::Audio));
        assert_eq!(c("https://cdn.example.com/get/8f3a", "range"), Some(Kind::Video));
        assert_eq!(c("https://cdn.example.com/get/8f3a", ""), None);
        assert_eq!(c("https://cdn.example.com/app.js", "range"), None);
        assert_eq!(c("https://cdn.example.com/photo.jpg", ""), None); // ordinary images are not collected from the network
        assert_eq!(c("https://example.com/page.html", ""), None);
        // only addresses that can be fetched again
        assert_eq!(c("blob:https://example.com/2f1c", "video"), None);
        assert_eq!(c("data:video/mp4;base64,AAAA", "video"), None);
        assert_eq!(c("", "video"), None);
        assert_eq!(c("视频.mp4", ""), None);
    }

    #[test]
    fn keeps_a_deduplicated_list_per_tab() {
        let (a, b) = (900_001, 900_002); // ids no other test uses
        assert!(note(a, "https://cdn.example.com/movie.mp4", "range"));
        assert!(!note(a, "https://cdn.example.com/movie.mp4", "range"), "the same address again");
        assert!(!note(a, "https://cdn.example.com/app.js", ""));
        assert!(note(a, "https://cdn.example.com/a \"b\".mp3", ""));
        assert!(note(a, "https://img.example.com/p?id=1", "image"));
        assert!(note(b, "https://other.example/live.m3u8", ""));
        assert_eq!((count(a), count(b), count(900_003)), (3, 1, 0));

        assert_eq!(
            json(a),
            "[{\"k\":\"video\",\"u\":\"https://cdn.example.com/movie.mp4\",\"e\":\"mp4\"},\
             {\"k\":\"audio\",\"u\":\"https://cdn.example.com/a \\\"b\\\".mp3\",\"e\":\"mp3\"},\
             {\"k\":\"image\",\"u\":\"https://img.example.com/p?id=1\",\"e\":\"\"}]"
        );
        assert_eq!(json(b), "[{\"k\":\"stream\",\"u\":\"https://other.example/live.m3u8\",\"e\":\"m3u8\"}]");
        assert_eq!(json(900_003), "[]");

        clear(a);
        assert_eq!((count(a), count(b)), (0, 1));
        clear(b);
        clear(b);
    }

    #[test]
    fn stops_at_the_cap() {
        let tab = 900_010;
        for i in 0..CAP + 50 {
            note(tab, &format!("https://cdn.example.com/{i}.mp4"), "");
        }
        assert_eq!(count(tab), CAP);
        clear(tab);
    }
}
