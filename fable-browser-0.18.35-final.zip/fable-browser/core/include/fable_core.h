/* Fable browser core: C ABI of the Rust crate in core/.
 *
 * Strings are NUL-terminated UTF-8. NULL is accepted for every pointer
 * argument. fable_should_block() and the string functions may be called from
 * any thread; a FableTabs handle must stay on one thread. */
#ifndef FABLE_CORE_H
#define FABLE_CORE_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

const char *fable_version(void);
/* 1 if the assembly FNV-1a routine is linked in, 0 if the portable one is used. */
int fable_native_hash(void);

/* Decode one QR symbol from an 8-bit luminance plane. Pixel (x,y) is at
 * luma[y * row_stride + x * pixel_stride]. For packed grayscale, pass width
 * and 1 as the strides. luma must be readable for len bytes during the call.
 * Returns the decoded byte count, or -1 for invalid input or no readable QR.
 * If out is NULL or too small, returns the required size without writing.
 * Otherwise copies the entire binary payload. The bytes have no trailing NUL. */
int fable_qr_decode(const uint8_t *luma, size_t len, size_t width, size_t height,
                    size_t row_stride, size_t pixel_stride, uint8_t *out, size_t capacity);

/* Language. UI text lives in ui/strings.tsv in Simplified Chinese,
 * Traditional Chinese, Japanese, English, Korean, Russian, French, Spanish,
 * Arabic, Dutch, German, Portuguese, Italian and Hindi. The language in effect is the
 * "language" setting if set ("zh-Hans", "zh-Hant", "ja", "en", "ko", "ru",
 * "fr", "es", "ar", "nl", "de", "pt", "it", "hi"), otherwise the
 * system locale reported here (any locale tag; unknown languages get English). */
void fable_set_system_locale(const char *tag);
char *fable_language(void);                /* fable_string_free */
char *fable_tr(const char *key);           /* text for a strings.tsv key; fable_string_free */

/* Bundled pages and scripts, localized. Each returns a new string: release
 * with fable_string_free. */
char *fable_reader_script(void);           /* run in a page; evaluates to "on", "off" or "none" */
char *fable_logo_uri(void);                /* the Fable logo as a data: URI, e.g. for tab icons: the skin's */
/* Skins (theme://name: an icon and the colours that go with it). For an address
   the user typed: 1 when it was theme://<name> (claude, chatgpt, deepseek, gemini,
   grok, kimi; any case) and that skin is now on: restyle, say nothing; 0 for
   theme:// with any other name: nothing changes, say nothing; either way load
   nothing. -1 for any other address. Never for a page's own navigations. */
int fable_theme_apply(const char *url);
/* The skin's colours, JSON: {"name":"kimi","dark_ui":true,"ground":"#000000",...}
   (dark_ui: a dark skin, so light system icons). Colours:
   ground, bar, card, ink, text, muted, icon, hint, line, sep, peach, spark,
   on_spark, link, ochre, quote, dark, on_dark, hero, faint, track, knob, radio,
   tag, tile_ink, glyph, shadow (core/src/theme.rs). Private mode keeps its own. */
char *fable_theme_palette(void);
/* Same JSON as fable_theme_palette, using the current skin's dark-mode colours for private tabs. */
char *fable_theme_private_palette(void);
/* One of those colours, "#RRGGBB"; "" for a name that is none. "dark_ui": "1" for
   a dark skin, else "". */
char *fable_theme_colour(const char *key);
char *fable_theme_current(void);           /* the skin in use: "claude" (default), "chatgpt", ... */
/* In-app UI (menu, tabs, settings, history, sniffer) for the shell's own
 * privileged web view; never load it where web content can reach its bridge. */
char *fable_panel_page(void);
/* New-tab page with the stored "shortcuts" filled in. incognito: 0 normal,
 * 1 private tab, 2 private tab whose cookies are shared with normal tabs (no
 * WebView profiles); the page then says so. icons_json may be NULL, or {"host": [dataUri, width]}
 * for icons the shell already has, which are then part of the page itself. */
char *fable_newtab_page(int incognito, const char *icons_json);
/* The new-tab page as the phone's home screen (Android, when Fable is the default home app):
 * shortcuts and installed apps on swipeable pages, every app in All apps (the drawer).
 * apps_json: [{"c": "package/activity", "n": "label"}, ...]. Setting home_new_apps "0": apps not
 * on the home screen yet stay in All apps only. wallpaper: 0 the page draws its own background,
 * 1 the system wallpaper shows through (light text), 2 the same with dark text (a light wallpaper). */
char *fable_launcher_page(const char *icons_json, const char *apps_json, int wallpaper);

/* Address bar. Turns typed text into a URL (or a search URL). Returns "" for
 * blank input. The result is heap-allocated: release with fable_string_free. */
char *fable_resolve(const char *input);
void fable_string_free(char *s);
/* e.g. "https://www.bing.com/search?q=%s". Returns 1 if accepted. */
int fable_set_search_template(const char *template_url);

/* Tracker blocking. Returns 1 when request_url is a third-party request to a
 * listed domain, given the URL of the page making it ("" if unknown).
 * The ad domains are blocked too, but only while the "block ads" setting is
 * on (it is off by default). */
int fable_should_block(const char *request_url, const char *page_url);
uint64_t fable_blocked_count(void);
/* What this process blocks: the trackers and the ads. The settings live in
 * the process that owns the store; a web process (the Linux web extension)
 * has a copy of the core of its own, so the shell tells it what to block. */
void fable_set_blocking(int trackers, int ads);
/* The blocked ones that were ads (of fable_blocked_count()). */
uint64_t fable_ads_blocked_count(void);
/* Load profile_dir/ads.txt, falling back to the packaged file or asset.
 * A NULL profile skips the override. A NULL file looks beside the executable.
 * Returns 1 on success; on failure the previous list stays active. */
int fable_ad_list_file(const char *profile_dir, const char *file);
int fable_ad_list_asset(const char *profile_dir, const uint8_t *data, size_t len);
char *fable_ad_list_text(void);  /* active domains, newline-separated; fable_string_free */
/* Automatic ad-list updates: the shell fetches the built-in community
 * sources (EasyList and EasyPrivacy, one URL per line from
 * fable_ads_update_sources) and hands the downloads, concatenated, to
 * fable_ads_update_apply. At most once a week, on startup, and only while
 * ad blocking is on. fable_ads_update_due is 1 when a fetch is due;
 * fable_ads_update_apply returns the new domain count, or -1 when the
 * download is not a usable list (the old list stays active then). */
int fable_ads_update_due(void);
char *fable_ads_update_sources(void);   /* newline-separated URLs; fable_string_free */
int fable_ads_update_apply(const uint8_t *data, size_t len);
uint64_t fable_ads_domain_count(void);
/* The ad domains as a WebKit content-blocker rule list, like
 * fable_content_rules() but for the ad list. fable_string_free. */
char *fable_ads_content_rules(void);
/* The script that hides the ad boxes on a page (CSS installed through the
 * CSSOM). The shell runs it in the page after it loads. fable_string_free. */
char *fable_adblock_script(void);
/* 1 when following this URL would leave the browser for another app (a custom
 * scheme, or an app store) and the "block external apps" setting is on, so the
 * navigation has to be stopped. */
int fable_block_external_app(const char *url);
/* Panel bridge (ui/panel.html). The requests every shell answers the same
 * way: "get" key, "set" key\nvalue, "settings", "history" query,
 * "historyDelete" time\nurl, "historyClear", "sniff" (resources of `tab`).
 * Returns NULL when the request is the shell's to answer; fable_string_free. */
char *fable_panel_query(const char *name, const char *arg, uint32_t tab);
/* 1 when the panel bridge may set `key` to `value`: only the keys the panel and
 * home pages write, values of bounded length without control characters. "set"
 * through fable_panel_query already checks this; for shells that answer it themselves. */
int fable_panel_setting_allowed(const char *key, const char *value);
char *fable_settings_json(void);   /* every setting as one JSON object */
char *fable_panel_reply(uint32_t id, const char *answer);   /* "Fable.reply(id, …)" to run in the panel */
char *fable_json_string(const char *s);                      /* a JSON string literal, quotes included */
/* A public-IP service's reply (Cloudflare /cdn-cgi/trace or ipify JSON) as
 * the panel's IP card: {"ip":…,"loc":…,"colo":…,"http":…,"tls":…,"src":…},
 * or "" when it holds no address. */
char *fable_parse_ip_reply(const char *body, const char *source);
/* This machine's facts for the metadata sheet on desktop (Linux, macOS,
 * Windows; empty elsewhere): the brief page's "device" object and the
 * sections' "system" object. `extras` is a JSON object (or NULL) whose keys
 * are appended — what only the shell can see, such as the screen. */
char *fable_device_info(const char *extras);
char *fable_system_info(const char *extras);

/* The same blocklist as a WebKit content-blocker rule list (JSON for
 * WKContentRuleListStore): third-party loads from listed domains are blocked.
 * For engines that block declaratively (macOS); fable_string_free. */
char *fable_content_rules(void);

/* Track normal-mode transfers from their native callbacks. A zero ID is ignored.
 * The panel reads "downloads" and removes records with "downloadForget" + ID. */
uint32_t fable_download_begin(const char *name);
void fable_download_finish(uint32_t id, int success);

/* User data: settings (opaque key/value strings) and history, stored as
 * plain files in a directory the shell chooses. Thread-safe. Without
 * fable_store_open() everything works in memory only.
 * The core itself acts on two keys: "search_template" (as
 * fable_set_search_template) and "block_trackers" ("0" turns blocking off). */
void fable_store_open(const char *dir);
char *fable_setting_get(const char *key);                 /* "" if unset; fable_string_free */
void fable_setting_set(const char *key, const char *value); /* "" removes the key */
void fable_history_add(const char *url, const char *title, uint64_t time_ms); /* wall-clock ms */
/* JSON array, newest first: [{"t":ms,"u":url,"n":title}]. query filters by
 * substring ("" = all). Release with fable_string_free. */
char *fable_history_json(const char *query, size_t limit);
void fable_history_delete(const char *url, uint64_t time_ms); /* time_ms 0 = every visit to url */
int fable_history_clear(void); /* 1 on success, 0 if history could not be cleared on disk */

/* Bookmarks: a flat table (bookmarks and folders, parent id, 0 = the root)
 * kept in bookmarks.tsv next to the other user data. Thread-safe. */
uint64_t fable_bookmark_add(const char *url, const char *title, uint64_t parent); /* id, or 0; an existing URL is kept and retitled */
uint64_t fable_bookmark_folder(const char *name, uint64_t parent);              /* id, or 0 */
void fable_bookmark_remove(uint64_t id);            /* a folder takes its contents with it */
void fable_bookmark_move(uint64_t id, uint64_t parent, size_t index); /* index past the end = last */
void fable_bookmark_rename(uint64_t id, const char *title);
uint64_t fable_bookmark_id(const char *url);        /* 0 when not bookmarked */
/* The tree as nested JSON: [{"i":id,"u":url,"n":title} | {"i":id,"f":1,"n":name,"c":[...]}, ...].
 * query filters by title/URL substring ("" = all). fable_string_free. */
char *fable_bookmarks_json(const char *query);
/* Import a Chrome/Firefox bookmark file (NETSCAPE HTML) into the root; returns
 * how many bookmarks were added (URLs already bookmarked are skipped). */
size_t fable_bookmark_import(const char *html);
/* The whole tree as a NETSCAPE bookmark file, for export. fable_string_free. */
char *fable_bookmark_export(void);
/* The whole tree as JSON ("json"), CSV ("csv") or HTML otherwise. fable_string_free. */
char *fable_bookmark_export_fmt(const char *format);

/* The session snapshot for "restore the last tabs on start": the shell saves
 * {"a":active index,"t":[{"u":url,"n":title}, ...]} of the NORMAL tabs only
 * (private tabs must never be in it). Thread-safe. */
int fable_session_save(const char *json);   /* 1 when accepted, 0 when refused */
char *fable_session_json(void);             /* the raw snapshot, "" when none; fable_string_free */
void fable_session_clear(void);
size_t fable_session_count(void);           /* tabs in the snapshot */
char *fable_session_url(size_t i);          /* "" when out of range; fable_string_free */
char *fable_session_title(size_t i);        /* fable_string_free */
size_t fable_session_active(void);          /* index of the tab that was in front */

/* Resource sniffing: the media a page loads, per tab, kept in memory only.
 * The shell reports each sub-resource request (hint "range" if it carried a
 * Range header, else "") and the result of running fable_sniff_js() in the
 * page, which yields [[hint, url], ...] with hint "video", "audio", "image"
 * or "". The core decides what is worth listing. Thread-safe. */
const char *fable_sniff_js(void);                               /* static */
int fable_sniff_note(uint32_t tab, const char *url, const char *hint); /* 1 if added */
size_t fable_sniff_count(uint32_t tab);
size_t fable_sniff_note_scan(uint32_t tab, const char *json);     /* ui/sniff.js's result; returns how many were new */
/* [{"k":"video|audio|image|stream","u":url,"e":extension}]; fable_string_free */
char *fable_sniff_json(uint32_t tab);
void fable_sniff_clear(uint32_t tab);                           /* on navigation or tab close */

/* Tabs and the sleep policy. now_ms is any monotonic millisecond clock. */
typedef struct FableTabs FableTabs;
FableTabs *fable_tabs_new(void);
void fable_tabs_free(FableTabs *t);
void fable_tabs_set_sleep_after_ms(FableTabs *t, uint64_t ms); /* default 10 min; 0 = never */
uint32_t fable_tabs_open(FableTabs *t, uint64_t now_ms);       /* new active tab; id >= 1 */
int fable_tabs_activate(FableTabs *t, uint32_t id, uint64_t now_ms);
int fable_tabs_touch(FableTabs *t, uint32_t id, uint64_t now_ms); /* keep awake without switching */
int fable_tabs_close(FableTabs *t, uint32_t id);
size_t fable_tabs_count(const FableTabs *t);
int fable_tabs_is_asleep(const FableTabs *t, uint32_t id);
/* Writes up to cap ids of background tabs that have been idle long enough,
 * marks them asleep, returns the number written. */
size_t fable_tabs_collect_sleepers(FableTabs *t, uint64_t now_ms, uint32_t *out, size_t cap);

#ifdef __cplusplus
}
#endif
#endif
