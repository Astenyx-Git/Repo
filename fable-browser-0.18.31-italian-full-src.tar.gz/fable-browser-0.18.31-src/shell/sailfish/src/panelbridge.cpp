#include "panelbridge.h"
#include "fablecore.h"

#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QSaveFile>
#include <QStandardPaths>
#include <QStringList>
#include <QUrl>

namespace {

const qint64 kBookmarkFileMax = 4 * 1024 * 1024;   // as on the other platforms
const int kSessionTabsMax = 500;                     // what the core accepts

// The user agents of the panel's list (ui/panel.html, UAS), as Android sends them.
// "desktop" is a desktop Firefox: Sailfish's WebView is Gecko.
QString uaFor(const QString &mode)
{
    if (mode == QLatin1String("desktop"))
        return QStringLiteral("Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0");
    if (mode == QLatin1String("android"))
        return QStringLiteral("Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36");
    if (mode == QLatin1String("iphone"))
        return QStringLiteral("Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1");
    if (mode == QLatin1String("ipad"))
        return QStringLiteral("Mozilla/5.0 (iPad; CPU OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1");
    if (mode == QLatin1String("chrome_win"))
        return QStringLiteral("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36");
    if (mode == QLatin1String("chrome_mac"))
        return QStringLiteral("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36");
    if (mode == QLatin1String("safari_mac"))
        return QStringLiteral("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Safari/605.1.15");
    if (mode == QLatin1String("firefox"))
        return QStringLiteral("Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0");
    if (mode == QLatin1String("edge"))
        return QStringLiteral("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0");
    return QString();   // "default": the WebView's own
}

} // namespace

PanelBridge::PanelBridge(FableCore *core, QObject *parent)
    : QObject(parent), m_core(core) {}

// How messages travel, whichever way Sailfish's runJavaScript turns out to run
// a script: in the page itself (then the page's CSP applies to it), or in a
// privileged sandbox (then the page's own variables may sit behind Xray
// wrappers, out of its sight). Messages wait in an attribute of <html>, which
// both worlds see; scripts for the page come in as a "fable-run" event and the
// page runs them itself; and both pages allow 'unsafe-eval' (withScript).

QString PanelBridge::bootstrapScript()
{
    return QStringLiteral(
        "(function(){var r=document.documentElement,k='data-fable-queue';window.FableSheet=true;"
        "window.webkit={messageHandlers:{fableui:{postMessage:function(m){"
        "var q=JSON.parse(r.getAttribute(k)||'[]');q.push(String(m));r.setAttribute(k,JSON.stringify(q));}}}};"
        "document.addEventListener('fable-run',function(e){(0,eval)(String(e.detail));});})();");
}

QString PanelBridge::homeBootstrapScript()
{
    return QStringLiteral(
        "(function(){var r=document.documentElement,k='data-fable-queue';"
        "window.FableHost={go:function(t){var q=JSON.parse(r.getAttribute(k)||'[]');q.push('go\\t'+String(t));"
        "r.setAttribute(k,JSON.stringify(q));}};})();");
}

// The script first thing in <head>, before anything of the page's own runs;
// the page's CSP lets scripts run by eval (see above).
static QString withScript(QString html, const QString &script)
{
    const QString inlineSrc = QStringLiteral("script-src 'unsafe-inline'");
    const int csp = html.indexOf(inlineSrc);
    if (csp >= 0) html.insert(csp + inlineSrc.size(), QStringLiteral(" 'unsafe-eval'"));
    const QString tag = QStringLiteral("<script>") + script + QStringLiteral("</script>");
    const int head = html.indexOf(QLatin1String("<head>"), 0, Qt::CaseInsensitive);
    if (head >= 0) html.insert(head + 6, tag);
    else html.prepend(tag);   // the core's pages have a <head>; never load one without the stand-in
    return html;
}

QString PanelBridge::panelHtml() const
{
    return withScript(m_core->panelPage(), bootstrapScript());
}

QString PanelBridge::homeUrl() const
{
    return QStringLiteral("https://fable.invalid/newtab");
}

bool PanelBridge::isHome(const QString &url) const
{
    return url == homeUrl() || url.startsWith(homeUrl() + QLatin1Char('#'));
}

QString PanelBridge::homeHtml(bool incognito) const
{
    return withScript(m_core->newTabPage(incognito ? 1 : 0, QString()), homeBootstrapScript());
}

QString PanelBridge::homeQuery(const QString &message) const
{
    if (!message.startsWith(QLatin1String("go\t"))) return QString();
    return message.mid(3).trimmed();
}

QString PanelBridge::drainScript() const
{
    return QStringLiteral(
        "(function(){var r=document.documentElement,v=r.getAttribute('data-fable-queue')||'[]';"
        "r.removeAttribute('data-fable-queue');return v;})()");
}

QString PanelBridge::runScript(const QString &script) const
{
    return QStringLiteral("document.dispatchEvent(new CustomEvent('fable-run',{detail:")
        + m_core->jsonString(script) + QStringLiteral("}));");
}

QString PanelBridge::handleMessage(const QString &message, quint32 tab, const QString &device)
{
    const QStringList parts = message.split(QLatin1Char('\t'));
    const QString kind = parts.value(0);
    if (kind == QLatin1String("a")) {   // "a\tname\targ": the argument may hold tabs itself
        if (parts.size() < 2 || parts.at(1).isEmpty()) return QString();
        emit actionRequested(parts.at(1), parts.mid(2).join(QLatin1Char('\t')));
        return QString();
    }
    if (kind != QLatin1String("q") || parts.size() < 3) return QString();
    bool ok = false;
    const quint32 id = parts.at(1).toUInt(&ok);
    if (!ok) return QString();
    const QString name = parts.at(2);
    const QString arg = parts.mid(3).join(QLatin1Char('\t'));

    QString answer = m_core->panelQuery(name, arg, tab);   // null: the shell's to answer
    if (answer.isNull()) {
        if (name == QLatin1String("device")) answer = m_core->deviceInfo(device);
        else answer = QStringLiteral("");   // "icon": no icons are kept here
    }
    if (name == QLatin1String("set")) {
        const int nl = arg.indexOf(QLatin1Char('\n'));
        if (nl > 0) emit settingChanged(arg.left(nl));
    }
    return m_core->panelReply(id, answer);
}

QString PanelBridge::caps() const
{
    QJsonObject caps;
    caps[QStringLiteral("bookmarks")] = true;          // the star, the list, import and export
    caps[QStringLiteral("restoreTabs")] = true;
    caps[QStringLiteral("thirdPartyCookies")] = true;  // WebEngineSettings.cookieBehavior
    caps[QStringLiteral("images")] = true;             // WebEngineSettings.autoLoadImages
    // What Sailfish's WebView cannot do, so the panel leaves it out:
    caps[QStringLiteral("networkBlock")] = false;      // no per-request hook: no tracker blocking, no blocked count
    caps[QStringLiteral("clearSiteData")] = false;     // no way for an app to clear cookies or the cache
    caps[QStringLiteral("find")] = false;              // no find API (window.find would hand the page the term)
    caps[QStringLiteral("javascript")] = false;        // WebEngineSettings.javascriptEnabled is engine-wide: it would stop the panel too
    caps[QStringLiteral("textSize")] = false;          // no text zoom
    caps[QStringLiteral("tabSleep")] = false;          // one WebView: tabs behind the one in front are never loaded
    caps[QStringLiteral("scan")] = false;
    caps[QStringLiteral("homeScreen")] = false;
    caps[QStringLiteral("openDownload")] = false;
    caps[QStringLiteral("addressBarTop")] = false;
    caps[QStringLiteral("orientation")] = false;
    caps[QStringLiteral("keepScreenOn")] = false;
    caps[QStringLiteral("statusBar")] = false;
    caps[QStringLiteral("screenshots")] = false;
    return QString::fromUtf8(QJsonDocument(caps).toJson(QJsonDocument::Compact));
}

QString PanelBridge::userAgent(const QString &mode, const QString &custom) const
{
    if (mode == QLatin1String("custom")) return custom.simplified();
    return uaFor(mode);
}

bool PanelBridge::isWeb(const QString &url) const
{
    const QUrl u(url, QUrl::StrictMode);
    const QString scheme = u.scheme().toLower();
    return u.isValid() && (scheme == QLatin1String("http") || scheme == QLatin1String("https")) && !u.host().isEmpty()
        && u.host().compare(QLatin1String("fable.invalid"), Qt::CaseInsensitive) != 0;   // Fable's own pages
}

bool PanelBridge::saveSession(const QVariantList &tabs, int active) const
{
    QJsonArray list;
    int at = 0;
    for (int i = 0; i < tabs.size(); ++i) {
        const QVariantMap t = tabs.at(i).toMap();
        const QString url = t.value(QStringLiteral("url")).toString();
        if (t.value(QStringLiteral("incognito")).toBool() || !isWeb(url) || list.size() >= kSessionTabsMax) continue;
        if (i == active) at = list.size();
        QJsonObject entry;
        entry[QStringLiteral("u")] = url;
        entry[QStringLiteral("n")] = t.value(QStringLiteral("title")).toString();
        list.append(entry);
    }
    QJsonObject snapshot;
    snapshot[QStringLiteral("a")] = at;
    snapshot[QStringLiteral("t")] = list;
    return m_core->sessionSave(QString::fromUtf8(QJsonDocument(snapshot).toJson(QJsonDocument::Compact)));
}

QVariantMap PanelBridge::restoreSession() const
{
    QVariantMap out;
    if (m_core->settingGet(QStringLiteral("restore_tabs")) == QLatin1String("0")) return out;
    const int count = m_core->sessionCount(), wanted = m_core->sessionActive();
    QVariantList tabs;
    int active = 0;
    for (int i = 0; i < count; ++i) {
        const QString url = m_core->sessionUrl(i);
        if (!isWeb(url)) continue;   // only web pages, whatever the file says
        if (i == wanted) active = tabs.size();
        QVariantMap t;
        t[QStringLiteral("url")] = url;
        t[QStringLiteral("title")] = m_core->sessionTitle(i);
        tabs.append(t);
    }
    if (tabs.isEmpty()) return out;
    out[QStringLiteral("tabs")] = tabs;
    out[QStringLiteral("active")] = active;
    return out;
}

QString PanelBridge::readText(const QString &path) const
{
    QFile file(path);
    if (file.size() > kBookmarkFileMax || !file.open(QIODevice::ReadOnly)) return QString();
    return QString::fromUtf8(file.read(kBookmarkFileMax));
}

bool PanelBridge::writeText(const QString &path, const QString &text) const
{
    QSaveFile file(path);
    if (!file.open(QIODevice::WriteOnly)) return false;
    const QByteArray bytes = text.toUtf8();
    return file.write(bytes) == bytes.size() && file.commit();
}

QString PanelBridge::downloadsPath(const QString &name) const
{
    const QString dir = QStandardPaths::writableLocation(QStandardPaths::DownloadLocation);
    QDir().mkpath(dir);
    const QFileInfo info(name);
    const QString base = info.completeBaseName(), suffix = info.suffix();
    QString path = dir + QLatin1Char('/') + name;
    for (int n = 2; QFileInfo::exists(path) && n < 1000; ++n)
        path = dir + QLatin1Char('/') + base + QLatin1Char('-') + QString::number(n) + (suffix.isEmpty() ? QString() : QLatin1Char('.') + suffix);
    return path;
}
