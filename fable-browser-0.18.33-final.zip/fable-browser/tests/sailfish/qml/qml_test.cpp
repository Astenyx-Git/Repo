// The Sailfish shell's QML (shell/sailfish/qml) run by Qt Quick Test on desktop
// Qt 5, against the real core through the real FableCore and PanelBridge, with
// stand-ins (tests/sailfish/qml/stubs) for the Sailfish modules that exist only
// on the device: Sailfish.Silica, Sailfish.WebView, Sailfish.WebEngine and
// Sailfish.Pickers. tests/sailfish_test.sh builds and runs it.
#include <QDir>
#include <QObject>
#include <QQmlContext>
#include <QQmlEngine>
#include <QQuickItem>
#include <QStandardPaths>
#include <QVariant>
#include <QtQml>
#include <QtQuickTest>

#include "fablecore.h"
#include "panelbridge.h"

// Sailfish.Silica's attached EnterKey: what the address field's Enter key does.
class EnterKeyAttached : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString iconSource MEMBER m_icon NOTIFY changed)
    Q_PROPERTY(bool enabled MEMBER m_enabled NOTIFY changed)
public:
    explicit EnterKeyAttached(QObject *parent) : QObject(parent) {}
signals:
    void clicked();
    void changed();
private:
    QString m_icon;
    bool m_enabled = true;
};

class EnterKey : public QObject
{
    Q_OBJECT
public:
    static EnterKeyAttached *qmlAttachedProperties(QObject *object) { return new EnterKeyAttached(object); }
};
QML_DECLARE_TYPEINFO(EnterKey, QML_HAS_ATTACHED_PROPERTIES)

class Orientation : public QObject
{
    Q_OBJECT
public:
    enum Value { Portrait = 1, Landscape = 2, PortraitInverted = 4, LandscapeInverted = 8, All = 15 };
    Q_ENUM(Value)
};

// Sailfish.WebEngine's WebEngineSettings singleton: what was set.
class WebEngineSettings : public QObject
{
    Q_OBJECT
    Q_PROPERTY(bool autoLoadImages MEMBER m_images NOTIFY changed)
    Q_PROPERTY(bool javascriptEnabled MEMBER m_javascript NOTIFY changed)
    Q_PROPERTY(int cookieBehavior MEMBER m_cookies NOTIFY changed)
    Q_PROPERTY(int colorScheme MEMBER m_scheme NOTIFY changed)
public:
    enum CookieBehavior { AcceptAll, BlockThirdParty, BlockAll };
    Q_ENUM(CookieBehavior)
    enum ColorScheme { PrefersLightMode, PrefersDarkMode, FollowsAmbience };
    Q_ENUM(ColorScheme)
signals:
    void changed();
private:
    bool m_images = true, m_javascript = true;
    int m_cookies = -1, m_scheme = -1;
};

// pageStack (Silica), and what the test needs from C++.
class Probe : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QVariant last MEMBER m_last NOTIFY pushed)
    Q_PROPERTY(int depth MEMBER m_depth NOTIFY pushed)
    Q_PROPERTY(QString shell MEMBER m_shell CONSTANT)
public:
    explicit Probe(const QString &shell) : m_shell(shell) {}
    Q_INVOKABLE void push(const QVariant &page) { m_last = page; ++m_depth; emit pushed(); }
    Q_INVOKABLE QObject *find(QObject *root, const QString &name) const { return root ? root->findChild<QObject *>(name) : nullptr; }
    // Press Enter in a text field: its EnterKey.onClicked.
    Q_INVOKABLE bool enter(QObject *field) const
    {
        auto *key = qobject_cast<EnterKeyAttached *>(qmlAttachedPropertiesObject<EnterKey>(field, false));
        if (!key) return false;
        emit key->clicked();
        return true;
    }
    Q_INVOKABLE QString downloads() const { return QStandardPaths::writableLocation(QStandardPaths::DownloadLocation); }
signals:
    void pushed();
private:
    QVariant m_last;
    int m_depth = 0;
    QString m_shell;
};

static QObject *coreSingleton(QQmlEngine *, QJSEngine *)
{
    QObject *core = FableCore::instance();
    QQmlEngine::setObjectOwnership(core, QQmlEngine::CppOwnership);
    return core;
}

static PanelBridge *s_bridge = nullptr;
static QObject *bridgeSingleton(QQmlEngine *, QJSEngine *)
{
    QQmlEngine::setObjectOwnership(s_bridge, QQmlEngine::CppOwnership);
    return s_bridge;
}

static QObject *settingsSingleton(QQmlEngine *, QJSEngine *) { return new WebEngineSettings; }

class Setup : public QObject
{
    Q_OBJECT
public slots:
    void qmlEngineAvailable(QQmlEngine *engine)
    {
        const QString here = QStringLiteral(FABLE_TEST_DIR), stubs = here + QStringLiteral("/stubs/");
        FableCore *core = FableCore::instance();
        core->storeOpen(QDir::homePath() + QStringLiteral("/profile"));
        core->setSystemLocale(QStringLiteral("zh-CN"));
        s_bridge = new PanelBridge(core, core);
        qmlRegisterSingletonType<FableCore>("harbour.fable.Core", 1, 0, "Fable", coreSingleton);
        qmlRegisterSingletonType<PanelBridge>("harbour.fable.Core", 1, 0, "Panel", bridgeSingleton);
        // The camera scanner (QtMultimedia): a stand-in, there is no camera here.
        qmlRegisterSingletonType(QUrl::fromLocalFile(stubs + QStringLiteral("QrScanner.qml")), "harbour.fable.Core", 1, 0, "QrScanner");

        const char *silica = "Sailfish.Silica";
        const char *files[] = { "Page", "ApplicationWindow", "TextField", "Label", "IconButton", "FadeAnimation",
                                "CoverBackground", "CoverActionList", "CoverAction", "PageHeader", "Button" };
        for (const char *name : files)
            qmlRegisterType(QUrl::fromLocalFile(stubs + QLatin1String(name) + QStringLiteral(".qml")), silica, 1, 0, name);
        for (const char *name : { "Theme", "Screen", "Clipboard" })
            qmlRegisterSingletonType(QUrl::fromLocalFile(stubs + QLatin1String(name) + QStringLiteral(".qml")), silica, 1, 0, name);
        qmlRegisterUncreatableType<EnterKey>(silica, 1, 0, "EnterKey", QStringLiteral("attached only"));
        qmlRegisterUncreatableType<Orientation>(silica, 1, 0, "Orientation", QStringLiteral("enum only"));
        qmlRegisterType(QUrl::fromLocalFile(stubs + QStringLiteral("WebView.qml")), "Sailfish.WebView", 1, 0, "WebView");
        qmlRegisterType(QUrl::fromLocalFile(stubs + QStringLiteral("Page.qml")), "Sailfish.WebView", 1, 0, "WebViewPage");
        qmlRegisterSingletonType<WebEngineSettings>("Sailfish.WebEngine", 1, 0, "WebEngineSettings", settingsSingleton);
        qmlRegisterType(QUrl::fromLocalFile(stubs + QStringLiteral("FilePickerPage.qml")), "Sailfish.Pickers", 1, 0, "FilePickerPage");
        qmlRegisterSingletonType(QUrl::fromLocalFile(stubs + QStringLiteral("FakeWeb.qml")), "Fake", 1, 0, "FakeWeb");

        auto *probe = new Probe(QUrl::fromLocalFile(QStringLiteral(FABLE_SHELL_QML)).toString());
        engine->rootContext()->setContextProperty(QStringLiteral("pageStack"), probe);
        engine->rootContext()->setContextProperty(QStringLiteral("probe"), probe);
    }
};

QUICK_TEST_MAIN_WITH_SETUP(sailfish_qml, Setup)

#include "qml_test.moc"
