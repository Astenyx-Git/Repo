#!/bin/sh
# Checks the iOS shell without a Mac:
#   1. the project files: versions match the core, the Xcode project is whole
#      and builds every Swift file, Info.plist and the asset catalog parse;
#   2. with a Swift toolchain (swiftc on PATH; Linux builds from swift.org work):
#      every Swift file parses, and the Foundation-only part (Core.swift,
#      Panel.swift) is built against core/target/release/libfable_core.a and
#      run by tests/swift/main.swift. Skipped (exit 0) without swiftc.
# UIKit and WebKit exist only in Apple's SDKs: compiling the rest needs Xcode.
set -eu
cd "$(dirname "$0")/.."
IOS=shell/ios
VERSION=$(sed -n 's/^version = "\(.*\)"/\1/p' core/Cargo.toml | head -n 1)
CODE=$(sed -n 's/^ *versionCode *\([0-9]*\).*/\1/p' shell/android/app/build.gradle | head -n 1)

python3 - "$VERSION" "$CODE" <<'PY'
import json, pathlib, plistlib, re, struct, sys
version, code = sys.argv[1], sys.argv[2]
ios = pathlib.Path("shell/ios")
fail = []
def check(ok, what):
    if not ok: fail.append(what)

# Versions: the Xcode project (and its spec) say what core/Cargo.toml and Android say.
spec = (ios / "project.yml").read_text()
pbx = (ios / "Fable.xcodeproj/project.pbxproj").read_text()
check(re.search(r"MARKETING_VERSION: %s\b" % re.escape(version), spec), "project.yml MARKETING_VERSION != " + version)
check(re.search(r"CURRENT_PROJECT_VERSION: %s\b" % code, spec), "project.yml CURRENT_PROJECT_VERSION != " + code)
check(set(re.findall(r"MARKETING_VERSION = ([^;]+);", pbx)) == {version}, "project.pbxproj MARKETING_VERSION != " + version)
check(set(re.findall(r"CURRENT_PROJECT_VERSION = ([^;]+);", pbx)) == {code}, "project.pbxproj CURRENT_PROJECT_VERSION != " + code)

# project.pbxproj: an OpenStep plist. Parse it, then follow every reference.
def parse(text):
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    text = re.sub(r"^//.*$", "", text, flags=re.M)
    tokens = re.findall(r'"(?:[^"\\]|\\.)*"|[{}();=,]|[^\s{}();=,"]+', text)
    pos = 0
    def value():
        nonlocal pos
        t = tokens[pos]; pos += 1
        if t == "{":
            d = {}
            while tokens[pos] != "}":
                k = value(); assert tokens[pos] == "=", tokens[pos]; pos += 1
                d[k] = value(); assert tokens[pos] == ";", tokens[pos]; pos += 1
            pos += 1
            return d
        if t == "(":
            a = []
            while tokens[pos] != ")":
                a.append(value())
                if tokens[pos] == ",": pos += 1
            pos += 1
            return a
        return t[1:-1] if t.startswith('"') else t
    root = value()
    assert pos == len(tokens), "trailing tokens"
    return root
root = parse(pbx)
objects = root["objects"]
ids = set(objects)
def refs(v):
    if isinstance(v, dict):
        for x in v.values(): yield from refs(x)
    elif isinstance(v, list):
        for x in v: yield from refs(x)
    elif isinstance(v, str) and re.fullmatch(r"[0-9A-F]{24}", v):
        yield v
dangling = {r for o in objects.values() for r in refs(o)} - ids
check(not dangling, "dangling references: %s" % sorted(dangling))
check(root["rootObject"] in ids, "rootObject")
check(int(root["objectVersion"]) <= 56, "objectVersion %s needs a newer Xcode than 15" % root["objectVersion"])
targets = [o for o in objects.values() if o.get("isa") == "PBXNativeTarget"]
check(len(targets) == 1 and targets[0]["productType"] == "com.apple.product-type.application", "one app target")
phases = [objects[p] for p in targets[0]["buildPhases"]]
check([p["isa"] for p in phases] == ["PBXShellScriptBuildPhase", "PBXSourcesBuildPhase", "PBXResourcesBuildPhase"], "phases: core, sources, resources")
check("build-ios.sh\\\" core" in phases[0]["shellScript"], "the first phase builds the core")
built = {objects[objects[f]["fileRef"]]["path"] for f in phases[1]["files"]}
swift = {p.name for p in (ios / "Fable").glob("*.swift")}
check(built == swift, "Sources phase %s != files %s" % (sorted(built), sorted(swift)))
resources = {objects[objects[f]["fileRef"]]["path"] for f in phases[2]["files"]}
check(resources == {"Assets.xcassets"}, "resources: %s" % sorted(resources))
for c in (objects[x] for x in objects[targets[0]["buildConfigurationList"]]["buildConfigurations"]):
    s = c["buildSettings"]
    check(s.get("INFOPLIST_FILE") == "Fable/Info.plist", "INFOPLIST_FILE")
    check(s.get("SWIFT_OBJC_BRIDGING_HEADER") == "Fable/Fable-Bridging-Header.h", "bridging header")
    check(s.get("OTHER_LDFLAGS") == "-lfable_core", "links the core")
    check("build/ios/$(PLATFORM_NAME)" in s.get("LIBRARY_SEARCH_PATHS", ""), "library path per SDK")
    check("core/include" in s.get("HEADER_SEARCH_PATHS", ""), "header path")
    check(s.get("ENABLE_USER_SCRIPT_SANDBOXING") == "NO", "the core phase writes outside the sandbox")
for rel in ["Fable/Info.plist", "Fable/Fable-Bridging-Header.h", "../../core/include/fable_core.h", "../../scripts/build-ios.sh"]:
    check((ios / rel).exists(), "missing " + rel)
scheme = (ios / "Fable.xcodeproj/xcshareddata/xcschemes/Fable.xcscheme").read_text()
check('BuildableName = "Fable.app"' in scheme, "shared scheme")

# Info.plist
info = plistlib.loads((ios / "Fable/Info.plist").read_bytes())
for key in ["CFBundleIdentifier", "CFBundleShortVersionString", "UIApplicationSceneManifest", "UILaunchScreen",
            "NSAppTransportSecurity", "NSCameraUsageDescription", "NSMicrophoneUsageDescription",
            "NSLocationWhenInUseUsageDescription", "NSPhotoLibraryAddUsageDescription"]:
    check(key in info, "Info.plist lacks " + key)
check(info["CFBundleShortVersionString"] == "$(MARKETING_VERSION)", "version from the project")
check(info["UIApplicationSceneManifest"]["UISceneConfigurations"]["UIWindowSceneSessionRoleApplication"][0]["UISceneDelegateClassName"]
      == "$(PRODUCT_MODULE_NAME).SceneDelegate", "scene delegate")
check(info.get("UIFileSharingEnabled") and info.get("LSSupportsOpeningDocumentsInPlace"), "downloads show in Files")
langs = open("ui/strings.tsv", encoding="utf-8").readline().split("\t")
check(set(info["CFBundleLocalizations"]) == {l.split(" ")[0].strip() for l in langs[1:]}, "CFBundleLocalizations = the languages of strings.tsv")

# Asset catalog: JSON, the colour Info.plist names, a 1024 opaque icon.
assets = ios / "Fable/Assets.xcassets"
for f in assets.rglob("Contents.json"): json.loads(f.read_text())
check((assets / (info["UILaunchScreen"]["UIColorName"] + ".colorset")).is_dir(), "launch colour")
icon = json.loads((assets / "AppIcon.appiconset/Contents.json").read_text())["images"][0]
png = (assets / "AppIcon.appiconset" / icon["filename"]).read_bytes()
w, h, depth, kind = struct.unpack(">IIBB", png[16:26])
check(png[:8] == b"\x89PNG\r\n\x1a\n" and (w, h) == (1024, 1024) and kind == 2, "AppIcon: 1024x1024 RGB without alpha (%dx%d type %d)" % (w, h, kind))

if fail:
    print("ios project: FAIL\n  " + "\n  ".join(fail)); sys.exit(1)
print("ios project: ok (%d objects, %d Swift files)" % (len(objects), len(swift)))
PY

# The iOS core libraries, when scripts/build-ios.sh core has made them: every
# function of the C header is there (needs llvm-nm, which reads Mach-O).
NM=${NM:-llvm-nm}
if command -v "$NM" >/dev/null 2>&1 && ls build/ios/*/libfable_core.a >/dev/null 2>&1; then
    want=$(grep -oE '\bfable_[a-z0-9_]+ *\(' core/include/fable_core.h | tr -d ' (' | sort -u)
    for lib in build/ios/*/libfable_core.a; do
        have=$("$NM" -g --defined-only "$lib" 2>/dev/null | awk '$2 == "T" { sub(/^_/, "", $3); print $3 }' | sort -u)
        missing=$(printf '%s\n' "$want" | while read -r f; do printf '%s\n' "$have" | grep -qx "$f" || echo "$f"; done)
        [ -z "$missing" ] || { echo "ios core: $lib lacks $missing"; exit 1; }
        echo "ios core: $lib exports all $(printf '%s\n' "$want" | wc -l | tr -d ' ') functions of fable_core.h"
    done
fi

command -v swiftc >/dev/null 2>&1 || { echo "ios swift: no swiftc, skipped"; exit 0; }
LIB=core/target/release/libfable_core.a
[ -f "$LIB" ] || (cd core && cargo build --release)
out=build/ios-test
mkdir -p "$out"
for f in "$IOS"/Fable/*.swift; do
    swiftc -parse "$f" || { echo "ios swift: $f does not parse"; exit 1; }
done
swiftc -import-objc-header core/include/fable_core.h "$IOS/Fable/Core.swift" "$IOS/Fable/Panel.swift" tests/swift/main.swift \
    "$LIB" -lpthread -ldl -lm -o "$out/ios_test"
"$out/ios_test" "$VERSION"
