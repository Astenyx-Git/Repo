package app.fable.browser;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.util.LruCache;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Fable as the phone's home screen. When the user picks Fable as the default
 * home app, the new-tab page also lists the installed apps, so sites and apps
 * share one set of pages (ui/newtab.html), and every app is in All apps, the
 * drawer swiped up from the bottom. This class knows the apps: which
 * there are, their icons drawn as full squares (the page rounds every tile
 * the same way, a site's or an app's), and how to start them.
 *
 * Every method may be called from WebView's network thread.
 */
final class Launcher {
    static final int ICON_PX = 192;

    /** Tests set this: Robolectric resolves Home to Fable whenever Fable is the only home app it knows. */
    static Boolean homeForTests = null;

    private final Context context;
    private volatile List<String[]> apps;   // {component, label}; null until listed, or after a package change
    private final LruCache<String, byte[]> icons = new LruCache<String, byte[]>(4 * 1024 * 1024) {
        @Override protected int sizeOf(String key, byte[] png) { return png.length; }
    };

    Launcher(Context context) {
        this.context = context.getApplicationContext();
    }

    /** Whether the system's Home goes to Fable (the user chose it as the default home app). */
    boolean isDefaultHome() {
        if (homeForTests != null) return homeForTests;
        Intent home = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
        ResolveInfo r = context.getPackageManager().resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY);
        return r != null && r.activityInfo != null && context.getPackageName().equals(r.activityInfo.packageName);
    }

    /**
     * 0.17.0 development builds swapped the home wallpaper for Fable's ground colour and
     * kept the old one here. That is gone (reading the wallpaper needs storage permission
     * up to Android 12, gives the stock wallpaper on 13 and throws on 14+), so the
     * leftover copy is only dropped.
     */
    void dropOldWallpaperCopy() {
        new File(context.getFilesDir(), "home-wallpaper-backup.png").delete();
    }

    /** Apps were installed, removed or updated: list them again, and redraw their icons. */
    void invalidate() {
        apps = null;
        icons.evictAll();
    }

    /** Launchable apps other than Fable itself, as {component, label}. */
    List<String[]> apps() {
        List<String[]> list = apps;
        if (list != null) return list;
        PackageManager pm = context.getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<String[]> found = new ArrayList<>();
        for (ResolveInfo r : pm.queryIntentActivities(main, 0)) {
            ActivityInfo a = r.activityInfo;
            if (a == null || context.getPackageName().equals(a.packageName)) continue;
            CharSequence label = r.loadLabel(pm);
            found.add(new String[] {new ComponentName(a.packageName, a.name).flattenToShortString(),
                                    label == null ? a.packageName : label.toString()});
        }
        apps = list = Collections.unmodifiableList(found);
        return list;
    }

    /** [{"c": component, "n": label}, …] for the page. */
    String appsJson() {
        JSONArray out = new JSONArray();
        try {
            for (String[] app : apps()) out.put(new JSONObject().put("c", app[0]).put("n", app[1]));
        } catch (JSONException ignored) {
            // put() with strings does not throw
        }
        return out.toString();
    }

    /** Only listed apps can be started from the page, and nothing else that happens to be exported. */
    boolean has(String component) {
        if (component == null) return false;
        for (String[] app : apps()) if (app[0].equals(component)) return true;
        return false;
    }

    /** The intent that starts an app as its launcher icon would; null for anything not listed. */
    Intent launchIntent(String component) {
        ComponentName name = has(component) ? ComponentName.unflattenFromString(component) : null;
        if (name == null) return null;
        return new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(name)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
    }

    /** The system's App info screen for a listed app (from All apps' long-press menu); null for anything not listed. */
    Intent infoIntent(String component) {
        ComponentName name = has(component) ? ComponentName.unflattenFromString(component) : null;
        if (name == null) return null;
        return new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", name.getPackageName(), null))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    }

    /**
     * The app's icon as a square PNG with nothing masked off: an adaptive icon's
     * layers fill the square (cut to the part a mask would show), an older icon
     * sits on white. The page rounds it like every other tile.
     */
    byte[] icon(String component) {
        if (!has(component)) return null;
        byte[] png = icons.get(component);
        if (png != null) return png;
        ComponentName name = ComponentName.unflattenFromString(component);
        Drawable d;
        try {
            d = context.getPackageManager().getActivityIcon(name);
        } catch (PackageManager.NameNotFoundException | RuntimeException e) {
            return null;
        }
        Bitmap bitmap = Bitmap.createBitmap(ICON_PX, ICON_PX, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        if (Build.VERSION.SDK_INT >= 26 && d instanceof AdaptiveIconDrawable) {
            // Layers are 108 dp with the visible 72 dp in the middle: draw them a quarter larger on each side.
            AdaptiveIconDrawable adaptive = (AdaptiveIconDrawable) d;
            int pad = ICON_PX / 4;
            Drawable back = adaptive.getBackground(), front = adaptive.getForeground();
            if (back == null) canvas.drawColor(Color.WHITE);
            for (Drawable layer : new Drawable[] {back, front}) {
                if (layer == null) continue;
                layer.setBounds(-pad, -pad, ICON_PX + pad, ICON_PX + pad);
                layer.draw(canvas);
            }
        } else {
            canvas.drawColor(Color.WHITE);
            int inset = ICON_PX / 8;
            d.setBounds(inset, inset, ICON_PX - inset, ICON_PX - inset);
            d.draw(canvas);
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
        bitmap.recycle();
        png = out.toByteArray();
        icons.put(component, png);
        return png;
    }
}
