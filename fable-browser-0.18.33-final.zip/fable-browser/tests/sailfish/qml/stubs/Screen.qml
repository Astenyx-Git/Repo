pragma Singleton
import QtQuick 2.0
QtObject { property int width: 1080; property int height: 2520 }
