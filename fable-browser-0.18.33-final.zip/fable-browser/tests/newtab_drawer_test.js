// All apps (the drawer) on the phone's home screen. Run with --lang zh-Hans and with --lang ar, with
// tests/launcher_drawer.json (new apps go to All apps only; one app taken off the home screen) and
// tests/launcher_prelude.js, and --wait 9: the checks take a few seconds.
(function () {
  var log = [], rtl = document.documentElement.dir === 'rtl', zh = document.documentElement.lang === 'zh-Hans';
  var W = window.innerWidth, H = window.innerHeight;
  function check(name, ok) { log.push((ok ? 'ok   ' : 'FAIL ') + name); }
  function wait(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function homeTiles() { return [].slice.call(document.querySelectorAll('.page a')); }
  function names(list) { return list.map(function (a) { return a.querySelector('.name').textContent; }); }
  function onHome(n) { return names(homeTiles()).indexOf(n) >= 0; }
  function drawerTiles() { return [].slice.call(document.querySelectorAll('#dlist a')).filter(function (a) { return a.style.display !== 'none'; }); }
  function inDrawer(n) { return drawerTiles().filter(function (a) { return a.querySelector('.name').textContent === n; })[0]; }
  function sent(op) { return window.__home.filter(function (u) { return u.indexOf('home/' + op + '?') === 0; }); }
  function lastSet(key) { var s = sent('set').filter(function (u) { return u.indexOf('k=' + key + '&') >= 0; }); return s.length ? JSON.parse(decodeURIComponent(s[s.length - 1].split('&v=')[1])) : null; }
  function fire(el, type, x, y) { el.dispatchEvent(new PointerEvent(type, { bubbles: true, cancelable: true, pointerId: 7, pointerType: 'touch', clientX: x, clientY: y, isPrimary: true })); }
  function touch(el, type, x, y) {
    var t = new Touch({ identifier: 7, target: el, clientX: x, clientY: y });
    var ev = new TouchEvent(type, { bubbles: true, cancelable: true, touches: type === 'touchend' ? [] : [t], targetTouches: type === 'touchend' ? [] : [t], changedTouches: [t] });
    el.dispatchEvent(ev);
    return ev;
  }
  function center(el) { var r = el.getBoundingClientRect(); return [r.left + r.width / 2, r.top + r.height / 2]; }
  function isOpen() { return document.body.classList.contains('drawer'); }
  var drawer = document.getElementById('drawer'), pages = document.getElementById('pages'), dq = document.getElementById('dq');
  var menu = document.getElementById('dmenu');
  function typeIn(text) { dq.value = text; dq.dispatchEvent(new Event('input', { bubbles: true })); }
  function swipeUp() {
    var x = W / 2, y = H * 0.6;
    fire(pages, 'pointerdown', x, y);
    fire(document, 'pointermove', x, y - 20);
    fire(document, 'pointermove', x, y - 120);
    var mid = getComputedStyle(drawer).visibility === 'visible' && /translateY\((\d+(\.\d+)?)%\)/.test(drawer.style.transform)
              && parseFloat(RegExp.$1) > 0 && parseFloat(RegExp.$1) < 100;
    fire(document, 'pointermove', x, y - 300);
    fire(document, 'pointerup', x, y - 300);
    return mid;
  }
  function longPress(el) {
    var c = center(el);
    fire(el, 'pointerdown', c[0], c[1]);
    return wait(600).then(function () { return c; });
  }

  (async function () {
    // The home screen with new apps going to All apps only.
    check('new apps stay in All apps only: the home screen has the sites and the two placed apps', onHome('微信') && onHome('zebra') && !onHome('支付宝')
          && !onHome('淘宝') && homeTiles().length === 8 + 2);
    var saved = lastSet('home_order');
    check('the order is saved complete on load (so the setting never moves what is there)', saved && saved.length === 10 && saved[0] === 'u:https://claude.ai/'
          && saved.indexOf('a:com.alipay/.M') < 0);
    var btn = document.getElementById('apps'), br = btn.getBoundingClientRect(), dr = document.getElementById('dots').getBoundingClientRect();
    check(rtl ? 'the All apps button sits at the left end of the dots row' : 'the All apps button sits at the right end of the dots row',
          br.width > 0 && br.top >= dr.top - 1 && br.bottom <= dr.bottom + 1 && (rtl ? br.left < 30 : W - br.right < 30) && btn.getAttribute('aria-label') === (zh ? '所有应用' : 'كل التطبيقات'));
    check('All apps starts closed and out of reach', !isOpen() && getComputedStyle(drawer).visibility === 'hidden' && drawer.getAttribute('aria-hidden') === 'true');

    // Sideways is the pages' own; up opens All apps, following the finger.
    fire(pages, 'pointerdown', W / 2, H / 2); fire(document, 'pointermove', W / 2 - 80, H / 2 - 10); fire(document, 'pointerup', W / 2 - 120, H / 2 - 10);
    check('a sideways swipe does not open All apps', !isOpen());
    var followed = swipeUp();
    check('swiping up opens All apps, following the finger on the way', followed && isOpen() && drawer.getAttribute('aria-hidden') === 'false');
    await wait(400);
    var rr = drawer.getBoundingClientRect();
    check('All apps covers the screen, the search field at the top', Math.abs(rr.top) < 1 && Math.abs(rr.bottom - H) < 1 && document.getElementById('dsearch').getBoundingClientRect().top < 40);

    // Every app, removed-from-Home ones too, in the language's order.
    var all = names(drawerTiles());
    check('every app is listed, also the one taken off the home screen', all.length === 13 && all.indexOf('淘宝') >= 0 && all.indexOf('支付宝') >= 0);
    function before(x, y) { return all.indexOf(x) >= 0 && all.indexOf(x) < all.indexOf(y); }
    check('numbers by value: 9 before 10', before('9 Lives', '10 Clock'));
    check('accents do not change the letter: Apple < Éclair < Notes < zebra', before('Apple', 'Éclair') && before('Éclair', 'Notes <b>') && before('Notes <b>', 'zebra'));
    if (zh) check('Chinese in pinyin order (淘 táo < 微 wēi < 小 xiǎo < 支 zhī), not by code point', before('淘宝', '微信') && before('微信', '小红书') && before('小红书', '支付宝'));
    if (zh) check('…among the Latin names by first letter, digits first (9 Lives, 10 Clock, Apple, Éclair, Notes, 淘宝 … 小红书, zebra/支付宝 under Z)',
                  before('10 Clock', 'Apple') && before('Notes <b>', '淘宝') && before('小红书', 'zebra') && before('小红书', '支付宝'));
    else check('Arabic in its letter order (ب < ت < و)', before('بريد', 'تقويم') && before('تقويم', 'واتساب'));
    var t0 = drawerTiles()[0].getBoundingClientRect(), t1 = drawerTiles()[1].getBoundingClientRect();
    check(rtl ? 'the list runs right to left' : 'the list runs left to right', rtl ? t0.left > t1.left : t0.left < t1.left);
    check('an app name is text, not markup', !document.querySelector('#dlist a b'));

    // Search.
    typeIn('ZEB');
    check('search filters by name, ignoring case', names(drawerTiles()).join() === 'zebra');
    typeIn('eclair');
    check('search ignores accents', names(drawerTiles()).join() === 'Éclair');
    typeIn('tencent');
    check('search also finds an app by its package name', names(drawerTiles()).join() === '微信');
    typeIn('واتس');
    check('search in Arabic', names(drawerTiles()).join() === 'واتساب');
    typeIn('支付');
    check('search in Chinese', names(drawerTiles()).join() === '支付宝');
    var launches = sent('launch').length;
    document.getElementById('dsearch').dispatchEvent(new Event('submit', { cancelable: true }));
    check('Enter starts the first app found', sent('launch').length === launches + 1 && sent('launch').pop().split('&r=')[0] === 'home/launch?c=' + encodeURIComponent('com.alipay/.M'));
    await wait(500);
    check('…and All apps is closed when you come back (search cleared)', !isOpen() && dq.value === '' && drawerTiles().length === 13);
    document.getElementById('apps').click();
    check('the button opens All apps too', isOpen());
    typeIn('qqqq');
    var none = document.getElementById('dnone'), web = document.getElementById('dweb');
    check('nothing found: says so and offers a web search for the text', drawerTiles().length === 0 && getComputedStyle(none).display === 'block'
          && getComputedStyle(web).display !== 'none' && web.textContent.indexOf('qqqq') >= 0);
    var went = [];
    window.FableHost = { go: function (q) { went.push(q); } };
    web.click();
    check('the web search goes to the shell (the tab searches) and All apps closes', went.join() === 'qqqq' && !isOpen());

    // Long press: the menu; Add to Home; App info.
    document.getElementById('apps').click();
    await wait(300);
    var alipay = inDrawer('支付宝');
    var c = await longPress(alipay);
    fire(document, 'pointerup', c[0], c[1]);
    var items = [].map.call(menu.querySelectorAll('button'), function (b) { return b.dataset.act; });
    var mr = menu.getBoundingClientRect();
    check('a long press opens the app\'s menu: Add to Home, App info', menu.classList.contains('on') && items.join() === 'drawer_add,drawer_info'
          && mr.left >= 0 && mr.right <= W && mr.top >= 0 && mr.bottom <= H);
    alipay.click();
    check('the long press does not also start the app', sent('launch').length === launches + 1);
    menu.querySelector('[data-act="drawer_info"]').click();
    check('App info asks the shell for the app\'s info screen', sent('info').pop() === 'home/info?c=' + encodeURIComponent('com.alipay/.M') && !menu.classList.contains('on'));
    c = await longPress(alipay);
    fire(document, 'pointerup', c[0], c[1]);
    menu.querySelector('[data-act="drawer_add"]').click();
    await wait(50);
    var order = lastSet('home_order');
    check('Add to Home puts it at the end of the home screen, shows it there, and closes All apps', !isOpen() && onHome('支付宝')
          && order[order.length - 1] === 'a:com.alipay/.M' && homeTiles().filter(function (a) { return a.classList.contains('flash'); }).length === 1);

    // An app on Home: the menu finds it. Carry an app taken off Home back onto it.
    swipeUp();
    await wait(300);
    c = await longPress(inDrawer('微信'));
    fire(document, 'pointerup', c[0], c[1]);
    check('for an app already on the home screen the menu offers to find it there', menu.querySelector('button').dataset.act === 'drawer_find');
    window.fableBack();
    check('Back closes the menu first', !menu.classList.contains('on') && isOpen());
    var taobao = inDrawer('淘宝');
    c = await longPress(taobao);
    var mv = touch(taobao, 'touchmove', c[0], c[1] + 30);
    check('after a long press, the finger\'s move is not a scroll of the list', mv.defaultPrevented);
    fire(document, 'pointermove', c[0], c[1] + 30);
    check('moving after the long press carries the app onto the home screen, editing, and closes All apps', !isOpen() && document.body.classList.contains('editing')
          && onHome('淘宝') && JSON.stringify(lastSet('home_hidden')) === '[]' && !!document.getElementById('lift'));
    var target = homeTiles()[0], tc = center(target);
    fire(document, 'pointermove', tc[0], tc[1]);
    fire(document, 'pointerup', tc[0], tc[1]);
    touch(taobao, 'touchend', tc[0], tc[1]);
    order = lastSet('home_order');
    check('dropped on the first tile, it takes its place and the order is saved', !document.getElementById('lift') && order[0] === 'a:com.taobao/.M' && names(homeTiles())[0] === '淘宝');
    swipeUp();
    check('no swipe up into All apps while editing', !isOpen());
    check('Back ends editing, then has nothing more to close', window.fableBack() === true && !document.body.classList.contains('editing') && window.fableBack() === false);

    // Closing: swipe down from the top of the list; Back; Home.
    swipeUp();
    await wait(350);
    var first = drawerTiles()[0], fc = center(first);
    touch(first, 'touchstart', fc[0], fc[1]);
    var pull = touch(first, 'touchmove', fc[0], fc[1] + 40);
    touch(first, 'touchmove', fc[0], fc[1] + 260);
    touch(first, 'touchend', fc[0], fc[1] + 260);
    check('swiping down from the top of the list closes All apps (the browser does not scroll)', pull.defaultPrevented && !isOpen());
    swipeUp();
    check('Back closes All apps', window.fableBack() === true && !isOpen());
    swipeUp();
    pages.scrollLeft = (rtl ? -1 : 1) * pages.clientWidth;
    window.fableHome();
    await wait(600);
    check('Home closes All apps and goes back to the first page', !isOpen() && Math.abs(pages.scrollLeft) < 2);
    var tap = inDrawer('Apple');
    swipeUp(); await wait(300);
    tap.click();
    check('a tap starts the app, from where its icon is', /&r=\d+%2C\d+%2C\d+%2C\d+$/.test(sent('launch').slice(-1)[0]) && sent('launch').pop().split('&r=')[0] === 'home/launch?c=' + encodeURIComponent('com.apple/.M'));
    console.log(log.join('\n'));
  })().catch(function (e) { console.log('FAIL script error: ' + e + '\n' + log.join('\n')); });
  return 'started';
})();
