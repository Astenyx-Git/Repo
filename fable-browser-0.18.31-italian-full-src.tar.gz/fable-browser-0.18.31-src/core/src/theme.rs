//! Skins: `theme://<name>` typed in the address bar puts on one of the
//! artworks in `assets/icon-variants/` with the colours that go with it.
//!
//! The core keeps the choice (the `icon_theme` setting) and serves what the
//! skin changes:
//! * the logo: the new-tab page shows it and the panel's tab list uses it for
//!   new-tab pages (`fable_logo_uri`);
//! * the palette: the new-tab page, the panel and reader mode are drawn in it
//!   (pages.rs), and the shells colour their own bars and buttons from
//!   `fable_theme_palette`. Private mode keeps its own dark colours.
//!
//! The shells also switch the system app icon where the platform lets an app
//! do that (Android's launcher aliases, iOS's alternate icons). `claude` is the
//! default: the icons and colours Fable always had. Switching says nothing,
//! and neither does a name that is no skin.
//!
//! The logos are made by `scripts/gen_themes.py` into `core/themes/`.

use crate::{pages, store};

/// The setting that holds the chosen pack (empty: the default).
pub const SETTING: &str = "icon_theme";
pub const DEFAULT: &str = "claude";

/// (name, as written, logo). The default's logo is the one in the new-tab page.
const PACKS: [(&str, &str, &[u8]); 6] = [
    ("claude", "Claude", &[]),
    ("chatgpt", "ChatGPT", include_bytes!("../themes/chatgpt.webp")),
    ("deepseek", "DeepSeek", include_bytes!("../themes/deepseek.webp")),
    ("gemini", "Gemini", include_bytes!("../themes/gemini.webp")),
    ("grok", "Grok", include_bytes!("../themes/grok.webp")),
    ("kimi", "Kimi", include_bytes!("../themes/kimi.webp")),
];

/// Every pack, by name ("claude", "chatgpt", …).
pub fn names() -> impl Iterator<Item = &'static str> {
    PACKS.iter().map(|p| p.0)
}

/// A pack by name, any case ("DeepSeek", "deepseek").
pub fn find(name: &str) -> Option<&'static str> {
    PACKS.iter().find(|p| p.0.eq_ignore_ascii_case(name)).map(|p| p.0)
}

/// The chosen pack; the default when none is, or the setting holds a name
/// this version does not know.
pub fn current() -> &'static str {
    find(&store::setting_get(SETTING)).unwrap_or(DEFAULT)
}

/// What `url` asks for, when it is a `theme://` address: `Ok(name)` for a
/// known pack, `Err(asked)` for anything else (`asked` may be empty). None
/// when it is not a `theme://` address at all.
pub fn from_url(url: &str) -> Option<Result<&'static str, String>> {
    let url = url.trim();
    let (scheme, rest) = url.split_once("://")?;
    if !scheme.eq_ignore_ascii_case("theme") {
        return None;
    }
    // theme://Kimi, theme://kimi/, theme://kimi?x: the name is the host.
    let asked = rest.split(['/', '?', '#']).next().unwrap_or("").trim();
    Some(find(asked).ok_or_else(|| asked.to_owned()))
}

/// What the address bar does with `theme://` (the user typed it; a page's own
/// navigations never come here: a page does not pick the skin).
#[derive(Debug, PartialEq, Eq)]
pub enum Applied {
    /// Not a `theme://` address: load it as usual.
    NotTheme,
    /// A `theme://` address that names no skin: nothing changes, nothing is said.
    Unknown,
    /// The skin is now `name` (perhaps it already was): restyle.
    Switched(&'static str),
}

pub fn apply(url: &str) -> Applied {
    match from_url(url) {
        None => Applied::NotTheme,
        Some(Err(_)) => Applied::Unknown,
        Some(Ok(name)) => {
            store::setting_set(SETTING, if name == DEFAULT { "" } else { name });
            Applied::Switched(name)
        }
    }
}

/// The logo of the chosen pack as a `data:` URI.
pub fn logo_uri() -> String {
    let logo = PACKS.iter().find(|p| p.0 == current()).map_or(&[][..], |p| p.2);
    if logo.is_empty() {
        pages::default_logo_uri().to_owned()
    } else {
        format!("data:image/webp;base64,{}", base64(logo))
    }
}

/// The colours of a skin, by name. The same names on every platform:
///
/// * ground, bar, card: the page, the browser's bars, the address pill and
///   cards on the page; ink, text, muted, icon, hint: titles, running text,
///   secondary text, the bars' icons, the address hint; line, sep: borders;
/// * spark: the accent (buttons, switches, the progress bar) and on_spark,
///   what is drawn on it; peach: a soft accent (highlights); ochre: accent
///   text; link, quote: reader mode's links and quote bars;
/// * dark, on_dark, hero: the panel's dark buttons and its metadata card;
///   faint, track, knob, radio, tag, tile_ink, glyph: the panel's and the
///   new-tab page's small parts.
///
/// claude's are the colours Fable always had (ui/panel.html, ui/newtab.html,
/// ui/reader.js and every shell's own constants).
pub const COLOURS: [&str; 27] = [
    "ground", "bar", "card", "ink", "text", "muted", "icon", "hint", "line", "sep", "peach", "spark", "on_spark", "link",
    "ochre", "quote", "dark", "on_dark", "hero", "faint", "track", "knob", "radio", "tag", "tile_ink", "glyph", "shadow",
];

// The packs' grounds: the colour of each artwork's own ground, which its logo and
// app icons are made with (scripts/gen_themes.py writes both), so the page round
// the logo is the logo's ground to the last unit.
include!("../themes/grounds.rs");

/// (name, dark UI, colours in the order of COLOURS)
const PALETTES: [(&str, bool, [&str; 27]); 6] = [
    ("claude", false, [
        "#FDF7F0", "#FBF2E8", "#FFFFFF", "#2A1A14", "#3A2820", "#6E5A4E", "#5E4A3F", "#8A766A", "#EBDDD0", "#F3E8DD", "#FBE3D5", "#D9512C", "#FFFFFF", "#B8411F",
        "#8E2F14", "#F1B48E", "#2A1A14", "#FBEFE4", "#2A1A14", "#C2AD9C", "#F1E5DA", "#DCCBBC", "#CDB9A8", "#F6ECE3", "#4A372D", "#B9A699", "#2A1A14",
    ]),
    // Soft lavender and pink.
    ("chatgpt", false, [
        GROUND_CHATGPT, "#EFE7F8", "#FFFFFF", "#2B2140", "#3A2F50", "#6D6283", "#5E5375", "#8D83A3", "#E2D8F0", "#ECE5F5", "#EADDF7", "#8A63C9", "#FFFFFF", "#7449B8",
        "#5B3E91", "#D3BFEF", "#2B2140", "#F6F1FC", "#2B2140", "#B8ADCB", "#E8E0F3", "#D2C6E4", "#C2B5D8", "#EEE7F7", "#463A5E", "#ABA0C0", "#2B2140",
    ]),
    // Ocean and cerulean.
    ("deepseek", false, [
        GROUND_DEEPSEEK, "#E2F1FA", "#FFFFFF", "#0B2545", "#18324F", "#4E6680", "#3F5A78", "#7A90A8", "#D3E5F2", "#E2EEF7", "#D6EBFA", "#1668E0", "#FFFFFF", "#0F57C2",
        "#0A3D9E", "#9ACBF2", "#0B2545", "#EEF7FC", "#0B2545", "#A6BCCF", "#DCEAF5", "#C3D6E6", "#AFC5D9", "#E5F0F9", "#24405F", "#93AAC0", "#0B2545",
    ]),
    // Blue, violet and pink on cool white.
    ("gemini", false, [
        GROUND_GEMINI, "#EEF1F8", "#FFFFFF", "#1C1F3A", "#2A2E4C", "#5C6185", "#4E5378", "#858AA8", "#DFE2F0", "#EAECF5", "#E6E4FB", "#5B5FE0", "#FFFFFF", "#4A4FD0",
        "#6A3FC4", "#D8B4F0", "#1C1F3A", "#F7F8FB", "#1C1F3A", "#AEB2CC", "#E6E8F3", "#CDD0E3", "#B9BDD6", "#EEF0F8", "#363B5E", "#9EA3C0", "#1C1F3A",
    ]),
    // Obsidian, burgundy and gold: dark.
    ("grok", true, [
        GROUND_GROK, "#1C1512", "#241B17", "#F1E6CF", "#E3D6BC", "#B09F86", "#C2B092", "#8C7C66", "#3A2D26", "#2B211C", "#3A2420", "#D6B062", "#15100D", "#E2C27A",
        "#E6C77F", "#7A2A30", "#F1E6CF", "#15100D", "#0C0907", "#6E5F50", "#3A2D26", "#54453A", "#6E5D4F", "#2B211C", "#E8DAC0", "#7D6C5A", "#000000",
    ]),
    // Black and silver: dark.
    ("kimi", true, [
        GROUND_KIMI, "#111114", "#1A1B1F", "#F2F3F6", "#DADCE1", "#A3A7B0", "#B8BCC4", "#7C8089", "#2C2E34", "#1F2025", "#26282E", "#E7E8EC", "#0B0B0D", "#D7DAE0",
        "#E7E8EC", "#63676F", "#F2F3F6", "#0B0B0D", "#000000", "#5A5D65", "#2C2E34", "#45484F", "#63676F", "#1F2025", "#E7E8EC", "#6E727B", "#000000",
    ]),
];

fn palette_of(name: &str) -> &'static (&'static str, bool, [&'static str; 27]) {
    PALETTES.iter().find(|p| p.0 == name).unwrap_or(&PALETTES[0])
}

/// One colour of the skin in use, "#RRGGBB" (claude's for an unknown name).
pub fn colour(key: &str) -> &'static str {
    let p = palette_of(current());
    COLOURS.iter().position(|k| *k == key).map_or("", |i| p.2[i])
}

/// Whether the skin in use is a dark one (light text, light system icons).
pub fn is_dark() -> bool {
    palette_of(current()).1
}

/// The skin in use as JSON for the shells: `{"name":"kimi","dark_ui":true,"ground":"#000000",…}`
/// (dark_ui: a dark skin, so light system icons; "dark" is a colour).
pub fn palette_json() -> String {
    let p = palette_of(current());
    let mut out = format!(r#"{{"name":"{}","dark_ui":{}"#, p.0, p.1);
    for (k, v) in COLOURS.iter().zip(p.2.iter()) {
        out.push_str(&format!(r#","{k}":"{v}""#));
    }
    out.push('}');
    out
}

/// The skin in use as CSS custom properties for Fable's own pages
/// (`--ground`, `--on-spark`, …); "" for the default, whose colours the pages
/// carry themselves.
pub fn palette_css() -> String {
    let p = palette_of(current());
    if p.0 == DEFAULT {
        return String::new();
    }
    let vars: Vec<String> = COLOURS.iter().zip(p.2.iter()).map(|(k, v)| format!("--{}:{v}", k.replace('_', "-"))).collect();
    // No color-scheme: a dark one would paint the transparent panel's canvas, hiding the page behind it.
    format!(":root{{{}}}", vars.join(";"))
}

fn base64(bytes: &[u8]) -> String {
    const ABC: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut out = String::with_capacity(bytes.len().div_ceil(3) * 4);
    for chunk in bytes.chunks(3) {
        let n = chunk.iter().enumerate().fold(0u32, |n, (i, b)| n | (*b as u32) << (16 - 8 * i));
        for i in 0..4 {
            out.push(if i <= chunk.len() { ABC[(n >> (18 - 6 * i)) as usize & 63] as char } else { '=' });
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn base64_matches_the_standard() {
        for (raw, want) in [("", ""), ("f", "Zg=="), ("fo", "Zm8="), ("foo", "Zm9v"), ("foob", "Zm9vYg=="), ("fooba", "Zm9vYmE="), ("foobar", "Zm9vYmFy")] {
            assert_eq!(base64(raw.as_bytes()), want);
        }
        assert_eq!(base64(&[0xff, 0xfe, 0x00]), "//4A");
    }

    #[test]
    fn reads_theme_addresses() {
        assert_eq!(from_url("theme://DeepSeek"), Some(Ok("deepseek")));
        assert_eq!(from_url("THEME://kimi/"), Some(Ok("kimi")));
        assert_eq!(from_url(" theme://ChatGPT?x=1 "), Some(Ok("chatgpt")));
        assert_eq!(from_url("theme://grok#top"), Some(Ok("grok")));
        assert_eq!(from_url("theme://Gemini"), Some(Ok("gemini")));
        assert_eq!(from_url("theme://claude"), Some(Ok("claude")));
        assert_eq!(from_url("theme://dark"), Some(Err("dark".to_owned())));
        assert_eq!(from_url("theme://"), Some(Err(String::new())));
        assert_eq!(from_url("theme:kimi"), None, "theme:kimi is a search, as the address bar treats it");
        assert_eq!(from_url("https://kimi.com/"), None);
        assert_eq!(from_url("https://example.com/?u=theme://kimi"), None);
        assert_eq!(from_url("mytheme://kimi"), None);
        assert_eq!(names().count(), 6);
    }

    // The only test that touches the setting, so it runs alone as far as the setting goes.
    #[test]
    fn switches_packs_and_serves_their_logo() {
        let default_logo = pages::default_logo_uri();
        assert_eq!(current(), DEFAULT);
        assert_eq!(logo_uri(), default_logo);

        assert_eq!(apply("theme://Kimi"), Applied::Switched("kimi"));
        assert_eq!(current(), "kimi");
        assert_eq!(store::setting_get(SETTING), "kimi");
        let logo = logo_uri();
        assert!(logo.starts_with("data:image/webp;base64,UklGR") && logo != default_logo);
        let page = pages::newtab_page("", "", 0);
        assert!(page.contains(&format!("<img id=\"icon\" src=\"{logo}\"")), "the new-tab page shows the pack's logo");
        assert!(!page.contains(default_logo));

        assert_eq!(palette_json(), palette_json_of_kimi());
        assert!(palette_css().starts_with(":root{--ground:#000000;") && palette_css().contains("--on-spark:#0B0B0D") && palette_css().ends_with("--shadow:#000000}"));
        assert!(!palette_css().contains("color-scheme"), "the panel's canvas stays transparent");
        assert_eq!(colour("spark"), "#E7E8EC");
        assert!(is_dark() && colour("nonsense").is_empty());

        assert_eq!(apply("theme://dark"), Applied::Unknown);
        assert_eq!(current(), "kimi", "an unknown name changes nothing");
        assert_eq!(apply("https://example.com/"), Applied::NotTheme);

        apply("theme://deepseek");
        assert_eq!(current(), "deepseek");
        assert_eq!(apply("theme://CLAUDE/"), Applied::Switched("claude"));
        assert_eq!(store::setting_get(SETTING), "", "back to the default: nothing stored");
        assert_eq!(palette_css(), "", "the default's colours are the pages' own");
        assert!(palette_json().starts_with(r##"{"name":"claude","dark_ui":false,"ground":"#FDF7F0","##));
        assert_eq!(logo_uri(), default_logo);
        assert!(pages::newtab_page("", "", 0).contains(default_logo));

        store::setting_set(SETTING, "winamp");
        assert_eq!(current(), DEFAULT, "a name from elsewhere falls back to the default");
        store::setting_set(SETTING, "");
    }

    fn palette_json_of_kimi() -> String {
        let p = palette_of("kimi");
        let mut out = String::from(r#"{"name":"kimi","dark_ui":true"#);
        for (k, v) in COLOURS.iter().zip(p.2.iter()) {
            out.push_str(&format!(r#","{k}":"{v}""#));
        }
        out + "}"
    }

    #[test]
    fn every_skin_has_a_full_palette_that_reads() {
        assert_eq!(PALETTES.len(), PACKS.len());
        let mut keys: Vec<&str> = COLOURS.to_vec();
        keys.extend(["name", "dark_ui"]);
        keys.sort();
        keys.dedup();
        assert_eq!(keys.len(), COLOURS.len() + 2, "every key of the JSON once");
        for (name, dark, colours) in &PALETTES {
            assert!(find(name).is_some(), "{name}: a skin of its own");
            for c in colours {
                assert!(c.len() == 7 && c.starts_with('#') && c[1..].chars().all(|h| h.is_ascii_hexdigit()), "{name}: {c}");
            }
            let at = |k: &str| luminance(colours[COLOURS.iter().position(|x| *x == k).unwrap()]);
            let contrast = |a: f64, b: f64| (a.max(b) + 0.05) / (a.min(b) + 0.05);
            assert_eq!(*dark, at("ground") < 0.2, "{name}: dark means a dark ground");
            assert!(contrast(at("ink"), at("ground")) >= 7.0, "{name}: titles on the page");
            assert!(contrast(at("text"), at("ground")) >= 7.0, "{name}: running text on the page");
            assert!(contrast(at("muted"), at("ground")) >= 4.5, "{name}: secondary text");
            assert!(contrast(at("icon"), at("bar")) >= 4.5, "{name}: the bars' icons");
            // Buttons, switches and badges: large text and glyphs, so WCAG's 3:1 (the default skin's white on orange is 4.1).
            assert!(contrast(at("on_spark"), at("spark")) >= 3.0, "{name}: what is drawn on the accent");
            assert!(contrast(at("spark"), at("ground")) >= 3.0, "{name}: the accent on the page");
            assert!(contrast(at("on_dark"), at("dark")) >= 7.0, "{name}: the panel's dark buttons");
            assert!(contrast(at("ink"), at("card")) >= 7.0, "{name}: text on cards");
            assert!(contrast(at("link"), at("ground")) >= 4.5, "{name}: reader links");
        }
    }

    /// Relative luminance (WCAG 2), for the contrast checks.
    fn luminance(hex: &str) -> f64 {
        let c = |i: usize| {
            let v = u8::from_str_radix(&hex[i..i + 2], 16).unwrap() as f64 / 255.0;
            if v <= 0.03928 { v / 12.92 } else { ((v + 0.055) / 1.055).powf(2.4) }
        };
        0.2126 * c(1) + 0.7152 * c(3) + 0.0722 * c(5)
    }

    #[test]
    fn every_pack_has_a_logo() {
        for p in &PACKS[1..] {
            // Lossless (VP8L), so the colours are exact; only the planet, see-through round it; about 10-15 KB each.
            assert!(p.2.starts_with(b"RIFF") && &p.2[8..12] == b"WEBP" && &p.2[12..16] == b"VP8L" && p.2.len() < 24 * 1024, "{}", p.0);
        }
    }
}
