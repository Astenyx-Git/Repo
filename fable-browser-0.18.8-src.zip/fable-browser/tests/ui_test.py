#!/usr/bin/env python3
"""Runs every page check (tests/*_test.js against ui/panel.html and
ui/newtab.html) through the harnesses and fails if any of them fails.

A run fails when its harness exits non-zero, when any line says FAIL, when the
page or the script threw, or when fewer checks passed ("ok ...") than the run is
known to have: a check that silently stops running is a failure too.

Engines: WebKitGTK (tests/web_harness.py; needs python3-gi, gir1.2-webkit2-4.1
and a display, e.g. xvfb-run) and headless Chrome (tests/chrome_harness.py;
needs google-chrome or chromium). Each run names the engines it belongs to: the
Android home screen (newtab launcher runs) only ever runs in Android's
Chromium WebView, so it runs in Chrome; the panel's desktop and iOS modes run
in WebKit where it is available. A run whose engines are all missing falls back
to Chrome; with no engine at all the runs are skipped (exit 0), unless
FABLE_REQUIRE_UI=1 (CI), which turns a skip into a failure.

usage: python3 tests/ui_test.py [--engine webkit|chrome] [--only NAME] [-v]"""
import argparse, os, re, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

# name, page, arguments, engines (in order of preference), minimum number of "ok" checks
RUNS = [
    ("panel",          "ui/panel.html#settings", ["--lang", "zh-Hans", "--js", "tests/panel_test.js"], ("webkit", "chrome"), 135),
    ("panel-desktop",  "ui/panel.html", ["--lang", "zh-Hans", "--prelude", "tests/desktop_prelude.js", "--js", "tests/panel_desktop_test.js"], ("webkit", "chrome"), 25),
    ("panel-ios",      "ui/panel.html", ["--lang", "zh-Hans", "--prelude", "tests/ios_prelude.js", "--js", "tests/panel_ios_test.js"], ("webkit",), 17),
    ("launcher",       "ui/newtab.html", ["--lang", "zh-Hans", "--launcher", "tests/launcher_apps.json", "--prelude", "tests/launcher_prelude.js", "--js", "tests/newtab_launcher_test.js", "--wait", "4"], ("chrome",), 19),
    ("breaks",         "ui/newtab.html", ["--lang", "zh-Hans", "--launcher", "tests/launcher_breaks.json", "--prelude", "tests/launcher_prelude.js", "--js", "tests/newtab_breaks_test.js"], ("chrome",), 1),
    ("editing-zh",     "ui/newtab.html", ["--lang", "zh-Hans", "--launcher", "tests/launcher_apps.json", "--prelude", "tests/launcher_prelude.js", "--js", "tests/newtab_editing_test.js", "--wait", "2"], ("chrome",), 6),
    ("editing-ar",     "ui/newtab.html", ["--lang", "ar", "--launcher", "tests/launcher_apps.json", "--prelude", "tests/launcher_prelude.js", "--js", "tests/newtab_editing_test.js", "--wait", "2"], ("chrome",), 6),
    ("drawer-zh",      "ui/newtab.html", ["--lang", "zh-Hans", "--launcher", "tests/launcher_drawer.json", "--prelude", "tests/launcher_prelude.js", "--js", "tests/newtab_drawer_test.js", "--wait", "9"], ("chrome",), 39),
    ("drawer-ar",      "ui/newtab.html", ["--lang", "ar", "--launcher", "tests/launcher_drawer.json", "--prelude", "tests/launcher_prelude.js", "--js", "tests/newtab_drawer_test.js", "--wait", "9"], ("chrome",), 38),
    ("wallpaper",      "ui/newtab.html", ["--lang", "zh-Hans", "--launcher", "tests/launcher_wallpaper.json", "--prelude", "tests/launcher_prelude.js", "--js", "tests/newtab_wallpaper_test.js", "--wait", "2"], ("chrome",), 7),
]

def have_webkit():
    try:
        r = subprocess.run([sys.executable, "-c", "import gi; gi.require_version('WebKit2', '4.1'); from gi.repository import WebKit2"],
                           capture_output=True, timeout=60)
    except Exception:
        return False
    return r.returncode == 0 and (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY") or shutil.which("xvfb-run"))

def have_chrome():
    return bool(os.environ.get("CHROME") or shutil.which("google-chrome") or shutil.which("chromium") or shutil.which("chromium-browser"))

def command(engine, page, args, out):
    if engine == "chrome":
        return [sys.executable, os.path.join(HERE, "chrome_harness.py"), page, out] + args
    cmd = [sys.executable, os.path.join(HERE, "web_harness.py"), page, out] + args
    if not (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")):
        cmd = ["xvfb-run", "-a"] + cmd
    return cmd

def verdict(code, output, minimum):
    """(passed, number of ok checks, reasons) for one harness run."""
    lines = output.splitlines()
    oks = sum(1 for l in lines if re.match(r"^(js result: )?ok\b", l))
    reasons = []
    if code != 0: reasons.append("harness exited %d" % code)
    fails = [l for l in lines if re.search(r"\bFAIL\b", l)]
    if fails: reasons.append("%d FAIL line(s)" % len(fails))
    if oks < minimum: reasons.append("only %d of at least %d checks passed" % (oks, minimum))
    return not reasons, oks, reasons + fails[:20]

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--engine", choices=["webkit", "chrome"])
    ap.add_argument("--only", action="append", default=[]); ap.add_argument("-v", "--verbose", action="store_true")
    a = ap.parse_args()
    require = os.environ.get("FABLE_REQUIRE_UI") == "1"
    available = {"webkit": bool(have_webkit()), "chrome": have_chrome()}
    if a.engine: available = {k: v and k == a.engine for k, v in available.items()}
    os.chdir(ROOT)
    out_dir = tempfile.mkdtemp(prefix="fable-ui-")
    failures, skipped, ran = [], [], 0
    for name, page, args, engines, minimum in RUNS:
        if a.only and name not in a.only: continue
        use = [e for e in engines if available[e]]
        if not use and available["chrome"]: use = ["chrome"]   # every check also passes in Chrome
        if not use:
            skipped.append(name); continue
        for engine in use:
            out = os.path.join(out_dir, "%s-%s.png" % (name, engine))
            try:
                r = subprocess.run(command(engine, page, args, out), capture_output=True, text=True, timeout=180)
                code, output = r.returncode, r.stdout + ("\n" + r.stderr if r.returncode else "")
            except subprocess.TimeoutExpired as e:
                code, output = 124, (e.stdout or b"").decode(errors="replace") if isinstance(e.stdout, bytes) else (e.stdout or "")
            ok, oks, reasons = verdict(code, output, minimum)
            ran += 1
            print("%-4s %-14s %-6s %3d checks ok%s" % ("ok" if ok else "FAIL", name, engine, oks, "" if ok else ": " + reasons[0]), flush=True)
            if not ok:
                for line in reasons[1:]: print("       " + line)
                failures.append("%s (%s)" % (name, engine))
            if a.verbose: print(output)
    shutil.rmtree(out_dir, ignore_errors=True)
    if skipped:
        print("ui_test: skipped (no WebKitGTK or Chrome here): " + ", ".join(skipped))
    if failures:
        print("ui_test: %d run(s) failed: %s" % (len(failures), ", ".join(failures))); return 1
    if skipped and require:
        print("ui_test: FABLE_REQUIRE_UI=1 and runs were skipped"); return 1
    if ran == 0 and not skipped:
        print("ui_test: nothing selected"); return 1
    print("ui_test: %d run(s) passed" % ran)
    return 0

if __name__ == "__main__":
    sys.exit(main())
