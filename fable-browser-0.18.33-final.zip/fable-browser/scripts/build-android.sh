#!/bin/sh
# Build the Rust core for Android, then the APK.
#   ANDROID_NDK_HOME set  -> the assembly hash is built with the NDK's clang
#   otherwise             -> the portable Rust hash is used
# Needs: rustup, Android SDK + NDK, Gradle 8.7+ (or open shell/android in Android Studio).
set -eu
cd "$(dirname "$0")/.."

API=24
for pair in aarch64-linux-android:aarch64 x86_64-linux-android:x86_64; do
    triple=${pair%%:*}
    rustup target add "$triple"
    if [ -n "${ANDROID_NDK_HOME:-}" ]; then
        bin=$(echo "$ANDROID_NDK_HOME"/toolchains/llvm/prebuilt/*/bin)
        (cd core && FABLE_CC="$bin/clang --target=$triple$API" FABLE_AR="$bin/llvm-ar" \
            cargo build --release --target "$triple" --features asm)
    else
        (cd core && cargo build --release --target "$triple")
    fi
done

cd shell/android
gradle :app:assembleDebug
echo "APK: shell/android/app/build/outputs/apk/debug/app-debug.apk (debug-signed, installable with adb install)"
