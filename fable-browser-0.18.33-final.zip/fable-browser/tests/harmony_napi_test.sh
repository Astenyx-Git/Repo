#!/bin/sh
# The HarmonyOS shell's C glue (shell/harmony/entry/src/main/cpp/fable_napi.c)
# without the HarmonyOS SDK:
#   1. it compiles warning-free against a stand-in for napi/native_api.h
#      (tests/harmony/napi, Node-API signatures);
#   2. every fable_* function it calls is one the core exports;
#   3. what it registers for ArkTS is what libfable/index.d.ts declares.
# ArkTS itself needs DevEco Studio or the OpenHarmony SDK (scripts/build-harmony.sh).
set -eu
cd "$(dirname "$0")/.."
CC=${CC:-cc}
GLUE=shell/harmony/entry/src/main/cpp/fable_napi.c
DTS=shell/harmony/entry/src/main/cpp/types/libfable/index.d.ts
[ -f core/target/release/libfable_core.a ] || (cd core && cargo build -q --release)
W=$(mktemp -d)
trap 'rm -rf "$W"' EXIT
$CC -std=c11 -c -Wall -Wextra -Werror -Icore/include -Itests/harmony "$GLUE" -o "$W/glue.o"
nm "$W/glue.o" | awk '/ U fable_/{print $2}' | sort -u > "$W/called"
nm core/target/release/libfable_core.a 2>/dev/null | awk '/ T fable_/{print $3}' | sort -u > "$W/exported"
missing=$(comm -23 "$W/called" "$W/exported")
[ -z "$missing" ] || { echo "FAIL harmony_napi_test: the glue calls what the core does not export: $missing"; exit 1; }
sed -n 's/^ *{"\([A-Za-z0-9]*\)", NULL, n_.*/\1/p' "$GLUE" | sort > "$W/registered"
sed -n 's/^export const \([A-Za-z0-9]*\):.*/\1/p' "$DTS" | sort > "$W/declared"
if ! cmp -s "$W/registered" "$W/declared"; then
    echo "FAIL harmony_napi_test: registered (<) and declared in index.d.ts (>) differ:"; diff "$W/registered" "$W/declared"; exit 1
fi
echo "harmony_napi_test: the glue compiles, calls $(wc -l < "$W/called") core functions that exist, registers the $(wc -l < "$W/declared") index.d.ts declares"
