// The panel behind a desktop shell's asynchronous bridge (see tests/desktop_prelude.js).
(function () {
  var log = [];
  function q(sel) { return document.querySelector(sel); }
  function rows() { return [].slice.call(document.querySelectorAll('#body .row')); }
  function rowByText(t) { return rows().filter(function (r) { return r.textContent.indexOf(t) >= 0; })[0]; }
  function title() { return q('#title').textContent; }
  function check(name, ok) { log.push((ok ? 'ok   ' : 'FAIL ') + name); }
  function posted() { return window.__posted; }
  function last(prefix) { var p = posted().filter(function (m) { return m.indexOf(prefix) === 0; }); return p[p.length - 1]; }
  function lastAsk(name) { var p = posted().filter(function (m) { var f = m.split('\t'); return f[0] === 'q' && f[2] === name; }); return p.length ? p[p.length - 1].split('\t') : null; }
  function tiles() { return [].slice.call(document.querySelectorAll('#body .tile')); }

  check('desktop layout, and no preview: nothing is shown before the shell asks', document.documentElement.classList.contains('desk') && tiles().length === 0);

  var state = { tabs: [{ id: 1, title: 'Example', url: 'https://example.com/', active: true }], url: 'https://example.com/', title: 'Example', web: true, active: 1,
                incognito: false, blocked: 3, sniffed: 2, version: '0.10.0', platform: 'linux',
                caps: { screenshots: false, thirdPartyCookies: true, images: true }, settings: { block_trackers: '1', ua_mode: 'iphone' } };
  Fable.show('menu', state);
  var t = tiles();
  check('menu without the Android-only desktop-site tile', t.length === 8 && t.every(function (x) { return x.textContent.indexOf('桌面版') < 0; }));
  t[1].click();
  check('entering private mode is an action message', last('a\tenterPrivate') === 'a\tenterPrivate\t');

  Fable.show('settings', state);
  check('settings read from the snapshot without asking', rowByText('拦截追踪器').querySelector('.switch').className === 'switch on' && !lastAsk('get'));
  check('screenshot switch hidden where the shell cannot block screenshots', !rowByText('无痕模式截图') && !!rowByText('第三方 Cookie'));
  check('user agent row reads the snapshot', rowByText('UA').textContent.indexOf('iPhone') >= 0);
  check('desktops have the Home button switch too', !!rowByText('显示主页按钮'));
  check('desktops zoom pages instead of text, and have no phone-only display rows',
        !!rowByText('页面缩放') && !rowByText('文字大小') && !rowByText('屏幕方向') && !rowByText('屏幕常亮') && !rowByText('隐藏状态栏') && !rowByText('地址栏置于顶部'));
  rowByText('页面缩放').click();
  check('page zoom has its own title', title() === '页面缩放' && !!q('#body input[type=range]'));
  Fable.back();
  rowByText('拦截追踪器').click();
  var set = lastAsk('set');
  check('a change is sent as a request and kept locally', set && set[3] === 'block_trackers\n0' && state.settings.block_trackers === '0'
        && rowByText('拦截追踪器').querySelector('.switch').className === 'switch');
  rowByText('UA').click();
  check('no "desktop" user agent on a desktop', rows().length === 10 && !rowByText('桌面'));
  Fable.back();

  // History: drawn when the answer comes; a stale answer is ignored.
  Fable.show('history', state);
  var h1 = lastAsk('history');
  check('history is requested and nothing is drawn yet', h1 && h1[3] === '' && rows().length === 0);
  var input = q('#body input');
  input.value = 'git'; input.oninput();
  var h2 = lastAsk('history');
  Fable.reply(Number(h2[1]), JSON.stringify([{ t: Date.now(), u: 'https://github.com/', n: 'GitHub' }]));
  Fable.reply(Number(h1[1]), JSON.stringify([{ t: Date.now(), u: 'https://a.example/', n: 'Stale' }, { t: Date.now(), u: 'https://b.example/', n: 'Stale 2' }]));
  check('only the newest answer is drawn', rows().length === 1 && rows()[0].textContent.indexOf('GitHub') >= 0);
  rows()[0].querySelector('.icon-btn').click();
  check('deleting an entry asks first (0.18.15), and nothing is deleted yet', !lastAsk('historyDelete') && !!q('#body .btn') && q('#body .group').textContent.indexOf('GitHub') >= 0);
  q('#body .btn').click();   // 删除
  var del = lastAsk('historyDelete');
  check('deleting asks, then the list is asked for again', del && /\nhttps:\/\/github\.com\/$/.test(del[3]) && Number(lastAsk('history')[1]) < Number(del[1]));
  Fable.reply(Number(del[1]), '');
  check('…after the delete is done', Number(lastAsk('history')[1]) > Number(del[1]));

  Fable.show('menu', state);
  tiles().filter(function (x) { return x.textContent === '下载管理'; })[0].click();
  var downloads = lastAsk('downloads');
  Fable.reply(Number(downloads[1]), JSON.stringify([
    { id: '8', name: 'one.zip', state: 'active', bytes: 10, total: 20 },
    { id: '7', name: '<two>.zip', state: 'done' }
  ]));
  check('download rows show progress and the literal filename', rows().length === 2 &&
    rows()[0].textContent.indexOf('50%') >= 0 && rows()[1].textContent.indexOf('<two>.zip') >= 0);
  check('active downloads cannot be forgotten', !rows()[0].querySelector('.icon-btn'));
  rows()[1].querySelector('.icon-btn').click();
  var forget = lastAsk('downloadForget');
  check('forget uses the record ID', forget && forget[3] === '7');
  Fable.reply(Number(forget[1]), '');
  Fable.reply(Number(lastAsk('downloads')[1]), '[]');
  check('empty downloads list', !!q('#body .empty') && q('#body .empty').textContent === '暂无下载记录');

  // Resources: loading, then the list.
  Fable.show('sniff', state);
  var sn = lastAsk('sniff');
  check('resource list says it is loading', !!sn && q('#body .empty') && q('#body .empty').textContent === '读取中');
  Fable.reply(Number(sn[1]), JSON.stringify([{ k: 'video', u: 'https://cdn.example.com/a.mp4', e: 'mp4' }]));
  check('resource list drawn from the answer', rows().length === 1 && rows()[0].textContent.indexOf('a.mp4') >= 0);
  var asks = posted().length;
  q('#body .chip').click();
  check('filter chips redraw without asking again', posted().length === asks && rows().length === 1);
  Fable.refresh('sniff');
  check('a refresh from the shell asks again', posted().length === asks + 1 && lastAsk('sniff')[1] !== sn[1]);

  // Metadata: device facts arrive late; sections without data are left out.
  Fable.show('meta', state);
  var dev = lastAsk('device');
  check('metadata asks for device facts, the system facts and the IP', !!dev && !!last('a\tsystem') && !!last('a\tip'));
  Fable.reply(Number(dev[1]), JSON.stringify({ os: 'Ubuntu 24.04.1 LTS', engine: 'WebKitGTK 2.46.3', manufacturer: 'Framework', model: 'Laptop 13', ram: 17179869184 }));
  var text = q('#body').textContent;
  check('brief page shows the desktop OS and engine', text.indexOf('Ubuntu 24.04.1 LTS') >= 0 && text.indexOf('WebKitGTK 2.46.3') >= 0 && text.indexOf('Framework Laptop 13') >= 0);
  state.settings.meta_mode = 'detailed';
  Fable.show('meta', state);
  Fable.reply(Number(lastAsk('device')[1]), JSON.stringify({ os: 'Ubuntu 24.04.1 LTS', engine: 'WebKitGTK 2.46.3' }));
  Fable.system({ system: { os: 'Ubuntu 24.04.1 LTS', kernel: '6.8.0' }, cpu: { cores: 12, hardware: 'AMD Ryzen 7 7840U' }, memory: { total: 17179869184, avail: 9e9 },
                 storage: { total: 5e11, free: 2e11 }, network: { transports: ['wifi'], iface: 'wlp1s0' } });
  var cats = [].slice.call(document.querySelectorAll('#body .row.cat')).map(function (r) { return r.querySelector('b').textContent; });
  check('sections without data are left out', cats.indexOf('传感器与相机') < 0 && cats.indexOf('媒体与 DRM') < 0 && cats.indexOf('系统') >= 0 && cats.indexOf('处理器与图形') >= 0);
  check('system summary uses the desktop OS', rowByText('系统').textContent.indexOf('Ubuntu 24.04.1 LTS') >= 0);

  // Windows and macOS (0.18.17) report bookmarks like Linux: the star, the list, the file dialogs.
  Fable.show('menu', { tabs: [{ id: 1, title: 'Example', url: 'https://example.com/', active: true }], url: 'https://example.com/', title: 'Example', web: true, active: 1,
                       incognito: false, platform: 'windows', bookmarked: 0, caps: { thirdPartyCookies: false, bookmarks: true, restoreTabs: true }, settings: {}, version: '0.18.17' });
  var star = tiles().filter(function (x) { return x.textContent.indexOf('收藏本页') >= 0; })[0];
  check('the star and the bookmarks list are in the menu', !!star && tiles().some(function (x) { return x.textContent.indexOf('书签') >= 0 && x !== star; }));
  star.click();
  check('the star is an action for the shell', !!last('a\tbookmarkToggle'));
  Fable.show('bookmarks', { tabs: [], platform: 'windows', caps: { bookmarks: true, restoreTabs: true }, settings: {}, version: '0.18.17' });
  Fable.reply(Number(lastAsk('bookmarks')[1]), '[]');
  [].slice.call(document.querySelectorAll('#body .btn')).filter(function (x) { return x.textContent.indexOf('导入书签') >= 0; })[0].click();
  check('import opens the shell\'s file dialog', !!last('a\tbookmarkImportPick'));
  [].slice.call(document.querySelectorAll('#body .btn')).filter(function (x) { return x.textContent.indexOf('导出书签') >= 0; })[0].click();
  check('export too', !!last('a\tbookmarkExport'));

  // Private mode: dark, and exit is an action.
  Fable.show('menu', { tabs: [], incognito: true, platform: 'linux', settings: {}, version: '0.10.0' });
  check('private mode is dark on desktop too, keeping the desktop layout', document.documentElement.classList.contains('incog') && document.documentElement.classList.contains('desk'));
  tiles()[1].click();
  check('exit private is an action, and closing the panel is immediate', !!last('a\texitPrivate') && last('a\thidden') === 'a\thidden\t');

  return log.join('\n');
})();
