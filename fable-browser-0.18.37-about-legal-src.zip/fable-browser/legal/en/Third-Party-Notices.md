# Fable Browser Third-Party Components and Materials Statement

Version: V1.2
Effective Date: November 25, 2026

Licensor: Fable browser team (Contact Email: [fable-browser-team@astermail.org](mailto:fable-browser-team@astermail.org))

---

## 1. Introduction

This Statement lists the sources, licenses, and ownership of third-party materials, components, and lists used or relied upon by Fable Browser. This Statement is an integral part of the End User License Agreement.

## 2. Icon Materials

The following interface icons are from the Google Material Symbols project, used under the **Apache License 2.0**:

- Home button icon "home" (outlined), used for interfaces on Android, HarmonyOS, and other platforms;
- Refresh button icon "refresh" (outlined), used for interfaces on Android, HarmonyOS, and other platforms;
- Search/find icon "search" (outlined), used for interfaces on Android, HarmonyOS, and the shared panel;
- Scan button icon "qr_code_scanner" (outlined), used for scan entry points on various platforms.

Source: [https://github.com/google/material-design-icons](https://github.com/google/material-design-icons) (Apache License 2.0, full license text at [https://www.apache.org/licenses/LICENSE-2.0](https://www.apache.org/licenses/LICENSE-2.0))

## 3. Blocklists

**3.1 Built-in Default Lists (Distributed offline with the app)**: This software comes with an ad domain list (`ads.txt`) and a tracking domain list (`trackers.txt`) maintained by the project itself, distributed offline with the installation package. These two lists are proprietary content of this project.

**3.2 List Update Sources (EasyList and EasyPrivacy)**: When the ad block switch is on, the app will check once a week upon startup and automatically pull the EasyList and EasyPrivacy community lists from easylist.to (no traffic is generated when the switch is off). According to the EasyList official license page ([https://easylist.to/pages/licence.html](https://easylist.to/pages/licence.html)):

> Unless otherwise noted, the contents of the EasyList repository are dual licensed under the GNU General Public License version 3 of the License, or (at your option) any later version, and Creative Commons Attribution-ShareAlike 3.0 Unported, or (at your option) any later version. You may use and/or modify the files as permitted by either licence; if required, "The EasyList authors ([https://easylist.to/](https://easylist.to/))" should be attributed as the source of the material.

This software pulls and parses the above lists locally for blocking and does not redistribute the list files externally. If subsequent versions package the list files directly into the installation package for redistribution, corresponding obligations (such as attribution and providing under the same license) shall be fulfilled according to the license chosen at that time.

## 4. System Web Engines (Built-in to each platform, not part of this software)

This software does not have a built-in web rendering engine; web content is loaded by the web engine provided by your platform system. Each engine belongs to its respective rights holder:

- **Android**: System WebView (Chromium core, Google / Chromium project)
- **HarmonyOS**: ArkWeb (Huawei)
- **iOS / iPadOS / macOS**: WKWebView (Apple WebKit)
- **Windows**: WebView2 (Microsoft Edge)
- **Linux**: WebKitGTK (GNOME Project)
- **Sailfish OS**: Sailfish WebView (Gecko / embedlite)

The names and trademarks of the above engines belong to their respective rights holders; there is no affiliation or endorsement between this software and the respective platform vendors arising from the use of the system engines.

## 5. Third-Party Names and Logos in Interface Skins

The built-in skins of this software can switch to display names, logos, or stylized graphics of certain third-party brands. The rights to such names, logos, and graphics belong to their respective rights holders; this software does not claim rights to them, and their presentation does not constitute affiliation, recognition, or endorsement. If relevant rights holders have any objections, they can provide feedback via the contact information listed in Article 13.3 of the End User License Agreement.

## 6. Other Links and Components

- The Wikipedia shortcut on the new tab page is an external link pointing to the corresponding language version of wikipedia.org and does not constitute embedding or reproduction of its content.
- A complete statement list of third-party code components introduced with the compilation toolchain in the binary files of this software (such as the Rust standard library, MIT / Apache-2.0 dual license; quircs QR decoding library, ISC license) will be automatically generated and appended to the end of this document in the final build artifacts.
