#!/bin/sh
# Installs the Rust toolchain CI builds with: a pinned rustup-init, checked
# against its SHA-256 before it runs, installing a pinned toolchain (rustup
# itself verifies the toolchain's downloads against the release manifest).
# Replaces `curl https://sh.rustup.rs | sh`, which ran whatever the network
# returned and installed whatever "stable" was that day.
#
# To move to newer versions: change the channel in rust-toolchain.toml, or the
# rustup version below and take the hashes
# from https://static.rust-lang.org/rustup/archive/<version>/<target>/rustup-init.sha256
# (and check them against the downloaded file).
set -eu
cd "$(dirname "$0")/../.."
RUSTUP_VERSION=1.29.3
# The toolchain: the one rust-toolchain.toml names, so local builds with
# rustup and CI use the same compiler.
RUST_VERSION=$(sed -n 's/^channel *= *"\([0-9][0-9.]*\)".*/\1/p' rust-toolchain.toml)
[ -n "$RUST_VERSION" ] || { echo "install-rust.sh: no pinned channel in rust-toolchain.toml" >&2; exit 1; }

case "$(uname -s)-$(uname -m)" in
    Darwin-arm64)  TARGET=aarch64-apple-darwin;     SHA256=63752a1919a3a4793173ec70f8f212621a7ce38ba6a246095984482f4de20f9f ;;
    Darwin-x86_64) TARGET=x86_64-apple-darwin;      SHA256=bc107f1fb0228de7fa32413c89c1b305cea9cd256e94b01150cd054128145429 ;;
    Linux-x86_64)  TARGET=x86_64-unknown-linux-gnu; SHA256=b1c8cb14e30889e7e2999e6b69e62d9e9b9ffc0f4df8180564d306d9680e6c55 ;;
    *) echo "install-rust.sh: no pinned rustup-init for $(uname -s)-$(uname -m)" >&2; exit 1 ;;
esac

tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
curl --proto '=https' --tlsv1.2 -sSf -o "$tmp/rustup-init" \
    "https://static.rust-lang.org/rustup/archive/$RUSTUP_VERSION/$TARGET/rustup-init"
if command -v sha256sum >/dev/null 2>&1; then
    got=$(sha256sum "$tmp/rustup-init" | cut -d' ' -f1)
else
    got=$(shasum -a 256 "$tmp/rustup-init" | cut -d' ' -f1)
fi
if [ "$got" != "$SHA256" ]; then
    echo "install-rust.sh: rustup-init checksum mismatch: got $got, want $SHA256" >&2
    exit 1
fi
chmod +x "$tmp/rustup-init"
"$tmp/rustup-init" -y --no-modify-path --profile minimal --default-toolchain "$RUST_VERSION"

BIN=${CARGO_HOME:-$HOME/.cargo}/bin
"$BIN/rustup" default "$RUST_VERSION"
version=$("$BIN/rustc" --version)
case "$version" in
    "rustc $RUST_VERSION "*) echo "install-rust.sh: $version" ;;
    *) echo "install-rust.sh: expected rustc $RUST_VERSION, got: $version" >&2; exit 1 ;;
esac
