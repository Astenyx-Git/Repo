// Scan a QR code with the system camera. AVFoundation detects QR on its own
// (no decoder to bundle): the shell shows this screen and hands the text back.
import AVFoundation
import UIKit

final class QRScannerViewController: UIViewController, AVCaptureMetadataOutputObjectsDelegate {
    /// Called with the scanned text once this screen has closed.
    var onResult: (String) -> Void = { _ in }

    private let session = AVCaptureSession()
    private let frame = UIView()            // the viewfinder square
    private let titleLabel = UILabel()
    private let hintLabel = UILabel()
    private let cancelButton = UIButton(type: .system)
    private var found = false

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black

        let preview = AVCaptureVideoPreviewLayer(session: session)
        preview.videoGravity = .resizeAspectFill
        preview.frame = view.bounds
        view.layer.insertSublayer(preview, at: 0)

        frame.layer.borderColor = Palette.spark.cgColor
        frame.layer.borderWidth = 2
        frame.layer.cornerRadius = 16
        view.addSubview(frame)

        titleLabel.text = Core.tr("scan_title")
        titleLabel.textColor = .white
        titleLabel.font = .systemFont(ofSize: 20, weight: .semibold)
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(titleLabel)

        hintLabel.text = Core.tr("scan_hint")
        hintLabel.textColor = UIColor.white.withAlphaComponent(0.85)
        hintLabel.font = .systemFont(ofSize: 15)
        hintLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(hintLabel)

        cancelButton.setTitle(Core.tr("cancel"), for: .normal)
        cancelButton.setTitleColor(.white, for: .normal)
        cancelButton.titleLabel?.font = .systemFont(ofSize: 17)
        cancelButton.addTarget(self, action: #selector(cancelTapped), for: .touchUpInside)
        cancelButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(cancelButton)

        NSLayoutConstraint.activate([
            titleLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            hintLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            hintLabel.topAnchor.constraint(equalTo: frame.bottomAnchor, constant: 16),
            cancelButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            cancelButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -24),
        ])
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        for layer in view.layer.sublayers ?? [] where layer is AVCaptureVideoPreviewLayer {
            layer.frame = view.bounds   // keep the preview filling the screen
        }
        let side = min(view.bounds.width, view.bounds.height) * 0.7
        frame.frame = CGRect(x: (view.bounds.width - side) / 2, y: (view.bounds.height - side) / 2, width: side, height: side)
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        startIfAuthorized()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        session.stopRunning()
    }

    // ---- camera ----

    private func startIfAuthorized() {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            start()
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { [weak self] ok in
                DispatchQueue.main.async { guard let self = self else { return }; if ok { self.start() } else { self.dismiss(animated: true) } }
            }
        default:
            dismiss(animated: true)   // denied or restricted: nothing to see
        }
    }

    private func start() {
        guard !session.isRunning,
              let device = AVCaptureDevice.default(for: .video),
              let input = try? AVCaptureDeviceInput(device: device),
              session.canAddInput(input) else {
            dismiss(animated: true)   // no camera here (the Simulator): close
            return
        }
        session.beginConfiguration()
        session.addInput(input)
        let output = AVCaptureMetadataOutput()
        if session.canAddOutput(output) {
            session.addOutput(output)
            output.setMetadataObjectsDelegate(self, queue: .main)
            output.metadataObjectTypes = [.qr]
        }
        session.commitConfiguration()
        session.startRunning()
    }

    // ---- QR results ----

    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        guard !found else { return }
        for object in metadataObjects {
            guard let code = object as? AVMetadataMachineReadableCodeObject,
                  code.type == .qr,
                  let text = code.stringValue,
                  !text.isEmpty else { continue }
            found = true
            session.stopRunning()
            dismiss(animated: true) { self.onResult(text) }
            return
        }
    }

    @objc private func cancelTapped() {
        session.stopRunning()
        dismiss(animated: true)
    }
}