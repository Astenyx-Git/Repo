//! The WebKit, WebView2 and ArkWeb shells send their normal-mode download events here.
use super::{escape, json_string, store, unescape, Store};
use std::{fs, io, sync::LazyLock, time::SystemTime};

static SESSION: LazyLock<String> = LazyLock::new(|| {
    let start = SystemTime::now().duration_since(SystemTime::UNIX_EPOCH).unwrap_or_default();
    format!("running-{}-{}", std::process::id(), start.as_nanos())
});

pub(super) struct Downloads {
    next_id: u32,
    rows: Vec<Record>, // oldest first
}

struct Record {
    id: u32,
    name: String,
    status: String,
}

impl Record {
    fn state(&self) -> &str {
        if self.status == *SESSION { "active" }
        else if self.status.starts_with("running-") { "unknown" }
        else { &self.status }
    }
}

impl Downloads {
    pub(super) const fn new() -> Self { Self { next_id: 0, rows: Vec::new() } }

    fn load(text: &str) -> Self {
        let mut list = Self::new();
        let mut lines = text.lines();
        list.next_id = lines.next().and_then(|v| v.parse().ok()).unwrap_or(0);
        for line in lines {
            let mut fields = line.splitn(3, '\t');
            let Some(id) = fields.next().and_then(|s| s.parse::<u32>().ok()) else { continue };
            let (Some(status), Some(name)) = (fields.next(), fields.next()) else { continue };
            list.rows.push(Record { id, name: unescape(name), status: status.into() });
            list.next_id = list.next_id.max(id);
        }
        list
    }

    fn text(&self) -> String {
        let mut text = format!("{}\n", self.next_id);
        for r in &self.rows {
            text.push_str(&format!("{}\t{}\t{}\n", r.id, r.status, escape(&r.name)));
        }
        text
    }

    fn json(&self) -> String {
        let rows: Vec<_> = self.rows.iter().rev().map(|r| {
            format!(r#"{{"id":"{}","name":{},"state":{}}}"#, r.id, json_string(&r.name), json_string(r.state()))
        }).collect();
        format!("[{}]", rows.join(","))
    }
}

impl Store {
    // Two desktop processes can share a profile. Hold a separate lock file across
    // read/modify/rename, so finishing one transfer cannot overwrite another.
    fn download_edit<T>(&mut self, edit: impl FnOnce(&mut Downloads) -> Option<T>) -> Option<T> {
        let Some(path) = self.path("downloads.tsv") else { return edit(&mut self.downloads) };
        let lock = fs::OpenOptions::new().create(true).truncate(false).read(true).write(true)
            .open(path.with_extension("lock")).ok()?;
        lock.lock().ok()?;
        let mut list = match fs::read_to_string(&path) {
            Ok(text) => Downloads::load(&text),
            Err(e) if e.kind() == io::ErrorKind::NotFound => Downloads::new(),
            Err(_) => return None,
        };
        let result = edit(&mut list)?;
        self.write_atomic("downloads.tsv", &list.text()).ok()?;
        Some(result)
    }
}

pub fn begin(name: &str) -> u32 {
    store().download_edit(|list| {
        let id = list.next_id.checked_add(1)?;
        list.next_id = id;
        list.rows.push(Record { id, name: name.into(), status: SESSION.clone() });
        Some(id)
    }).unwrap_or(0)
}

pub fn finish(id: u32, ok: bool) {
    if id == 0 { return; }
    store().download_edit(|list| {
        let row = list.rows.iter_mut().find(|r| r.id == id && r.state() == "active")?;
        row.status = if ok { "done" } else { "failed" }.into();
        Some(())
    });
}

pub fn list() -> String {
    let s = store();
    let Some(path) = s.path("downloads.tsv") else { return s.downloads.json() };
    match fs::read_to_string(path) {
        Ok(text) => Downloads::load(&text).json(),
        Err(e) if e.kind() == io::ErrorKind::NotFound => "[]".into(),
        Err(_) => String::new(),
    }
}

pub fn forget(id: u32) -> bool {
    store().download_edit(|list| {
        let index = list.rows.iter().position(|r| r.id == id && r.state() != "active")?;
        list.rows.remove(index);
        Some(())
    }).is_some()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn reopening_keeps_names_and_does_not_guess_another_engines_state() {
        let text = "7\n1\tdone\ta\\tb\n2\trunning-old-session\tsame.zip\n3\tfailed\tsame.zip\n";
        let d = Downloads::load(text);
        assert_eq!(d.next_id, 7);
        assert_eq!(d.rows[0].name, "a\tb");
        assert_eq!(d.rows[1].state(), "unknown");
        assert_eq!(d.text(), text);
    }

    #[test]
    fn stores_in_the_same_directory_merge_changes_and_persist_removals() {
        let dir = super::super::tests::temp_dir();
        let mut a = Store::open(&dir);
        let mut b = Store::open(&dir);
        for store in [&mut a, &mut b] {
            store.download_edit(|d| {
                d.next_id += 1;
                d.rows.push(Record { id: d.next_id, name: "report".into(), status: "done".into() });
                Some(())
            }).unwrap();
        }
        b.download_edit(|d| { d.rows.remove(0); Some(()) }).unwrap();
        let json = Downloads::load(&a.read("downloads.tsv")).json();
        assert_eq!(json, r#"[{"id":"2","name":"report","state":"done"}]"#);
        fs::remove_dir_all(dir).unwrap();
    }
}
