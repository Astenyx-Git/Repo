use fable_core::qr::decode_luma_plane;

// Raw grayscale camera frames. The symbols were independently encoded with libqrencode:
// version 1, level M, byte mode; and version 7, level Q, mixed alphanumeric/numeric.
const BINARY: &[u8] = include_bytes!("../../tests/qr/binary-87x87.y8");
const PERSPECTIVE: &[u8] = include_bytes!("../../tests/qr/perspective-212x210.y8");
const PAYLOAD: &[u8] = b"Fable\x00\xff\x80\xe6\x89\xab\xe7\xa0\x81";

#[test]
fn decodes_projected_symbol() {
    // The frame includes a slight rotation, keystone distortion and interpolated gray edges.
    assert_eq!(
        decode_luma_plane(PERSPECTIVE, 212, 210, 212, 1).as_deref(),
        Some(b"QR MODEL 2 / VERSION 7 / 123456789012345678901234567890".as_slice()),
    );
}

#[test]
fn decodes_rotated_strided_camera_plane_with_a_damaged_module() {
    let side = 87;
    let pixel_stride = 2;
    let row_stride = side * pixel_stride + 9;
    // Like Android image buffers, the last row ends at the last sample, before padding.
    let length = (side - 1) * row_stride + (side - 1) * pixel_stride + 1;
    let mut plane = vec![127; length];
    for y in 0..side {
        for x in 0..side {
            let mut sample = BINARY[y * side + x];
            // Flip the bottom-right data module of the 21x21 symbol (three pixels per module).
            if (72..75).contains(&x) && (72..75).contains(&y) {
                sample = 255 - sample;
            }
            plane[x * row_stride + (side - 1 - y) * pixel_stride] = sample;
        }
    }
    assert_eq!(decode_luma_plane(&plane, side, side, row_stride, pixel_stride).as_deref(), Some(PAYLOAD));
    assert!(decode_luma_plane(&plane[..length - 1], side, side, row_stride, pixel_stride).is_none());
}

#[test]
fn rejects_invalid_layouts_and_frames_without_a_symbol() {
    assert!(decode_luma_plane(BINARY, 87, 87, 86, 1).is_none());
    assert!(decode_luma_plane(BINARY, 87, 87, 87, 0).is_none());
    assert!(decode_luma_plane(BINARY, 0, 87, 87, 1).is_none());
    assert!(decode_luma_plane(BINARY, usize::MAX, 2, usize::MAX, 2).is_none());
    assert!(decode_luma_plane(&[255; 87 * 87], 87, 87, 87, 1).is_none());
}
