// Site icons for the new-tab page's shortcuts, kept as small PNG files per
// host, so the page shows them at once instead of an empty tile. Icons come
// from pages the user visited (their favicon) or, for a shortcut never
// visited, from the site's /favicon.ico, fetched without cookies.
import { fileIo } from '@kit.CoreFileKit';
import { image } from '@kit.ImageKit';
import { http } from '@kit.NetworkKit';
import { util } from '@kit.ArkTS';
import { BusinessError } from '@kit.BasicServicesKit';

const ICON_SIZE: number = 64;

export class FableIcons {
  private dir: string;
  private uris: Map<string, string> = new Map<string, string>();   // host -> data: URI, '' when known to be missing
  private fetching: Set<string> = new Set<string>();
  private userAgent: string;
  version: number = 0;                                              // bumps whenever an icon is added or cleared

  constructor(dir: string, userAgent: string) {
    this.dir = dir;
    this.userAgent = userAgent;
    try {
      fileIo.mkdirSync(dir, true);
    } catch (e) {
      // exists already
    }
  }

  static hostOf(url: string): string {
    const match: RegExpMatchArray | null = url.match(new RegExp('^[a-z][a-z0-9+.-]*://([^/?#:]+)', 'i'));
    return match !== null && match.length > 1 ? match[1].toLowerCase() : '';
  }

  private fileOf(host: string): string {
    return this.dir + '/' + host.replace(new RegExp('[^a-z0-9.-]', 'g'), '_') + '.png';
  }

  /** The stored PNG, or undefined. */
  get(host: string): ArrayBuffer | undefined {
    if (host.length === 0) {
      return undefined;
    }
    const path: string = this.fileOf(host);
    try {
      if (!fileIo.accessSync(path)) {
        return undefined;
      }
      const size: number = fileIo.statSync(path).size;
      const buffer: ArrayBuffer = new ArrayBuffer(size);
      const file: fileIo.File = fileIo.openSync(path, fileIo.OpenMode.READ_ONLY);
      fileIo.readSync(file.fd, buffer);
      fileIo.closeSync(file);
      return buffer;
    } catch (e) {
      return undefined;
    }
  }

  dataUri(host: string): string {
    const known: string | undefined = this.uris.get(host);
    if (known !== undefined) {
      return known;
    }
    const png: ArrayBuffer | undefined = this.get(host);
    let uri: string = '';
    try {
      uri = png === undefined ? '' : 'data:image/png;base64,' + new util.Base64Helper().encodeToStringSync(new Uint8Array(png));
    } catch (e) {
      uri = '';
    }
    if (uri.length > 0) {
      this.uris.set(host, uri);
    }
    return uri;
  }

  /** {"host": [dataUri, width]} for the hosts that have an icon: the new-tab page's own copy. */
  bundle(hosts: string[]): string {
    const parts: string[] = [];
    for (const host of hosts) {
      const uri: string = this.dataUri(host);
      if (uri.length > 0) {
        parts.push(JSON.stringify(host) + ':[' + JSON.stringify(uri) + ',' + ICON_SIZE + ']');
      }
    }
    return '{' + parts.join(',') + '}';
  }

  private save(host: string, png: ArrayBuffer): void {
    try {
      const file: fileIo.File = fileIo.openSync(this.fileOf(host),
        fileIo.OpenMode.CREATE | fileIo.OpenMode.WRITE_ONLY | fileIo.OpenMode.TRUNC);
      fileIo.writeSync(file.fd, png);
      fileIo.closeSync(file);
      this.uris.delete(host);
      this.version++;
    } catch (e) {
      // a full disk only costs the icon
    }
  }

  /** A favicon the web view reported for a page in a normal tab. */
  offer(host: string, icon: image.PixelMap): void {
    if (host.length === 0 || this.get(host) !== undefined) {
      return;
    }
    const packer: image.ImagePacker = image.createImagePacker();
    const options: image.PackingOption = { format: 'image/png', quality: 100 };
    packer.packToData(icon, options).then((png: ArrayBuffer): void => {
      this.save(host, png);
      packer.release();
    }).catch((e: BusinessError): void => {
      packer.release();
    });
  }

  /** Fetch a shortcut's icon in the background; the new-tab page asks again shortly. */
  request(origin: string): void {
    const host: string = FableIcons.hostOf(origin);
    if (host.length === 0 || this.fetching.has(host) || this.get(host) !== undefined) {
      return;
    }
    this.fetching.add(host);
    const client: http.HttpRequest = http.createHttp();
    const headers: Record<string, string> = { 'User-Agent': this.userAgent, 'Accept': 'image/*' };
    const options: http.HttpRequestOptions = {
      method: http.RequestMethod.GET,
      header: headers,
      expectDataType: http.HttpDataType.ARRAY_BUFFER,
      connectTimeout: 10000,
      readTimeout: 10000,
      usingCache: false
    };
    client.request('https://' + host + '/favicon.ico', options).then((reply: http.HttpResponse): Promise<image.PixelMap> => {
      client.destroy();
      if (reply.responseCode !== 200 || !(reply.result instanceof ArrayBuffer)) {
        throw new Error('no icon');
      }
      const source: image.ImageSource = image.createImageSource(reply.result as ArrayBuffer);
      const decode: image.DecodingOptions = { desiredSize: { width: ICON_SIZE, height: ICON_SIZE } };
      return source.createPixelMap(decode);
    }).then((icon: image.PixelMap): void => {
      this.fetching.delete(host);
      this.offer(host, icon);
    }).catch((e: Error): void => {
      client.destroy();
      this.fetching.delete(host);
    });
  }

  clear(): void {
    try {
      for (const name of fileIo.listFileSync(this.dir)) {
        fileIo.unlinkSync(this.dir + '/' + name);
      }
    } catch (e) {
      // nothing stored
    }
    this.uris.clear();
    this.version++;
  }
}
