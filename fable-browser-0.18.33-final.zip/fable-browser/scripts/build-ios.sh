#!/bin/sh
# Builds the iOS app (shell/ios) or just its Rust core. The app needs a Mac with:
#   - Xcode 15 or later                   https://developer.apple.com/xcode/
#   - Rust                                https://rustup.rs (the iOS targets are added below)
# Usage:
#   scripts/build-ios.sh            core + app for the Simulator (unsigned, Debug)
#   scripts/build-ios.sh device     core + app for an iPhone/iPad (Release); needs
#                                   DEVELOPMENT_TEAM=<your team id> for automatic signing
#   scripts/build-ios.sh core       the core only: build/ios/<sdk>/libfable_core.a, one per SDK
#                                   (the Simulator's holds arm64 and x86_64). Xcode's first build
#                                   phase runs this; it also runs on Linux, with clang + llvm-ar
#                                   on PATH for the assembly hash (else the portable Rust hash).
# Or open shell/ios/Fable.xcodeproj in Xcode, pick a team under Signing, and Run.
set -eu
cd "$(dirname "$0")/.."
OUT=build/ios
MIN=15.0
MODE=${1:-simulator}

# Build phases run with Xcode's environment: put cargo on PATH, and drop the
# iOS SDKROOT, which would break the host build of the core's build script.
PATH="$HOME/.cargo/bin:$PATH"
unset SDKROOT
export IPHONEOS_DEPLOYMENT_TARGET=$MIN
command -v cargo >/dev/null || { echo "Rust is missing: https://rustup.rs" >&2; exit 1; }
DARWIN=0
[ "$(uname -s)" = Darwin ] && DARWIN=1

# The assembler driver for native/fnv1a_<arch>.S: Xcode's clang on a Mac, any
# clang elsewhere (clang writes Mach-O objects for any target).
asm_tools() {   # $1: clang target triple; prints "cc|ar" or nothing
    if [ "${FABLE_NO_ASM:-0}" = 1 ]; then return; fi
    if [ $DARWIN = 1 ]; then
        case $1 in *-simulator) kit=iphonesimulator ;; *) kit=iphoneos ;; esac
        echo "xcrun --sdk $kit clang -target $1|xcrun ar"
    elif command -v "${CLANG:-clang}" >/dev/null && command -v "${LLVM_AR:-llvm-ar}" >/dev/null; then
        echo "${CLANG:-clang} --target=$1|${LLVM_AR:-llvm-ar}"
    fi
}

core_for() {   # $1: iphoneos | iphonesimulator, $2: architectures
    sdk=$1 libs=""
    for arch in $2; do
        case "$sdk:$arch" in
            iphoneos:arm64)         triple=aarch64-apple-ios;     target=arm64-apple-ios$MIN ;;
            iphonesimulator:arm64)  triple=aarch64-apple-ios-sim; target=arm64-apple-ios$MIN-simulator ;;
            iphonesimulator:x86_64) triple=x86_64-apple-ios;      target=x86_64-apple-ios$MIN-simulator ;;
            *) echo "build-ios.sh: no Rust target for $arch on $sdk" >&2; exit 1 ;;
        esac
        rustup target add "$triple" >/dev/null 2>&1 || true
        tools=$(asm_tools "$target")
        if [ -n "$tools" ]; then
            (cd core && FABLE_CC="${tools%%|*}" FABLE_AR="${tools#*|}" cargo build --release --features asm --target "$triple")
        else
            (cd core && cargo build --release --target "$triple")
        fi
        libs="$libs core/target/$triple/release/libfable_core.a"
    done
    mkdir -p "$OUT/$sdk"
    set -- $libs
    if [ $# -gt 1 ] && command -v lipo >/dev/null; then
        lipo -create "$@" -output "$OUT/$sdk/libfable_core.a.new"
    else
        [ $# -gt 1 ] && echo "build-ios.sh: no lipo here; $OUT/$sdk gets $1 only" >&2
        cp "$1" "$OUT/$sdk/libfable_core.a.new"
    fi
    # Same bytes: keep the old file, so Xcode does not relink for nothing.
    if cmp -s "$OUT/$sdk/libfable_core.a.new" "$OUT/$sdk/libfable_core.a"; then rm "$OUT/$sdk/libfable_core.a.new"
    else mv "$OUT/$sdk/libfable_core.a.new" "$OUT/$sdk/libfable_core.a"; fi
}

case $MODE in
    core)
        if [ -n "${PLATFORM_NAME:-}" ]; then   # from Xcode: just what this build needs
            core_for "$PLATFORM_NAME" "${ARCHS:-arm64}"
        else
            core_for iphoneos arm64
            core_for iphonesimulator "arm64 x86_64"
        fi
        ls -l "$OUT"/*/libfable_core.a
        exit 0 ;;
    simulator|device) ;;
    *) echo "usage: scripts/build-ios.sh [simulator|device|core]" >&2; exit 2 ;;
esac

[ $DARWIN = 1 ] || { echo "The app needs Xcode on a Mac; here only 'scripts/build-ios.sh core' works." >&2; exit 1; }
command -v xcodebuild >/dev/null || { echo "Xcode is missing: https://developer.apple.com/xcode/" >&2; exit 1; }
# The project's first build phase builds the core for the SDK and architectures at hand.
if [ "$MODE" = simulator ]; then
    xcodebuild -project shell/ios/Fable.xcodeproj -scheme Fable -configuration Debug \
        -destination 'generic/platform=iOS Simulator' -derivedDataPath "$OUT/DerivedData" \
        CODE_SIGNING_ALLOWED=NO build
    APP=$OUT/DerivedData/Build/Products/Debug-iphonesimulator/Fable.app
    echo "App: $APP"
    echo "Run it: open -a Simulator; xcrun simctl install booted $APP && xcrun simctl launch booted app.fable.browser"
else
    [ -n "${DEVELOPMENT_TEAM:-}" ] || { echo "Signing for a device needs DEVELOPMENT_TEAM=<team id> (Xcode > Settings > Accounts)." >&2; exit 1; }
    xcodebuild -project shell/ios/Fable.xcodeproj -scheme Fable -configuration Release \
        -destination 'generic/platform=iOS' -derivedDataPath "$OUT/DerivedData" \
        -allowProvisioningUpdates DEVELOPMENT_TEAM="$DEVELOPMENT_TEAM" build
    APP=$OUT/DerivedData/Build/Products/Release-iphoneos/Fable.app
    echo "App: $APP"
    echo "Install it: xcrun devicectl device install app --device <device id> $APP (or Run from Xcode)"
fi
