import QtQuick 2.0
import Sailfish.Silica 1.0
import Sailfish.WebEngine 1.0
import harbour.fable.Core 1.0
import "pages"
import "cover"

ApplicationWindow {
    id: app

    property Item browser: null        // the BrowserPage, for the cover's actions

    initialPage: Fable.panelQuery("legalAccepted", "", 0) === "true" ? browserComponent : licenseComponent
    Component {
        id: licenseComponent
        Page {
            Column {
                anchors.fill: parent
                PageHeader { title: "EULA" }
                Flickable {
                    width: parent.width
                    height: Math.max(0, parent.height - y - agree.height - Theme.paddingLarge)
                    contentHeight: terms.height
                    clip: true
                    Label {
                        id: terms
                        x: Theme.horizontalPageMargin
                        width: parent.width - 2 * x
                        wrapMode: Text.Wrap
                        textFormat: Text.PlainText
                        text: Fable.panelQuery("legalText", "", 0)
                    }
                }
                Button {
                    id: agree
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: Fable.tr("eula_agree")
                    onClicked: {
                        Fable.panelQuery("legalAccept", "", 0);
                        pageStack.replace(browserComponent);
                    }
                }
            }
        }
    }
    Component {
        id: browserComponent
        BrowserPage {
            id: browserPage
            Component.onCompleted: app.browser = browserPage
        }
    }
    cover: Component {
        CoverPage {
            title: app.browser ? app.browser.coverTitle : Fable.tr("brand_name")
            onNewTab: {
                if (app.browser) app.browser.openTab("", false);
                app.activate();
            }
            onReloadPage: if (app.browser) app.browser.reloadPage()
        }
    }
    allowedOrientations: defaultAllowedOrientations

    // The settings Sailfish's WebView takes engine-wide (WebEngineSettings), for
    // web pages and Fable's own pages alike. JavaScript is not among them: the
    // panel is JavaScript, so the panel leaves that switch out (caps.javascript).
    function applySettings() {
        WebEngineSettings.autoLoadImages = Fable.settingGet("data_saver") !== "1";
        WebEngineSettings.cookieBehavior = Fable.settingGet("block_3p_cookies") === "0"
            ? WebEngineSettings.AcceptAll : WebEngineSettings.BlockThirdParty;
        try {
            WebEngineSettings.colorScheme = WebEngineSettings.FollowsAmbience;   // newer Sailfish OS releases
        } catch (e) {}
    }

    Connections {
        target: Panel
        onSettingChanged: {
            if (key === "data_saver" || key === "block_3p_cookies") app.applySettings();
        }
    }

    Component.onCompleted: applySettings()
}
