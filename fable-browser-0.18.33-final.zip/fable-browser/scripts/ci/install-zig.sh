#!/bin/sh
# Installs the Zig compiler the native layer is built with (native/hostset.zig,
# build.zig): a pinned release, checked against its SHA-256 before it is
# unpacked. Prints the folder holding the `zig` binary.
#
#   ZIG_DIR=<folder>  where to put it (default: $HOME/.zig)
#
# To move to a newer Zig: change the version and take the hashes from
# https://ziglang.org/download/index.json (and check them against the files).
set -eu
ZIG_VERSION=0.14.1
case "$(uname -s)-$(uname -m)" in
    Darwin-arm64)  PLATFORM=aarch64-macos; SHA256=39f3dc5e79c22088ce878edc821dedb4ca5a1cd9f5ef915e9b3cc3053e8faefa ;;
    Darwin-x86_64) PLATFORM=x86_64-macos;  SHA256=b0f8bdfb9035783db58dd6c19d7dea89892acc3814421853e5752fe4573e5f43 ;;
    Linux-x86_64)  PLATFORM=x86_64-linux;  SHA256=24aeeec8af16c381934a6cd7d95c807a8cb2cf7df9fa40d359aa884195c4716c ;;
    *) echo "install-zig.sh: no pinned Zig for $(uname -s)-$(uname -m)" >&2; exit 1 ;;
esac
DIR=${ZIG_DIR:-$HOME/.zig}
NAME=zig-$PLATFORM-$ZIG_VERSION
if [ ! -x "$DIR/$NAME/zig" ]; then
    mkdir -p "$DIR"
    tmp=$(mktemp -d)
    trap 'rm -rf "$tmp"' EXIT
    curl --proto '=https' --tlsv1.2 -sSf -o "$tmp/zig.tar.xz" "https://ziglang.org/download/$ZIG_VERSION/$NAME.tar.xz"
    if command -v sha256sum >/dev/null 2>&1; then got=$(sha256sum "$tmp/zig.tar.xz" | cut -d' ' -f1)
    else got=$(shasum -a 256 "$tmp/zig.tar.xz" | cut -d' ' -f1); fi
    [ "$got" = "$SHA256" ] || { echo "install-zig.sh: checksum mismatch: got $got, want $SHA256" >&2; exit 1; }
    tar -xJf "$tmp/zig.tar.xz" -C "$DIR"
fi
version=$("$DIR/$NAME/zig" version)
[ "$version" = "$ZIG_VERSION" ] || { echo "install-zig.sh: expected Zig $ZIG_VERSION, got $version" >&2; exit 1; }
echo "$DIR/$NAME"
