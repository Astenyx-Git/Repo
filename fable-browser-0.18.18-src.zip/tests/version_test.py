#!/usr/bin/env python3
"""Every place that carries the version agrees, and a release commit carries
the version its subject names.

0.18.4 was committed as "0.18.4: ..." while every file still said 0.18.3 (and
versionCode 32), so that build never existed under its name. This check makes
that impossible to miss:

  python3 tests/version_test.py              the working tree (make test)
  python3 tests/version_test.py --commit REV a commit: its files, and its subject if it is "X.Y.Z: ..."
  python3 tests/version_test.py --message F  a commit message about to be made (scripts/hooks/commit-msg)

The same versionCode is used by Android, HarmonyOS and iOS (CURRENT_PROJECT_VERSION).
Also checked: the Rust release (rust-toolchain.toml) and Xcode (codemagic.yaml)
are pinned to exact versions, and CI pipes no download into a shell."""
import argparse, os, re, subprocess, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def reader(rev):
    def read(path):
        if rev is None:
            with open(os.path.join(ROOT, path), encoding="utf-8") as f: return f.read()
        return subprocess.run(["git", "-C", ROOT, "show", "%s:%s" % (rev, path)], check=True, capture_output=True, text=True).stdout
    return read

def one(pattern, text, what, problems, all_of=False):
    found = re.findall(pattern, text, re.M)
    if not found: problems.append("%s: not found" % what); return None
    if all_of and len(set(found)) > 1: problems.append("%s: differs within the file: %s" % (what, sorted(set(found))))
    return found[0]

def versions(read):
    """{place: version} and {place: versionCode}, and the problems met reading them."""
    p = []
    v = {
        "core/Cargo.toml": one(r'^version = "([^"]+)"', read("core/Cargo.toml"), "core/Cargo.toml version", p),
        "core/Cargo.lock": one(r'name = "fable_core"\nversion = "([^"]+)"', read("core/Cargo.lock"), "Cargo.lock fable_core", p),
        "android build.gradle versionName": one(r"versionName '([^']+)'", read("shell/android/app/build.gradle"), "versionName", p),
        "harmony app.json5 versionName": one(r'"versionName": "([^"]+)"', read("shell/harmony/AppScope/app.json5"), "harmony versionName", p),
        "ios project.yml MARKETING_VERSION": one(r"MARKETING_VERSION: ([0-9.]+)", read("shell/ios/project.yml"), "project.yml", p),
        "ios project.pbxproj MARKETING_VERSION": one(r"MARKETING_VERSION = ([^;]+);", read("shell/ios/Fable.xcodeproj/project.pbxproj"), "pbxproj", p, True),
        "tests CoreTest.java": one(r'Core\.version\(\)\.equals\("([^"]+)"\)', read("tests/java/app/fable/browser/CoreTest.java"), "CoreTest", p),
        "tests MainActivityTest.java": one(r'assertEquals\("([0-9.]+)", state\.getString\("version"\)\)', read("shell/android/app/src/test/java/app/fable/browser/MainActivityTest.java"), "MainActivityTest", p),
        "README 当前版本": one(r"当前版本 ([0-9.]+)", read("README.md"), "README current version", p),
    }
    c = {
        "android versionCode": one(r"versionCode (\d+)", read("shell/android/app/build.gradle"), "versionCode", p),
        "harmony versionCode": one(r'"versionCode": (\d+)', read("shell/harmony/AppScope/app.json5"), "harmony versionCode", p),
        "ios project.yml CURRENT_PROJECT_VERSION": one(r"CURRENT_PROJECT_VERSION: (\d+)", read("shell/ios/project.yml"), "project.yml build", p),
        "ios project.pbxproj CURRENT_PROJECT_VERSION": one(r"CURRENT_PROJECT_VERSION = (\d+);", read("shell/ios/Fable.xcodeproj/project.pbxproj"), "pbxproj build", p, True),
    }
    return v, c, p

def pins(read):
    """The tools CI builds with are pinned to exact versions (audit finding High-4)."""
    p = []
    try: toolchain = read("rust-toolchain.toml")
    except (OSError, subprocess.CalledProcessError): return ["rust-toolchain.toml is missing: pin the Rust release"]
    if not re.search(r'^channel = "\d+\.\d+\.\d+"', toolchain, re.M):
        p.append('rust-toolchain.toml must pin an exact release (channel = "1.x.y"), not a channel name')
    for xcode in re.findall(r"^\s*xcode: *(\S+)", read("codemagic.yaml"), re.M):
        if not re.fullmatch(r"\d+(\.\d+)+", xcode): p.append("codemagic.yaml: xcode: %s is not a pinned version" % xcode)
    if re.search(r"curl[^\n|]*\|\s*(ba)?sh", read("codemagic.yaml")):
        p.append("codemagic.yaml pipes a download into a shell")
    return p

def check(read, subject=None, label="working tree"):
    v, c, problems = versions(read)
    version = v["core/Cargo.toml"]
    for place, value in v.items():
        if value is not None and value != version: problems.append("%s says %s, core/Cargo.toml says %s" % (place, value, version))
    code = c["android versionCode"]
    for place, value in c.items():
        if value is not None and value != code: problems.append("%s is %s, Android's versionCode is %s" % (place, value, code))
    m = re.match(r"(\d+\.\d+\.\d+): ", subject or "")
    if m and m.group(1) != version:
        problems.append('the subject says %s but the files say %s: bump every version (see README, 版本号) in the same commit' % (m.group(1), version))
    if version and "**%s" % version not in read("README.md"):
        problems.append("README has no section for %s (a **%s ...** heading under 验证到了哪一步)" % (version, version))
    problems += pins(read)
    for line in problems: print("FAIL version (%s): %s" % (label, line))
    if not problems: print("version_test: %s is %s (versionCode %s) everywhere" % (label, version, code))
    return not problems

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--commit"); ap.add_argument("--message")
    a = ap.parse_args()
    if a.commit:
        subject = subprocess.run(["git", "-C", ROOT, "log", "-1", "--format=%s", a.commit], check=True, capture_output=True, text=True).stdout.strip()
        return 0 if check(reader(a.commit), subject, a.commit) else 1
    subject = None
    if a.message:
        with open(a.message, encoding="utf-8") as f: subject = f.readline().strip()
    return 0 if check(reader(None), subject) else 1

if __name__ == "__main__":
    sys.exit(main())
