pragma Singleton
import QtQuick 2.0
QtObject {
    property int paddingSmall: 6; property int paddingMedium: 12; property int paddingLarge: 24
    property int horizontalPageMargin: 24; property int itemSizeSmall: 80
    property int fontSizeTiny: 16; property int fontSizeExtraSmall: 20; property int fontSizeSmall: 24; property int fontSizeLarge: 40
    property color highlightColor: "cyan"; property color primaryColor: "white"; property color highlightBackgroundColor: "teal"
}
