package app.fable.browser;

import java.nio.charset.StandardCharsets;

/**
 * Java face of the Rust core (libfable_jni.so = fable_jni.c + libfable_core.a).
 *
 * Text crosses JNI as UTF-8 byte arrays rather than Java strings: JNI's own
 * string functions use "modified UTF-8", which mangles characters outside the
 * Basic Multilingual Plane (emoji in a search, for example).
 *
 * This class has no Android dependencies, so it also runs on a desktop JVM
 * (see tests/jni_test.sh).
 */
final class Core {
    static {
        System.loadLibrary("fable_jni");
    }

    private Core() {}

    /** Typed text to a URL; "" for blank input. */
    static String resolve(String input) {
        return fromUtf8(resolve0(utf8(input)));
    }

    /** True when the request is a third-party request to a listed tracker. Thread-safe. */
    static boolean shouldBlock(String requestUrl, String pageUrl) {
        return shouldBlock0(utf8(requestUrl), utf8(pageUrl));
    }

    // Language: the "language" setting if set, else the system locale given here.
    static void setSystemLocale(String tag) {
        setSystemLocale0(utf8(tag));
    }

    /** "zh-Hans", "zh-Hant", "ja", "en", "ko", "ru", "fr", "es" or "ar". */
    static String language() {
        return fromUtf8(language0());
    }

    /** UI text for a key of ui/strings.tsv in the current language. */
    static String tr(String key) {
        return fromUtf8(tr0(utf8(key)));
    }

    /** UI text with its {n} placeholder filled in. */
    static String tr(String key, Object n) {
        return tr(key).replace("{n}", String.valueOf(n));
    }

    /** The reader-mode script, localized. */
    static String readerScript() {
        return fromUtf8(readerScript0());
    }

    /** The script that hides the ad boxes on a page (the "block ads" setting). */
    static String adblockScript() {
        return fromUtf8(adblockScript0());
    }

    /**
     * True when following this URL would leave the browser for another app
     * (an app store, or a custom scheme) and the "block external apps" setting
     * is on. Thread-safe.
     */
    static boolean blockExternalApp(String url) {
        return blockExternalApp0(utf8(url));
    }

    /**
     * True when the panel bridge may store this setting: a key the panel or
     * home page writes, and a value of bounded length without control characters.
     */
    static boolean panelSettingAllowed(String key, String value) {
        return panelSettingAllowed0(utf8(key), utf8(value));
    }

    static native long blockedCount();

    // Settings and history, stored by the core in the given directory. Thread-safe.
    static boolean loadAdList(String profile, byte[] defaults) {
        return loadAdList0(utf8(profile), defaults);
    }

    private static native boolean loadAdList0(byte[] profile, byte[] defaults);

    /** 1 when the ad list is due a fetch: blocking is on and a week has passed. */
    static boolean adsUpdateDue() {
        return adsUpdateDue0();
    }

    private static native boolean adsUpdateDue0();

    /** The update sources, one URL per line (EasyList and EasyPrivacy). */
    static String adsUpdateSources() {
        return fromUtf8(adsUpdateSources0());
    }

    private static native byte[] adsUpdateSources0();

    /** Validate the download as a list and install it; the new domain count, or -1. */
    static int adsUpdateApply(byte[] data) {
        return adsUpdateApply0(data);
    }

    private static native int adsUpdateApply0(byte[] data);

    static void storeOpen(String dir) {
        storeOpen0(utf8(dir));
    }

    /** "" when unset. */
    static String settingGet(String key) {
        return fromUtf8(settingGet0(utf8(key)));
    }

    static void settingSet(String key, String value) {
        settingSet0(utf8(key), utf8(value));
    }

    static void historyAdd(String url, String title, long wallClockMs) {
        historyAdd0(utf8(url), utf8(title), wallClockMs);
    }

    /** JSON array, newest first: [{"t":ms,"u":url,"n":title}]. */
    static String historyJson(String query, int limit) {
        return fromUtf8(historyJson0(utf8(query), limit));
    }

    static void historyDelete(String url, long wallClockMs) {
        historyDelete0(utf8(url), wallClockMs);
    }

    static native boolean historyClear();

    /**
     * A panel request the core answers the same way on every platform
     * (settings, history, sniff, bookmarks, the session snapshot).
     * null when the shell has to answer itself.
     */
    static String panelQuery(String name, String arg, int tab) {
        byte[] out = panelQuery0(utf8(name), utf8(arg), tab);
        return out == null ? null : fromUtf8(out);
    }

    /**
     * New-tab page: localized, with the stored shortcuts and the icons already
     * on hand ({"host": [dataUri, width]}, or "" for none) drawn into the page.
     * incognito: 0 normal, 1 private, 2 private with cookies shared with normal tabs.
     */
    /**
     * The new-tab page as the home screen: shortcuts and apps ([{"c": component, "n": label}, …]) on swipeable pages.
     * wallpaper: 0 the page's own background, 1 the system wallpaper through it with light text, 2 with dark text.
     */
    static String launcherPage(String iconsJson, String appsJson, int wallpaper) {
        return fromUtf8(launcherPage0(utf8(iconsJson), utf8(appsJson), wallpaper));
    }

    static String newtabPage(int incognito, String iconsJson) {
        return fromUtf8(newtabPage0(incognito, utf8(iconsJson)));
    }

    /** The Fable logo as a data: URI. */
    static String logoUri() {
        return fromUtf8(logoUri0());
    }

    /** In-app UI (menu, tabs, settings, history, sniffer) for the privileged panel view, localized. */
    static String panelPage() {
        return fromUtf8(panelPage0());
    }

    static String version() {
        return fromUtf8(version0());
    }

    // Resource sniffing: media a tab's page loads, kept in memory by the core. Thread-safe.

    /** Script that lists media elements and large images in a page: [[hint, url], ...]. */
    static String sniffJs() {
        return fromUtf8(sniffJs0());
    }

    /** Report a URL seen in a tab; hint is "range", "video", "audio", "image" or "". True if it was added. */
    static boolean sniffNote(int tab, String url, String hint) {
        return sniffNote0(tab, utf8(url), utf8(hint));
    }

    /** JSON array: [{"k":"video|audio|image|stream","u":url,"e":extension}]. */
    static String sniffJson(int tab) {
        return fromUtf8(sniffJson0(tab));
    }

    static native int sniffCount(int tab);
    static native void sniffClear(int tab);

    // Tab table and sleep policy. The handle must stay on one thread.
    static native long tabsNew();
    static native void tabsFree(long handle);
    static native int tabsOpen(long handle, long nowMs);
    static native boolean tabsActivate(long handle, int id, long nowMs);
    static native boolean tabsClose(long handle, int id);
    static native void tabsSetSleepAfterMs(long handle, long ms);
    /** Ids of background tabs that should be put to sleep now. */
    static native int[] tabsCollectSleepers(long handle, long nowMs);

    private static native byte[] resolve0(byte[] input);
    private static native boolean shouldBlock0(byte[] requestUrl, byte[] pageUrl);
    private static native void setSystemLocale0(byte[] tag);
    private static native byte[] language0();
    private static native byte[] tr0(byte[] key);
    private static native byte[] readerScript0();
    private static native byte[] adblockScript0();
    private static native boolean blockExternalApp0(byte[] url);
    private static native boolean panelSettingAllowed0(byte[] key, byte[] value);
    private static native void storeOpen0(byte[] dir);
    private static native byte[] settingGet0(byte[] key);
    private static native void settingSet0(byte[] key, byte[] value);
    private static native void historyAdd0(byte[] url, byte[] title, long wallClockMs);
    private static native byte[] historyJson0(byte[] query, int limit);
    private static native byte[] panelQuery0(byte[] name, byte[] arg, int tab);
    private static native void historyDelete0(byte[] url, long wallClockMs);
    private static native byte[] newtabPage0(int incognito, byte[] iconsJson);
    private static native byte[] launcherPage0(byte[] iconsJson, byte[] appsJson, int wallpaper);
    private static native byte[] panelPage0();
    private static native byte[] logoUri0();
    private static native byte[] version0();
    private static native byte[] sniffJs0();
    private static native boolean sniffNote0(int tab, byte[] url, byte[] hint);
    private static native byte[] sniffJson0(int tab);

    private static byte[] utf8(String s) {
        return (s == null ? "" : s).getBytes(StandardCharsets.UTF_8);
    }

    private static String fromUtf8(byte[] b) {
        return b == null ? "" : new String(b, StandardCharsets.UTF_8);
    }
}
