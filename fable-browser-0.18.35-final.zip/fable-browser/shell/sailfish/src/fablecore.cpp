#include "fablecore.h"

extern "C" {
#include "fable_core.h"
}

#include <QImage>
#include <QTextCodec>
#include <QtMath>
#include <QVariantList>

namespace {

// Copy a core-owned C string into a QString and free it immediately.
QString take(char *s)
{
    if (!s) return QString();
    QString out = QString::fromUtf8(s);
    fable_string_free(s);
    return out;
}

QString fromUtf8(const char *s)
{
    return s ? QString::fromUtf8(s) : QString();
}

QByteArray toUtf8(const QString &s)
{
    return s.toUtf8();
}

// A QR payload as text. QR codes carry UTF-8 almost everywhere, but many made
// in China use GBK, which GB18030 covers; the standard's own default,
// ISO-8859-1, takes whatever is left, since it maps every byte. (As on Android.)
QString qrPayloadText(const QByteArray &payload)
{
    const char *names[] = { "UTF-8", "GB18030" };
    for (const char *name : names) {
        QTextCodec *codec = QTextCodec::codecForName(name);
        if (!codec) continue;
        QTextCodec::ConverterState state;   // invalidChars counts what it could not read
        const QString text = codec->toUnicode(payload.constData(), payload.size(), &state);
        if (state.invalidChars == 0) return text;
    }
    return QString::fromLatin1(payload);
}

} // namespace

FableCore *FableCore::instance(QObject *parent)
{
    static FableCore *self = new FableCore(parent ? parent : nullptr);
    return self;
}

FableCore::FableCore(QObject *parent) : QObject(parent) {}

QString FableCore::version() const { return fromUtf8(fable_version()); }
QString FableCore::language() const { return languageValue(); }
bool FableCore::nativeHash() const { return fable_native_hash() != 0; }

QString FableCore::languageValue() const { return take(fable_language()); }

QString FableCore::tr(const QString &key) const
{
    return take(fable_tr(toUtf8(key).constData()));
}

QString FableCore::resolve(const QString &input) const
{
    return take(fable_resolve(toUtf8(input).constData()));
}

bool FableCore::setSearchTemplate(const QString &url)
{
    return fable_set_search_template(toUtf8(url).constData()) != 0;
}

QString FableCore::readerScript() const { return take(fable_reader_script()); }
QString FableCore::logoUri() const { return take(fable_logo_uri()); }

int FableCore::themeApply(const QString &url)
{
    return fable_theme_apply(toUtf8(url).constData());
}

QString FableCore::themeCurrent() const { return take(fable_theme_current()); }

QString FableCore::themePalette() const { return take(fable_theme_palette()); }
QString FableCore::panelPage() const { return take(fable_panel_page()); }

QString FableCore::newTabPage(int incognito, const QString &iconsJson) const
{
    return take(fable_newtab_page(incognito,
                                  iconsJson.isEmpty() ? nullptr : toUtf8(iconsJson).constData()));
}

QString FableCore::sniffJs() const { return fromUtf8(fable_sniff_js()); }
QString FableCore::adblockScript() const { return take(fable_adblock_script()); }
QString FableCore::contentRules() const { return take(fable_content_rules()); }
QString FableCore::adsContentRules() const { return take(fable_ads_content_rules()); }

bool FableCore::shouldBlock(const QString &requestUrl, const QString &pageUrl) const
{
    // WebView (Gecko) has no per-request callback on Sailfish OS; this is used
    // by the QML-side link/navigation guard and by any future network adapter.
    return fable_should_block(toUtf8(requestUrl).constData(),
                              toUtf8(pageUrl).constData()) != 0;
}

bool FableCore::blockExternalApp(const QString &url) const
{
    return fable_block_external_app(toUtf8(url).constData()) != 0;
}

void FableCore::setBlocking(bool trackers, bool ads)
{
    fable_set_blocking(trackers ? 1 : 0, ads ? 1 : 0);
}

quint64 FableCore::blockedCount() const { return fable_blocked_count(); }
quint64 FableCore::adsBlockedCount() const { return fable_ads_blocked_count(); }

QString FableCore::panelQuery(const QString &name, const QString &arg, quint32 tab) const
{
    char *out = fable_panel_query(toUtf8(name).constData(), toUtf8(arg).constData(), tab);
    // A null QString means the request is the shell's to answer; an answer,
    // even an empty one, is never null.
    if (!out) return QString();
    QString answer = take(out);
    return answer.isNull() ? QStringLiteral("") : answer;
}

bool FableCore::panelSettingAllowed(const QString &key, const QString &value) const
{
    return fable_panel_setting_allowed(toUtf8(key).constData(), toUtf8(value).constData()) != 0;
}

QString FableCore::settingsJson() const { return take(fable_settings_json()); }

QString FableCore::panelReply(quint32 id, const QString &answer) const
{
    return take(fable_panel_reply(id, toUtf8(answer).constData()));
}

QString FableCore::jsonString(const QString &s) const
{
    return take(fable_json_string(toUtf8(s).constData()));
}

QString FableCore::parseIpReply(const QString &body, const QString &source) const
{
    return take(fable_parse_ip_reply(toUtf8(body).constData(), toUtf8(source).constData()));
}

void FableCore::storeOpen(const QString &dir) { fable_store_open(toUtf8(dir).constData()); }

QString FableCore::settingGet(const QString &key) const
{
    return take(fable_setting_get(toUtf8(key).constData()));
}

void FableCore::settingSet(const QString &key, const QString &value)
{
    fable_setting_set(toUtf8(key).constData(), toUtf8(value).constData());
    if (key == QLatin1String("language")) emit languageChanged();
}

void FableCore::historyAdd(const QString &url, const QString &title, quint64 timeMs)
{
    fable_history_add(toUtf8(url).constData(), toUtf8(title).constData(), timeMs);
}

QString FableCore::historyJson(const QString &query, int limit) const
{
    return take(fable_history_json(toUtf8(query).constData(), static_cast<size_t>(limit)));
}

void FableCore::historyDelete(const QString &url, quint64 timeMs)
{
    fable_history_delete(toUtf8(url).constData(), timeMs);
}

bool FableCore::historyClear() { return fable_history_clear() != 0; }

quint64 FableCore::bookmarkAdd(const QString &url, const QString &title, quint64 parent)
{
    return fable_bookmark_add(toUtf8(url).constData(), toUtf8(title).constData(), parent);
}

quint64 FableCore::bookmarkFolder(const QString &name, quint64 parent)
{
    return fable_bookmark_folder(toUtf8(name).constData(), parent);
}

void FableCore::bookmarkRemove(quint64 id) { fable_bookmark_remove(id); }
void FableCore::bookmarkMove(quint64 id, quint64 parent, int index)
{
    fable_bookmark_move(id, parent, static_cast<size_t>(index));
}
void FableCore::bookmarkRename(quint64 id, const QString &title)
{
    fable_bookmark_rename(id, toUtf8(title).constData());
}
quint64 FableCore::bookmarkId(const QString &url) const
{
    return fable_bookmark_id(toUtf8(url).constData());
}
QString FableCore::bookmarksJson(const QString &query) const
{
    return take(fable_bookmarks_json(toUtf8(query).constData()));
}
int FableCore::bookmarkImport(const QString &html)
{
    return static_cast<int>(fable_bookmark_import(toUtf8(html).constData()));
}
QString FableCore::bookmarkExport() const { return take(fable_bookmark_export()); }
QString FableCore::bookmarkExportFmt(const QString &fmt) const { return take(fable_bookmark_export_fmt(toUtf8(fmt).constData())); }

bool FableCore::sessionSave(const QString &json)
{
    return fable_session_save(toUtf8(json).constData()) != 0;
}
QString FableCore::sessionJson() const { return take(fable_session_json()); }
void FableCore::sessionClear() { fable_session_clear(); }
int FableCore::sessionCount() const { return static_cast<int>(fable_session_count()); }
QString FableCore::sessionUrl(int i) const { return take(fable_session_url(static_cast<size_t>(i))); }
QString FableCore::sessionTitle(int i) const { return take(fable_session_title(static_cast<size_t>(i))); }
int FableCore::sessionActive() const { return static_cast<int>(fable_session_active()); }

bool FableCore::sniffNote(quint32 tab, const QString &url, const QString &hint)
{
    return fable_sniff_note(tab, toUtf8(url).constData(), toUtf8(hint).constData()) != 0;
}
int FableCore::sniffCount(quint32 tab) const { return static_cast<int>(fable_sniff_count(tab)); }
int FableCore::sniffNoteScan(quint32 tab, const QString &json)
{
    return static_cast<int>(fable_sniff_note_scan(tab, toUtf8(json).constData()));
}
QString FableCore::sniffJson(quint32 tab) const { return take(fable_sniff_json(tab)); }
void FableCore::sniffClear(quint32 tab) { fable_sniff_clear(tab); }

bool FableCore::adListFile(const QString &profileDir, const QString &file)
{
    return fable_ad_list_file(toUtf8(profileDir).constData(),
                              file.isEmpty() ? nullptr : toUtf8(file).constData()) != 0;
}
bool FableCore::adListAsset(const QByteArray &data)
{
    return fable_ad_list_asset(nullptr,
        reinterpret_cast<const uint8_t *>(data.constData()), static_cast<size_t>(data.size())) != 0;
}
QString FableCore::adListText() const { return take(fable_ad_list_text()); }
bool FableCore::adsUpdateDue() const { return fable_ads_update_due() != 0; }
QString FableCore::adsUpdateSources() const { return take(fable_ads_update_sources()); }
int FableCore::adsUpdateApply(const QByteArray &data)
{
    return fable_ads_update_apply(reinterpret_cast<const uint8_t *>(data.constData()),
                                  static_cast<size_t>(data.size()));
}
quint64 FableCore::adsDomainCount() const { return fable_ads_domain_count(); }

QString FableCore::deviceInfo(const QString &extras) const
{
    return take(fable_device_info(extras.isEmpty() ? nullptr : toUtf8(extras).constData()));
}
QString FableCore::systemInfo(const QString &extras) const
{
    return take(fable_system_info(extras.isEmpty() ? nullptr : toUtf8(extras).constData()));
}

quint32 FableCore::downloadBegin(const QString &name)
{
    return fable_download_begin(toUtf8(name).constData());
}
void FableCore::downloadFinish(quint32 id, bool success)
{
    fable_download_finish(id, success ? 1 : 0);
}

QString FableCore::qrDecodeLuma(const uint8_t *luma, size_t len,
                                size_t width, size_t height,
                                size_t rowStride, size_t pixelStride)
{
    const int needed = fable_qr_decode(luma, len, width, height, rowStride, pixelStride, nullptr, 0);
    if (needed <= 0) return QString();   // -1: nothing readable; 0: an empty payload
    QByteArray payload(needed, 0);
    const int got = fable_qr_decode(luma, len, width, height, rowStride, pixelStride,
                                    reinterpret_cast<uint8_t *>(payload.data()),
                                    static_cast<size_t>(payload.size()));
    if (got != needed) return QString();
    return qrPayloadText(payload);
}

QString FableCore::qrDecodeImage(const QString &path) const
{
    QImage image(path);
    if (image.isNull()) return QString();
    // The core's decoder takes at most 4096 px an edge and 4 MP in all:
    // shrink a bigger picture first, keeping its shape.
    const qint64 pixels = static_cast<qint64>(image.width()) * image.height();
    if (image.width() > 4096 || image.height() > 4096 || pixels > 4 * 1024 * 1024) {
        const double scale = qMin(4096.0 / image.width(),
                                  qMin(4096.0 / image.height(),
                                       qSqrt((4.0 * 1024 * 1024) / static_cast<double>(pixels))));
        image = image.scaled(qMax(1, static_cast<int>(image.width() * scale)),
                             qMax(1, static_cast<int>(image.height() * scale)),
                             Qt::KeepAspectRatio, Qt::SmoothTransformation);
        if (image.isNull()) return QString();
    }
    const QImage gray = image.convertToFormat(QImage::Format_Grayscale8);
    // Packed grayscale would be width and 1 as the strides; a QImage row can
    // be padded, so hand the decoder the real row stride.
    // bytesPerLine() * height(), not sizeInBytes() (Qt 5.10, newer than
    // Sailfish's 5.6) nor byteCount() (deprecated since).
    return qrDecodeLuma(reinterpret_cast<const uint8_t *>(gray.constBits()),
                        static_cast<size_t>(gray.bytesPerLine()) * static_cast<size_t>(gray.height()),
                        static_cast<size_t>(gray.width()),
                        static_cast<size_t>(gray.height()),
                        static_cast<size_t>(gray.bytesPerLine()), 1);
}

quint64 FableCore::tabsNew() { return reinterpret_cast<quint64>(fable_tabs_new()); }
void FableCore::tabsFree(quint64 handle)
{
    fable_tabs_free(reinterpret_cast<FableTabs *>(handle));
}
void FableCore::tabsSetSleepAfterMs(quint64 handle, quint64 ms)
{
    fable_tabs_set_sleep_after_ms(reinterpret_cast<FableTabs *>(handle), ms);
}
quint32 FableCore::tabsOpen(quint64 handle, quint64 nowMs)
{
    return fable_tabs_open(reinterpret_cast<FableTabs *>(handle), nowMs);
}
bool FableCore::tabsActivate(quint64 handle, quint32 id, quint64 nowMs)
{
    return fable_tabs_activate(reinterpret_cast<FableTabs *>(handle), id, nowMs) != 0;
}
bool FableCore::tabsTouch(quint64 handle, quint32 id, quint64 nowMs)
{
    return fable_tabs_touch(reinterpret_cast<FableTabs *>(handle), id, nowMs) != 0;
}
bool FableCore::tabsClose(quint64 handle, quint32 id)
{
    return fable_tabs_close(reinterpret_cast<FableTabs *>(handle), id) != 0;
}
int FableCore::tabsCount(quint64 handle) const
{
    return static_cast<int>(fable_tabs_count(reinterpret_cast<FableTabs *>(handle)));
}
bool FableCore::tabsIsAsleep(quint64 handle, quint32 id) const
{
    return fable_tabs_is_asleep(reinterpret_cast<FableTabs *>(handle), id) != 0;
}
QVariantList FableCore::tabsCollectSleepers(quint64 handle, quint64 nowMs)
{
    uint32_t ids[256];
    size_t n = fable_tabs_collect_sleepers(reinterpret_cast<FableTabs *>(handle),
                                            nowMs, ids, 256);
    QVariantList out;
    out.reserve(static_cast<int>(n));
    for (size_t i = 0; i < n; ++i) out << QVariant(ids[i]);
    return out;
}

void FableCore::setSystemLocale(const QString &tag)
{
    fable_set_system_locale(toUtf8(tag).constData());
    emit languageChanged();
}
