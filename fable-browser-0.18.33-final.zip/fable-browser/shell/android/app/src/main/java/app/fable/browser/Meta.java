package app.fable.browser;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.os.BatteryManager;
import android.os.Build;
import android.os.StatFs;
import android.util.DisplayMetrics;
import android.view.Display;
import android.webkit.CookieManager;

import androidx.webkit.WebViewCompat;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * Facts for the metadata sheet that a web page cannot read itself: the device,
 * the system, the real screen, and the public IP address. Everything a page
 * can read (GPU, time zone, languages ...) is collected by the sheet in its
 * own WebView, which runs the same engine as the tabs.
 */
final class Meta {
    /** Where the public IP comes from; package-visible so tests can point it at a local server. */
    static String traceEndpoint = "https://www.cloudflare.com/cdn-cgi/trace";
    static String fallbackEndpoint = "https://api.ipify.org?format=json";
    private static final int TIMEOUT_MS = 6000;

    private Meta() {}

    /** Device and system facts as JSON. Cheap; any thread. */
    @SuppressWarnings("deprecation")   // getRealMetrics: the one call that reports the full panel on every API level
    static String device(Activity a, String userAgent) {
        JSONObject o = new JSONObject();
        try {
            o.put("manufacturer", Build.MANUFACTURER);
            o.put("model", Build.MODEL);
            o.put("android", Build.VERSION.RELEASE);
            o.put("sdk", Build.VERSION.SDK_INT);
            o.put("abi", Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "");
            o.put("kernel", System.getProperty("os.version", ""));
            o.put("ua", userAgent);

            Display display = a.getWindowManager().getDefaultDisplay();
            DisplayMetrics dm = new DisplayMetrics();
            display.getRealMetrics(dm);
            o.put("screenW", Math.min(dm.widthPixels, dm.heightPixels));    // portrait order, as phones are specified
            o.put("screenH", Math.max(dm.widthPixels, dm.heightPixels));
            o.put("dpi", dm.densityDpi);
            o.put("refresh", Math.round(display.getRefreshRate()));

            ActivityManager.MemoryInfo memory = new ActivityManager.MemoryInfo();
            ((ActivityManager) a.getSystemService(Context.ACTIVITY_SERVICE)).getMemoryInfo(memory);
            if (memory.totalMem > 0) o.put("ram", memory.totalMem);

            // The battery state is a sticky broadcast: reading it needs no permission and no receiver.
            Intent battery = a.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (battery != null) {
                int level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1), scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                int status = battery.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                if (level >= 0 && scale > 0) o.put("battery", Math.round(level * 100f / scale));
                o.put("charging", status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL);
            }

            StatFs fs = new StatFs(a.getFilesDir().getPath());
            o.put("storageTotal", fs.getTotalBytes());
            o.put("storageFree", fs.getAvailableBytes());

            PackageInfo webview = WebViewCompat.getCurrentWebViewPackage(a);
            if (webview != null) o.put("webview", webview.versionName);
            o.put("cookies", CookieManager.getInstance().acceptCookie());
        } catch (JSONException | RuntimeException partial) {
            // Whatever was collected before the failure is still worth showing.
        }
        return o.toString();
    }

    /**
     * Public IP and connection facts as JSON {ip, loc, colo, http, tls, src},
     * or {} when nothing answered. Blocks: call off the UI thread. Sends no
     * cookies; the User-Agent is the one the tabs use.
     */
    static String lookupIp(String userAgent) {
        try {
            String trace = get(traceEndpoint, userAgent);
            if (trace != null) {
                JSONObject o = new JSONObject();
                for (String line : trace.split("\n")) {
                    int eq = line.indexOf('=');
                    if (eq <= 0) continue;
                    String key = line.substring(0, eq).trim(), value = line.substring(eq + 1).trim();
                    if (key.matches("ip|loc|colo|http|tls")) o.put(key, value);
                }
                if (o.has("ip")) return o.put("src", host(traceEndpoint)).toString();
            }
            String plain = get(fallbackEndpoint, userAgent);
            if (plain != null) {
                String ip = new JSONObject(plain).optString("ip");
                if (!ip.isEmpty()) return new JSONObject().put("ip", ip).put("src", host(fallbackEndpoint)).toString();
            }
        } catch (JSONException | RuntimeException ignored) { }
        return "{}";
    }

    private static String host(String url) {
        String h = Icons.hostOf(url);
        return h.startsWith("www.") ? h.substring(4) : h;
    }

    private static String get(String address, String userAgent) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(address).openConnection();
            c.setConnectTimeout(TIMEOUT_MS);
            c.setReadTimeout(TIMEOUT_MS);
            c.setUseCaches(false);
            c.setRequestProperty("User-Agent", userAgent);
            if (c.getResponseCode() != 200) return null;
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try (InputStream in = c.getInputStream()) {
                byte[] buf = new byte[4096];
                for (int n; (n = in.read(buf)) > 0 && out.size() < 16384; ) out.write(buf, 0, n);
            }
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }
}
