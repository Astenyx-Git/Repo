// The panel behind the iOS shell (see tests/ios_prelude.js): messages like the
// desktops, the bottom sheet and phone settings like Android, and caps that
// hide what iOS does not allow.
(function () {
  var log = [];
  function q(sel) { return document.querySelector(sel); }
  function rows() { return [].slice.call(document.querySelectorAll('#body .row')); }
  function rowByText(t) { return rows().filter(function (r) { return r.textContent.indexOf(t) >= 0; })[0]; }
  function check(name, ok) { log.push((ok ? 'ok   ' : 'FAIL ') + name); }
  function posted() { return window.__posted; }
  function last(prefix) { var p = posted().filter(function (m) { return m.indexOf(prefix) === 0; }); return p[p.length - 1]; }
  function lastAsk(name) { var p = posted().filter(function (m) { var f = m.split('\t'); return f[0] === 'q' && f[2] === name; }); return p.length ? p[p.length - 1].split('\t') : null; }
  function tiles() { return [].slice.call(document.querySelectorAll('#body .tile')); }
  function sheetHeight() { return q('#sheet').getBoundingClientRect().height; }

  check('bottom sheet, not the desktop window layout, and no preview', !document.documentElement.classList.contains('desk') && tiles().length === 0);

  var caps = { screenshots: false, thirdPartyCookies: false, orientation: true, bookmarks: true, restoreTabs: true };   // what Panel.caps says
  var state = { tabs: [{ id: 1, title: 'Example', url: 'https://example.com/', active: true, icon: '' }], url: 'https://example.com/', title: 'Example', web: true, active: 1,
                incognito: false, desktop: false, blocked: 0, sniffed: 0, version: '0.16.0', platform: 'ios', caps: caps,
                settings: { block_trackers: '1', address_top: '0', text_size: '100' } };
  Fable.show('menu', state);
  var t = tiles();
  check('menu has the phone-only desktop-site tile, the star and the bookmarks (0.18.17)', t.length === 11 && t.some(function (x) { return x.textContent.indexOf('桌面版网站') >= 0; }));
  var star = t.filter(function (x) { return x.textContent.indexOf('收藏本页') >= 0; })[0];
  check('the star is there for a web page', !!star);
  star.click();
  check('the star is an action for the shell', !!last('a\tbookmarkToggle'));
  Fable.show('bookmarks', state);
  var b = lastAsk('bookmarks');
  Fable.reply(Number(b[1]), '[]');
  var buttons = [].slice.call(document.querySelectorAll('#body .btn')).map(function (x) { return x.textContent; }).join('|');
  check('bookmarks import and export go through the Files picker', buttons.indexOf('导入书签') >= 0 && buttons.indexOf('导出书签') >= 0);
  Fable.show('menu', state);
  check('the menu is a sheet over the page, not the whole view', sheetHeight() < innerHeight * 0.9);
  t.filter(function (x) { return x.textContent.indexOf('桌面版网站') >= 0; })[0].click();
  check('desktop site is an action message', !!last('a\tdesktop'));

  Fable.show('settings', state);
  check('settings read from the snapshot without asking', rowByText('拦截追踪器').querySelector('.switch').className === 'switch on' && !lastAsk('get'));
  check('phone display rows: text size, orientation, keep awake, status bar, address at the top',
        !!rowByText('文字大小') && !rowByText('页面缩放') && !!rowByText('屏幕方向') && !!rowByText('屏幕常亮') && !!rowByText('隐藏状态栏') && !!rowByText('地址栏置于顶部'));
  check('no screenshot switch (iOS cannot block screenshots), no third-party cookie switch (WebKit decides)',
        !rowByText('允许无痕模式截图') && !rowByText('拦截第三方 Cookie'));
  check('"Don\'t load images" and the Home button stay', !!rowByText('不加载图片') && !!rowByText('显示主页按钮'));
  check('restore tabs on start is a switch here (0.18.17)', !!rowByText('启动时恢复上次标签页'));
  rowByText('地址栏置于顶部').click();
  var set = lastAsk('set');
  check('a change is a request, kept locally', set && set[3] === 'address_top\n1' && state.settings.address_top === '1'
        && rowByText('地址栏置于顶部').querySelector('.switch').className === 'switch on');
  Fable.reply(Number(set[1]), '');
  rowByText('浏览器标识').click();
  check('phones may ask for desktop sites by user agent too', rows().length === 11 && !!rowByText('桌面版'));
  Fable.back();

  // iPad: iOS ignores an orientation lock for apps that allow multitasking, so the shell says so.
  Fable.show('settings', { tabs: [], platform: 'ios', caps: { screenshots: false, thirdPartyCookies: false, orientation: false }, settings: {}, version: '0.16.0' });
  check('no orientation row when the shell cannot lock it', !rowByText('屏幕方向') && !!rowByText('屏幕常亮'));

  // History answers come back through Fable.reply, as on the desktops.
  Fable.show('history', state);
  var h = lastAsk('history');
  Fable.reply(Number(h[1]), JSON.stringify([{ t: Date.now(), u: 'https://github.com/', n: 'GitHub' }]));
  check('history request and reply', rows().length === 1 && rows()[0].textContent.indexOf('GitHub') >= 0);

  // Device facts come from the shell.
  Fable.show('meta', state);
  var d = lastAsk('device');
  check('device facts are asked of the shell', !!d);
  Fable.reply(Number(d[1]), JSON.stringify({ manufacturer: 'Apple', model: 'iPhone15,2', os: 'iOS 17.5', engine: 'WebKit 618.2.12' }));
  check('…and shown', document.body.textContent.indexOf('iOS 17.5') >= 0);

  // Closing: the sheet slides away first, then the shell hides the view (Android's timing).
  var delays = [], realTimeout = window.setTimeout;
  window.setTimeout = function (fn, ms) { delays.push(ms); fn(); return 0; };
  var before = posted().length;
  q('#close').click();
  window.setTimeout = realTimeout;
  check('closing slides the sheet down, then says hidden after 240 ms', document.body.className === '' && delays.indexOf(240) >= 0 && posted().slice(before).indexOf('a\thidden\t') >= 0);

  // Private mode: dark sheet, still a sheet.
  Fable.show('menu', { tabs: [], incognito: true, platform: 'ios', caps: caps, settings: {}, version: '0.16.0' });
  check('private mode is dark and keeps the sheet', document.documentElement.classList.contains('incog') && !document.documentElement.classList.contains('desk'));
  check('no size messages: those are for the desktops\' panel windows', posted().every(function (m) { return m.indexOf('a\tsize') !== 0; }));

  return log.join('\n');
})();
