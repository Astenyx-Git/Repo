// Fable reader mode. The shell injects this into the current page; the value
// of the script is 'on', 'off' or 'none' (no article found) so the shell can
// tell the user what happened. Running it again restores the original page.
//
// Styling goes through the CSSOM (el.style) rather than a <style> tag so that
// pages with a strict Content-Security-Policy still render correctly.
(function () {
  var STRINGS = /*FABLE_STRINGS*/null/*END*/;   // UI text, filled in by the core
  var PALETTE = /*FABLE_PALETTE*/null/*END*/;   // the skin's colours (theme://name), filled in by the core
  function T(key) { return (STRINGS && STRINGS[key]) || key; }
  // The default skin's colours where the core gave none.
  var C = { ground: '#FDF7F0', bar: '#FBF2E8', ink: '#2A1A14', text: '#3A2820', muted: '#6E5A4E', line: '#EBDDD0',
            peach: '#FBE3D5', link: '#B8411F', ochre: '#8E2F14', quote: '#F1B48E' };
  for (var key in C) if (PALETTE && PALETTE[key]) C[key] = PALETTE[key];
  var root = document.documentElement;
  var saved = window.__fableReader;
  if (saved) {                                   // leave reader mode: put the page back as it was
    root.replaceChild(saved.body, document.body);
    root.style.cssText = saved.rootStyle;
    for (var s = 0; s < saved.sheets.length; s++) saved.sheets[s].disabled = false;
    root.removeAttribute('data-fable-reader');
    window.__fableReader = null;
    window.scrollTo(0, saved.scroll);
    return 'off';
  }
  if (!document.body) return 'none';

  // Text length that treats one CJK character like two Latin letters, so the
  // thresholds below mean roughly the same amount of reading in any language.
  function weight(text) {
    var n = 0;
    for (var i = 0; i < text.length; i++) {
      var c = text.charCodeAt(i);
      if (c <= 32) continue;
      n += (c >= 0x2E80 && c <= 0x9FFF) || (c >= 0xAC00 && c <= 0xD7AF) || (c >= 0xF900 && c <= 0xFAFF) ? 2 : 1;
    }
    return n;
  }
  var BLOCKS = /^(P|DIV|SECTION|ARTICLE|UL|OL|TABLE|H[1-6]|BLOCKQUOTE|PRE|FIGURE|HEADER|FOOTER|NAV|ASIDE|FORM|MAIN)$/;
  var GOOD = /article|content|post|entry|story|text|body|main|rich|markdown|detail/i;
  var BAD = /comment|reply|sidebar|footer|foot|header|nav|menu|share|social|related|recommend|promo|advert|banner|toolbar|breadcrumb|copyright|popup|modal|login/i;
  function hint(el) { return (el.className && el.className.baseVal === undefined ? el.className : '') + ' ' + (el.id || ''); }

  // A "paragraph" is a <p>/<pre>/<blockquote>/<li>, or a <div>/<section>/<td>
  // that holds text directly instead of further blocks (common on sites that
  // separate lines with <br>). Each long one votes for its parent, and half
  // as strongly for its grandparent.
  var scores = new Map();
  var nodes = document.body.querySelectorAll('p, pre, blockquote, li, div, section, td');
  for (var i = 0; i < nodes.length; i++) {
    var node = nodes[i];
    if (/^(DIV|SECTION|TD)$/.test(node.tagName)) {
      var leaf = true;
      for (var k = 0; k < node.children.length; k++) if (BLOCKS.test(node.children[k].tagName)) { leaf = false; break; }
      if (!leaf) continue;
    }
    if (node.closest('nav, aside, footer, form, [hidden], [aria-hidden="true"]')) continue;
    var w = weight(node.textContent);
    if (w < 50) continue;
    var links = node.querySelectorAll('a'), linked = 0;
    for (k = 0; k < links.length; k++) linked += weight(links[k].textContent);
    if (linked > w * 0.5) continue;              // a list of links, not prose
    var parent = node.parentElement, grand = parent && parent.parentElement;
    if (parent) scores.set(parent, (scores.get(parent) || 0) + w);
    if (grand && grand !== root) scores.set(grand, (scores.get(grand) || 0) + w / 2);
  }
  var best = null, bestScore = 0;
  scores.forEach(function (score, el) {
    var h = hint(el);
    if (el.tagName === 'ARTICLE' || GOOD.test(h)) score *= 1.25;
    if (BAD.test(h)) score *= 0.4;
    if (score > bestScore) { best = el; bestScore = score; }
  });
  if (!best || bestScore < 400) return 'none';   // about 200 Chinese characters or 400 Latin letters of prose
  if (best === document.body) { var only = document.querySelector('article, main, [role="main"]'); if (only && weight(only.textContent) > 400) best = only; }

  var h1 = document.querySelector('article h1, main h1, h1');
  var title = document.title;
  if (h1) {                                      // the heading without edit links and other controls inside it
    var clean = h1.cloneNode(true), extras = clean.querySelectorAll('button, [role="button"], a[href*="action=edit"], .mw-editsection, svg');
    for (i = 0; i < extras.length; i++) extras[i].remove();
    title = clean.textContent.trim() || title;
  }
  var article = best.cloneNode(true);

  // Many sites lazy-load images: move the real address into src before the
  // page's own scripts are gone.
  var imgs = article.querySelectorAll('img');
  for (i = 0; i < imgs.length; i++) {
    var real = imgs[i].getAttribute('data-src') || imgs[i].getAttribute('data-original') || imgs[i].getAttribute('data-lazy-src') || imgs[i].getAttribute('data-actualsrc');
    if (real && !/^data:/.test(real)) imgs[i].setAttribute('src', real);
    imgs[i].removeAttribute('srcset'); imgs[i].removeAttribute('width'); imgs[i].removeAttribute('height'); imgs[i].removeAttribute('loading');
  }
  var junk = article.querySelectorAll('script,style,link,iframe,form,nav,aside,footer,button,input,select,textarea,canvas,noscript,dialog,[hidden],[aria-hidden="true"]');
  for (i = 0; i < junk.length; i++) junk[i].remove();
  var all = article.querySelectorAll('*');
  for (i = all.length - 1; i >= 0; i--) {
    var el = all[i];
    if (BAD.test(hint(el)) && weight(el.textContent) < 400 && el.parentNode) { el.remove(); continue; }
    el.removeAttribute('style'); el.removeAttribute('class'); el.removeAttribute('id');
  }

  var narrow = window.innerWidth < 600;
  var serif = '"Noto Serif SC","Source Han Serif SC","Songti SC","SimSun",Georgia,serif';
  var sans = '"Noto Sans SC","PingFang SC","Microsoft YaHei",system-ui,sans-serif';
  var size = narrow ? 18 : 19;
  function css(el, text) { el.style.cssText = text; }
  function each(sel, text) { var n = article.querySelectorAll(sel); for (var j = 0; j < n.length; j++) css(n[j], text); }
  css(article, 'font:' + size + 'px/1.85 ' + serif + ';color:' + C.text + ';overflow-wrap:break-word;word-break:break-word');
  each('div,section,span,td,th,figure,figcaption,ul,ol,dl,dd,dt,table', 'font:inherit;color:inherit;background:none;border:0;float:none;position:static;width:auto;max-width:100%;margin-left:0;margin-right:0');
  each('p,li', 'margin:0 0 1.1em;font:inherit;color:inherit');
  each('ul,ol', 'padding-inline-start:1.4em;margin:0 0 1.1em');
  each('h1', 'display:none');
  each('h2,h3,h4,h5,h6', 'margin:1.7em 0 .6em;font:600 ' + (size + 3) + 'px/1.4 ' + serif + ';color:' + C.ink);
  each('img,video,picture,svg', 'display:block;max-width:100%;height:auto;border-radius:10px;margin:1.1em auto');
  each('figcaption', 'font:13px/1.6 ' + sans + ';color:' + C.muted + ';text-align:center;margin:-.4em 0 1.2em');
  each('a', 'color:' + C.link + ';text-decoration:none');
  each('sup', 'font-size:.7em;line-height:0');
  each('blockquote', 'margin:1.2em 0;padding:4px 0;padding-inline-start:18px;border-inline-start:3px solid ' + C.quote + ';color:' + C.ochre);
  each('pre', 'font:14px/1.6 ui-monospace,Menlo,Consolas,monospace;background:' + C.bar + ';border-radius:10px;padding:14px 16px;overflow-x:auto;white-space:pre');
  each('code', 'font:.88em ui-monospace,Menlo,Consolas,monospace;background:' + C.bar + ';border-radius:5px;padding:1px 5px');
  each('pre code', 'background:none;padding:0');
  each('table', 'display:block;overflow-x:auto;border-collapse:collapse;font:15px/1.6 ' + sans + ';margin:1.2em 0');
  each('td,th', 'border:1px solid ' + C.line + ';padding:6px 10px;text-align:start');

  var page = document.createElement('main');
  css(page, 'max-width:700px;margin:0 auto;padding:' + (narrow ? '18px 22px 96px' : '40px 28px 120px'));

  // A small bar that says where you are and offers the way back.
  var bar = document.createElement('div');
  css(bar, 'display:flex;align-items:center;justify-content:space-between;gap:12px;margin:0 0 ' + (narrow ? '22px' : '34px') + ';font:13px/1 ' + sans);
  var badge = document.createElement('span');
  badge.textContent = T('reader_mode') + ' · ' + T('reader_minutes').replace('{n}', Math.max(1, Math.round(weight(article.textContent) / 900)));
  css(badge, 'background:' + C.peach + ';color:' + C.ochre + ';border-radius:14px;padding:8px 14px');
  var exit = document.createElement('a');
  exit.textContent = T('exit');
  exit.href = '#';
  css(exit, 'color:' + C.muted + ';text-decoration:none;border:1px solid ' + C.line + ';border-radius:14px;padding:7px 14px');
  bar.appendChild(badge);
  bar.appendChild(exit);

  var heading = document.createElement('h1');
  heading.textContent = title;
  css(heading, 'margin:0 0 ' + (narrow ? '22px' : '30px') + ';padding-bottom:' + (narrow ? '18px' : '24px') + ';border-bottom:1px solid ' + C.line + ';font:600 ' + (narrow ? 28 : 36) + 'px/1.35 ' + serif + ';color:' + C.ink);
  page.appendChild(bar);
  page.appendChild(heading);
  page.appendChild(article);

  var body = document.createElement('body');
  css(body, 'margin:0;background:' + C.ground + ';-webkit-text-size-adjust:100%;text-size-adjust:100%');
  body.appendChild(page);

  var toggle = arguments.callee;
  exit.addEventListener('click', function (e) { e.preventDefault(); toggle(); });
  // Switch the page's own style sheets off while reading, so rules written for
  // its layout (fixed widths, flex bodies, heading fonts) cannot leak into ours.
  var sheets = [];
  for (i = 0; i < document.styleSheets.length; i++) {
    if (!document.styleSheets[i].disabled) { document.styleSheets[i].disabled = true; sheets.push(document.styleSheets[i]); }
  }
  window.__fableReader = { body: document.body, rootStyle: root.style.cssText, scroll: window.scrollY, sheets: sheets };
  root.replaceChild(body, document.body);
  root.setAttribute('data-fable-reader', '1');
  css(root, 'background:' + C.ground + ';overflow:auto;height:auto;font-size:16px');
  window.scrollTo(0, 0);
  return 'on';
})();
