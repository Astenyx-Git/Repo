//! Bookmarks: a flat list of entries (bookmarks and folders) with a parent
//! id, plus the NETSCAPE bookmark-file format Chrome and Firefox write and
//! read (`<!DOCTYPE NETSCAPE-Bookmark-file-1>`, `<DL>`/`<DT><A HREF>`/
//! `<H3>` folders). Parsing and export are pure functions over strings; the
//! persistence lives in store.rs (bookmarks.tsv), like the history.

use crate::store::json_string;

/// One row of the bookmark table. `parent == 0` is the root (the toolbar).
/// The order inside the flat list is the order among siblings.
pub struct Entry {
    pub id: u64,
    pub folder: bool,
    pub parent: u64,
    pub title: String,
    pub url: String, // "" for folders
}

/// A parsed node of an imported file, before it is flattened into entries.
pub struct Node {
    pub folder: bool,
    pub title: String,
    pub url: String,
    pub children: Vec<Node>,
}

// ---- JSON for the panel ----------------------------------------------------

/// The root's children as a nested JSON array: bookmarks are
/// `{"i":id,"u":url,"n":title}`, folders `{"i":id,"f":1,"n":name,"c":[...]}`.
/// `query` keeps the bookmarks whose title or URL contains it (case
/// insensitive) and the folders that still hold something; a folder whose
/// own name matches keeps its whole subtree.
pub fn tree_json(items: &[Entry], query: &str) -> String {
    let needle = query.trim().to_lowercase();
    fn kids<'a>(items: &'a [Entry], parent: u64) -> Vec<&'a Entry> {
        items.iter().filter(|e| e.parent == parent).collect()
    }
    fn bookmark_json(e: &Entry, out: &mut String) {
        out.push_str(&format!("{{\"i\":{},\"u\":{},\"n\":{}}}", e.id, json_string(&e.url), json_string(&e.title)));
    }
    fn emit_all(e: &Entry, items: &[Entry], out: &mut String) {
        out.push_str(&format!("{{\"i\":{},\"f\":1,\"n\":{},\"c\":[", e.id, json_string(&e.title)));
        for (i, c) in kids(items, e.id).iter().enumerate() {
            if i > 0 {
                out.push(',');
            }
            if c.folder {
                emit_all(c, items, out);
            } else {
                bookmark_json(c, out);
            }
        }
        out.push_str("]}");
    }
    /// Emits the folder with only the matching descendants; false when nothing matched.
    fn emit_filtered(e: &Entry, items: &[Entry], needle: &str, out: &mut String) -> bool {
        out.push_str(&format!("{{\"i\":{},\"f\":1,\"n\":{},\"c\":[", e.id, json_string(&e.title)));
        let mut any = false;
        for c in kids(items, e.id) {
            if c.folder {
                if needle.is_empty() || c.title.to_lowercase().contains(needle) {
                    if any {
                        out.push(',');
                    }
                    any = true;
                    emit_all(c, items, out);
                } else {
                    let mut sub = String::new();
                    if emit_filtered(c, items, needle, &mut sub) {
                        if any {
                            out.push(',');
                        }
                        any = true;
                        out.push_str(&sub);
                    }
                }
            } else if needle.is_empty() || c.title.to_lowercase().contains(needle) || c.url.to_lowercase().contains(needle) {
                if any {
                    out.push(',');
                }
                any = true;
                bookmark_json(c, out);
            }
        }
        out.push_str("]}");
        any
    }
    let mut out = String::from("[");
    let mut first = true;
    for e in kids(items, 0) {
        if e.folder {
            if needle.is_empty() || e.title.to_lowercase().contains(&needle) {
                if !first {
                    out.push(',');
                }
                first = false;
                emit_all(e, items, &mut out);
            } else {
                let mut sub = String::new();
                if emit_filtered(e, items, &needle, &mut sub) {
                    if !first {
                        out.push(',');
                    }
                    first = false;
                    out.push_str(&sub);
                }
            }
        } else if needle.is_empty() || e.title.to_lowercase().contains(&needle) || e.url.to_lowercase().contains(&needle) {
            if !first {
                out.push(',');
            }
            first = false;
            bookmark_json(e, &mut out);
        }
    }
    out.push(']');
    out
}

// ---- NETSCAPE bookmark file -------------------------------------------------

/// Parses a Chrome/Firefox bookmark export into root nodes. Anything that is
/// not `<DL>`/`<DT><A HREF>`/`<H3>` structure is skipped; entities in titles
/// and URLs are decoded.
pub fn parse_netscape(html: &str) -> Vec<Node> {
    let c: Vec<char> = html.chars().collect();
    let mut pos = 0;
    // Find the first <dl ...>.
    while pos < c.len() {
        if c[pos] == '<' {
            if let Some((name, _, end)) = peek_tag(&c, pos) {
                if name == "dl" {
                    pos = end;
                    return parse_dl(&c, &mut pos);
                }
                pos = end;
                continue;
            }
        }
        pos += 1;
    }
    Vec::new()
}

/// A tag read without consuming it: (lowercase name, raw attributes, index
/// just past '>'). "</x" comes back as name "/x".
fn peek_tag(c: &[char], pos: usize) -> Option<(String, String, usize)> {
    if c.get(pos) != Some(&'<') {
        return None;
    }
    let mut end = pos + 1;
    while end < c.len() && c[end] != '>' {
        end += 1;
    }
    if end >= c.len() {
        return None;
    }
    let inner: String = c[pos + 1..end].iter().collect();
    let inner = inner.trim_end_matches('/').trim_end();
    let name_len = inner.find(|ch: char| ch.is_whitespace()).unwrap_or(inner.len());
    let name = inner[..name_len].to_lowercase();
    let attrs = inner[name_len..].trim().to_owned();
    Some((name, attrs, end + 1))
}

/// Reads text until the closing tag `name`, decoding entities; consumes it.
fn read_text_to_close(c: &[char], pos: &mut usize, name: &str) -> String {
    let mut out = String::new();
    while *pos < c.len() {
        if c[*pos] == '<' {
            if let Some((tag, _, end)) = peek_tag(c, *pos) {
                if tag == format!("/{name}") {
                    *pos = end;
                    break;
                }
                *pos = end; // skip a nested tag
                continue;
            }
        }
        out.push(c[*pos]);
        *pos += 1;
    }
    decode_entities(out.trim())
}

/// The children of one `<dl>` level.
fn parse_dl(c: &[char], pos: &mut usize) -> Vec<Node> {
    let mut out = Vec::new();
    while *pos < c.len() {
        if c[*pos] != '<' {
            *pos += 1; // text between tags (whitespace, stray words)
            continue;
        }
        let Some((name, attrs, end)) = peek_tag(c, *pos) else { break };
        if name.starts_with('/') {
            *pos = end;
            if name == "/dl" {
                return out;
            }
            continue;
        }
        match name.as_str() {
            "a" => {
                *pos = end;
                let url = attr(&attrs, "href").unwrap_or_default();
                let title = read_text_to_close(c, pos, "a");
                out.push(Node { folder: false, title, url, children: Vec::new() });
            }
            "h3" => {
                *pos = end;
                let title = read_text_to_close(c, pos, "h3");
                // The folder's <dl> follows; anything else ends it (left for the outer loop).
                let mut children = Vec::new();
                loop {
                    while *pos < c.len() && c[*pos] != '<' {
                        *pos += 1;
                    }
                    if *pos >= c.len() {
                        break;
                    }
                    match peek_tag(c, *pos) {
                        Some((tag, _, tag_end)) if tag == "dl" => {
                            *pos = tag_end;
                            children = parse_dl(c, pos);
                            break;
                        }
                        Some((tag, _, _)) if tag.starts_with('/') => {
                            // </dl> of this level with an empty folder: leave it to the outer loop
                            break;
                        }
                        Some(_) => break, // a new entry: not consumed
                        None => break,
                    }
                }
                out.push(Node { folder: true, title, url: String::new(), children });
            }
            _ => {
                *pos = end; // dt, p, meta, comments, ...
            }
        }
    }
    out
}

/// `name="value"` or `name='value'` (case-insensitive name) from a tag's raw attributes.
fn attr(attrs: &str, want: &str) -> Option<String> {
    let a = attrs.to_lowercase();
    let w = want.to_lowercase();
    let mut from = 0;
    while let Some(at) = a[from..].find(&w) {
        let at = from + at;
        let before_ok = at == 0 || a.as_bytes()[at - 1].is_ascii_whitespace();
        let mut i = at + w.len();
        if before_ok && a[i..].starts_with('=') {
            i += 1;
            while i < a.len() && a.as_bytes()[i].is_ascii_whitespace() {
                i += 1;
            }
            if i < a.len() && (a.as_bytes()[i] == b'"' || a.as_bytes()[i] == b'\'') {
                let q = a.as_bytes()[i];
                if let Some(close) = a[i + 1..].find(q as char) {
                    return Some(decode_entities(&attrs[i + 1..i + 1 + close]));
                }
            }
        }
        from = at + w.len();
    }
    None
}

/// The HTML entities bookmark files use (plus numeric ones).
pub fn decode_entities(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    let mut rest = s;
    while let Some(at) = rest.find('&') {
        out.push_str(&rest[..at]);
        let after = &rest[at + 1..];
        let semi = after.find(';');
        let (entity, consumed) = match semi {
            Some(si) if si <= 10 => (&after[..si], si + 1),
            _ => {
                out.push('&');
                rest = after;
                continue;
            }
        };
        match entity {
            "amp" => out.push('&'),
            "lt" => out.push('<'),
            "gt" => out.push('>'),
            "quot" => out.push('"'),
            "apos" | "#39" => out.push('\''),
            "nbsp" => out.push('\u{a0}'),
            num if num.starts_with("#x") || num.starts_with("#X") => {
                if let Ok(n) = u32::from_str_radix(&num[2..], 16) {
                    out.push(char::from_u32(n).unwrap_or('\u{fffd}'));
                } else {
                    out.push('&');
                    out.push_str(entity);
                    out.push(';');
                }
            }
            num if num.starts_with('#') => {
                if let Ok(n) = num[1..].parse::<u32>() {
                    out.push(char::from_u32(n).unwrap_or('\u{fffd}'));
                } else {
                    out.push('&');
                    out.push_str(entity);
                    out.push(';');
                }
            }
            _ => {
                out.push('&');
                out.push_str(entity);
                out.push(';');
            }
        }
        rest = &after[consumed..];
    }
    out.push_str(rest);
    out
}

pub fn escape_html(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    for ch in s.chars() {
        match ch {
            '&' => out.push_str("&amp;"),
            '<' => out.push_str("&lt;"),
            '>' => out.push_str("&gt;"),
            '"' => out.push_str("&quot;"),
            c => out.push(c),
        }
    }
    out
}

/// The root's children as a NETSCAPE bookmark file, the format Chrome and
/// Firefox export (and import back).
pub fn export_html(items: &[Entry]) -> String {
    let mut out = String::from(
        "<!DOCTYPE NETSCAPE-Bookmark-file-1>\n\
         <!-- This is an automatically generated file.\n\
         It will be read and overwritten.\n\
         DO NOT EDIT! -->\n\
         <META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=UTF-8\">\n\
         <TITLE>Bookmarks</TITLE>\n\
         <H1>Bookmarks</H1>\n\
         <DL><p>\n",
    );
    write_nodes(items, 0, 1, &mut out);
    out.push_str("</DL><p>\n");
    out
}

fn write_nodes(items: &[Entry], parent: u64, depth: usize, out: &mut String) {
    let pad = "    ".repeat(depth);
    for e in items.iter().filter(|e| e.parent == parent) {
        if e.folder {
            out.push_str(&format!("{pad}<DT><H3>{}</H3>\n{pad}<DL><p>\n", escape_html(&e.title)));
            write_nodes(items, e.id, depth + 1, out);
            out.push_str(&format!("{pad}</DL><p>\n"));
        } else {
            out.push_str(&format!("{pad}<DT><A HREF=\"{}\">{}</A>\n", escape_html(&e.url), escape_html(&e.title)));
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn entry(id: u64, folder: bool, parent: u64, title: &str, url: &str) -> Entry {
        Entry { id, folder, parent, title: title.to_owned(), url: url.to_owned() }
    }

    const CHROME: &str = r##"<!DOCTYPE NETSCAPE-Bookmark-file-1>
<!-- This is an automatically generated file. -->
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>Bookmarks</TITLE>
<H1>Bookmarks</H1>
<DL><p>
    <DT><A HREF="https://example.com/" ADD_DATE="1700000000">Example &amp; Co</A>
    <DT><H3 ADD_DATE="1700000001" PERSONAL_TOOLBAR_FOLDER="true">Toolbar</H3>
    <DL><p>
        <DT><A HREF="https://a.example/x?q=1&lt;2">A &lt;page&gt;</A>
        <DT><H3>Sub &#x1F600;</H3>
        <DL><p>
            <DT><A HREF='https://b.example/'>B</A>
        </DL><p>
    </DL><p>
    <DT><A HREF="javascript:alert(1)">not imported</A>
</DL><p>
"##;

    #[test]
    fn parses_chrome_and_firefox_files() {
        let roots = parse_netscape(CHROME);
        assert_eq!(roots.len(), 3);
        assert_eq!(roots[0].url, "https://example.com/");
        assert_eq!(roots[0].title, "Example & Co");
        assert!(!roots[0].folder);
        assert!(roots[1].folder);
        assert_eq!(roots[1].title, "Toolbar");
        assert_eq!(roots[1].children.len(), 2);
        assert_eq!(roots[1].children[0].url, "https://a.example/x?q=1<2");
        assert_eq!(roots[1].children[0].title, "A <page>");
        assert!(roots[1].children[1].folder);
        assert_eq!(roots[1].children[1].title, "Sub \u{1f600}");
        assert_eq!(roots[1].children[1].children[0].url, "https://b.example/");
        assert_eq!(roots[2].url, "javascript:alert(1)");

        // Firefox shape: lowercase tags, no <p>, extra whitespace.
        let ff = "<dl><dt><a href=\"https://ff.example/\">FF</a><dt><h3>Dir</h3><dl><dt><a href=\"https://ff.example/2\">2</a></dl></dl>";
        let roots = parse_netscape(ff);
        assert_eq!(roots.len(), 2);
        assert_eq!(roots[0].title, "FF");
        assert_eq!(roots[1].children[0].url, "https://ff.example/2");
        assert!(parse_netscape("").is_empty());
        assert_eq!(parse_netscape("<html><body>no list</body></html>").len(), 0);
    }

    #[test]
    fn export_import_round_trip() {
        let items = vec![
            entry(1, false, 0, "Example & <Co>", "https://example.com/?a=1&b=2"),
            entry(2, true, 0, "Dir \"quoted\"", ""),
            entry(3, false, 2, "A", "https://a.example/"),
            entry(4, true, 2, "Sub", ""),
            entry(5, false, 4, "B", "https://b.example/"),
        ];
        let html = export_html(&items);
        assert!(html.starts_with("<!DOCTYPE NETSCAPE-Bookmark-file-1>"));
        assert!(html.contains("HREF=\"https://example.com/?a=1&amp;b=2\""));
        assert!(html.contains("Example &amp; &lt;Co&gt;"));
        let roots = parse_netscape(&html);
        assert_eq!(roots.len(), 2);
        assert_eq!(roots[0].url, "https://example.com/?a=1&b=2");
        assert_eq!(roots[0].title, "Example & <Co>");
        assert_eq!(roots[1].title, "Dir \"quoted\"");
        assert_eq!(roots[1].children.len(), 2);
        assert_eq!(roots[1].children[1].children[0].url, "https://b.example/");
    }

    #[test]
    fn tree_json_nests_and_filters() {
        let items = vec![
            entry(1, false, 0, "Example", "https://example.com/"),
            entry(2, true, 0, "News", ""),
            entry(3, false, 2, "Paper", "https://paper.example/"),
            entry(4, true, 2, "Old", ""),
            entry(5, false, 4, "Archive", "https://archive.example/"),
        ];
        assert_eq!(tree_json(&items, ""),
            "[{\"i\":1,\"u\":\"https://example.com/\",\"n\":\"Example\"},\
              {\"i\":2,\"f\":1,\"n\":\"News\",\"c\":[\
                {\"i\":3,\"u\":\"https://paper.example/\",\"n\":\"Paper\"},\
                {\"i\":4,\"f\":1,\"n\":\"Old\",\"c\":[{\"i\":5,\"u\":\"https://archive.example/\",\"n\":\"Archive\"}]}]}]");
        // a URL match keeps the folder chain
        assert_eq!(tree_json(&items, "ARCHIVE.example"),
            "[{\"i\":2,\"f\":1,\"n\":\"News\",\"c\":[{\"i\":4,\"f\":1,\"n\":\"Old\",\"c\":[{\"i\":5,\"u\":\"https://archive.example/\",\"n\":\"Archive\"}]}]}]");
        // a folder name match keeps its whole subtree
        assert_eq!(tree_json(&items, "old").matches("\"i\":").count(), 3); // the News chain plus Old and Archive
        assert_eq!(tree_json(&items, "nothing"), "[]");
        assert_eq!(tree_json(&[], ""), "[]");
    }

    #[test]
    fn entities_decode() {
        assert_eq!(decode_entities("a &amp; b &lt;c&gt; &quot;d&quot; &#65;&#x42; &nbsp;e &unknown; &"), "a & b <c> \"d\" AB \u{a0}e &unknown; &");
    }
}
