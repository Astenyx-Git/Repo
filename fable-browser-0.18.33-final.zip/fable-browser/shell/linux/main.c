/* Fable for Linux: GTK 3 + WebKitGTK (webkit2gtk-4.1) shell.
 *
 * Each window is a row of chrome (back, forward, reload, address bar, the
 * tab strip, "+", the menu button) over its tabs. The menu button opens the
 * same panel as on Android (ui/panel.html: menu, settings, history, resource
 * list, metadata) in a popover, talking to this shell by messages.
 *
 * Private windows, as in Chrome: an ephemeral web context of their own (cookies,
 * cache and storage only in memory), dropped when the last private window
 * closes; no history. Blocking runs in the web process (webext.c), which also
 * reports blocked requests and media it sees.
 *
 * Ctrl+T tab · Ctrl+N window · Ctrl+Shift+N private window · Ctrl+W close tab ·
 * Ctrl+Shift+W close window · Ctrl+L address · Ctrl+R/F5 reload · Alt+←/→ ·
 * Ctrl+H history · Ctrl+Shift+R reader · Ctrl +/−/0 zoom · F10 menu
 */
#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>
#include <jsc/jsc.h>
#include <libsoup/soup.h>
#include <webkit2/webkit2.h>
#include <math.h>
#include <string.h>
#include "fable_core.h"

#define NEWTAB_URI "fable://newtab"
/* The new-tab page, exactly: fable://newtab (WebKit may add the "/"). A prefix
 * test would also take fable://newtab.example or fable://newtab/../x. */
static gboolean is_newtab(const char *uri) {
    return uri && (!strcmp(uri, NEWTAB_URI) || !strcmp(uri, NEWTAB_URI "/"));
}
#define PANEL_URI "fable://panel/"
#define SLEEP_CHECK_SECONDS 30
#define ANDROID_UA "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
#define IPHONE_UA "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1"
#define IPAD_UA "Mozilla/5.0 (iPad; CPU OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1"
#define CHROME_WIN_UA "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
#define CHROME_MAC_UA "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
#define SAFARI_MAC_UA "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Safari/605.1.15"
#define FIREFOX_UA "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0"
#define EDGE_UA "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0"

static const char *preset_ua(const char *mode) {
    if (strcmp(mode, "android") == 0) return ANDROID_UA;
    if (strcmp(mode, "iphone") == 0) return IPHONE_UA;
    if (strcmp(mode, "ipad") == 0) return IPAD_UA;
    if (strcmp(mode, "chrome_win") == 0) return CHROME_WIN_UA;
    if (strcmp(mode, "chrome_mac") == 0) return CHROME_MAC_UA;
    if (strcmp(mode, "safari_mac") == 0) return SAFARI_MAC_UA;
    if (strcmp(mode, "firefox") == 0) return FIREFOX_UA;
    if (strcmp(mode, "edge") == 0) return EDGE_UA;
    return NULL;
}
#ifndef FABLE_WEBEXT_DIR
#define FABLE_WEBEXT_DIR "/usr/local/lib/fable/webext"
#endif

typedef struct Win Win;

typedef struct {
    uint32_t id;          /* id in the core's tab table                 */
    Win *win;
    GtkWidget *slot;      /* notebook page: a box holding the view      */
    GtkWidget *label;     /* title label inside the tab                 */
    GtkWidget *icon;      /* the site's icon, or a placeholder          */
    WebKitWebView *view;  /* NULL while the tab is asleep               */
    char *url;            /* last known URL, used to wake the tab       */
    char *title;
} Tab;

struct Win {
    GtkWidget *window, *notebook, *entry, *back, *forward, *home, *reload, *plus, *menu, *toast;
    gboolean private;
    guint toast_timer;
};

static struct {
    FableTabs *tabs;
    WebKitWebContext *normal, *private;  /* private: ephemeral, from the first private window to the last */
    WebKitSettings *settings;            /* shared by every page view                                     */
    GList *wins;                         /* Win*, the most recently focused first                          */
    GtkWidget *popover;                  /* the panel                                                      */
    WebKitWebView *panel;
    GtkWidget *panel_box;                /* holds the panel and carries its size (a web view will not shrink) */
    gboolean panel_loaded;
    GString *panel_queue;                /* scripts waiting for the panel page to load                     */
    char *panel_view;                    /* the view the panel was opened on                               */
    SoupSession *soup;
    GHashTable *text;                    /* the UI strings in use, by key                                  */
    uint64_t blocked;                    /* counted in the web processes                                   */
    char *nonce;                         /* proves a "fable" message came from our new-tab page (see below) */
    guint find_index, find_total;        /* find in page, front tab: the match shown (from 1), and how many */
} app;

static Tab *tab_new(Win *w, const char *input, gboolean background, WebKitWebView *related);
static Win *win_new(gboolean private);
static void win_close(Win *w);
static void tab_close(Tab *t);
static void show_panel(Win *w, const char *view);
static void panel_run(const char *script);
static void save_session(void);
static void update_entry_icon(Win *w);
static void import_bookmarks_file(Win *w);
static void export_bookmarks_file(Win *w);
static void scan_image_file(Win *w);

/* ---- small helpers ------------------------------------------------------ */

static uint64_t now_ms(void) { return (uint64_t)(g_get_monotonic_time() / 1000); }
static uint64_t wall_ms(void) { return (uint64_t)(g_get_real_time() / 1000); }

/* A UI string in the language in effect; valid until the language changes. */
static const char *T(const char *key) {
    const char *hit = g_hash_table_lookup(app.text, key);
    if (hit) return hit;
    char *s = fable_tr(key);
    char *copy = g_strdup(s);
    fable_string_free(s);
    g_hash_table_insert(app.text, g_strdup(key), copy);
    return copy;
}

static char *TN(const char *key, const char *n) {   /* "{n}" filled in; g_free */
    GString *s = g_string_new(T(key));
    char *at = strstr(s->str, "{n}");
    if (at) {
        gssize pos = at - s->str;
        g_string_erase(s, pos, 3);
        g_string_insert(s, pos, n ? n : "");
    }
    return g_string_free(s, FALSE);
}

static char *setting(const char *key) {   /* g_free */
    char *s = fable_setting_get(key);
    char *copy = g_strdup(s);
    fable_string_free(s);
    return copy;
}

static gboolean setting_is(const char *key, const char *value) {
    char *s = setting(key);
    gboolean same = strcmp(s, value) == 0;
    g_free(s);
    return same;
}

static void json_str(GString *out, const char *s) {
    char *q = fable_json_string(s ? s : "");
    g_string_append(out, q);
    fable_string_free(q);
}

static Tab *tab_of_slot(GtkWidget *slot) { return slot ? g_object_get_data(G_OBJECT(slot), "fable-tab") : NULL; }

static Tab *win_tab(Win *w) {
    int n = gtk_notebook_get_current_page(GTK_NOTEBOOK(w->notebook));
    return n < 0 ? NULL : tab_of_slot(gtk_notebook_get_nth_page(GTK_NOTEBOOK(w->notebook), n));
}

static Win *front_win(void) { return app.wins ? app.wins->data : NULL; }
static Tab *front_tab(void) { return front_win() ? win_tab(front_win()) : NULL; }

static Win *front_win_of(gboolean private) {
    for (GList *l = app.wins; l; l = l->next)
        if (((Win *)l->data)->private == private) return l->data;
    return NULL;
}

/* Every tab of every window, for lookups by id. */
static GList *all_tabs(void) {
    GList *out = NULL;
    for (GList *l = app.wins; l; l = l->next) {
        Win *w = l->data;
        int count = gtk_notebook_get_n_pages(GTK_NOTEBOOK(w->notebook));
        for (int i = 0; i < count; i++) {
            Tab *t = tab_of_slot(gtk_notebook_get_nth_page(GTK_NOTEBOOK(w->notebook), i));
            if (t) out = g_list_append(out, t);
        }
    }
    return out;
}

static Tab *tab_by_id(uint32_t id) {
    GList *tabs = all_tabs();
    Tab *hit = NULL;
    for (GList *l = tabs; l && !hit; l = l->next)
        if (((Tab *)l->data)->id == id) hit = l->data;
    g_list_free(tabs);
    return hit;
}

static Tab *tab_of_view(WebKitWebView *view) {
    GList *tabs = all_tabs();
    Tab *hit = NULL;
    for (GList *l = tabs; l && !hit; l = l->next)
        if (((Tab *)l->data)->view == view) hit = l->data;
    g_list_free(tabs);
    return hit;
}

/* An icon from the theme, or none at all rather than a "missing image" mark. */
static void set_icon(GtkWidget *image, const char *name) {
    if (gtk_icon_theme_has_icon(gtk_icon_theme_get_default(), name)) {
        gtk_image_set_from_icon_name(GTK_IMAGE(image), name, GTK_ICON_SIZE_MENU);
        gtk_widget_show(image);
    } else {
        gtk_widget_hide(image);
    }
}

static gboolean is_home(const char *url) { return !url || !*url || is_newtab(url); }   /* display only: titles, the address bar */
static gboolean is_web(const char *url) { return url && (g_str_has_prefix(url, "http://") || g_str_has_prefix(url, "https://")); }

/* ---- toasts ------------------------------------------------------------- */

static gboolean toast_hide(gpointer data) {
    Win *w = data;
    w->toast_timer = 0;
    gtk_widget_hide(w->toast);
    return G_SOURCE_REMOVE;
}

static void say(Win *w, const char *text) {
    if (!w) return;
    gtk_label_set_text(GTK_LABEL(w->toast), text);
    gtk_widget_show(w->toast);
    if (w->toast_timer) g_source_remove(w->toast_timer);
    w->toast_timer = g_timeout_add(2400, toast_hide, w);
}

/* ---- settings ----------------------------------------------------------- */

static void apply_cookie_policy(WebKitWebContext *ctx) {
    if (!ctx) return;
    gboolean block = !setting_is("block_3p_cookies", "0");
    webkit_cookie_manager_set_accept_policy(webkit_web_context_get_cookie_manager(ctx),
        block ? WEBKIT_COOKIE_POLICY_ACCEPT_NO_THIRD_PARTY : WEBKIT_COOKIE_POLICY_ACCEPT_ALWAYS);
}

/* What this process blocks, as "trackers:ads" ("0" or "1" each). The web
 * process has a copy of the core of its own, so it is told. */
static char *blocking_state(void) {
    gboolean trackers = !setting_is("block_trackers", "0");
    gboolean ads = setting_is("block_ads", "1");
    return g_strdup_printf("%d:%d", trackers ? 1 : 0, ads ? 1 : 0);
}

static void apply_blocking(WebKitWebContext *ctx) {
    if (!ctx) return;
    char *state = blocking_state();
    webkit_web_context_send_message_to_all_extensions(ctx, webkit_user_message_new("fable.block", g_variant_new_string(state)));
    g_free(state);
}

static void apply_page_settings(void) {
    webkit_settings_set_enable_javascript(app.settings, !setting_is("javascript", "0"));
    webkit_settings_set_auto_load_images(app.settings, !setting_is("data_saver", "1"));
    char *mode = setting("ua_mode");
    char *custom = setting("ua_custom");
    const char *ua = preset_ua(mode);
    if (!ua && strcmp(mode, "custom") == 0 && *custom) ua = custom;
    webkit_settings_set_user_agent(app.settings, ua);   /* NULL: WebKit's own */
    g_free(mode);
    g_free(custom);
}

/* The "text size" setting: on desktops the default zoom of every page (50–300%), since
 * text-only zoom would leave layouts built for the default size. */
static double default_zoom(void) {
    char *v = setting("text_size");
    double z = *v ? g_ascii_strtod(v, NULL) / 100.0 : 1.0;
    g_free(v);
    return z >= 0.5 && z <= 3.0 ? z : 1.0;
}

static void apply_home_buttons(void);

static void apply_zoom_all(void) {
    GList *tabs = all_tabs();
    for (GList *l = tabs; l; l = l->next) {
        Tab *t = l->data;
        if (t->view) webkit_web_view_set_zoom_level(t->view, default_zoom());
    }
    g_list_free(tabs);
}

static void apply_sleep(void) {
    char *minutes = setting("sleep_minutes");
    const char *env = g_getenv("FABLE_SLEEP_AFTER_SECONDS");
    if (env) fable_tabs_set_sleep_after_ms(app.tabs, g_ascii_strtoull(env, NULL, 10) * 1000);
    else if (*minutes) fable_tabs_set_sleep_after_ms(app.tabs, g_ascii_strtoull(minutes, NULL, 10) * 60000);
    g_free(minutes);
}

static void relabel_all(void);
static void panel_load(void);
static void apply_style(void);

/* A setting the panel just changed. */
static void setting_changed(const char *key) {
    if (strcmp(key, "language") == 0) {
        g_hash_table_remove_all(app.text);
        relabel_all();
        panel_load();   /* the panel page carries its strings */
    } else if (strcmp(key, "block_3p_cookies") == 0) {
        apply_cookie_policy(app.normal);
        apply_cookie_policy(app.private);
    } else if (strcmp(key, "block_trackers") == 0 || strcmp(key, "block_ads") == 0) {
        apply_blocking(app.normal);
        apply_blocking(app.private);
    } else if (!strcmp(key, "javascript") || !strcmp(key, "data_saver") || !strcmp(key, "ua_mode") || !strcmp(key, "ua_custom")) {
        apply_page_settings();
    } else if (strcmp(key, "sleep_minutes") == 0) {
        apply_sleep();
    } else if (strcmp(key, "text_size") == 0) {
        apply_zoom_all();
    } else if (strcmp(key, "home_button") == 0) {
        apply_home_buttons();
    }
}

/* ---- chrome ------------------------------------------------------------- */

static void set_tab_label(Tab *t) {
    const char *title = t->title && *t->title ? t->title : is_home(t->url) ? T("newtab") : t->url;
    gtk_label_set_text(GTK_LABEL(t->label), title);
    gtk_widget_set_tooltip_text(t->label, title);
}

static void win_title(Win *w) {
    Tab *t = win_tab(w);
    const char *page = t ? gtk_label_get_text(GTK_LABEL(t->label)) : "";
    char *title = w->private ? g_strdup_printf("%s — %s (%s)", page, T("brand_name"), T("private_mode")) : g_strdup_printf("%s — %s", page, T("brand_name"));
    gtk_window_set_title(GTK_WINDOW(w->window), title);
    g_free(title);
}

/* The icon at the right end of the address bar: the QR-from-image button
 * while the field is empty, the bookmark star once a web page's address is
 * in it, and nothing otherwise. The two share the secondary slot, so only
 * one shows at a time; the star is hidden in private windows. */
static void update_entry_icon(Win *w) {
    GtkEntry *entry = GTK_ENTRY(w->entry);
    if (gtk_entry_get_text_length(entry) == 0) {
        gtk_entry_set_icon_from_icon_name(entry, GTK_ENTRY_ICON_SECONDARY, "image-x-generic-symbolic");
        return;
    }
    Tab *t = win_tab(w);
    if (t && !w->private && is_web(t->url)) {
        gtk_entry_set_icon_from_icon_name(entry, GTK_ENTRY_ICON_SECONDARY,
                                          fable_bookmark_id(t->url) ? "starred-symbolic" : "non-starred-symbolic");
        return;
    }
    gtk_entry_set_icon_from_icon_name(entry, GTK_ENTRY_ICON_SECONDARY, NULL);
}

/* Reflect the window's tab in the address bar and the buttons. Page-driven
 * updates leave the address bar alone while the user is typing in it. */
static void show_in_chrome(Win *w, gboolean force) {
    Tab *t = win_tab(w);
    if (!t) return;
    if (force || !gtk_widget_has_focus(w->entry))
        gtk_entry_set_text(GTK_ENTRY(w->entry), is_home(t->url) ? "" : t->url);
    gtk_widget_set_sensitive(w->back, t->view && webkit_web_view_can_go_back(t->view));
    gtk_widget_set_sensitive(w->forward, t->view && webkit_web_view_can_go_forward(t->view));
    win_title(w);
    update_entry_icon(w);
}

static void relabel_win(Win *w) {
    gtk_entry_set_placeholder_text(GTK_ENTRY(w->entry), T("addr_hint"));
    gtk_widget_set_tooltip_text(w->back, T("go_back"));
    gtk_widget_set_tooltip_text(w->forward, T("go_forward"));
    gtk_widget_set_tooltip_text(w->home, T("go_home"));
    gtk_widget_set_tooltip_text(w->reload, T("reload"));
    gtk_widget_set_tooltip_text(w->plus, T(w->private ? "new_private" : "new_tab_btn"));
    gtk_widget_set_tooltip_text(w->menu, T("menu"));
    int count = gtk_notebook_get_n_pages(GTK_NOTEBOOK(w->notebook));
    for (int i = 0; i < count; i++) {
        Tab *t = tab_of_slot(gtk_notebook_get_nth_page(GTK_NOTEBOOK(w->notebook), i));
        if (!t) continue;
        set_tab_label(t);
        if (t->view && is_home(t->url)) webkit_web_view_reload(t->view);   /* the new-tab page in the new language */
    }
    show_in_chrome(w, TRUE);
}

static void relabel_all(void) {
    for (GList *l = app.wins; l; l = l->next) relabel_win(l->data);
}

/* Every tab showing the new-tab page draws it again (a skin's colours and logo). */
static void reload_home_tabs(void) {
    for (GList *l = app.wins; l; l = l->next) {
        Win *w = l->data;
        int count = gtk_notebook_get_n_pages(GTK_NOTEBOOK(w->notebook));
        for (int i = 0; i < count; i++) {
            Tab *t = tab_of_slot(gtk_notebook_get_nth_page(GTK_NOTEBOOK(w->notebook), i));
            if (t && t->view && is_newtab(t->url)) webkit_web_view_reload(t->view);
        }
    }
}

static void navigate(Tab *t, const char *input) {
    char *url = fable_resolve(input);
    int skin = fable_theme_apply(url);
    if (skin >= 0) {   /* theme://name: a skin, not a page, and nothing is said; a name that is no skin changes nothing */
        fable_string_free(url);
        if (skin == 1) {
            g_hash_table_remove_all(app.text);
            for (GList *l = app.wins; l; l = l->next) win_title(l->data);
            apply_style();       /* the windows */
            reload_home_tabs();  /* the new-tab pages */
            panel_load();        /* the panel page carries its colours */
        }
        show_in_chrome(t->win, TRUE);
        return;
    }
    if (t->view) webkit_web_view_load_uri(t->view, *url ? url : NEWTAB_URI);
    fable_string_free(url);
    if (t->view) gtk_widget_grab_focus(GTK_WIDGET(t->view));
}

/* ---- web view signals --------------------------------------------------- */

static void on_uri_changed(WebKitWebView *view, GParamSpec *pspec, Tab *t) {
    (void)pspec;
    const char *uri = webkit_web_view_get_uri(view);
    if (!uri) return;
    g_free(t->url);
    t->url = g_strdup(uri);
    if (t == win_tab(t->win)) show_in_chrome(t->win, FALSE);
}

static void on_title_changed(WebKitWebView *view, GParamSpec *pspec, Tab *t) {
    (void)pspec;
    g_free(t->title);
    t->title = g_strdup(webkit_web_view_get_title(view));
    set_tab_label(t);
    if (t == win_tab(t->win)) win_title(t->win);
}

static void on_favicon_changed(WebKitWebView *view, GParamSpec *pspec, Tab *t) {
    (void)pspec;
    cairo_surface_t *surface = webkit_web_view_get_favicon(view);
    GdkPixbuf *pixbuf = NULL;
    if (surface) {
        int w = cairo_image_surface_get_width(surface), h = cairo_image_surface_get_height(surface);
        GdkPixbuf *full = w > 0 && h > 0 ? gdk_pixbuf_get_from_surface(surface, 0, 0, w, h) : NULL;
        if (full) {
            pixbuf = gdk_pixbuf_scale_simple(full, 16, 16, GDK_INTERP_BILINEAR);
            g_object_unref(full);
        }
    }
    if (pixbuf) {
        gtk_image_set_from_pixbuf(GTK_IMAGE(t->icon), pixbuf);
        gtk_widget_show(t->icon);
        g_object_unref(pixbuf);
    } else {
        set_icon(t->icon, t->win->private ? "view-conceal-symbolic" : "web-browser-symbolic");
    }
}

static void on_load_changed(WebKitWebView *view, WebKitLoadEvent event, Tab *t) {
    if (event == WEBKIT_LOAD_COMMITTED) fable_sniff_clear(t->id);   /* a new page: a new resource list */
    if (event == WEBKIT_LOAD_FINISHED) {
        if (setting_is("block_ads", "1")) {
            /* Hide the ad boxes the page shows itself; the web extension
             * already stops the third-party ones. */
            char *script = fable_adblock_script();
            webkit_web_view_evaluate_javascript(t->view, script, -1, NULL, NULL, NULL, NULL, NULL);
            fable_string_free(script);
        }
        if (!t->win->private && is_web(webkit_web_view_get_uri(view))) {
            const char *title = webkit_web_view_get_title(view);
            fable_history_add(webkit_web_view_get_uri(view), title ? title : "", wall_ms());   /* private windows keep no history */
            save_session();   /* the snapshot follows along, so a crash loses little */
        }
    }
    if (t == win_tab(t->win)) show_in_chrome(t->win, FALSE);
}

/* target=_blank and window.open(): a tab of the same window, related to the
 * opener so sign-in pop-ups can talk back to it. WebKit loads the request. */
static GtkWidget *on_create(WebKitWebView *view, WebKitNavigationAction *action, Tab *t) {
    (void)action;
    Tab *opened = tab_new(t->win, NULL, FALSE, view);
    return GTK_WIDGET(opened->view);
}

/* window.close() from the page: close its tab, once the signal has returned. */
static gboolean close_later(gpointer data) {
    Tab *t = tab_by_id(GPOINTER_TO_UINT(data));
    if (t) tab_close(t);
    return G_SOURCE_REMOVE;
}
static void on_close_request(WebKitWebView *view, Tab *t) { (void)view; g_idle_add(close_later, GUINT_TO_POINTER(t->id)); }

/* Ctrl-click and middle-click open a background tab; downloads for what a
 * page cannot show. */
static gboolean on_decide_policy(WebKitWebView *view, WebKitPolicyDecision *decision, WebKitPolicyDecisionType type, Tab *t) {
    (void)view;
    if (type == WEBKIT_POLICY_DECISION_TYPE_NAVIGATION_ACTION) {
        WebKitNavigationAction *action = webkit_navigation_policy_decision_get_navigation_action(WEBKIT_NAVIGATION_POLICY_DECISION(decision));
        const char *uri = webkit_uri_request_get_uri(webkit_navigation_action_get_request(action));
        if (g_ascii_strncasecmp(uri, "fable:", 6) == 0 && !is_newtab(uri)) {
            webkit_policy_decision_ignore(decision);   /* only the new-tab page is served to tabs */
            return TRUE;
        }
        if (g_ascii_strncasecmp(uri, "theme:", 6) == 0) {
            webkit_policy_decision_ignore(decision);   /* icon packs are the address bar's (navigate); a page does not pick one */
            return TRUE;
        }
        if (fable_block_external_app(uri)) {
            webkit_policy_decision_ignore(decision);   /* the page tried to open another app */
            say(t->win, T("external_app_blocked"));
            return TRUE;
        }
        guint mods = webkit_navigation_action_get_modifiers(action);
        if (webkit_navigation_action_get_navigation_type(action) == WEBKIT_NAVIGATION_TYPE_LINK_CLICKED
            && (webkit_navigation_action_get_mouse_button(action) == 2 || (mods & GDK_CONTROL_MASK))) {
            tab_new(t->win, uri, !(mods & GDK_SHIFT_MASK), NULL);
            webkit_policy_decision_ignore(decision);
            return TRUE;
        }
    } else if (type == WEBKIT_POLICY_DECISION_TYPE_RESPONSE) {
        WebKitResponsePolicyDecision *r = WEBKIT_RESPONSE_POLICY_DECISION(decision);
        WebKitURIResponse *response = webkit_response_policy_decision_get_response(r);
        SoupMessageHeaders *headers = webkit_uri_response_get_http_headers(response);
        const char *disposition = headers ? soup_message_headers_get_one(headers, "Content-Disposition") : NULL;
        if (webkit_response_policy_decision_is_main_frame_main_resource(r)
            && (!webkit_response_policy_decision_is_mime_type_supported(r) || (disposition && g_ascii_strncasecmp(disposition, "attachment", 10) == 0))) {
            webkit_policy_decision_download(decision);
            return TRUE;
        }
    }
    return FALSE;
}

/* Messages from the web process (webext.c): a blocked request, a media URL. */
static gboolean on_user_message(WebKitWebView *view, WebKitUserMessage *message, Tab *t) {
    (void)view;
    const char *name = webkit_user_message_get_name(message);
    if (strcmp(name, "fable.blocked") == 0) {
        app.blocked++;
        return TRUE;
    }
    if (strcmp(name, "fable.sniff") == 0) {
        GVariant *p = webkit_user_message_get_parameters(message);
        const char *url = NULL, *hint = NULL;
        if (p && g_variant_is_of_type(p, G_VARIANT_TYPE("(ss)"))) g_variant_get(p, "(&s&s)", &url, &hint);
        if (url && fable_sniff_note(t->id, url, hint) && app.panel_view && strcmp(app.panel_view, "sniff") == 0) panel_run("Fable.refresh('sniff')");
        return TRUE;
    }
    return FALSE;
}

/* The new-tab page posts its search box text here (see ui/newtab.html) as
 * "<nonce>\n<text>". The nonce matters because WebKitGTK gives a pop-up
 * (webkit_web_view_new_with_related_view) its opener's user content manager,
 * handler included: whatever a pop-up posts arrives here with the opener's tab,
 * and WebKitGTK does not say which page sent it. Only our page knows the nonce:
 * it is written into the HTML served for fable://newtab, which no web page can
 * read, being of another origin. The tab must be showing that page as well. */

static const char *bridge_text(const char *message) {
    size_t n = strlen(app.nonce);
    return strncmp(message, app.nonce, n) == 0 && message[n] == '\n' ? message + n + 1 : NULL;
}

static void on_page_message(WebKitUserContentManager *manager, WebKitJavascriptResult *result, Tab *t) {
    (void)manager;
    JSCValue *value = webkit_javascript_result_get_js_value(result);
    if (!t->view || !jsc_value_is_string(value) || !is_newtab(webkit_web_view_get_uri(t->view))) return;
    char *message = jsc_value_to_string(value);
    const char *text = bridge_text(message);
    if (text) navigate(t, text);
    g_free(message);
}

/* ---- find in page: WebKitGTK's find controller, answered to the panel's find view ---- */

#define FIND_OPTIONS (WEBKIT_FIND_OPTIONS_CASE_INSENSITIVE | WEBKIT_FIND_OPTIONS_WRAP_AROUND)

static void find_report(Tab *t) {
    if (t != front_tab()) return;   /* a tab in the background finished counting */
    char js[64];
    snprintf(js, sizeof js, "Fable.find(%u,%u)", app.find_total ? app.find_index : 0u, app.find_total);
    panel_run(js);
}

static void on_find_counted(WebKitFindController *finder, guint count, Tab *t) {
    (void)finder;
    app.find_total = count;
    if (app.find_index == 0 || app.find_index > count) app.find_index = count ? 1 : 0;
    find_report(t);
}

static void on_find_failed(WebKitFindController *finder, Tab *t) {
    (void)finder;
    app.find_index = app.find_total = 0;
    find_report(t);
}

/* "find" (as the term is typed; empty clears), "findNext", "findPrev", "findStop".
 * WebKitGTK gives the count but not which match is shown: stepping counts it here,
 * the search wrapping around as the controller does. */
static void find_act(Tab *t, const char *name, const char *arg) {
    if (!t || !t->view) return;
    WebKitFindController *finder = webkit_web_view_get_find_controller(t->view);
    if (!strcmp(name, "find")) {
        app.find_index = app.find_total = 0;
        if (!arg || !*arg) {
            webkit_find_controller_search_finish(finder);
            return;
        }
        app.find_index = 1;
        webkit_find_controller_search(finder, arg, FIND_OPTIONS, G_MAXUINT);
        webkit_find_controller_count_matches(finder, arg, FIND_OPTIONS, G_MAXUINT);
    } else if (!strcmp(name, "findStop")) {
        webkit_find_controller_search_finish(finder);
        app.find_index = app.find_total = 0;
    } else if (webkit_find_controller_get_search_text(finder)) {
        gboolean next = !strcmp(name, "findNext");
        if (next) webkit_find_controller_search_next(finder);
        else webkit_find_controller_search_previous(finder);
        if (app.find_total) {
            app.find_index = next ? app.find_index % app.find_total + 1 : (app.find_index > 1 ? app.find_index - 1 : app.find_total);
            find_report(t);
        }
    }
}

static void make_view(Tab *t, WebKitWebView *related) {
    if (related) {
        t->view = WEBKIT_WEB_VIEW(webkit_web_view_new_with_related_view(related));
    } else {
        WebKitUserContentManager *manager = webkit_user_content_manager_new();
        webkit_user_content_manager_register_script_message_handler(manager, "fable");
        g_signal_connect(manager, "script-message-received::fable", G_CALLBACK(on_page_message), t);
        t->view = WEBKIT_WEB_VIEW(g_object_new(WEBKIT_TYPE_WEB_VIEW,
                                               "web-context", t->win->private ? app.private : app.normal,
                                               "settings", app.settings,
                                               "user-content-manager", manager, NULL));
        g_object_unref(manager);
    }
    webkit_web_view_set_zoom_level(t->view, default_zoom());
    g_signal_connect(t->view, "notify::uri", G_CALLBACK(on_uri_changed), t);
    g_signal_connect(t->view, "notify::title", G_CALLBACK(on_title_changed), t);
    g_signal_connect(t->view, "notify::favicon", G_CALLBACK(on_favicon_changed), t);
    g_signal_connect(t->view, "load-changed", G_CALLBACK(on_load_changed), t);
    g_signal_connect(t->view, "create", G_CALLBACK(on_create), t);
    g_signal_connect(t->view, "close", G_CALLBACK(on_close_request), t);
    g_signal_connect(t->view, "decide-policy", G_CALLBACK(on_decide_policy), t);
    g_signal_connect(t->view, "user-message-received", G_CALLBACK(on_user_message), t);
    WebKitFindController *finder = webkit_web_view_get_find_controller(t->view);   /* find in page; one per view */
    g_signal_connect(finder, "counted-matches", G_CALLBACK(on_find_counted), t);
    g_signal_connect(finder, "failed-to-find-text", G_CALLBACK(on_find_failed), t);
    gtk_box_pack_start(GTK_BOX(t->slot), GTK_WIDGET(t->view), TRUE, TRUE, 0);
    gtk_widget_show(GTK_WIDGET(t->view));
}

/* ---- tabs ---------------------------------------------------------------- */

static void tab_free(Tab *t) {
    fprintf(stderr, "DBG tab_free tabid=%u url=[%s]\n", t->id, t->url ? t->url : "(null)");
    fable_tabs_close(app.tabs, t->id);
    fable_sniff_clear(t->id);
    g_free(t->url);
    g_free(t->title);
    g_free(t);
}

static void tab_close(Tab *t) {
    Win *w = t->win;
    int n = gtk_notebook_page_num(GTK_NOTEBOOK(w->notebook), t->slot);
    g_object_set_data(G_OBJECT(t->slot), "fable-tab", NULL);
    gtk_notebook_remove_page(GTK_NOTEBOOK(w->notebook), n);   /* destroys slot, view and label */
    tab_free(t);
    if (gtk_notebook_get_n_pages(GTK_NOTEBOOK(w->notebook)) == 0) win_close(w);
    else save_session();
}

/* Snapshot the normal tabs (never the private ones) for the next start:
 * {"a":active index,"t":[{"u":url,"n":title}, ...]}, windows in focus order,
 * tabs in page order. */
static gboolean session_live;   /* off until start-up has read (and restored) the last snapshot */

static void save_session(void) {
    if (!session_live) return;   /* the first window's blank tab must not overwrite what is about to be restored */
    GString *s = g_string_new("{\"t\":[");
    int index = 0, active = 0;
    Tab *front = front_tab();
    for (GList *l = app.wins; l; l = l->next) {
        Win *w = l->data;
        if (w->private) continue;   /* private tabs never enter the snapshot */
        int count = gtk_notebook_get_n_pages(GTK_NOTEBOOK(w->notebook));
        for (int i = 0; i < count; i++) {
            Tab *t = tab_of_slot(gtk_notebook_get_nth_page(GTK_NOTEBOOK(w->notebook), i));
            if (!t) continue;
            /* The new-tab page is a tab of ours, not a web page: it goes into
             * the snapshot with an empty URL, so it comes back with the rest. */
            gboolean home = is_newtab(t->url);
            if (!home && !is_web(t->url)) continue;
            if (t == front) active = index;
            if (index) g_string_append_c(s, ',');
            g_string_append(s, "{\"u\":");
            json_str(s, home ? "" : t->url);
            g_string_append(s, ",\"n\":");
            json_str(s, t->title ? t->title : "");
            g_string_append_c(s, '}');
            index++;
        }
    }
    g_string_append_printf(s, "],\"a\":%d}", active);
    fable_session_save(s->str);
    g_string_free(s, TRUE);
}

/* Reopen the snapshot's tabs in a fresh normal window ("restore tabs on
 * start" is on unless the setting says "0"). FALSE when there was nothing. */
static gboolean restore_session(Win *w) {
    if (setting_is("restore_tabs", "0")) return FALSE;
    size_t n = fable_session_count();
    if (!n) return FALSE;
    /* Read it all first: opening and switching tabs saves the session again as it goes. */
    char **urls = g_new0(char *, n), **titles = g_new0(char *, n);
    for (size_t i = 0; i < n; i++) {
        urls[i] = fable_session_url(i);
        titles[i] = fable_session_title(i);
    }
    size_t active = fable_session_active();
    Tab *blank = win_tab(w);   /* the empty tab win_new opened: it goes once the others are there */
    Tab *front = NULL;
    for (size_t i = 0; i < n; i++) {
        /* An empty URL is Fable's own new-tab page: it comes back as one. */
        gboolean home = urls[i][0] == '\0';
        if (!home && !is_web(urls[i])) continue;   /* only web pages, whatever the file says */
        Tab *t = tab_new(w, home ? "" : urls[i], TRUE, NULL);
        gtk_notebook_reorder_child(GTK_NOTEBOOK(w->notebook), t->slot, -1);   /* in their old order, not each next to the front tab */
        if (*titles[i]) {
            g_free(t->title);
            t->title = g_strdup(titles[i]);
            set_tab_label(t);
        }
        if (!front || i == active) front = t;
    }
    for (size_t i = 0; i < n; i++) {
        fable_string_free(urls[i]);
        fable_string_free(titles[i]);
    }
    g_free(urls);
    g_free(titles);
    if (!front) return FALSE;
    gtk_notebook_set_current_page(GTK_NOTEBOOK(w->notebook), gtk_notebook_page_num(GTK_NOTEBOOK(w->notebook), front->slot));
    if (blank && blank != front) tab_close(blank);   /* never the last tab, so the window stays */
    show_in_chrome(w, TRUE);
    return TRUE;
}

static void on_close_clicked(GtkButton *button, Tab *t) { (void)button; tab_close(t); }

static gboolean on_tab_head_click(GtkWidget *head, GdkEventButton *event, Tab *t) {
    (void)head;
    if (event->type == GDK_BUTTON_PRESS && event->button == 2) { tab_close(t); return TRUE; }   /* middle-click closes */
    return FALSE;
}

static Tab *tab_new(Win *w, const char *input, gboolean background, WebKitWebView *related) {
    Tab *t = g_new0(Tab, 1);
    t->win = w;
    t->id = fable_tabs_open(app.tabs, now_ms());
    /* A tab with no address of its own shows the new-tab page: it knows so
     * from the start. Inserting the tab into the notebook saves the session
     * (the "switch-page" signal), so the address has to be there already. */
    if (!input || !*input) t->url = g_strdup(NEWTAB_URI);
    t->slot = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
    g_object_set_data(G_OBJECT(t->slot), "fable-tab", t);

    GtkWidget *events = gtk_event_box_new();
    GtkWidget *head = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 6);
    t->icon = gtk_image_new();
    t->label = gtk_label_new(T("newtab"));
    gtk_label_set_ellipsize(GTK_LABEL(t->label), PANGO_ELLIPSIZE_END);
    gtk_label_set_width_chars(GTK_LABEL(t->label), 12);
    gtk_label_set_max_width_chars(GTK_LABEL(t->label), 18);
    gtk_label_set_xalign(GTK_LABEL(t->label), 0);
    GtkWidget *close = gtk_button_new_from_icon_name("window-close-symbolic", GTK_ICON_SIZE_MENU);
    gtk_button_set_relief(GTK_BUTTON(close), GTK_RELIEF_NONE);
    gtk_widget_set_tooltip_text(close, T("close_tab"));
    g_signal_connect(close, "clicked", G_CALLBACK(on_close_clicked), t);
    gtk_box_pack_start(GTK_BOX(head), t->icon, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(head), t->label, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(head), close, FALSE, FALSE, 0);
    gtk_container_add(GTK_CONTAINER(events), head);
    g_signal_connect(events, "button-press-event", G_CALLBACK(on_tab_head_click), t);
    gtk_widget_show_all(events);
    set_icon(t->icon, w->private ? "view-conceal-symbolic" : "web-browser-symbolic");

    make_view(t, related);
    gtk_widget_show(t->slot);
    int current = gtk_notebook_get_current_page(GTK_NOTEBOOK(w->notebook));
    int n = gtk_notebook_insert_page(GTK_NOTEBOOK(w->notebook), t->slot, events, current < 0 ? -1 : current + 1);
    gtk_notebook_set_tab_reorderable(GTK_NOTEBOOK(w->notebook), t->slot, TRUE);
    if (!background) gtk_notebook_set_current_page(GTK_NOTEBOOK(w->notebook), n);
    else if (win_tab(w)) fable_tabs_activate(app.tabs, win_tab(w)->id, now_ms());   /* the front tab stays the core's front tab */

    if (!related) {
        navigate(t, input ? input : "");
        if ((!input || !*input) && !background) gtk_widget_grab_focus(w->entry);
    }
    return t;
}

static void on_switch_page(GtkNotebook *notebook, GtkWidget *slot, guint index, Win *w) {
    (void)notebook; (void)index;
    Tab *t = tab_of_slot(slot);
    if (!t) return;
    fable_tabs_activate(app.tabs, t->id, now_ms());
    if (!t->view) {   /* wake: rebuild the view and reload where the tab was */
        make_view(t, NULL);
        webkit_web_view_load_uri(t->view, t->url ? t->url : NEWTAB_URI);
        gtk_widget_set_opacity(t->label, 1.0);
    }
    show_in_chrome(w, TRUE);
    save_session();   /* the tab in front changed */
}

/* Put idle background tabs to sleep: drop the web view (and with it the
 * page's memory), keep the URL, dim the tab. Tabs on screen or playing sound
 * stay awake. */
static gboolean on_sleep_tick(gpointer data) {
    (void)data;
    uint32_t ids[64];
    size_t count = fable_tabs_collect_sleepers(app.tabs, now_ms(), ids, G_N_ELEMENTS(ids));
    for (size_t i = 0; i < count; i++) {
        Tab *t = tab_by_id(ids[i]);
        if (!t || !t->view) continue;
        if (t == win_tab(t->win) || webkit_web_view_is_playing_audio(t->view)) {
            fable_tabs_touch(app.tabs, t->id, now_ms());
            continue;
        }
        gtk_widget_destroy(GTK_WIDGET(t->view));
        t->view = NULL;
        gtk_widget_set_opacity(t->label, 0.55);
    }
    return G_SOURCE_CONTINUE;
}

/* ---- reader, resources, downloads ---------------------------------------- */

static void reader_done(GObject *source, GAsyncResult *res, gpointer data) {
    Win *w = data;
    JSCValue *v = webkit_web_view_evaluate_javascript_finish(WEBKIT_WEB_VIEW(source), res, NULL);
    if (!v) return;
    if (jsc_value_is_string(v)) {
        char *s = jsc_value_to_string(v);
        if (strcmp(s, "none") == 0) say(w, T("no_article"));
        else if (strcmp(s, "on") == 0) say(w, T("reader_on"));
        g_free(s);
    }
    g_object_unref(v);
}

static void toggle_reader(Tab *t) {
    if (!t || !t->view) return;
    char *script = fable_reader_script();
    webkit_web_view_evaluate_javascript(t->view, script, -1, NULL, NULL, NULL, reader_done, t->win);
    fable_string_free(script);
}

/* Read the already loaded main resource. A POST or private page is never requested again. */
static void source_done(GObject *source, GAsyncResult *res, gpointer token) {
    WebKitWebResource *resource = WEBKIT_WEB_RESOURCE(source);
    gsize size = 0;
    guchar *bytes = webkit_web_resource_get_data_finish(resource, res, &size, NULL);
    WebKitURIResponse *response = webkit_web_resource_get_response(resource);
    SoupMessageHeaders *headers = response ? webkit_uri_response_get_http_headers(response) : NULL;
    GHashTable *params = NULL;
    if (headers) soup_message_headers_get_content_type(headers, &params);
    const char *charset = params ? g_hash_table_lookup(params, "charset") : NULL;
    char *utf8 = NULL;
    if (bytes && !memchr(bytes, 0, size)) {
        if (charset) utf8 = g_convert((const char *)bytes, size, "UTF-8", charset, NULL, NULL, NULL);
        else if (g_utf8_validate((const char *)bytes, size, NULL)) utf8 = g_strndup((const char *)bytes, size);
    }
    char *quoted = utf8 ? fable_json_string(utf8) : NULL;
    char *reply = g_strdup_printf("Fable.source(%s,%s,true)", (char *)token, quoted ? quoted : "null");
    panel_run(reply);
    g_free(reply);
    fable_string_free(quoted);
    fable_string_free(token);
    g_free(utf8);
    g_free(bytes);
    if (params) g_hash_table_unref(params);
}

static void scan_done(GObject *source, GAsyncResult *res, gpointer data) {
    uint32_t id = GPOINTER_TO_UINT(data);
    JSCValue *v = webkit_web_view_evaluate_javascript_finish(WEBKIT_WEB_VIEW(source), res, NULL);
    if (!v) return;
    char *json = jsc_value_to_json(v, 0);
    if (json && fable_sniff_note_scan(id, json) > 0) panel_run("Fable.refresh('sniff')");
    g_free(json);
    g_object_unref(v);
}

/* What the page itself shows (media elements, large images, what it fetched). */
static void scan_page(Tab *t) {
    if (!t || !t->view) return;
    webkit_web_view_evaluate_javascript(t->view, fable_sniff_js(), -1, NULL, NULL, NULL, scan_done, GUINT_TO_POINTER(t->id));
}

static char *downloads_directory(void) {
    const char *dir = g_get_user_special_dir(G_USER_DIRECTORY_DOWNLOAD);
    if (dir) return g_strdup(dir);
    char *fallback = g_build_filename(g_get_home_dir(), "Downloads", NULL);
    if (g_file_test(fallback, G_FILE_TEST_IS_DIR)) return fallback;
    g_free(fallback);
    return g_strdup(g_get_home_dir());
}

static gboolean on_decide_destination(WebKitDownload *download, const char *suggested, gpointer data) {
    (void)data;
    char *dir = downloads_directory();
    char *base = g_path_get_basename(suggested && *suggested ? suggested : "download");
    char *path = g_build_filename(dir, base, NULL);
    for (int i = 2; g_file_test(path, G_FILE_TEST_EXISTS) && i < 1000; i++) {   /* name (2).ext … */
        const char *dot = strrchr(base, '.');
        char *stem = dot && dot != base ? g_strndup(base, dot - base) : g_strdup(base);
        char *name = g_strdup_printf("%s (%d)%s", stem, i, dot && dot != base ? dot : "");
        g_free(path);
        path = g_build_filename(dir, name, NULL);
        g_free(stem);
        g_free(name);
    }
    char *uri = g_filename_to_uri(path, NULL, NULL);
    webkit_download_set_destination(download, uri);
    WebKitWebView *view = webkit_download_get_web_view(download);
    Tab *t = view ? tab_of_view(view) : NULL;
    char *name = g_path_get_basename(path);
    if (view && !webkit_web_context_is_ephemeral(webkit_web_view_get_context(view)))
        g_object_set_data(G_OBJECT(download), "record-id", GUINT_TO_POINTER(fable_download_begin(name)));
    char *msg = TN("dl_start", name);
    say(t ? t->win : front_win(), msg);
    g_free(msg);
    g_free(name);
    g_free(uri);
    g_free(path);
    g_free(base);
    g_free(dir);
    return TRUE;
}

static void on_download_finished(WebKitDownload *download, gpointer data) {
    (void)data;
    if (g_object_get_data(G_OBJECT(download), "failed")) return; // finished also follows failed
    fable_download_finish(GPOINTER_TO_UINT(g_object_get_data(G_OBJECT(download), "record-id")), 1);
    const char *dest = webkit_download_get_destination(download);
    char *path = dest ? g_filename_from_uri(dest, NULL, NULL) : NULL;
    char *name = path ? g_path_get_basename(path) : g_strdup("");
    char *msg = TN("mac_downloaded", name);
    say(front_win(), msg);
    g_free(msg);
    g_free(name);
    g_free(path);
}

static void on_download_failed(WebKitDownload *download, GError *error, gpointer data) {
    (void)data;
    g_object_set_data(G_OBJECT(download), "failed", GINT_TO_POINTER(1));
    fable_download_finish(GPOINTER_TO_UINT(g_object_get_data(G_OBJECT(download), "record-id")), 0);
    if (!g_error_matches(error, WEBKIT_DOWNLOAD_ERROR, WEBKIT_DOWNLOAD_ERROR_CANCELLED_BY_USER)) say(front_win(), T("dl_fail"));
}

static void on_download_started(WebKitWebContext *ctx, WebKitDownload *download, gpointer data) {
    (void)ctx; (void)data;
    g_signal_connect(download, "decide-destination", G_CALLBACK(on_decide_destination), NULL);
    g_signal_connect(download, "finished", G_CALLBACK(on_download_finished), NULL);
    g_signal_connect(download, "failed", G_CALLBACK(on_download_failed), NULL);
}

/* ---- metadata -------------------------------------------------------------- */

/* What only the shell can see: the screen under the window, the engine, the UA. */
static void screen_facts(Win *w, int *pw, int *ph, int *hz, int *dpi, double *inches, char **name) {
    GdkDisplay *display = gdk_display_get_default();
    GdkWindow *gw = w ? gtk_widget_get_window(w->window) : NULL;
    GdkMonitor *m = gw ? gdk_display_get_monitor_at_window(display, gw) : gdk_display_get_primary_monitor(display);
    if (!m) m = gdk_display_get_monitor(display, 0);
    *pw = *ph = *hz = *dpi = 0;
    *inches = 0;
    *name = NULL;
    if (!m) return;
    GdkRectangle g;
    gdk_monitor_get_geometry(m, &g);
    int scale = gdk_monitor_get_scale_factor(m);
    *pw = g.width * scale;
    *ph = g.height * scale;
    *hz = (gdk_monitor_get_refresh_rate(m) + 500) / 1000;
    int mm_w = gdk_monitor_get_width_mm(m), mm_h = gdk_monitor_get_height_mm(m);
    if (mm_w > 0 && mm_h > 0) {
        *inches = round(sqrt((double)mm_w * mm_w + (double)mm_h * mm_h) / 25.4 * 10) / 10;
        *dpi = (int)round(*pw / (mm_w / 25.4));
    }
    const char *maker = gdk_monitor_get_manufacturer(m), *model = gdk_monitor_get_model(m);
    *name = g_strstrip(g_strdup_printf("%s %s", maker ? maker : "", model ? model : ""));
}

static char *device_extras(void) {
    int pw, ph, hz, dpi;
    double inches;
    char *name;
    screen_facts(front_win(), &pw, &ph, &hz, &dpi, &inches, &name);
    GString *s = g_string_new("{");
    g_string_append_printf(s, "\"engine\":\"WebKitGTK %u.%u.%u\",\"cookies\":true", webkit_get_major_version(), webkit_get_minor_version(), webkit_get_micro_version());
    g_string_append(s, ",\"ua\":");
    json_str(s, webkit_settings_get_user_agent(app.settings));
    if (pw) g_string_append_printf(s, ",\"screenW\":%d,\"screenH\":%d", pw, ph);
    if (hz) g_string_append_printf(s, ",\"refresh\":%d", hz);
    if (dpi) g_string_append_printf(s, ",\"dpi\":%d", dpi);
    g_string_append(s, "}");
    g_free(name);
    return g_string_free(s, FALSE);
}

static char *system_extras(void) {
    int pw, ph, hz, dpi;
    double inches;
    char *name;
    screen_facts(front_win(), &pw, &ph, &hz, &dpi, &inches, &name);
    GString *s = g_string_new("{\"display\":{");
    g_string_append_printf(s, "\"w\":%d,\"h\":%d", pw, ph);
    if (hz) g_string_append_printf(s, ",\"refresh\":%d", hz);
    if (dpi) g_string_append_printf(s, ",\"dpi\":%d", dpi);
    if (inches > 0) g_string_append_printf(s, ",\"inches\":%.1f", inches);
    if (name && *name) { g_string_append(s, ",\"name\":"); json_str(s, name); }
    g_string_append(s, "}}");
    g_free(name);
    return g_string_free(s, FALSE);
}

/* Public IP for the metadata sheet: Cloudflare's trace, then ipify. No cookies. */
static void lookup_ip(int attempt);

static void ip_done(GObject *source, GAsyncResult *res, gpointer data) {
    int attempt = GPOINTER_TO_INT(data);
    GBytes *bytes = soup_session_send_and_read_finish(SOUP_SESSION(source), res, NULL);
    char *json = NULL;
    if (bytes) {
        gsize n = 0;
        const char *p = g_bytes_get_data(bytes, &n);
        char *body = g_strndup(p ? p : "", n);
        json = fable_parse_ip_reply(body, attempt == 0 ? "cloudflare.com" : "ipify.org");
        g_free(body);
        g_bytes_unref(bytes);
    }
    if ((!json || !*json) && attempt == 0) {
        if (json) fable_string_free(json);
        lookup_ip(1);
        return;
    }
    char *script = g_strdup_printf("Fable.ip(%s)", json && *json ? json : "{}");
    panel_run(script);
    g_free(script);
    if (json) fable_string_free(json);
}

static void lookup_ip(int attempt) {
    SoupMessage *m = soup_message_new("GET", attempt == 0 ? "https://www.cloudflare.com/cdn-cgi/trace" : "https://api.ipify.org?format=json");
    soup_message_headers_replace(soup_message_get_request_headers(m), "User-Agent", webkit_settings_get_user_agent(app.settings));
    soup_session_send_and_read_async(app.soup, m, G_PRIORITY_DEFAULT, NULL, ip_done, GINT_TO_POINTER(attempt));
    g_object_unref(m);
}

/* ---- ad-list updates ------------------------------------------------------ */

/* Fetch the built-in community ad lists (at most 8 MiB each) and hand them
 * to the core, concatenated. A source that fails is skipped. The shell
 * fetches because the core builds offline and has no HTTP client. */
static gboolean ads_updating = FALSE;

typedef struct {
    SoupMessage *msg;
    GInputStream *stream;
    GByteArray *body;   /* this source's download */
    GByteArray *all;    /* the downloads so far, newline-separated */
    char **urls;        /* the sources, one per line */
    int next;           /* the source to fetch next */
    guint8 buf[8192];
} AdsFetch;

static void ads_fetch_next(AdsFetch *f);

static void ads_fetch_done(AdsFetch *f) {
    ads_updating = FALSE;
    if (f->all->len > 0) {
        int count = fable_ads_update_apply((const uint8_t *)f->all->data, f->all->len);
        if (count >= 0) {
            /* The web processes still block with the list they started with:
             * hand them the new one, so the update takes effect without a restart. */
            char *text = fable_ad_list_text();
            webkit_web_context_send_message_to_all_extensions(app.normal,
                webkit_user_message_new("fable.ads", g_variant_new_string(text)));
            fable_string_free(text);
        }
    }
    if (f->stream) g_object_unref(f->stream);
    if (f->msg) g_object_unref(f->msg);
    g_byte_array_free(f->body, TRUE);
    g_byte_array_free(f->all, TRUE);
    g_strfreev(f->urls);
    g_free(f);
}

static void ads_fetch_read(GObject *source, GAsyncResult *res, gpointer data) {
    AdsFetch *f = data;
    gssize n = g_input_stream_read_finish(G_INPUT_STREAM(source), res, NULL);
    if (n < 0) { ads_fetch_next(f); return; }   /* a read error: skip this source */
    if (n == 0) {   /* end of body: only a 200 with a complete body counts */
        if (soup_message_get_status(f->msg) == SOUP_STATUS_OK) {
            g_byte_array_append(f->all, f->body->data, f->body->len);
            g_byte_array_append(f->all, (const guint8 *)"\n", 1);
        }
        ads_fetch_next(f);
        return;
    }
    if (f->body->len + (gsize)n > (gsize)8 * 1024 * 1024 + 1) { ads_fetch_next(f); return; }
    g_byte_array_append(f->body, f->buf, (gsize)n);
    g_input_stream_read_async(f->stream, f->buf, sizeof f->buf, G_PRIORITY_DEFAULT, NULL, ads_fetch_read, f);
}

static void ads_fetch_sent(GObject *source, GAsyncResult *res, gpointer data) {
    AdsFetch *f = data;
    f->stream = soup_session_send_finish(SOUP_SESSION(source), res, NULL);
    if (!f->stream) { ads_fetch_next(f); return; }
    g_input_stream_read_async(f->stream, f->buf, sizeof f->buf, G_PRIORITY_DEFAULT, NULL, ads_fetch_read, f);
}

static void ads_fetch_next(AdsFetch *f) {
    if (f->stream) { g_object_unref(f->stream); f->stream = NULL; }
    if (f->msg) { g_object_unref(f->msg); f->msg = NULL; }
    g_byte_array_set_size(f->body, 0);
    if (!f->urls[f->next]) { ads_fetch_done(f); return; }
    SoupMessage *m = soup_message_new("GET", f->urls[f->next++]);
    if (!m) { ads_fetch_next(f); return; }
    f->msg = m;
    soup_session_send_async(app.soup, m, G_PRIORITY_DEFAULT, NULL, ads_fetch_sent, f);
}

static void ads_update_fetch(void) {
    if (ads_updating) return;
    char *sources = fable_ads_update_sources();
    if (!sources || !*sources) { fable_string_free(sources); return; }
    AdsFetch *f = g_new0(AdsFetch, 1);
    f->body = g_byte_array_new();
    f->all = g_byte_array_new();
    f->urls = g_strsplit(sources, "\n", -1);
    fable_string_free(sources);
    ads_updating = TRUE;
    ads_fetch_next(f);
}

/* ---- clearing data ----------------------------------------------------------- */

static void clear_data(const char *what) {
    gboolean history_cleared = !strstr(what, "history") || fable_history_clear();
    WebKitWebsiteDataTypes types = 0;
    if (strstr(what, "cookies"))
        types |= WEBKIT_WEBSITE_DATA_COOKIES | WEBKIT_WEBSITE_DATA_LOCAL_STORAGE | WEBKIT_WEBSITE_DATA_INDEXEDDB_DATABASES
                 | WEBKIT_WEBSITE_DATA_SESSION_STORAGE | WEBKIT_WEBSITE_DATA_SERVICE_WORKER_REGISTRATIONS | WEBKIT_WEBSITE_DATA_HSTS_CACHE;
    if (strstr(what, "cache")) types |= WEBKIT_WEBSITE_DATA_DISK_CACHE | WEBKIT_WEBSITE_DATA_MEMORY_CACHE | WEBKIT_WEBSITE_DATA_OFFLINE_APPLICATION_CACHE;
    if (types) webkit_website_data_manager_clear(webkit_web_context_get_website_data_manager(app.normal), types, 0, NULL, NULL, NULL);
    say(front_win(), T(history_cleared ? "data_cleared" : "history_clear_failed"));
}

/* ---- the panel ----------------------------------------------------------------- */

/* What the panel shows: tabs of every window (for the private-tab count), the
 * front tab, the settings snapshot and what this shell can do. */
static char *panel_state(void) {
    Tab *front = front_tab();
    Win *fw = front_win();
    GString *s = g_string_new("{\"tabs\":[");
    GList *tabs = all_tabs();
    for (GList *l = tabs; l; l = l->next) {
        Tab *t = l->data;
        if (l != tabs) g_string_append_c(s, ',');
        g_string_append_printf(s, "{\"id\":%u,\"title\":", t->id);
        json_str(s, t->title ? t->title : "");
        g_string_append(s, ",\"url\":");
        json_str(s, is_home(t->url) ? "" : t->url);
        g_string_append_printf(s, ",\"active\":%s,\"private\":%s,\"asleep\":%s}", t == front ? "true" : "false",
                               t->win->private ? "true" : "false", t->view ? "false" : "true");
    }
    g_list_free(tabs);
    g_string_append_printf(s, "],\"active\":%u,\"url\":", front ? front->id : 0);
    json_str(s, front && !is_home(front->url) ? front->url : "");
    g_string_append(s, ",\"title\":");
    json_str(s, front && front->title ? front->title : "");
    gboolean web = front && is_web(front->url) && !(fw && fw->private);
    g_string_append_printf(s, ",\"web\":%s,\"incognito\":%s,\"desktop\":false,\"blocked\":%" G_GUINT64_FORMAT ",\"sniffed\":%zu,\"bookmarked\":%llu,\"version\":",
                           web ? "true" : "false", fw && fw->private ? "true" : "false", app.blocked, front ? fable_sniff_count(front->id) : (size_t)0,
                           (unsigned long long)(web ? fable_bookmark_id(front->url) : 0));
    json_str(s, fable_version());
    char *settings = fable_settings_json();
    g_string_append_printf(s, ",\"platform\":\"linux\",\"caps\":{\"screenshots\":false,\"bookmarks\":true,\"restoreTabs\":true},\"settings\":%s}", settings);
    fable_string_free(settings);
    return g_string_free(s, FALSE);
}

static void panel_run(const char *script) {
    if (!app.panel) return;
    if (!app.panel_loaded) {   /* run once the page is in */
        g_string_append(app.panel_queue, script);
        g_string_append(app.panel_queue, ";\n");
        return;
    }
    webkit_web_view_evaluate_javascript(app.panel, script, -1, NULL, NULL, NULL, NULL, NULL);
}

static void panel_update(void) {
    if (!app.panel_view) return;
    char *state = panel_state();
    char *script = g_strdup_printf("Fable.update(%s)", state);
    panel_run(script);
    g_free(script);
    g_free(state);
}

static void panel_hide(void) {
    if (app.popover) gtk_popover_popdown(GTK_POPOVER(app.popover));
}

static void on_panel_closed(GtkPopover *popover, gpointer data) {
    (void)popover; (void)data;
    g_clear_pointer(&app.panel_view, g_free);
}

static Win *normal_win(void) {
    Win *w = front_win_of(FALSE);
    return w ? w : win_new(FALSE);
}

static void panel_act(const char *name, const char *arg) {
    Tab *front = front_tab();
    Win *fw = front_win();
    if (!strcmp(name, "hidden")) {
        panel_hide();
    } else if (!strcmp(name, "size")) {   /* the panel's content height */
        int h = (int)g_ascii_strtoll(arg, NULL, 10);
        if (h >= 200 && h <= 800) {
            gtk_widget_set_size_request(app.panel_box, 400, h);
        }
    } else if (!strcmp(name, "switchTab") || !strcmp(name, "closeTab")) {
        Tab *t = tab_by_id((uint32_t)g_ascii_strtoull(arg, NULL, 10));
        if (!t) return;
        if (name[0] == 'c') { tab_close(t); panel_update(); return; }
        gtk_notebook_set_current_page(GTK_NOTEBOOK(t->win->notebook), gtk_notebook_page_num(GTK_NOTEBOOK(t->win->notebook), t->slot));
        gtk_window_present(GTK_WINDOW(t->win->window));
    } else if (!strcmp(name, "newTab")) {             /* a normal tab: in a normal window */
        Win *w = fw && !fw->private ? fw : normal_win();
        tab_new(w, NULL, FALSE, NULL);
        gtk_window_present(GTK_WINDOW(w->window));
    } else if (!strcmp(name, "newPrivate")) {         /* in this private window, or a new one */
        if (fw && fw->private) tab_new(fw, NULL, FALSE, NULL);
        else win_new(TRUE);
    } else if (!strcmp(name, "enterPrivate")) {       /* back to a private window, or a new one */
        Win *w = front_win_of(TRUE);
        if (w) gtk_window_present(GTK_WINDOW(w->window));
        else win_new(TRUE);
    } else if (!strcmp(name, "exitPrivate")) {        /* every private window closes */
        GList *privates = NULL;
        for (GList *l = app.wins; l; l = l->next)
            if (((Win *)l->data)->private) privates = g_list_prepend(privates, l->data);
        Win *stay = privates ? normal_win() : NULL;
        for (GList *l = privates; l; l = l->next) win_close(l->data);
        if (stay) { gtk_window_present(GTK_WINDOW(stay->window)); say(stay, T("private_closed")); }
        g_list_free(privates);
    } else if (!strcmp(name, "open")) {
        if (front) navigate(front, arg);
    } else if (!strcmp(name, "openNew")) {
        if (fw) tab_new(fw, arg, FALSE, NULL);
    } else if (!strcmp(name, "reader")) {
        toggle_reader(front);
    } else if (!strcmp(name, "downloadFolder")) {
        char *dir = downloads_directory();
        char *uri = g_filename_to_uri(dir, NULL, NULL);
        if (!uri || !g_app_info_launch_default_for_uri(uri, NULL, NULL)) say(fw, T("dl_manage_error"));
        g_free(uri);
        g_free(dir);
    } else if (!strcmp(name, "clear")) {
        clear_data(arg);
    } else if (!strcmp(name, "pageSource")) {
        WebKitWebResource *resource = front && front->view ? webkit_web_view_get_main_resource(front->view) : NULL;
        if (resource) webkit_web_resource_get_data(resource, NULL, source_done, fable_json_string(arg));
    } else if (!strcmp(name, "sniffScan")) {
        scan_page(front);
    } else if (!strcmp(name, "download")) {
        if (front && front->view) webkit_web_view_download_uri(front->view, arg);
    } else if (!strcmp(name, "copy") || !strcmp(name, "copyText")) {
        gtk_clipboard_set_text(gtk_clipboard_get(GDK_SELECTION_CLIPBOARD), arg, -1);
        say(fw, T(name[4] ? "m_copied" : "link_copied"));
    } else if (!strcmp(name, "toast")) {
        say(fw, arg);
    } else if (!strcmp(name, "ip")) {
        lookup_ip(0);
    } else if (!strcmp(name, "system")) {
        char *extras = system_extras();
        char *info = fable_system_info(extras);
        char *script = g_strdup_printf("Fable.system(%s)", info);
        panel_run(script);
        g_free(script);
        fable_string_free(info);
        g_free(extras);
    } else if (!strcmp(name, "bookmarkToggle")) {   /* the star: the page in front */
        if (front && fw && !fw->private && is_web(front->url)) {
            uint64_t id = fable_bookmark_id(front->url);
            if (id) {
                fable_bookmark_remove(id);
                say(fw, T("removed_bookmark"));
            } else {
                fable_bookmark_add(front->url, front->title ? front->title : "", 0);
                say(fw, T("added_bookmark"));
            }
            panel_update();
        }
    } else if (!strcmp(name, "bookmarkImportPick")) {
        import_bookmarks_file(fw ? fw : front_win());
    } else if (!strcmp(name, "bookmarkExport")) {
        export_bookmarks_file(fw ? fw : front_win());
    } else if (!strcmp(name, "find") || !strcmp(name, "findNext") || !strcmp(name, "findPrev") || !strcmp(name, "findStop")) {
        find_act(front, name, arg);
    }
}

/* Import a Chrome/Firefox bookmark file (NETSCAPE HTML) chosen in a file dialog. */
static void import_bookmarks_file(Win *w) {
    if (!w) return;
    GtkWidget *dlg = gtk_file_chooser_dialog_new(T("bookmark_import"), GTK_WINDOW(w->window), GTK_FILE_CHOOSER_ACTION_OPEN,
                                                 "_Cancel", GTK_RESPONSE_CANCEL, "_Open", GTK_RESPONSE_ACCEPT, NULL);
    GtkFileFilter *filter = gtk_file_filter_new();
    gtk_file_filter_set_name(filter, "HTML");
    gtk_file_filter_add_pattern(filter, "*.html");
    gtk_file_filter_add_pattern(filter, "*.htm");
    gtk_file_chooser_add_filter(GTK_FILE_CHOOSER(dlg), filter);
    if (gtk_dialog_run(GTK_DIALOG(dlg)) == GTK_RESPONSE_ACCEPT) {
        char *path = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(dlg));
        char *text = NULL;
        gsize len = 0;
        if (path && g_file_get_contents(path, &text, &len, NULL) && len <= 4 * 1024 * 1024 && text) {
            size_t n = fable_bookmark_import(text);
            char nb[16];
            g_snprintf(nb, sizeof nb, "%zu", n);
            char *msg = TN("bookmark_imported", nb);
            say(w, msg);
            g_free(msg);
            if (app.panel_view && strcmp(app.panel_view, "bookmarks") == 0) panel_run("Fable.refresh('bookmarks')");
        }
        g_free(text);
        g_free(path);
    }
    gtk_widget_destroy(dlg);
}

static char *qr_payload_text(const uint8_t *data, int len) {
    if (g_utf8_validate((const char *)data, len, NULL)) return g_strndup((const char *)data, len);
    char *s = g_convert((const char *)data, len, "UTF-8", "GB18030", NULL, NULL, NULL);
    if (s) return s;
    return g_convert((const char *)data, len, "UTF-8", "ISO-8859-1", NULL, NULL, NULL);
}

/* A QR code just read (Android's scanned() rule, in the shell): a web
 * address opens in the tab in front; anything else is shown first, so
 * nothing in it reaches a search engine unless the user asks. The dialog's
 * Search navigates to it (a web address opens, other text is searched). */
static void scan_result(Win *w, char *text) {
    g_strstrip(text);
    if (!*text) { say(w, T("scan_unknown")); return; }
    Tab *t = win_tab(w);
    if (!t) return;
    if (is_web(text)) { navigate(t, text); return; }
    GtkWidget *dlg = gtk_dialog_new_with_buttons(T("scan_text"), GTK_WINDOW(w->window),
                                                 GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
                                                 T("scan_search"), GTK_RESPONSE_ACCEPT,
                                                 T("copy"), GTK_RESPONSE_APPLY,
                                                 T("cancel"), GTK_RESPONSE_CANCEL,
                                                 NULL);
    GtkWidget *label = gtk_label_new(text);
    gtk_label_set_line_wrap(GTK_LABEL(label), TRUE);
    gtk_label_set_selectable(GTK_LABEL(label), TRUE);
    gtk_label_set_max_width_chars(GTK_LABEL(label), 60);
    gtk_container_add(GTK_CONTAINER(gtk_dialog_get_content_area(GTK_DIALOG(dlg))), label);
    gtk_widget_show_all(dlg);
    int resp = gtk_dialog_run(GTK_DIALOG(dlg));
    gtk_widget_destroy(dlg);
    if (resp == GTK_RESPONSE_ACCEPT) navigate(t, text);
    else if (resp == GTK_RESPONSE_APPLY) {
        gtk_clipboard_set_text(gtk_clipboard_get(GDK_SELECTION_CLIPBOARD), text, -1);
        say(w, T("m_copied"));
    }
}

/* Read a QR code from an image file (Linux has no camera scan): pick the file,
 * turn it into a greyscale plane, and let the core's QR decoder read it. The
 * result is handled in the shell (scan_result): a web address opens, other
 * text is shown first. */
static void scan_image_file(Win *w) {
    if (!w) return;
    GtkWidget *dlg = gtk_file_chooser_dialog_new(T("scan_image"), GTK_WINDOW(w->window), GTK_FILE_CHOOSER_ACTION_OPEN,
                                                 "_Cancel", GTK_RESPONSE_CANCEL, "_Open", GTK_RESPONSE_ACCEPT, NULL);
    GtkFileFilter *filter = gtk_file_filter_new();
    gtk_file_filter_set_name(filter, "Images");
    gtk_file_filter_add_mime_type(filter, "image/png");
    gtk_file_filter_add_mime_type(filter, "image/jpeg");
    gtk_file_filter_add_mime_type(filter, "image/gif");
    gtk_file_filter_add_mime_type(filter, "image/bmp");
    gtk_file_filter_add_mime_type(filter, "image/webp");
    gtk_file_chooser_add_filter(GTK_FILE_CHOOSER(dlg), filter);
    if (gtk_dialog_run(GTK_DIALOG(dlg)) != GTK_RESPONSE_ACCEPT) { gtk_widget_destroy(dlg); return; }
    char *path = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(dlg));
    gtk_widget_destroy(dlg);
    if (!path) return;
    GdkPixbuf *pb = gdk_pixbuf_new_from_file(path, NULL);
    g_free(path);
    if (!pb) { say(w, T("scan_unknown")); return; }
    /* The core decoder caps at 4096 an edge and 4 megapixels: shrink first. */
    int pw = gdk_pixbuf_get_width(pb), ph = gdk_pixbuf_get_height(pb);
    int nw = pw, nh = ph;
    if (nw > 4096 || nh > 4096) {
        double s = 4096.0 / (nw > nh ? nw : nh);
        nw = (int)(nw * s + 0.5); nh = (int)(nh * s + 0.5);
    }
    while ((int64_t)nw * nh > 4 * 1024 * 1024) { nw /= 2; nh /= 2; }
    if (nw < 1) nw = 1;
    if (nh < 1) nh = 1;
    if (nw != pw || nh != ph) {
        GdkPixbuf *small = gdk_pixbuf_scale_simple(pb, nw, nh, GDK_INTERP_BILINEAR);
        g_object_unref(pb);
        if (!small) { say(w, T("scan_unknown")); return; }
        pb = small; pw = nw; ph = nh;
    }
    int ch = gdk_pixbuf_get_n_channels(pb);
    int stride = gdk_pixbuf_get_rowstride(pb);
    const guchar *px = gdk_pixbuf_get_pixels(pb);
    size_t n = (size_t)pw * ph;
    uint8_t *luma = g_malloc(n);
    for (int y = 0; y < ph; y++) {
        const guchar *row = px + (size_t)y * stride;
        for (int x = 0; x < pw; x++) {
            const guchar *p = row + (size_t)x * ch;
            /* Rec.601; a greyscale image (1 or 2 channels) already is luma. */
            luma[(size_t)y * pw + x] = ch >= 3 ? (uint8_t)((299 * p[0] + 587 * p[1] + 114 * p[2]) / 1000) : p[0];
        }
    }
    g_object_unref(pb);
    int need = fable_qr_decode(luma, n, pw, ph, pw, 1, NULL, 0);
    if (need <= 0) { g_free(luma); say(w, T("scan_unknown")); return; }
    uint8_t *out = g_malloc(need);
    int got = fable_qr_decode(luma, n, pw, ph, pw, 1, out, need);
    g_free(luma);
    if (got <= 0) { g_free(out); say(w, T("scan_unknown")); return; }
    char *text = qr_payload_text(out, got);
    g_free(out);
    if (!text) { say(w, T("scan_unknown")); return; }
    scan_result(w, text);
    g_free(text);
}

/* Export the bookmark tree as a NETSCAPE HTML file chosen in a save dialog. */
static void export_bookmarks_file(Win *w) {
    if (!w) return;
    GtkWidget *dlg = gtk_file_chooser_dialog_new(T("bookmark_export"), GTK_WINDOW(w->window), GTK_FILE_CHOOSER_ACTION_SAVE,
                                                 "_Cancel", GTK_RESPONSE_CANCEL, "_Save", GTK_RESPONSE_ACCEPT, NULL);
    gtk_file_chooser_set_current_name(GTK_FILE_CHOOSER(dlg), "bookmarks.html");
    if (gtk_dialog_run(GTK_DIALOG(dlg)) == GTK_RESPONSE_ACCEPT) {
        char *path = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(dlg));
        char *html = fable_bookmark_export();
        if (path && g_file_set_contents(path, html, -1, NULL)) say(w, T("exported_bookmark"));
        fable_string_free(html);
        g_free(path);
    }
    gtk_widget_destroy(dlg);
}

/* "q\tid\tname\targ" (a request) or "a\tname\targ" (an action). */
static void on_panel_message(WebKitUserContentManager *manager, WebKitJavascriptResult *result, gpointer data) {
    (void)manager; (void)data;
    JSCValue *value = webkit_javascript_result_get_js_value(result);
    if (!jsc_value_is_string(value)) return;
    char *msg = jsc_value_to_string(value);
    if (msg[0] == 'q' && msg[1] == '\t') {
        char **f = g_strsplit(msg + 2, "\t", 3);
        if (f[0] && f[1]) {
            uint32_t id = (uint32_t)g_ascii_strtoull(f[0], NULL, 10);
            const char *name = f[1], *arg = f[2] ? f[2] : "";
            Tab *front = front_tab();
            char *answer = fable_panel_query(name, arg, front ? front->id : 0);
            char *own = NULL;
            if (!answer && !strcmp(name, "device")) {
                char *extras = device_extras();
                own = fable_device_info(extras);
                g_free(extras);
            }
            char *script = fable_panel_reply(id, answer ? answer : own ? own : "");   /* "icon": none kept here */
            panel_run(script);
            fable_string_free(script);
            if (answer) fable_string_free(answer);
            if (own) fable_string_free(own);
            if (!strcmp(name, "set")) {
                char *nl = strchr(arg, '\n');
                char *key = nl ? g_strndup(arg, nl - arg) : g_strdup(arg);
                setting_changed(key);
                g_free(key);
            }
        }
        g_strfreev(f);
    } else if (msg[0] == 'a' && msg[1] == '\t') {
        char **f = g_strsplit(msg + 2, "\t", 2);
        if (f[0]) panel_act(f[0], f[1] ? f[1] : "");
        g_strfreev(f);
    }
    g_free(msg);
}

static void on_panel_load(WebKitWebView *view, WebKitLoadEvent event, gpointer data) {
    (void)data;
    if (event != WEBKIT_LOAD_FINISHED) return;
    app.panel_loaded = TRUE;
    if (app.panel_queue->len) {
        webkit_web_view_evaluate_javascript(view, app.panel_queue->str, -1, NULL, NULL, NULL, NULL, NULL);
        g_string_truncate(app.panel_queue, 0);
    }
}

/* The panel page may not go anywhere else. */
static gboolean on_panel_policy(WebKitWebView *view, WebKitPolicyDecision *decision, WebKitPolicyDecisionType type, gpointer data) {
    (void)view; (void)data;
    if (type != WEBKIT_POLICY_DECISION_TYPE_NAVIGATION_ACTION) return FALSE;
    WebKitNavigationAction *action = webkit_navigation_policy_decision_get_navigation_action(WEBKIT_NAVIGATION_POLICY_DECISION(decision));
    const char *uri = webkit_uri_request_get_uri(webkit_navigation_action_get_request(action));
    if (g_str_has_prefix(uri, PANEL_URI) || g_str_has_prefix(uri, "about:")) return FALSE;
    webkit_policy_decision_ignore(decision);
    return TRUE;
}

static void panel_load(void) {
    if (!app.panel) return;
    app.panel_loaded = FALSE;
    char *html = fable_panel_page();
    webkit_web_view_load_html(app.panel, html, PANEL_URI);
    fable_string_free(html);
    if (app.panel_view) {   /* open: show the same view again in the new language */
        char *view = g_strdup(app.panel_view);
        char *state = panel_state();
        char *script = g_strdup_printf("Fable.show('%s',%s)", view, state);
        panel_run(script);
        g_free(script);
        g_free(state);
        g_free(view);
    }
}

static void panel_create(void) {
    WebKitUserContentManager *manager = webkit_user_content_manager_new();
    webkit_user_content_manager_register_script_message_handler(manager, "fableui");
    g_signal_connect(manager, "script-message-received::fableui", G_CALLBACK(on_panel_message), NULL);
    WebKitSettings *settings = webkit_settings_new();   /* its own: the user's "JavaScript off" is for web pages */
    app.panel = WEBKIT_WEB_VIEW(g_object_new(WEBKIT_TYPE_WEB_VIEW, "web-context", app.normal, "settings", settings, "user-content-manager", manager, NULL));
    g_object_unref(settings);
    g_object_unref(manager);
    g_object_ref_sink(app.panel);
    gtk_widget_set_size_request(GTK_WIDGET(app.panel), 1, 1);
    app.panel_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
    g_object_ref_sink(app.panel_box);
    gtk_box_pack_start(GTK_BOX(app.panel_box), GTK_WIDGET(app.panel), TRUE, TRUE, 0);
    gtk_widget_set_size_request(app.panel_box, 400, 640);
    g_signal_connect(app.panel, "load-changed", G_CALLBACK(on_panel_load), NULL);
    g_signal_connect(app.panel, "decide-policy", G_CALLBACK(on_panel_policy), NULL);
    app.panel_queue = g_string_new("");
    panel_load();
}

static void show_panel(Win *w, const char *view) {
    if (!app.panel) panel_create();
    if (!app.popover) {
        app.popover = gtk_popover_new(w->menu);
        g_object_ref_sink(app.popover);   /* ours: it outlives the window it was opened from */
        gtk_popover_set_position(GTK_POPOVER(app.popover), GTK_POS_BOTTOM);
        gtk_container_add(GTK_CONTAINER(app.popover), app.panel_box);
        g_signal_connect(app.popover, "closed", G_CALLBACK(on_panel_closed), NULL);
        gtk_widget_show_all(app.panel_box);
    }
    if (gtk_popover_get_relative_to(GTK_POPOVER(app.popover)) != w->menu) {
        gtk_widget_hide(app.popover);
        gtk_popover_set_relative_to(GTK_POPOVER(app.popover), w->menu);
    }
    g_free(app.panel_view);
    app.panel_view = g_strdup(view);
    char *state = panel_state();
    char *script = g_strdup_printf("Fable.show('%s',%s)", view, state);
    panel_run(script);
    g_free(script);
    g_free(state);
    gtk_popover_popup(GTK_POPOVER(app.popover));
    gtk_widget_grab_focus(GTK_WIDGET(app.panel));
}

/* ---- window chrome callbacks ------------------------------------------------- */

static void on_entry_activate(GtkEntry *entry, Win *w) {
    Tab *t = win_tab(w);
    if (t && t->view) navigate(t, gtk_entry_get_text(entry));
}

/* The icon at the right end of the address bar: the image button reads a QR
 * code from a picture file (Linux has no camera scan); the star toggles the
 * bookmark of the page in front (hidden in private windows). */
static void on_entry_icon_press(GtkEntry *entry, GtkEntryIconPosition pos, GdkEvent *event, Win *w) {
    (void)event;
    if (pos != GTK_ENTRY_ICON_SECONDARY) return;
    if (gtk_entry_get_text_length(entry) == 0) {
        scan_image_file(w);
        return;
    }
    Tab *t = win_tab(w);
    if (!t || w->private || !is_web(t->url)) return;
    uint64_t id = fable_bookmark_id(t->url);
    if (id) {
        fable_bookmark_remove(id);
        say(w, T("removed_bookmark"));
    } else {
        fable_bookmark_add(t->url, t->title ? t->title : "", 0);
        say(w, T("added_bookmark"));
    }
    update_entry_icon(w);
}

/* The address bar's text changed: the secondary icon follows it (the image
 * button while the field is empty, the star once an address is in it). */
static void on_entry_changed(GtkEntry *entry, Win *w) {
    (void)entry;
    update_entry_icon(w);
}

static void on_back(GtkButton *b, Win *w) { (void)b; Tab *t = win_tab(w); if (t && t->view) webkit_web_view_go_back(t->view); }
/* The optional Home button (Settings › Display): the new-tab page, in this tab. Off unless switched on. */
static void apply_home_buttons(void) {
    char *on = setting("home_button");
    for (GList *l = app.wins; l; l = l->next) gtk_widget_set_visible(((Win *)l->data)->home, strcmp(on, "1") == 0);
    g_free(on);
}
static void on_home(GtkButton *b, Win *w) { (void)b; Tab *t = win_tab(w); if (t) navigate(t, ""); }
static void on_forward(GtkButton *b, Win *w) { (void)b; Tab *t = win_tab(w); if (t && t->view) webkit_web_view_go_forward(t->view); }
static void on_reload(GtkButton *b, Win *w) { (void)b; Tab *t = win_tab(w); if (t && t->view) webkit_web_view_reload(t->view); }
static void on_plus(GtkButton *b, Win *w) { (void)b; tab_new(w, NULL, FALSE, NULL); }
static void on_menu(GtkButton *b, Win *w) { (void)b; show_panel(w, "menu"); }

static void zoom(Win *w, double step) {
    Tab *t = win_tab(w);
    if (!t || !t->view) return;
    double z = step == 0 ? default_zoom() : CLAMP(webkit_web_view_get_zoom_level(t->view) + step, 0.5, 3.0);
    webkit_web_view_set_zoom_level(t->view, z);
}

static gboolean on_key(GtkWidget *window, GdkEventKey *event, Win *w) {
    (void)window;
    guint key = gdk_keyval_to_lower(event->keyval);
    gboolean ctrl = event->state & GDK_CONTROL_MASK, shift = event->state & GDK_SHIFT_MASK, alt = event->state & GDK_MOD1_MASK;
    Tab *t = win_tab(w);
    if (key == GDK_KEY_Escape && gtk_widget_has_focus(w->entry)) {   /* Esc puts the page's address back */
        show_in_chrome(w, TRUE);
        if (t && t->view) gtk_widget_grab_focus(GTK_WIDGET(t->view));
        return TRUE;
    }
    if (key == GDK_KEY_F10) { show_panel(w, "menu"); return TRUE; }
    if (key == GDK_KEY_F5) { if (t && t->view) webkit_web_view_reload(t->view); return TRUE; }
    if (alt && key == GDK_KEY_Home) { if (t) navigate(t, ""); return TRUE; }
    if (alt && (key == GDK_KEY_Left || key == GDK_KEY_Right)) {
        if (t && t->view) { if (key == GDK_KEY_Left) webkit_web_view_go_back(t->view); else webkit_web_view_go_forward(t->view); }
        return TRUE;
    }
    if (!ctrl) return FALSE;
    switch (key) {
    case GDK_KEY_l: gtk_widget_grab_focus(w->entry); return TRUE;
    case GDK_KEY_t: tab_new(w, NULL, FALSE, NULL); return TRUE;
    case GDK_KEY_n: win_new(shift); return TRUE;   /* Ctrl+Shift+N: a private window */
    case GDK_KEY_w: if (shift) win_close(w); else if (t) tab_close(t); return TRUE;
    case GDK_KEY_r: if (shift) toggle_reader(t); else if (t && t->view) webkit_web_view_reload(t->view); return TRUE;
    case GDK_KEY_f: if (t) { show_panel(w, "find"); } return TRUE;
    case GDK_KEY_h: show_panel(w, "history"); return TRUE;
    case GDK_KEY_plus: case GDK_KEY_equal: case GDK_KEY_KP_Add: zoom(w, 0.1); return TRUE;
    case GDK_KEY_minus: case GDK_KEY_KP_Subtract: zoom(w, -0.1); return TRUE;
    case GDK_KEY_0: case GDK_KEY_KP_0: zoom(w, 0); return TRUE;
    default: return FALSE;
    }
}

static gboolean on_focus_in(GtkWidget *widget, GdkEvent *event, Win *w) {
    (void)widget; (void)event;
    app.wins = g_list_remove(app.wins, w);
    app.wins = g_list_prepend(app.wins, w);   /* most recently focused first */
    Tab *t = win_tab(w);
    if (t) fable_tabs_activate(app.tabs, t->id, now_ms());
    return FALSE;
}

static GtkWidget *icon_button(const char *icon, GCallback callback, Win *w) {
    GtkWidget *button = gtk_button_new_from_icon_name(icon, GTK_ICON_SIZE_BUTTON);
    gtk_button_set_relief(GTK_BUTTON(button), GTK_RELIEF_NONE);
    g_signal_connect(button, "clicked", callback, w);
    return button;
}

/* ---- windows ------------------------------------------------------------------- */

static void on_fable_scheme(WebKitURISchemeRequest *request, gpointer data);
static void on_init_web_extensions(WebKitWebContext *context, gpointer data);

static WebKitWebContext *make_context(gboolean ephemeral) {
    WebKitWebContext *ctx = ephemeral ? webkit_web_context_new_ephemeral() : g_object_ref(webkit_web_context_get_default());
    webkit_web_context_register_uri_scheme(ctx, "fable", on_fable_scheme, NULL, NULL);
    g_signal_connect(ctx, "initialize-web-extensions", G_CALLBACK(on_init_web_extensions), NULL);
    g_signal_connect(ctx, "download-started", G_CALLBACK(on_download_started), NULL);
    if (!ephemeral) webkit_web_context_set_favicon_database_directory(ctx, NULL);   /* private windows keep no icons */
    apply_cookie_policy(ctx);
    return ctx;
}

static gboolean on_delete(GtkWidget *window, GdkEvent *event, Win *w) {
    (void)window; (void)event;
    win_close(w);
    return TRUE;
}

static void win_close(Win *w) {
    if (!g_list_find(app.wins, w)) return;
    save_session();   /* before its tabs go: the snapshot keeps what was open */
    app.wins = g_list_remove(app.wins, w);
    if (app.popover && gtk_popover_get_relative_to(GTK_POPOVER(app.popover)) == w->menu) {
        gtk_widget_hide(app.popover);   /* at once: a closing animation would not finish in a closing window */
        gtk_popover_set_relative_to(GTK_POPOVER(app.popover), NULL);
        g_clear_pointer(&app.panel_view, g_free);
    }
    int count = gtk_notebook_get_n_pages(GTK_NOTEBOOK(w->notebook));
    for (int i = 0; i < count; i++) {
        Tab *t = tab_of_slot(gtk_notebook_get_nth_page(GTK_NOTEBOOK(w->notebook), i));
        if (t) { g_object_set_data(G_OBJECT(t->slot), "fable-tab", NULL); tab_free(t); }
    }
    if (w->toast_timer) g_source_remove(w->toast_timer);
    gtk_widget_destroy(w->window);
    gboolean private_left = FALSE;
    for (GList *l = app.wins; l; l = l->next) private_left |= ((Win *)l->data)->private;
    if (w->private && !private_left) g_clear_object(&app.private);   /* the last private window: its data goes too */
    g_free(w);
    if (!app.wins) gtk_main_quit();
}

static Win *win_new(gboolean private) {
    Win *w = g_new0(Win, 1);
    w->private = private;
    if (private && !app.private) app.private = make_context(TRUE);

    w->window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_default_size(GTK_WINDOW(w->window), 1280, 820);
    gtk_window_set_icon_name(GTK_WINDOW(w->window), "fable");
    if (private) gtk_style_context_add_class(gtk_widget_get_style_context(w->window), "fable-private");
    g_signal_connect(w->window, "delete-event", G_CALLBACK(on_delete), w);
    g_signal_connect(w->window, "key-press-event", G_CALLBACK(on_key), w);
    g_signal_connect(w->window, "focus-in-event", G_CALLBACK(on_focus_in), w);

    w->notebook = gtk_notebook_new();
    gtk_notebook_set_scrollable(GTK_NOTEBOOK(w->notebook), TRUE);
    gtk_notebook_set_show_border(GTK_NOTEBOOK(w->notebook), FALSE);
    g_signal_connect_after(w->notebook, "switch-page", G_CALLBACK(on_switch_page), w);   /* after: the new page is current by then */

    /* Left of the tabs: back, forward, (home), reload, address bar. */
    GtkWidget *left = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 2);
    w->back = icon_button("go-previous-symbolic", G_CALLBACK(on_back), w);
    w->forward = icon_button("go-next-symbolic", G_CALLBACK(on_forward), w);
    w->home = icon_button("go-home-symbolic", G_CALLBACK(on_home), w);
    w->reload = icon_button("view-refresh-symbolic", G_CALLBACK(on_reload), w);
    w->entry = gtk_entry_new();
    gtk_widget_set_size_request(w->entry, 420, -1);
    gtk_widget_set_margin_start(w->entry, 6);
    gtk_widget_set_margin_end(w->entry, 10);
    if (private && gtk_icon_theme_has_icon(gtk_icon_theme_get_default(), "view-conceal-symbolic"))
        gtk_entry_set_icon_from_icon_name(GTK_ENTRY(w->entry), GTK_ENTRY_ICON_PRIMARY, "view-conceal-symbolic");
    g_signal_connect(w->entry, "activate", G_CALLBACK(on_entry_activate), w);
    g_signal_connect(w->entry, "changed", G_CALLBACK(on_entry_changed), w);
    g_signal_connect(w->entry, "icon-press", G_CALLBACK(on_entry_icon_press), w);
    gtk_box_pack_start(GTK_BOX(left), w->back, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(left), w->forward, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(left), w->home, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(left), w->reload, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(left), w->entry, FALSE, FALSE, 0);
    gtk_widget_show_all(left);
    char *home_on = setting("home_button");
    gtk_widget_set_visible(w->home, strcmp(home_on, "1") == 0);
    g_free(home_on);
    gtk_notebook_set_action_widget(GTK_NOTEBOOK(w->notebook), left, GTK_PACK_START);

    /* Right of the tabs: new tab, then the menu (the panel). */
    GtkWidget *right = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 2);
    w->plus = icon_button("list-add-symbolic", G_CALLBACK(on_plus), w);
    w->menu = icon_button("open-menu-symbolic", G_CALLBACK(on_menu), w);
    gtk_box_pack_start(GTK_BOX(right), w->plus, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(right), w->menu, FALSE, FALSE, 0);
    gtk_widget_show_all(right);
    gtk_notebook_set_action_widget(GTK_NOTEBOOK(w->notebook), right, GTK_PACK_END);

    GtkWidget *overlay = gtk_overlay_new();
    gtk_container_add(GTK_CONTAINER(overlay), w->notebook);
    w->toast = gtk_label_new("");
    gtk_style_context_add_class(gtk_widget_get_style_context(w->toast), "fable-toast");
    gtk_widget_set_halign(w->toast, GTK_ALIGN_CENTER);
    gtk_widget_set_valign(w->toast, GTK_ALIGN_END);
    gtk_widget_set_margin_bottom(w->toast, 28);
    gtk_widget_set_no_show_all(w->toast, TRUE);
    gtk_overlay_add_overlay(GTK_OVERLAY(overlay), w->toast);
    gtk_overlay_set_overlay_pass_through(GTK_OVERLAY(overlay), w->toast, TRUE);
    gtk_container_add(GTK_CONTAINER(w->window), overlay);
    gtk_widget_show_all(w->window);

    app.wins = g_list_prepend(app.wins, w);
    relabel_win(w);
    tab_new(w, NULL, FALSE, NULL);
    gtk_window_present(GTK_WINDOW(w->window));
    return w;
}

/* ---- web context ------------------------------------------------------------- */

/* fable://newtab is served from the page embedded in the core; private
 * windows get the private variant (their data really is kept apart). */
static void on_fable_scheme(WebKitURISchemeRequest *request, gpointer data) {
    (void)data;
    const char *path = webkit_uri_scheme_request_get_path(request);
    const char *uri = webkit_uri_scheme_request_get_uri(request);
    if (!is_newtab(uri)) {
        GError *error = g_error_new_literal(G_IO_ERROR, G_IO_ERROR_NOT_FOUND, path ? path : "");
        webkit_uri_scheme_request_finish_error(request, error);
        g_error_free(error);
        return;
    }
    WebKitWebView *view = webkit_uri_scheme_request_get_web_view(request);
    gboolean private = view && webkit_web_view_get_context(view) == app.private && app.private;
    char *page = fable_newtab_page(private ? 1 : 0, NULL);
    /* The bridge nonce, ahead of the page's own scripts (see on_page_message). */
    const char *head = strstr(page, "<head>");
    size_t at = head ? (size_t)(head - page) + 6 : 0;
    char *html = g_strdup_printf("%.*s<script>window.fableNonce=\"%s\";</script>%s", (int)at, page, app.nonce, page + at);
    fable_string_free(page);
    gsize length = strlen(html);
    GInputStream *stream = g_memory_input_stream_new_from_data(html, (gssize)length, g_free);
    webkit_uri_scheme_request_finish(request, stream, (gint64)length, "text/html");
    g_object_unref(stream);
}

/* The blocker extension is looked up in $FABLE_WEBEXT_DIR, then next to the
 * executable (./webext), then in the install location. It starts with the
 * "block trackers" setting; later changes reach it as messages. */
static char *web_extensions_dir(void) {
    const char *configured = g_getenv("FABLE_WEBEXT_DIR");
    if (configured) return g_strdup(configured);
    char *exe = g_file_read_link("/proc/self/exe", NULL);
    if (exe) {
        char *exe_dir = g_path_get_dirname(exe);
        char *local = g_build_filename(exe_dir, "webext", NULL);
        g_free(exe_dir);
        g_free(exe);
        if (g_file_test(local, G_FILE_TEST_IS_DIR)) return local;
        g_free(local);
    }
    return g_strdup(FABLE_WEBEXT_DIR);
}

static void on_init_web_extensions(WebKitWebContext *context, gpointer data) {
    (void)data;
    char *dir = web_extensions_dir();
    webkit_web_context_set_web_extensions_directory(context, dir);
    char *blocking = blocking_state();
    char *domains = fable_ad_list_text();
    webkit_web_context_set_web_extensions_initialization_user_data(context, g_variant_new("(ss)", blocking, domains));
    fable_string_free(domains);
    g_free(blocking);
    g_free(dir);
}

static const char *COMMON_STYLE =
    ".fable-toast, .fable-toast label { background: rgba(42, 26, 20, .92); color: #FBEFE4; }"
    ".fable-toast { border-radius: 9px; padding: 7px 16px; }"
    "popover { padding: 0; }";

static GtkCssProvider *style_provider;

static void apply_style(void) {
    char *bar = fable_theme_colour("bar"), *sep = fable_theme_colour("sep"), *muted = fable_theme_colour("muted"),
         *card = fable_theme_colour("card"), *ink = fable_theme_colour("ink"), *line = fable_theme_colour("line"),
         *spark = fable_theme_colour("spark"), *icon = fable_theme_colour("icon"), *hint = fable_theme_colour("hint");
    GString *css = g_string_new(NULL);
    g_string_append_printf(css, "window, notebook > header { background: %s; }", bar);
    g_string_append_printf(css, "notebook > header { border-color: %s; padding: 4px 6px; }", sep);
    g_string_append_printf(css, "notebook > header > tabs > tab { padding: 2px 6px 2px 10px; margin: 0 2px; border-radius: 8px; color: %s; border: 1px solid transparent; }", muted);
    g_string_append_printf(css, "notebook > header > tabs > tab:checked { background: %s; color: %s; border-color: %s; box-shadow: inset 0 -2px %s; }", card, ink, line, spark);
    g_string_append_printf(css, "entry { min-height: 32px; border-radius: 10px; border: 1px solid %s; background: %s; color: %s; padding: 0 10px; caret-color: %s; }", line, card, ink, spark);
    g_string_append_printf(css, "entry image { color: %s; } entry text placeholder { color: %s; }", icon, hint);
    g_string_append_printf(css, "entry:focus { border-color: %s; box-shadow: none; outline: none; }", spark);
    g_string_append_printf(css, "button, image, label { color: %s; }", icon);
    char *priv_json = fable_theme_private_palette();
    const char *pkeys[] = {"bar", "sep", "muted", "card", "ink", "line", "spark", "icon", "hint"};
    char *pv[9] = {NULL};
    for (int i = 0; i < 9; i++) {
        char pat[32]; snprintf(pat, sizeof pat, "\"%s\":\"", pkeys[i]);
        const char *hit = strstr(priv_json, pat);
        if (hit) {
            hit += strlen(pat);
            const char *end = strchr(hit, '"');
            if (end) pv[i] = g_strndup(hit, (gsize)(end - hit));
        }
    }
    if (pv[0] && pv[1] && pv[2] && pv[3] && pv[4] && pv[5] && pv[6] && pv[7] && pv[8]) {
        g_string_append_printf(css, ".fable-private, .fable-private notebook > header { background: %s; }", pv[0]);
        g_string_append_printf(css, ".fable-private notebook > header { border-color: %s; }", pv[1]);
        g_string_append_printf(css, ".fable-private notebook > header > tabs > tab { color: %s; }", pv[2]);
        g_string_append_printf(css, ".fable-private notebook > header > tabs > tab:checked { background: %s; color: %s; border-color: %s; box-shadow: inset 0 -2px %s; }", pv[3], pv[4], pv[5], pv[6]);
        g_string_append_printf(css, ".fable-private entry { background: %s; color: %s; border-color: %s; }", pv[3], pv[4], pv[5]);
        g_string_append_printf(css, ".fable-private entry image { color: %s; } .fable-private entry text placeholder { color: %s; }", pv[7], pv[8]);
        g_string_append_printf(css, ".fable-private entry:focus { border-color: %s; }", pv[6]);
        g_string_append_printf(css, ".fable-private button, .fable-private image, .fable-private label { color: %s; }", pv[7]);
    }
    for (int i = 0; i < 9; i++) g_free(pv[i]);
    fable_string_free(priv_json);
    g_string_append(css, COMMON_STYLE);
    gtk_css_provider_load_from_data(style_provider, css->str, -1, NULL);
    g_string_free(css, TRUE);
    for (char *c[] = {bar, sep, muted, card, ink, line, spark, icon, hint}, **p = c; p < c + 9; p++) fable_string_free(*p);
}

static gboolean accept_license(void) {
    char *state = fable_panel_query("legalAccepted", "", 0);
    gboolean accepted = g_strcmp0(state, "true") == 0;
    fable_string_free(state);
    if (accepted) return TRUE;
    GtkWidget *dialog = gtk_dialog_new_with_buttons("EULA", NULL, GTK_DIALOG_MODAL,
        T("exit"), GTK_RESPONSE_CANCEL, T("eula_agree"), GTK_RESPONSE_ACCEPT, NULL);
    gtk_window_set_default_size(GTK_WINDOW(dialog), 640, 520);
    GtkWidget *scroll = gtk_scrolled_window_new(NULL, NULL);
    GtkWidget *view = gtk_text_view_new();
    gtk_text_view_set_editable(GTK_TEXT_VIEW(view), FALSE);
    gtk_text_view_set_wrap_mode(GTK_TEXT_VIEW(view), GTK_WRAP_WORD_CHAR);
    char *terms = fable_panel_query("legalText", "", 0);
    gtk_text_buffer_set_text(gtk_text_view_get_buffer(GTK_TEXT_VIEW(view)), terms, -1);
    fable_string_free(terms);
    gtk_container_add(GTK_CONTAINER(scroll), view);
    gtk_box_pack_start(GTK_BOX(gtk_dialog_get_content_area(GTK_DIALOG(dialog))), scroll, TRUE, TRUE, 8);
    gtk_widget_show_all(dialog);
    accepted = gtk_dialog_run(GTK_DIALOG(dialog)) == GTK_RESPONSE_ACCEPT;
    gtk_widget_destroy(dialog);
    if (accepted) fable_string_free(fable_panel_query("legalAccept", "", 0));
    return accepted;
}

int main(int argc, char **argv) {
    gtk_init(&argc, &argv);

    char *dir = g_build_filename(g_get_user_data_dir(), "fable", NULL);
    g_mkdir_with_parents(dir, 0700);
    char *ext_dir = web_extensions_dir();
    char *ads_file = g_build_filename(ext_dir, "ads.txt", NULL);
    fable_ad_list_file(dir, ads_file);
    g_free(ads_file);
    g_free(ext_dir);
    fable_store_open(dir);                                   /* settings and history */
    g_free(dir);
    fable_set_system_locale(g_get_language_names()[0]);      /* unless the "language" setting says otherwise */
    app.text = g_hash_table_new_full(g_str_hash, g_str_equal, g_free, g_free);
    if (!accept_license()) return 0;
    if (fable_ads_update_due()) ads_update_fetch();   /* a week since the last fetch, while ad blocking is on */
    app.nonce = g_uuid_string_random();
    app.tabs = fable_tabs_new();
    app.settings = webkit_settings_new();
    apply_page_settings();
    apply_sleep();
    app.normal = make_context(FALSE);
    app.soup = soup_session_new_with_options("timeout", 10, NULL);

    style_provider = gtk_css_provider_new();
    apply_style();
    gtk_style_context_add_provider_for_screen(gdk_screen_get_default(), GTK_STYLE_PROVIDER(style_provider), GTK_STYLE_PROVIDER_PRIORITY_APPLICATION);

    Win *w = win_new(g_getenv("FABLE_PRIVATE") != NULL);
    gboolean restored = !w->private && restore_session(w);   /* "restore tabs on start", unless switched off */
    if (argc > 1) {
        if (restored) tab_new(w, argv[1], FALSE, NULL);   /* a link handed over opens on top of them */
        else navigate(win_tab(w), argv[1]);
    }
    session_live = TRUE;
    if (!w->private) save_session();
    guint tick = SLEEP_CHECK_SECONDS;
    const char *sleep_after = g_getenv("FABLE_SLEEP_AFTER_SECONDS");   /* for trying it out: e.g. 5 */
    if (sleep_after && g_ascii_strtoull(sleep_after, NULL, 10) > 0 && g_ascii_strtoull(sleep_after, NULL, 10) < tick) tick = (guint)g_ascii_strtoull(sleep_after, NULL, 10);
    g_timeout_add_seconds(tick, on_sleep_tick, NULL);
    gtk_main();
    fable_tabs_free(app.tabs);
    return 0;
}
