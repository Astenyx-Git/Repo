# Fable Browser for Sailfish OS

Sailfish OS 外壳：Silica 界面 + Sailfish WebView（Gecko / embedlite），共用 Rust 核心（C ABI 静态库）。
0.18.22 由 Hy 移植，0.18.23 修到能用。**还没有在 Sailfish 设备或模拟器上运行过**，见文末"没验证的"。

## 结构

```
shell/sailfish/
├── harbour-fable.pro          qmake 工程（sailfishapp，C++11）
├── harbour-fable.desktop      Desktop Entry + X-Sailjail 权限
├── harbour-fable*.png         86/108/128/172 图标（由 iOS 的 1024 图标生成）
├── src/
│   ├── main.cpp               入口：注册 QML 单例 Fable、Panel
│   ├── fablecore.{h,cpp}      核心 C ABI → QObject（Fable）
│   └── panelbridge.{h,cpp}    面板与新标签页的消息、caps、会话、书签文件、UA（Panel）
├── qml/
│   ├── harbour-fable.qml      ApplicationWindow、引擎级设置、封面
│   ├── pages/BrowserPage.qml  地址栏、一个 WebView、工具栏、标签、面板的动作
│   ├── pages/PanelView.qml    面板自己的 WebView 与消息泵
│   └── cover/CoverPage.qml    封面：当前页标题，"新标签页""刷新"
├── rpm/harbour-fable.spec
└── 3rdparty/                  scripts/build-sailfish-core.sh 生成（不提交）
```

QML 里的 JavaScript 只能用 ES5：Sailfish OS 带的是 Qt 5.6。

## 面板和新标签页怎么跟外壳说话

面板（`ui/panel.html`）走 iOS 的消息协议：问题 `q\tid\tname\targ`，外壳用 `Fable.reply(id, text)` 回答；动作 `a\tname\targ`。
面板在自己的脚本开始时只选一次走哪条桥，所以 `Panel.panelHtml()` 把替身脚本放在 `<head>` 最前面，比面板的脚本先跑。

Sailfish 的 `runJavaScript` 是在页面里执行（那样受页面 CSP 约束），还是在特权沙箱里执行（那样页面自己设的变量可能被 Xray 隔开），文档没说。下面的做法两种情况都能用：

- 消息存在 `<html data-fable-queue>` 这个属性里（两边都看得到），QML 每 50 ms 用 `Panel.drainScript()` 读出并清空，交给 `Panel.handleMessage()`。
- 发给面板的脚本（`Fable.show`、`Fable.reply`……）由 `Panel.runScript()` 包成 `fable-run` 事件，由页面自己执行。
- 面板和新标签页的 CSP 加上 `'unsafe-eval'`；两页都不加载任何外部内容（`default-src 'none'` 不变）。

新标签页是核心的 `newtab.html`，用 `loadHtml` 放在 `https://fable.invalid/newtab`（`.invalid` 不会解析，网页不可能是这个地址）。它的搜索框调用 `FableHost.go(q)`，替身把 `go\tq` 放进同一个队列；外壳只在显示新标签页时读，显示网页时不读。

## 能力（`state.caps`）

| 能力 | Sailfish 上 |
|------|------|
| 地址栏、搜索引擎、快捷方式、新标签页 | 核心提供 |
| 皮肤（`theme://名字`，0.18.26 起） | 新标签页、面板、阅读模式的配色与标志跟着换，不提示；栏是 Silica 的，跟随系统氛围；Sailfish 没有让应用换自己桌面图标的接口 |
| 书签（收藏、列表、导入、导出） | 导入用系统文件选择器（`Sailfish.Pickers`），导出到"下载"文件夹，已有就存成 `bookmarks-2.html` |
| 历史、恢复标签页 | 核心提供；只保存普通标签里的网页 |
| 无痕 | `WebView.privateMode`，只能在创建 WebView 时设，切换时重建 |
| UA、桌面版网站 | `WebView.httpUserAgent`；改了就重建 WebView |
| 不加载图片、第三方 Cookie | `WebEngineSettings.autoLoadImages`、`cookieBehavior`（整个引擎） |
| 隐藏广告（页面内 CSS） | `adblockScript()`，页面加载完时注入 |
| 阅读模式、资源嗅探、元数据、公网 IP | `runJavaScript` / 核心 / `XMLHttpRequest` |
| 阻止跳转外部应用 | 只管地址栏和面板打开的地址；页面里的链接由 Gecko 自己处理 |
| 追踪器拦截、拦截计数 | ✗ `networkBlock:false`：Gecko WebView 没有逐请求的回调 |
| 清除 Cookie 和缓存 | ✗ `clearSiteData:false`：应用清不了；"清除数据"只有历史 |
| JavaScript 开关 | ✗ `javascript:false`：`WebEngineSettings.javascriptEnabled` 管整个引擎，关掉会连面板一起停 |
| 文字大小 | ✗ `textSize:false`：没有文字缩放接口 |
| 标签休眠 | ✗ `tabSleep:false`：只有一个 WebView，后台标签本来就不加载 |
| 页内查找、扫码、下载列表 | ✗ 不显示；面板里的"下载"交给系统浏览器 |

只有一个 WebView：切换标签会重新加载那个标签的地址，滚动位置和表单内容不保留。Gecko 只在还有私密 WebView 时保留私密会话，所以从无痕标签切回普通标签，无痕标签的 Cookie 和登录就没了。

## 编译

需要 Sailfish SDK（`sfdk`，armv7hl / aarch64 目标）和 Rust（版本见仓库根的 `rust-toolchain.toml`）。

```bash
./scripts/build-sailfish-core.sh aarch64      # 或 armv7hl
# 产物：shell/sailfish/3rdparty/aarch64/libfable_core.a、shell/sailfish/3rdparty/include/fable_core.h
cd shell/sailfish
sfdk build                                     # qmake + make + RPM
# 产物：RPMS/harbour-fable-0.18.27-1.<arch>.rpm
sfdk deploy --sdk                              # 或 pkcon install-local RPMS/...
```

静态库不需要链接，所以 Cargo 不需要交叉链接器；交叉 C 编译器只在 `--features asm` 时用到。`.pro` 按 `FABLE_CORE_TARGET` 选 `3rdparty/<target>/`，SPEC 里已传 `%{_arch}`。

发布前：SPEC 里的 `License` 现在是 `LicenseRef-Unspecified`，项目还没选许可证，要填上。

## Harbour

- 名称 `harbour-fable`，图标四种尺寸。
- Sailjail 权限 `Internet;WebView;UserDirs;Audio`，都在 Harbour 允许的清单里（https://docs.sailfishos.org/Develop/Apps/Harbour/Allowed_Permissions/）。`UserDirs` 用于书签文件，`Audio` 用于网页里的声音。
- QML 只用 Silica、Sailfish.WebView、Sailfish.WebEngine、Sailfish.Pickers。
- Rust 核心静态链接，只依赖 libc、libpthread、libdl、libm。

## 测试（不需要 SDK）

`tests/sailfish_test.sh`（`make test` 会跑；没有 Qt 5 时跳过，`FABLE_REQUIRE_SAILFISH=1` 时算失败）：

1. `src/` 按 C++11 用桌面版 Qt 5 编译，连真的核心；`tests/sailfish/bridge_test.cpp` 检查桥（消息解析、caps、UA、会话、书签文件、新标签页）。`main.cpp` 对着一个替身 `sailfishapp.h` 做编译检查。
2. 桥生成的面板页和新标签页在 headless Chrome 里打开（Chrome 和 Gecko 一样执行页面的 CSP），用 QML 实际执行的脚本驱动：`tests/sailfish/panel_test.js`、`home_test.js`。
3. `qml/` 用 Qt Quick Test 运行：Silica、WebView、WebEngineSettings、文件选择器换成替身（`tests/sailfish/qml/stubs`），核心是真的。`tests/sailfish/qml/tst_browser.qml` 覆盖启动、地址栏、面板状态与消息、无痕、UA、新标签页搜索、书签、清除历史、嗅探、恢复标签页、关标签、窗口设置与封面。
4. 检查 QML 里没有 ES5 以外的写法，`qmllint`。

核心在 x86-64 Linux 上交叉编译到 `armv7-unknown-linux-gnueabihf` 和 `aarch64-unknown-linux-gnu` 都通过。

## 没验证的

- 真正的 Silica 和 Sailfish WebView：界面画出来什么样，面板的 WebView 背景能不能透明（不能的话面板盖住页面，而不是浮在页面上），`runJavaScript` 实际在哪里执行。
- `loadHtml` 之后 `WebView.url` 报什么：报基地址或者别的非网页地址，新标签页都能认出来；用"后退"回到新标签页能不能正常显示，没把握。
- `sfdk build` 打 RPM、在设备上安装运行。
