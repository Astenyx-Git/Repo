#!/bin/sh
# Builds build/macos/Fable.app: a universal (Apple silicon + Intel) app for
# macOS 11 or later. Run on a Mac with:
#   - Xcode Command Line Tools   xcode-select --install
#   - Rust                       https://rustup.rs (the two Apple targets are added below)
# Optional: ZIG_NATIVE=1 links the Zig blocklist table (needs zig 0.14+).
# Result: build/macos/Fable.app, ad-hoc signed so it runs on this Mac; copy it
# to /Applications. Sharing it with other Macs needs a Developer ID signature
# and notarization (see README).
set -eu
cd "$(dirname "$0")/.."
ROOT=$PWD
OUT=build/macos
APP=$OUT/Fable.app
MIN=11.0
VERSION=$(sed -n 's/^version = "\(.*\)"/\1/p' core/Cargo.toml | head -n 1)

[ "$(uname -s)" = Darwin ] || { echo "build-macos.sh runs on macOS (it needs the macOS SDK)." >&2; exit 1; }
command -v cargo >/dev/null || { echo "Rust is missing: https://rustup.rs" >&2; exit 1; }
xcrun --show-sdk-path >/dev/null || { echo "The macOS SDK is missing: xcode-select --install" >&2; exit 1; }
export MACOSX_DEPLOYMENT_TARGET=$MIN
rustup target add aarch64-apple-darwin x86_64-apple-darwin >/dev/null 2>&1 || true

# 1. The Rust core for each architecture, with the matching assembly hash
#    (or, with ZIG_NATIVE=1, the Zig layer: assembly hash + compiled table).
LIBS=""
for pair in arm64:aarch64-apple-darwin:aarch64-macos x86_64:x86_64-apple-darwin:x86_64-macos; do
    ARCH=${pair%%:*}; rest=${pair#*:}; TRIPLE=${rest%%:*}; ZTARGET=${rest#*:}
    if [ "${ZIG_NATIVE:-0}" = 1 ]; then
        zig build -Dtarget="$ZTARGET" --prefix "$OUT/zig-$ARCH"
        (cd core && FABLE_NATIVE_LIB_DIR="$ROOT/$OUT/zig-$ARCH/lib" cargo build --release --features zig-native --target "$TRIPLE")
    else
        (cd core && FABLE_CC="cc -arch $ARCH -mmacosx-version-min=$MIN" FABLE_AR=ar cargo build --release --features asm --target "$TRIPLE")
    fi
    LIBS="$LIBS core/target/$TRIPLE/release/libfable_core.a"
done
mkdir -p "$OUT"
lipo -create $LIBS -output "$OUT/libfable_core.a"

# 2. The shell, both architectures in one binary.
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cc -fobjc-arc -O2 -Wall -Wextra -Wno-unused-parameter -Wunguarded-availability-new \
   -arch arm64 -arch x86_64 -mmacosx-version-min=$MIN \
   -Icore/include shell/macos/main.m "$OUT/libfable_core.a" \
   -framework Cocoa -framework WebKit -framework Metal -framework IOKit -framework CoreGraphics -Wl,-dead_strip \
   -o "$APP/Contents/MacOS/Fable"

# 3. The bundle.
sed "s/@VERSION@/$VERSION/g" shell/macos/Info.plist > "$APP/Contents/Info.plist"
plutil -lint "$APP/Contents/Info.plist" >/dev/null
cp shell/macos/Fable.icns "$APP/Contents/Resources/Fable.icns"
printf 'APPL????' > "$APP/Contents/PkgInfo"
codesign --force --deep --sign - "$APP"   # ad hoc: runs here; not for distribution

lipo -info "$APP/Contents/MacOS/Fable"
echo "App: $APP ($VERSION) — open it with: open $APP"
