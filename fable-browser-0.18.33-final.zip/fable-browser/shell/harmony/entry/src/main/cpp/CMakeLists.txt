# libfable.so: the Node-API bridge (fable_napi.c) linked with the Rust core.
# scripts/build-harmony.sh builds the core for each ABI into lib/<abi>/ first.
cmake_minimum_required(VERSION 3.5.0)
project(fable C)

set(FABLE_ROOT "${CMAKE_CURRENT_SOURCE_DIR}/../../../../../.." CACHE PATH "Repository root")
set(FABLE_CORE_LIB "${CMAKE_CURRENT_SOURCE_DIR}/lib/${OHOS_ARCH}/libfable_core.a")
if(NOT EXISTS "${FABLE_CORE_LIB}")
  message(FATAL_ERROR "No Rust core for ${OHOS_ARCH} at ${FABLE_CORE_LIB}: run scripts/build-harmony.sh")
endif()

add_library(fable SHARED fable_napi.c)
target_include_directories(fable PRIVATE "${FABLE_ROOT}/core/include")
target_compile_options(fable PRIVATE -Wall -Wextra -O2)
# --gc-sections drops the parts of the core this shell never calls.
target_link_options(fable PRIVATE -Wl,--gc-sections -Wl,--exclude-libs,ALL)
target_link_libraries(fable PRIVATE "${FABLE_CORE_LIB}" libace_napi.z.so libdeviceinfo_ndk.z.so libohbattery_info.so)
