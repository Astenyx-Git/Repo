import QtQuick 2.0
Item {
    property int allowedOrientations: 0
    property bool backNavigation: true
    property bool showNavigationIndicator: true
}
