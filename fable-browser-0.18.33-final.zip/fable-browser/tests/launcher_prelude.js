// The home screen's requests to the Android shell (fetch of home/... and app icons), recorded instead of sent.
window.__home = [];
window.fetch = function (url) { window.__home.push(String(url)); return Promise.resolve(new Response(null, { status: 204 })); };
