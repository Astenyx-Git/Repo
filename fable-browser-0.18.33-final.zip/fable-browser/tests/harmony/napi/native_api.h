/* Compile-only stand-in for HarmonyOS's napi/native_api.h (Node-API signatures). */
#pragma once
#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
typedef struct napi_env__ *napi_env;
typedef struct napi_value__ *napi_value;
typedef struct napi_callback_info__ *napi_callback_info;
typedef enum { napi_ok } napi_status;
typedef enum { napi_undefined, napi_null, napi_boolean, napi_number, napi_string, napi_symbol, napi_object, napi_function, napi_external, napi_bigint } napi_valuetype;
typedef enum { napi_int8_array, napi_uint8_array, napi_uint8_clamped_array } napi_typedarray_type;
typedef enum { napi_default = 0 } napi_property_attributes;
typedef napi_value (*napi_callback)(napi_env env, napi_callback_info info);
typedef void (*napi_finalize)(napi_env env, void *data, void *hint);
typedef struct { const char *utf8name; napi_value name; napi_callback method; napi_callback getter; napi_callback setter; napi_value value; napi_property_attributes attributes; void *data; } napi_property_descriptor;
typedef napi_value (*napi_addon_register_func)(napi_env env, napi_value exports);
typedef struct { int nm_version; unsigned int nm_flags; const char *nm_filename; napi_addon_register_func nm_register_func; const char *nm_modname; void *nm_priv; void *reserved[4]; } napi_module;
napi_status napi_create_array_with_length(napi_env, size_t, napi_value *);
napi_status napi_create_arraybuffer(napi_env, size_t, void **, napi_value *);
napi_status napi_create_double(napi_env, double, napi_value *);
napi_status napi_create_string_utf8(napi_env, const char *, size_t, napi_value *);
napi_status napi_define_properties(napi_env, napi_value, size_t, const napi_property_descriptor *);
napi_status napi_get_arraybuffer_info(napi_env, napi_value, void **, size_t *);
napi_status napi_get_boolean(napi_env, bool, napi_value *);
napi_status napi_get_cb_info(napi_env, napi_callback_info, size_t *, napi_value *, napi_value *, void **);
napi_status napi_get_null(napi_env, napi_value *);
napi_status napi_get_typedarray_info(napi_env, napi_value, napi_typedarray_type *, size_t *, void **, napi_value *, size_t *);
napi_status napi_get_undefined(napi_env, napi_value *);
napi_status napi_get_value_double(napi_env, napi_value, double *);
napi_status napi_get_value_string_utf8(napi_env, napi_value, char *, size_t, size_t *);
napi_status napi_set_element(napi_env, napi_value, uint32_t, napi_value);
napi_status napi_typeof(napi_env, napi_value, napi_valuetype *);
void napi_module_register(napi_module *);
#define NAPI_AUTO_LENGTH ((size_t)-1)
